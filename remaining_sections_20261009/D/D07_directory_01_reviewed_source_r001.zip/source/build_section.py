"""Batch D source authoring. Blender4.3.2; metres. Authored local (u,height,v) maps to world XYZ then Blender(X,-Z,Y). Native/export omit floors and QA context. No registry IDs created."""
import bpy,math,json,hashlib,importlib.util,sys
from pathlib import Path
from mathutils import Vector,Matrix
P=Path(__file__).resolve().parents[1]; C=P/'dependencies/Catalogue';CONFIG=json.loads((P/'docs/design.json').read_text());SIDE=CONFIG['side'];Z=CONFIG['z'];KEY=CONFIG['key']; A=[];LIGHTS=[];M={};seq=0

def world(p):u,y,v=p;return (SIDE*(CONFIG['xbase']+u),CONFIG['floor_y']+y,Z+v)
def xyz(p):x,y,z=world(p);return Vector((x,-z,y))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def uv(o):
 if o.type!='MESH':return
 me=o.data;me.update();layer=me.uv_layers.get('UV0') or me.uv_layers.new(name='UV0')
 for f in me.polygons:
  drop=max(range(3),key=lambda a:abs(f.normal[a]));ax=[a for a in range(3) if a!=drop]
  for li in f.loop_indices:
   v=me.vertices[me.loops[li].vertex_index].co;tile=o.data.materials[0].get('meters_per_tile_uv',1.0) if o.data.materials else 1.0;layer.data[li].uv=(v[ax[0]]/tile,v[ax[1]]/tile)

def finish(o,n,mat='ivory_enamel',support='root_floor_proposal',zone='architecture',bev=.03):
 o.name=KEY+'__'+n
 if o.type=='MESH':
  bpy.context.view_layer.objects.active=o
  if bev:
   b=o.modifiers.new('Edge craft','BEVEL');b.width=bev;b.segments=2;bpy.ops.object.modifier_apply(modifier=b.name)
  o.data.materials.clear();o.data.materials.append(M[mat]);uv(o)
  bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.normals_make_consistent(inside=False);bpy.ops.object.mode_set(mode='OBJECT')
 o['section']=KEY;o['support']=support if support.startswith(('root_',KEY)) else KEY+'__'+support;o['zone']=zone;A.append(o);return o

def box(n,p,d,mat='ivory_enamel',sup='root_floor_proposal',zone='architecture',bev=.03):
 bpy.ops.mesh.primitive_cube_add(size=1,location=xyz(p));o=bpy.context.object;o.dimensions=(d[0],d[2],d[1]);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,n,mat,sup,zone,min(bev,min(d)*.3))

def rod(n,a,b,r=.06,mat='champagne_metal',sup='root_floor_proposal',zone='architecture',verts=12):
 va,vb=xyz(a),xyz(b);delta=vb-va;bpy.ops.mesh.primitive_cylinder_add(vertices=verts,radius=r,depth=delta.length,location=(va+vb)/2);o=bpy.context.object;o.rotation_euler=delta.to_track_quat('Z','Y').to_euler();bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,n,mat,sup,zone,.008)

def prism(n,poly,y,h,mat='warm_walnut',sup='root_floor_proposal',zone='architecture'):
 vs=[xyz((u,y,v)) for u,v in poly]+[xyz((u,y+h,v)) for u,v in poly];k=len(poly);faces=[tuple(range(k-1,-1,-1)),tuple(range(k,2*k))]+[(i,(i+1)%k,(i+1)%k+k,i+k) for i in range(k)];me=bpy.data.meshes.new(n);me.from_pydata(vs,[],faces);me.update();o=bpy.data.objects.new(n,me);bpy.context.collection.objects.link(o);return finish(o,n,mat,sup,zone,.025)

def cyl(n,p,r,h,mat='champagne_metal',sup='root_floor_proposal',zone='programme'):
 return rod(n,p,(p[0],p[1]+h,p[2]),r,mat,sup,zone,32)

def wall(n,a,b,h=4.9,w=.36,mat='ivory_enamel',y=0,sup='root_floor_proposal',zone='architecture'):
 u,v=a;du,dv=b[0]-u,b[1]-v;l=math.hypot(du,dv);o=box(n,((u+b[0])/2,y+h/2,(v+b[1])/2),(l,w,h) if False else (l,h,w),mat,sup,zone,.045)
 # Long box local BlenderX must align actual converted wall vector.
 vec=xyz((b[0],y,b[1]))-xyz((a[0],y,a[1]));o.rotation_euler[2]=math.atan2(vec.y,vec.x);return o

def sign(n,body,u,v,y=1.7,sup='root_floor_proposal'):
 back=box(n+'_plate',(u,y,v),(.10,.50,2.0),'warm_walnut',sup,zone='wayfinding');cu=bpy.data.curves.new(n,'FONT');cu.body=body;cu.align_x='CENTER';cu.align_y='CENTER';cu.size=.16;cu.extrude=.001;o=bpy.data.objects.new(n,cu);bpy.context.collection.objects.link(o);o.location=xyz((u-.06,y,v));o.rotation_euler=(math.pi/2,0, math.pi/2 if SIDE<0 else -math.pi/2);o.data.materials.append(M['ivory_enamel']);finish(o,n+'_text',support=back.name,zone='wayfinding',bev=0)

def asset(n,file,u,v,y=0,yaw=None,sup=None):
 with bpy.data.libraries.load(str(C/file),link=False) as (data,to):to.objects=data.objects
 os=[o for o in to.objects if o and o.type=='MESH']
 for ob in os:bpy.context.collection.objects.link(ob)
 bpy.context.view_layer.update()
 original_world={o:o.matrix_world.copy() for o in os}
 for ob in os:ob.parent=None
 rot=Matrix.Rotation((SIDE*math.pi/2 if yaw is None else yaw),4,'Z');trans=Matrix.Translation(xyz((u,y,v)))
 for o in os:
  o.hide_render=False;o.hide_viewport=False;o.hide_select=False;o.hide_set(False);o.parent=None;o.matrix_world=trans@rot@original_world[o];o.name=KEY+'__'+n+'__'+o.name;o['section']=KEY;o['zone']='catalogue_'+n;o['support']='catalogue_contact_graph';o['shelf_support']=sup or '';A.append(o)
  for im in bpy.data.images:
   if im.source=='FILE' and not im.packed_file:
    try:im.pack()
    except:pass
 return os

def seat(n,u,v,length=5,face=1,cloth='teal_weave',zone='rest'):
 b=box(n+'_plinth',(u,.17,v),(1.3,.34,length),'warm_walnut',zone=zone,bev=.08)
 box(n+'_pad',(u,.45,v),(1.4,.22,length-.15),cloth,b.name,zone,.075)
 back=box(n+'_back',(u-.56*face,.86,v),(.24,1.10,length),cloth,b.name,zone,.08)
 for k in [-1,1]:box(n+'_arm'+str(k),(u,.52,v+k*(length/2-.12)),(1.42,.40,.24),'warm_walnut',b.name,zone,.06)
 return b.name

def arcseat(n,u,v,r,start,end,cloth='oatmeal_weave'):
 # Faceted continuous fitted seating with radial depth; generous gap in arrival sector.
 count=max(3,int(abs(end-start)/18));poly=[]
 for j in range(count+1):a=math.radians(start+(end-start)*j/count);poly.append((u+(r+.55)*math.cos(a),v+(r+.55)*math.sin(a)))
 for j in range(count,-1,-1):a=math.radians(start+(end-start)*j/count);poly.append((u+(r-.55)*math.cos(a),v+(r-.55)*math.sin(a)))
 b=prism(n+'_base',poly,0,.33,'warm_walnut',zone='gathering');prism(n+'_cushion',poly,.33,.20,cloth,b.name,'gathering')
 for j in range(count):
  a0=math.radians(start+(end-start)*j/count);a1=math.radians(start+(end-start)*(j+1)/count)
  pa=(u+(r+.54)*math.cos(a0),v+(r+.54)*math.sin(a0));pb=(u+(r+.54)*math.cos(a1),v+(r+.54)*math.sin(a1));wall(n+'_back'+str(j),pa,pb,.78,.20,cloth,.33,b.name,'gathering')

def table(n,u,v,r=.85):
 f=cyl(n+'_foot',(u,0,v),r*.60,.08,'dark_rubber');p=cyl(n+'_stem',(u,.08,v),.11,.61,'champagne_metal',f.name);t=cyl(n+'_top',(u,.69,v),r,.10,'warm_walnut',p.name)
 cyl(n+'_cup',(u+.20,.79,v),.09,.13,'ivory_enamel',t.name);box(n+'_folio',(u-.20,.815,v-.10),(.34,.05,.45),'clay_weave',t.name,'rest',.008);return t.name

def fixture(n,u,v,y=4.4,power=900):
 # Floor-supported blade pendant: roof frame and visible diffuser.
 post=box(n+'_post',(u,y/2,v),(.16,y,.16),'champagne_metal',zone='light_support')
 box(n+'_arm',(u+.5,y-.12,v),(1.14,.16,.18),'warm_walnut',post.name,'fixture')
 box(n+'_shade',(u+.86,y-.24,v),(.60,.32,.90),'ivory_enamel',n+'_arm','fixture',.09)
 box(n+'_lens',(u+.86,y-.42,v),(.48,.04,.74),'oatmeal_weave',n+'_shade','fixture',.01)
 LIGHTS.append((n,(u+.86,y-.47,v),power,.65,.85))

def books(n,u,v,length=5):
 b=box(n+'_back',(u,1.5,v),(.18,3,length),'warm_walnut',zone='collection')
 for h in [.20,.91,1.62,2.33,2.95]:
  shelf=box(n+'_shelf'+str(h),(u-.44,h,v),(1.0,.08,length),'warm_walnut',b.name,'collection')
  if h<2.9:
   # One detailed existing stock group anchors each shelf; fitted bound volumes fill the remaining bays economically.
   q=v-length/2+.45
   asset(n+'_books'+str(h)+'_catalogue','assets/library_contents/AST-LIB-006_upright_book_group.blend',u-.40,q,h+.04,yaw=SIDE*math.pi/2,sup=shelf.name)
   for j in range(1,int(length/.48)):
    q=v-length/2+.45+j*.48
    for k in range(2):
     ht=.32+.07*((j+k)%3);z=q+k*.13;name=n+'_volume'+str(h)+'_'+str(j)+'_'+str(k)
     pages=box(name+'_pages',(u-.43,h+.04+ht/2,z),(.36,ht,.11),'ivory_enamel',shelf.name,'collection',.009)
     box(name+'_spine',(u-.61,h+.04+(ht+.02)/2,z),(.045,ht+.02,.14),'teal_weave' if (j+k)%2 else 'clay_weave',shelf.name,'collection',.008)
 return b.name

def cupboard(n,u,v):
 b=box(n+'_body',(u,1.1,v),(1.20,2.2,4.0),'warm_walnut',zone='service')
 for q in [-1,1]:box(n+'_door'+str(q),(u-.62,1.20,v+q*.98),(.08,1.85,1.84),'ivory_enamel',b.name,'service')
 for q in [-1,1]:box(n+'_handle'+str(q),(u-.70,1.30,v+q*.35),(.09,.30,.09),'champagne_metal',n+'_door'+str(q),'service')
 sign(n,'CARE / STOCK',u-.67,v,2.02,n+'_door-1')


_original_box=box
def box(*args,**kwargs):
 o=_original_box(*args,**kwargs);o['source_primitive']='closed_box_shared_vertices';return o

def uv(o):
 if o.type!='MESH':return
 me=o.data;me.update();layer=me.uv_layers.get('UV0') or me.uv_layers.new(name='UV0')
 scale=o.data.materials[0].get('meters_per_tile_uv',[1,1]) if o.data.materials else [1,1]
 if isinstance(scale,(float,int)):scale=[scale,scale]
 for f in me.polygons:
  drop=max(range(3),key=lambda a:abs(f.normal[a]));ax=[a for a in range(3) if a!=drop]
  for li in f.loop_indices:
   v=me.vertices[me.loops[li].vertex_index].co;layer.data[li].uv=(v[ax[0]]/scale[0],v[ax[1]]/scale[1])

def staff_materials():
 manifest=json.loads((C/'materials/staff/manifest.json').read_text())
 for role,r in manifest['materials'].items():
  ma=bpy.data.materials.new('ASTRAEA_'+role);ma.use_nodes=True;ma['meters_per_tile_uv']=r['meters_per_tile_uv'];ma['astraea_material_role']=role
  ma.diffuse_color=tuple(x/255 for x in r['colour_srgb_8bit'])+(1,)
  nd=ma.node_tree.nodes;nd.clear();bs=nd.new('ShaderNodeBsdfPrincipled');bs.inputs['Roughness'].default_value=r['roughness'];bs.inputs['Metallic'].default_value=r['metallic'];tx=nd.new('ShaderNodeTexImage');tx.image=bpy.data.images.load(str(C/'materials/staff'/r['file']),check_existing=True);tx.image.pack();tx.extension='REPEAT';out=nd.new('ShaderNodeOutputMaterial');ma.node_tree.links.new(tx.outputs['Color'],bs.inputs['Base Color']);ma.node_tree.links.new(bs.outputs['BSDF'],out.inputs['Surface']);M[role]=ma

def perimeter(height=5.5,mat='ivory_enamel'):
 poly=CONFIG['footprint']
 for i,(a,b) in enumerate(zip(poly,poly[1:]+poly[:1])):
  if a[0]==b[0]==.45:
   wall('mouth_fore',a,(.45,4.0 if a[1]>0 else -4.0),3.4,.32,mat);wall('mouth_aft',(.45,4.0 if b[1]>0 else -4.0),b,3.4,.32,mat)
  else:wall('outer_return_'+str(i),a,b,height,.30,mat)
 # Deep threshold, keeping eight metres open through the central mouth.
 for v in [-4.2,4.2]:
  p=box('entry_pier_'+str(v),(2,1.65,v),(3.3,3.3,.35),'warm_walnut' if mat=='ivory_enamel' else mat)
  rod('threshold_high_'+str(v),(2,3.3,v),(8,4.5,v),.16,'champagne_metal',p.name)
 sign('identity',CONFIG['title'].upper(),2,-4.42,1.7,'entry_pier_-4.2')

def stock(n,u,v):
 return asset(n,'assets/staff_workbay/AST-STF-007_supply_work_cabinet.blend',u,v,0,yaw=-math.pi/2)

def lockers(n,u,v,count=5,face=-1):
 for i in range(count):
  q=v+(i-(count-1)/2)*.95;b=box(n+'_case_'+str(i),(u,1.1,q),(1.1,2.2,.9),'warm_walnut',zone='personal_storage')
  box(n+'_leaf_'+str(i),(u+.59*face,1.18,q),(.08,1.95,.84),'clay_weave',b.name,'personal_storage')
  box(n+'_pull_'+str(i),(u+.66*face,1.17,q+.28),(.08,.24,.05),'champagne_metal',n+'_leaf_'+str(i),'personal_storage',.01)

def bench(n,u,v,length=6,mat='warm_walnut',along_v=True):
 for i in [-1,1]:
  p=(u,0,v+i*(length/2-.5)) if along_v else (u+i*(length/2-.5),0,v)
  box(n+'_support_'+str(i),(p[0],.20,p[2]),(.65,.40,.60),mat,zone='bench')
 d=(1.0,.15,length) if along_v else (length,.15,1.0)
 return box(n+'_seat',(u,.475,v),d,mat,n+'_support_-1','bench',.07)

def worktable(n,u,v,l=6,width=2.3,mat='warm_walnut'):
 legs=[]
 for a in [-1,1]:
  for b in [-1,1]:legs.append(box(n+'_leg_'+str(a)+'_'+str(b),(u+a*(width/2-.25),.43,v+b*(l/2-.35)),(.26,.86,.26),'staff_zinc' if mat.startswith('staff') else 'champagne_metal',zone='work_support'))
 return box(n+'_top',(u,.91,v),(width,.12,l),mat,legs[0].name,'work_surface',.035)

def roofblade(n,a,b,h0,h1,mat='warm_walnut',radius=.18):
 post=box(n+'_post',(a[0],h0/2,a[1]),(.42,h0,.42),mat,zone='roof_support')
 return rod(n+'_beam',(a[0],h0,a[1]),(b[0],h1,b[1]),radius,mat,post.name,'roof_frame')

def paintline(n,a,b,width=.10,mat='ivory_enamel'):
 return wall(n,a,b,.008,width,mat,0,'root_floor_proposal','paint_marker')

def circlemark(n,u,v,r,start=0,end=360,mat='ivory_enamel'):
 count=max(8,int(abs(end-start)/10))
 for i in range(count):
  a=math.radians(start+(end-start)*i/count);b=math.radians(start+(end-start)*(i+1)/count)
  paintline(n+str(i),(u+r*math.cos(a),v+r*math.sin(a)),(u+r*math.cos(b),v+r*math.sin(b)),.09,mat)

def lowbay(n,poly,height=3.0):
 walls=[]
 for i,(a,b) in enumerate(zip(poly,poly[1:])):walls.append(wall(n+'_wall'+str(i),a,b,height,.28,'warm_walnut'))
 # Connected low roof strip sits on the actual fitted walls, leaving the entry open.
 for i,(a,b) in enumerate(zip(poly,poly[1:])):
  rod(n+'_crown'+str(i),(a[0],height,a[1]),(b[0],height,b[1]),.24,'ivory_enamel',walls[i].name,'shelter')

def propcase(n,u,v,w=2,h=1.4,l=2):
 b=box(n+'_body',(u,h/2,v),(w,h,l),'staff_bluegrey_paint',zone='ordinary_prop_storage')
 for q in [-1,1]:box(n+'_rail'+str(q),(u+q*(w/2-.06),h/2,v),(.10,h,l),'staff_zinc',b.name,'ordinary_prop_storage',.015)
 box(n+'_lid',(u,h+.04,v),(w+.05,.08,l+.05),'staff_zinc',b.name,'ordinary_prop_storage',.02)
 return b

def cue(n,u,v):
 return asset(n,'assets/auditorium_use/source/AST-CUL-004.blend',u,v,0,yaw=math.pi)

def construct():
 perimeter(6.1)
 # High barrel ribs are entirely below the protected pool underside.
 for j,v in enumerate([-28,-14,14,28]):
  left=roofblade('court_rib_'+str(j),(14,v),(26,v),5.8,7.3)
  right=roofblade('court_rib_return_'+str(j),(43,v),(26,v),5.8,7.3)
 # Play dimensions are proposed source geometry: a 30x18m marked field and broad clear apron.
 for i,(a,b) in enumerate([((17,-15),(35,-15)),((35,-15),(35,15)),((35,15),(17,15)),((17,15),(17,-15)),((17,0),(35,0))]):paintline('court_boundary_'+str(i),a,b,.12)
 circlemark('court_center_',26,0,2.5)
 for s in [-1,1]:
  for i,(a,b) in enumerate([((22,s*15),(22,s*10)),((22,s*10),(30,s*10)),((30,s*10),(30,s*15))]):paintline('end_zone_'+str(s)+'_'+str(i),a,b)
  circlemark('throw_arc_'+str(s)+'_',26,s*10,2.0,0 if s<0 else 180,180 if s<0 else 360)
  vb=s*18.5;base=box('target_base_'+str(s),(26,.18,vb),(2.2,.36,1.4),'dark_rubber',zone='target_support')
  post=box('target_post_'+str(s),(26,2.0,vb),(.30,3.64,.30),'champagne_metal',base.name,'target_support')
  arm=rod('target_arm_'+str(s),(26,3.8,vb),(26,3.8,s*16.1),.12,'champagne_metal',post.name,'target_support')
  board=box('target_board_'+str(s),(26,3.50,s*16.1),(1.9,1.3,.12),'ivory_enamel',arm.name,'target')
  bracket=rod('ring_bracket_'+str(s),(26,3.1,s*16.04),(26,3.1,s*15.45),.05,'champagne_metal',board.name,'target')
  for i in range(16):
   a=s*math.pi/2+i*math.tau/16;b=s*math.pi/2+(i+1)*math.tau/16;rod('ring_'+str(s)+'_'+str(i),(26+.25*math.cos(a),3.1,s*15.45+.25*math.sin(a)),(26+.25*math.cos(b),3.1,s*15.45+.25*math.sin(b)),.023,'clay_weave',bracket.name if i==0 else 'ring_'+str(s)+'_'+str(i-1),'target',8)
 # Screened changing entry folds away from the court and arrival sightline.
 lowbay('changing',[(3,-19),(3,-30),(10,-30),(10,-24)])
 lockers('personal_stow',4.8,-26,5,face=1);bench('change_bench',4.8,-21,3)
 wall('change_screen',(3,-19),(9,-19),2.6,.25,'clay_weave')
 stock('court_care',5,25);prop=propcase('equipment_case',7,29,3,1.4,2)
 for i in range(3):
  bpy.ops.mesh.primitive_uv_sphere_add(segments=16,ring_count=8,radius=.23,location=xyz((6.1+i*.65,1.71,29)));finish(bpy.context.object,'ball_stow_'+str(i),'clay_weave','equipment_case_lid','equipment',0)
 # Fitted curve follows the spectator edge, retaining a generous approach at u37.
 for v in [-10,10]:
  seat('watch_bank_'+str(v),41,v,8,1,'teal_weave','spectator');wall('watch_return_'+str(v),(43.7,v-5),(43.7,v+5),2.3,.35,'warm_walnut')
 bench('team_pause',7,12,6)
 for i,(u,v) in enumerate([(12,-29),(12,29),(43,-22),(43,22),(5,-17),(5,17)]):fixture('court_fixture_'+str(i),u,v,4.9,2700)
def native_export():
 bpy.context.view_layer.update()
 # All bitmap resources embedded in actual editable source.
 for im in bpy.data.images:
  if im.source=='FILE' and not im.packed_file:im.pack()
 bpy.context.scene['deterministic_source_sha256']=sha(__file__)
 bpy.ops.wm.save_as_mainfile(filepath=str(P/'source/section.blend'))
 # Export evaluated production copies into a clean scene: no inherited collection selection/visibility state.
 dg=bpy.context.evaluated_depsgraph_get();prepared=[]
 for i,o in enumerate(A):
  name=o.name;eo=o.evaluated_get(dg);me=bpy.data.meshes.new_from_object(eo,preserve_all_data_layers=True,depsgraph=dg);prepared.append((name,me,o.matrix_world.copy(),dict(o.items())))
 for i,o in enumerate(A):o.name='NATIVE_HOLD_'+str(i)
 ex=bpy.data.scenes.new('Production exchange only');bpy.context.window.scene=ex
 for name,me,matrix,extra in prepared:
  clone=bpy.data.objects.new(name,me);ex.collection.objects.link(clone);clone.matrix_world=matrix
  for k,v in extra.items():clone[k]=v
  if not me.uv_layers:uv(clone)
 bpy.ops.export_scene.gltf(filepath=str(P/'exports'/(KEY+'.glb')),export_format='GLB',use_selection=False,use_active_scene=True,export_yup=True,export_extras=True,export_apply=True,export_texcoords=True,export_materials='EXPORT')
 (P/'qa/fixtures.json').write_text(json.dumps(LIGHTS,indent=2))


def preview():
 # Reload actual exported GLB for all reviewed pixels; retain native independently.
 bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(P/'exports'/(KEY+'.glb')))
 # QA floor from the separate proposal; never saved/exported with section.
 poly=CONFIG['footprint'];me=bpy.data.meshes.new('QA_FLOOR');me.from_pydata([xyz((u,0,v)) for u,v in poly],[],[tuple(range(len(poly)))]);me.update();o=bpy.data.objects.new('QA_ONLY_FLOOR_PROPOSAL',me);bpy.context.collection.objects.link(o);o.data.materials.append(next((m for m in bpy.data.materials if 'warm_stone' in m.name),next(iter(bpy.data.materials))));uv(o)
 for n,p,power,w,l in LIGHTS:
  da=bpy.data.lights.new(n,'AREA');da.energy=power;da.color=tuple(CONFIG.get('light_color',[1,.82,.60]));da.shape='RECTANGLE';da.size=w;da.size_y=l;ob=bpy.data.objects.new(n,da);bpy.context.collection.objects.link(ob);ob.location=xyz(p)
 sc=bpy.context.scene;sc.render.engine='CYCLES';sc.cycles.samples=8;sc.cycles.use_denoising=True;sc.render.threads_mode='FIXED';sc.render.threads=2;sc.render.resolution_x=960;sc.render.resolution_y=540;sc.render.resolution_percentage=100
 sc.world=bpy.data.worlds.new('Dim QA neutral');sc.world.use_nodes=True;sc.world.node_tree.nodes['Background'].inputs['Color'].default_value=(.18,.20,.23,1);sc.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.17;sc.view_settings.view_transform='AgX';sc.view_settings.exposure=.8
 camd=bpy.data.cameras.new('Eye165');cam=bpy.data.objects.new('Eye165',camd);bpy.context.collection.objects.link(cam);sc.camera=cam;camd.lens=18;camd.clip_start=.05;camd.clip_end=120
 rows=[]
 for n,p,t in CONFIG['views']:
  cam.location=xyz(p);cam.rotation_euler=(xyz(t)-cam.location).to_track_quat('-Z','Y').to_euler();sc.render.filepath=str(P/'qa/views'/(n+'.png'));bpy.ops.render.render(write_still=True);rows.append({'name':n,'eye_world':world(p),'eye_above_proposed_floor':p[1],'target_world':world(t),'file':'qa/views/'+n+'.png','sha256':sha(sc.render.filepath)})
 (P/'qa/view_receipt.json').write_text(json.dumps({'deterministic_source_sha256':sha(__file__),'scope':'Actual exported GLB reimport; source preview floor and fixture preview illumination; no Godot/CRT acceptance','native_sha256':sha(P/'source/section.blend'),'glb_sha256':sha(P/'exports'/(KEY+'.glb')),'views':rows},indent=2))


if __name__=='__main__':
 bpy.ops.wm.read_factory_settings(use_empty=True);s=importlib.util.spec_from_file_location('materials',C/'standards/materials.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);M=m.materials();staff_materials();construct();native_export();preview();print('SECTION_BUILD_COMPLETE',KEY,len(A))
