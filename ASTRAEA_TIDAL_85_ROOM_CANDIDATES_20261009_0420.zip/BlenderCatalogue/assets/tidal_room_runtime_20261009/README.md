# Retained Tidal room runtime candidates

Eight existing full editable room assemblies are batched for runtime reuse across their 85 original source placements, preserving 221 proposed rest-slot anchors. The native originals remain unchanged in the retained Tidal source package. This is reuse and runtime preparation, not 85 newly designed rooms or default-scene adoption.

Static door components are excluded from the derived GLBs because the existing shared guest-entry and bathroom-door controllers supply those exact source fittings. Door positions and yaw remain the retained source bindings. No new interaction state machine was introduced. Geometry coordinates and source UVs are retained; only static mesh grouping changes.

The candidates have passed exact rest-anchor and open-pose entry support/capsule checks in the actual default ship with the retained Tidal architecture. Direct door-pose setup is not an ordinary-input interaction test. The full room, cart/species, privacy, occupied capacity, lighting, target performance and final visual quality remain unaccepted. Listening Salon receiving support and default-ship graphical review remain open.

The 81 original landscape/seating placements use six exact registered source exports and the production botanical collision policy. They are not new source designs or proof of a finished neighbourhood.
