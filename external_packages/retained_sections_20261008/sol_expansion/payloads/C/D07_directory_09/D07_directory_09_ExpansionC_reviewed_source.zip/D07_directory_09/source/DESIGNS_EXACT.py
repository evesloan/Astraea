"""Construction-first compositions. One exclusive programme per invocation."""
def construct(G,N):
 box,rod,disc,asset,sign,lamp,bed= [G[x] for x in ['box','rod','disc','asset','sign','lamp','bed']]
 math,bpy,xyz,finish= [G[x] for x in ['math','bpy','xyz','finish']]
 points,carts,lights=G['POINTS'],G['CART_POINTS'],G['LIGHTS']
 counts={};walk=[]
 def wall(n,u,v,w,l,h=3.6,mat='staff'):
  return box(n,(u,h/2,v),(w,h,l),mat)
 def edge(n,a,b,h=3.6,mat='staff',thick=.22):
  pa,pb=xyz((a[0],h/2,a[1])),xyz((b[0],h/2,b[1]));d=pb-pa
  bpy.ops.mesh.primitive_cube_add(size=1,location=(pa+pb)/2);o=bpy.context.object;o.dimensions=(thick,d.length,h);o.rotation_euler.z=math.atan2(-d.x,d.y);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,n,mat)
 def bench(n,u,v,yaw=0):
  g=asset('AST-FUR-001',n,u,v,yaw=yaw);points.append((n,(u-2.8,v)));carts.append((n+'_cart',(u-3.8,v)));return g
 def canopy(n,u,v,w,l,h=3.6,mat='staff'):
  supports=[]
  for q,(x,z) in enumerate([(u-w/2,v-l/2),(u+w/2,v-l/2),(u-w/2,v+l/2),(u+w/2,v+l/2)]):
   supports.append(wall(n+'_pier'+str(q),x,z,.32,.32,h,mat))
  return box(n+'_header',(u,h+.1,v),(w+.35,.2,l+.35),mat,supports[0].name)
 def workbench(n,u,v,w=6,l=1.8,mat='staff'):
  b=box(n+'_base',(u,.47,v),(w,.94,l),mat);t=box(n+'_top',(u,1.02,v),(w+.15,.15,l+.15),'ivory',b.name)
  for q in (-1,1):
   s=box(n+'_instrument'+str(q),(u+q*w*.28,1.29,v),(.65,.4,.5),'staff',t.name);box(n+'_instrument_face'+str(q),(u+q*w*.28,1.32,v-.26),(.48,.22,.035),'opal',s.name)
  return t
 def service(n,u,v):
  workbench(n,u,v,5,1.7);asset('AST-MED-002',n+'_wash',u,v+4);asset('AST-MED-004',n+'_trolley',u+4,v+4)
  points.append((n+'_approach',(u+2.5,v+4)));carts.append((n+'_cart',(u+2.5,v+4)))
 def header_entry():
  # No external leaf or shared portal; the root's 4x4m keep-clear remains empty.
  for q,v in enumerate((29.5,38.5)):
   p=wall('threshold_pier'+str(q),4,v,.8,1.1,3.2,'stone')
   rod('threshold_branch'+str(q),(4,3.1,v),(8,3.65,v+(-1 if q==0 else 1)),.16,'wood',p.name)
  p=wall('wayfinding_post',3,27.5,.3,.3,2.25,'staff');sign('section_name',G['TITLE'].upper(),2.89,27.5,1.9,p.name)
 def ramp(n,u0,u1,v0,v1,h,along_v=False):
  lo=.012
  verts=[xyz((u0,0,v0)),xyz((u1,0,v0)),xyz((u1,0,v1)),xyz((u0,0,v1))]
  heights=[lo,lo,h,h] if along_v else [lo,h,h,lo]
  verts += [xyz((u,y,v)) for (u,v),y in zip([(u0,v0),(u1,v0),(u1,v1),(u0,v1)],heights)]
  faces=[(3,2,1,0),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]
  me=bpy.data.meshes.new(n);me.from_pydata(verts,[],faces);me.update()
  if G['SIDE']==1:
   for f in me.polygons:f.flip()
  o=bpy.data.objects.new(n,me);bpy.context.collection.objects.link(o);finish(o,n,'stone',bevel=0);walk.append(o.name)
 header_entry()
 # Shared practical stocked cupboard is a compatible kit, not the room's form.
 G['care'](5,8)
 if N==0:
  # Three interlocking research wings around an open clean analysis spine.
  for j,v in enumerate((15,34,53)):
   wall('research_back'+str(j),41,v,.28,13,3.9)
   edge('research_return'+str(j),(41,v-6.5),(31,v-8),3.9)
   edge('research_short_return'+str(j),(41,v+6.5),(36,v+7.5),3.9)
   canopy('research_service_bridge'+str(j),35.5,v+5.8,9.5,1.5,4.2)
   workbench('analysis_island'+str(j),31,v,8,2.2)
   workbench('instrument_edge'+str(j),38,v-3.5,4,1.6)
   asset('AST-MED-002','clean_wash'+str(j),38,v+3.5)
   lamp('research_task'+str(j),26,v+4,3.1)
   points.append(('analysis_work'+str(j),(31,v+2.5)));carts.append(('analysis_cart'+str(j),(31,v+2.8)))
  wall('controlled_prep_back',15,57,12,.28,3.4);service('prep_and_return',16,60)
  wall('archive_screen',13,20,.28,13,3.5);workbench('records_and_readout',10,20,5,1.6)
  routes=[[(1,34),(23,34),(23,10),(23,61),(29,61)],[(23,10),(8.3,10),(8.3,8)],[(23,17.8),(31,17.8)],[(23,36.8),(31,36.8)],[(23,55.8),(31,55.8)]]
  views=[('arrival',(1,34),(32,34)),('research',(23,37),(37,34)),('clean_prep',(23,60),(16,60)),('service',(10,8),(5,8))]
  purpose='Three interlocking instrument/research wings face a continuous clean analysis spine. Shaped opaque returns protect work edges; overhead supported service bridges and a separate preparation/return corner define staffed research. Six workbench fixtures are proposed construction furniture, not six registered laboratories or treatment capacity.'
  counts={'registered_destinations_preserved':1,'research_wings':3,'workbench_fixtures':8,'clinical_occupancy':None}
 elif N==1:
  # Sheltered recovery pockets along two offset, quiet-facing edges.
  for j,v in enumerate((15,31,50)):
   for k,u in enumerate((23,39)):
    wall('recovery_back'+str(j)+'_'+str(k),u+3.6,v,.25,9,3.2,'stone')
    edge('recovery_screen'+str(j)+'_'+str(k),(u+3.6,v-4.5),(u-1,v-5.5),2.8,'wood')
    asset('AST-MED-003','neutral_rest'+str(j)+'_'+str(k),u,v)
    bench('accompanying_seat'+str(j)+'_'+str(k),u,v+3.5,math.pi/2)
    lamp('recovery_light'+str(j)+'_'+str(k),u+2.5,v+3.5,2.6)
   canopy('quiet_soffit'+str(j),40,v,6,8,3.6,'wood')
  service('assisted_care',11,58)
  routes=[[(1,34),(15,34),(15,10),(15,59),(30,59),(30,10)],[(15,10),(8.3,10),(8.3,8)]]
  views=[('arrival',(1,34),(28,34)),('recovery',(29.5,31),(39,31)),('quiet_bay',(34,50),(39,50)),('service',(18,58),(11,58))]
  purpose='Offset recovery pockets provide adaptable neutral support surfaces and nearby accompanying seats. Opaque angled returns interrupt busy sightlines; low supported soffits shelter the quiet edge. An assisted-care work zone sits apart from resting pockets. No overnight berth or treatment suitability is registered.'
  counts={'registered_destinations_preserved':1,'neutral_support_proposals':6,'clinical_occupancy':None}
 elif N==2:
  # Sealed samples form a central experimental procession, clear perimeter service.
  for j,(u,v,radius) in enumerate([(25,18,3.2),(32,34,4),(25,51,3.2)]):
   b=disc('sample_cell_base'+str(j),u,v,radius,0,.65,'staff')
   for q in range(8):
    a=q*math.tau/8;rod('sample_cell_mullion'+str(j)+'_'+str(q),(u+radius*math.cos(a),.6,v+radius*math.sin(a)),(u+radius*math.cos(a),3.8,v+radius*math.sin(a)),.07,'staff',b.name)
   disc('sealed_sample_shell'+str(j),u,v,radius-.15,.65,2.9,'glass',b.name)
   disc('sample_cap'+str(j),u,v,radius,.0+3.55,.25,'staff','C_sample_cell_mullion'+str(j)+'_0')
   for q in (-1,1):
    p=wall('manifold_post'+str(j)+'_'+str(q),u+q*(radius+1),v,.3,.3,4.3)
    rod('manifold_branch'+str(j)+'_'+str(q),(u+q*(radius+1),4.2,v),(u,4.6,v),.16,'staff',p.name)
  wall('control_back',41,33,.25,35,3.2);workbench('atmosphere_readout',38,28,3,7)
  service('calibration_and_filters',11,58)
  routes=[[(1,34),(17,34),(17,10),(17,59),(39,59),(39,42)],[(17,10),(8.3,10),(8.3,8)]]
  views=[('arrival',(1,34),(32,34)),('sample_cells',(18,27),(32,34)),('controls',(35,23),(38,28)),('service',(19,58),(11,58))]
  purpose='Three sealed static sample columns and supported manifolds organize an atmosphere research procession. A protected control edge and distinct calibration/filter corner preserve operational separation. Transparent shells are internal research vessels, with no hull opening, gas simulation or life-support certification.'
  counts={'registered_destinations_preserved':1,'static_sample_columns':3,'clinical_occupancy':None}
 elif N==3:
  # Staggered consultation chambers; entrances face a branching staffed commons.
  for j,v in enumerate((14,33,52)):
   for k,u in enumerate((22,39)):
    wall('pod_rear'+str(j)+'_'+str(k),u+4,v,.24,12,3.25)
    wall('pod_north'+str(j)+'_'+str(k),u,v-6,8,.24,3.25)
    wall('pod_south'+str(j)+'_'+str(k),u,v+6,8,.24,3.25)
    for t,z in enumerate((v-4.25,v+4.25)):wall('pod_entry_return'+str(j)+'_'+str(k)+'_'+str(t),u-4,z,.24,3.5,3.25)
    roof=box('pod_roof'+str(j)+'_'+str(k),(u,3.35,v),(8.2,.2,12.2),'staff','C_pod_rear'+str(j)+'_'+str(k))
    asset('AST-DIN-001','consultation_table'+str(j)+'_'+str(k),u,v)
    for t,z in enumerate((v-1.6,v+1.6)):asset('AST-DIN-002','consultation_chair'+str(j)+'_'+str(k)+'_'+str(t),u,z,yaw=math.pi if t else 0)
    asset('AST-MED-003','adaptable_consult_support'+str(j)+'_'+str(k),u+2,v+3)
    lamp('consultation_task'+str(j)+'_'+str(k),u+2.7,v-3.8,2.8)
  service('consultation_records',10,60)
  routes=[[(1,34),(14,34),(14,9),(14,62),(29,62),(29,9)],[(14,10),(8.3,10),(8.3,8)]]
  views=[('arrival',(1,34),(23,33)),('consultation',(18.8,33),(23,33)),('branching_common',(29,33),(35,33)),('service',(18,60),(10,60))]
  purpose='Six proposed opaque consultation chambers form staggered paired banks around a branching level common route. Deep open source thresholds, supported roofs and adaptable support furnishing preserve privacy and staffed care. No moving door, treatment gameplay, species certification or clinical occupancy is claimed.'
  counts={'registered_destinations_preserved':1,'proposed_consultation_chambers':6,'clinical_occupancy':None}
 elif N==4:
  # Quiet care: nested inward-facing rest bays shielded from service spine.
  for j,(u,v) in enumerate([(24,14),(38,25),(24,37),(38,49),(24,59)]):
   wall('care_bay_rear'+str(j),u+4,v,.25,10,3.5,'stone')
   edge('care_bay_fore'+str(j),(u+4,v-5),(u-2,v-6),3.3,'wood')
   edge('care_bay_aft'+str(j),(u+4,v+5),(u,v+6),3.3,'wood')
   asset('AST-MED-003','quiet_support'+str(j),u,v)
   asset('AST-FUR-001','quiet_companion'+str(j),u,v+3.4,yaw=math.pi/2)
   lamp('quiet_care_light'+str(j),u+2.7,v-3,2.7)
  wall('observation_return',12,55,.25,15,3.2);service('quiet_staff_support',7,57)
  routes=[[(1,34),(16,34),(16,10),(16,66.8),(31,66.8),(31,10)],[(16,10),(8.3,10),(8.3,8)]]
  views=[('arrival',(1,34),(24,37)),('quiet_care',(18.5,37),(25,37)),('screened_rest',(32,49),(39,49)),('service',(10.5,55),(7,57))]
  purpose='Five inward-facing rest bays are nested behind staggered opaque acoustic/privacy returns. A level shared path and separate practical staff edge support quiet assisted care without adding guest berths, a medical procedure or assumptions about alien treatment.'
  counts={'registered_destinations_preserved':1,'neutral_rest_proposals':5,'clinical_occupancy':None}
 elif N==5:
  # Local programme terraces, independent of the root's common receiving slab.
  for j,(v,h,run) in enumerate([(18,.45,5.4),(50,.9,10.8)]):
   platform=box('activity_terrace'+str(j),(36.5,h/2,v),(15,h,18),'stone');walk.append(platform.name)
   ramp('activity_ramp'+str(j),29-run,29,v-2,v+2,h)
   asset('AST-FUR-001','terrace_rest'+str(j),41,v+5,y=h,yaw=math.pi/2,sup=platform.name)
   points.append(('terrace_rest'+str(j),(39,v+5,h)));carts.append(('terrace_rest_cart'+str(j),(38,v+5,h)))
   for q in (-1,1):
    post=box('terrace_edge_pier'+str(j)+'_'+str(q),(43,h+.55,v+q*8.2),(.3,1.1,.3),'wood',platform.name)
    rod('terrace_edge_rail'+str(j),(43,h+1.05,v),(43,h+1.05,v+q*8.2),.07,'wood',post.name)
   routes_extra=[[(29-run-.9,v,0),(29-run,v,0),(29,v,h),(35,v,h),(38,v+5,h)]]
   if j==0:terrace_routes=routes_extra
   else:terrace_routes+=routes_extra
  wall('activity_focus_back',39,34,.3,8,4.5,'wood');workbench('activity_review',35,34,5,2,'wood')
  for j,v in enumerate((11,29,40,60)):lamp('activity_marker'+str(j),16,v,3.2)
  service('activity_store',10,60)
  routes=[[(1,34),(14,34),(14,10),(14,62),(21,62)],[(14,10),(8.3,10),(8.3,8)]]+terrace_routes
  views=[('arrival',(1,34),(35,34)),('terrace',(22,18),(39,18,.45)),('upper_activity',(34,50,.9),(41,55,.9)),('service',(18,58),(10,60))]
  purpose='Two productive activity platforms at0.45m and0.9m are reached by separate broad1:12 source ramps. A level branching arrival remains clear and a fitted review edge anchors the centre. Resting edges face the activity clearings. Platforms are dedicated programme construction, not a common receiving floor; no activity gameplay or capacity is asserted.'
  counts={'registered_destinations_preserved':1,'local_programme_terraces':2,'registered_occupancy':None}
 elif N==6:
  # Quiet viewing steps face an internal source display, no fabricated real opening.
  for j,(u,h) in enumerate([(30.5,.45),(39.5,.9)]):
   platform=box('viewing_step'+str(j),(u,h/2,40),(9,h,36),'stone');walk.append(platform.name)
   ramp('viewing_ramp'+str(j),u-2,u+2,22-12*h,22,h,along_v=True)
   for k,v in enumerate((29,40,51)):
    asset('AST-FUR-001','viewing_seat'+str(j)+'_'+str(k),u+1.5,v,y=h,yaw=math.pi/2,sup=platform.name)
    points.append(('viewing_stance'+str(j)+'_'+str(k),(u-1,v,h)));carts.append(('viewing_cart'+str(j)+'_'+str(k),(u-1.5,v,h)))
   routes_extra=[[(u,22-12*h-.9,0),(u,22-12*h,0),(u,22,h),(u-1,25,h),(u-1,54,h)]]
   if j==0:viewing_routes=routes_extra
   else:viewing_routes+=routes_extra
  back=wall('internal_view_focus',15,40,.5,24,5.1,'staff');box('static_view_panel',(15.3,2.6,40),(.08,3.6,21),'opal',back.name)
  for j,v in enumerate((27,53)):lamp('viewing_rest_light'+str(j),21,v,3)
  service('viewing_control',10,60)
  routes=[[(1,34),(9,34),(9,15),(23,15),(23,62)],[(9,15),(8.3,15),(8.3,8)]]+viewing_routes
  views=[('arrival',(1,34),(34,40,.45)),('viewing',(29.5,40,.45),(15,40)),('upper_step',(38.5,40,.9),(15,40)),('service',(19,60),(10,60))]
  purpose='Two stepped viewing bands preserve level adjacent access and each has an independent broad1:12 ramp. Fitted seating faces a supported internal static display wall. Cross-spine sports adjacency remains a root connection proposal; no real court view, hull opening, crowd capacity or screen gameplay is claimed.'
  counts={'registered_destinations_preserved':1,'viewing_levels':2,'source_seating_fixtures':6,'registered_occupancy':None}
 elif N==7:
  # Branching training commons with two distinct demonstration courts and review edge.
  for j,(u,v,w,l) in enumerate([(30,18,15,15),(33,48,19,18)]):
   edge('demonstration_rear'+str(j),(u+w/2,v-l/2),(u+w/2,v+l/2),4.8,'wood')
   edge('demonstration_return'+str(j),(u+w/2,v-l/2),(u-w/2+2,v-l/2-3),4.8,'wood')
   for k in (-1,1):
    foot=disc('training_station_base'+str(j)+'_'+str(k),u+k*4,v,1,0,.25,'staff')
    post=rod('training_station_post'+str(j)+'_'+str(k),(u+k*4,.25,v),(u+k*4,2.8,v),.14,'staff',foot.name)
    rod('training_station_grip'+str(j)+'_'+str(k),(u+k*4-1,2.65,v),(u+k*4+1,2.65,v),.09,'wood',post.name)
   lamp('training_court_light'+str(j),u-6,v+5,3.2)
   points.append(('demonstration_access'+str(j),(u,v)));carts.append(('demonstration_cart'+str(j),(u,v)))
  wall('review_edge',40,34,.28,7,3.5,'wood');workbench('training_review',36,34,6,1.8,'wood');bench('training_rest',16,48,math.pi/2)
  service('training_equipment',10,60)
  routes=[[(1,34),(20,34),(20,12),(20,62),(30,62)],[(20,10),(8.3,10),(8.3,8)],[(20,18),(30,18)],[(20,48),(33,48)]]
  views=[('arrival',(1,34),(36,34)),('training',(23,18),(32,18)),('second_court',(24,48),(37,48)),('service',(18,60),(10,60))]
  purpose='A branching level commons reaches two unequal demonstration clearings with grounded training frames, fitted review bench and nearby rest edge. Deep angled backdrops separate working sightlines from through movement. Static equipment proxies imply no invented exercise mechanics, species suitability or capacity.'
  counts={'registered_destinations_preserved':1,'demonstration_clearings':2,'static_training_frames':4,'registered_occupancy':None}
 elif N==8:
  # Enclosed simulator suites of different proportions, deep supported entrance bays.
  for j,(u,v,w,l) in enumerate([(30,17,23,17),(33,48,18,24)]):
   rear=wall('simulation_rear'+str(j),u+w/2,v,.3,l,5.6)
   wall('simulation_fore'+str(j),u,v-l/2,w,.3,5.6)
   wall('simulation_aft'+str(j),u,v+l/2,w,.3,5.6)
   for k,z in enumerate((v-l/2+2.5,v+l/2-2.5)):wall('suite_threshold_return'+str(j)+'_'+str(k),u-w/2,z,.3,5,5.6)
   box('suite_roof'+str(j),(u,5.7,v),(w+.3,.2,l+.3),'staff',rear.name)
   box('static_immersive_panel'+str(j),(u+w/2-.18,3,v),(.06,3.6,l-3),'opal',rear.name)
   workbench('simulation_controls'+str(j),u,v+3,6,1.8)
   points.append(('simulation_control_approach'+str(j),(u,v+5)));carts.append(('simulation_control_cart'+str(j),(u,v+5)))
   for k,x in enumerate((u-3,u+3)):asset('AST-DIN-002','simulator_seat'+str(j)+'_'+str(k),x,v)
   lamp('suite_task'+str(j),u-5,v+5.5,3.1)
  workbench('suite_dispatch',12,42,4,1.7);service('simulation_technical',10,60)
  routes=[[(1,34),(14,34),(14,11),(14,62)],[(14,10),(8.3,10),(8.3,8)],[(14,17),(24,17),(24,22),(30,22)],[(14,48),(27,48),(27,53),(33,53)]]
  views=[('arrival',(1,34),(27,26)),('simulation',(22,17),(38,17)),('second_suite',(26,48),(39,48)),('service',(18,60),(10,60))]
  purpose='Two independently enclosed immersive source suites use unequal chamber proportions and deep open thresholds off a staffed dispatch spine. Tall supported roofs and static internal panels define spatial immersion. No simulation software, moving portal, projected capacity or hull opening is asserted.'
  counts={'registered_destinations_preserved':1,'proposed_enclosed_suites':2,'registered_occupancy':None}
 elif N==9:
  # Tall but single-deck practice volume, grounded frames around a protected arena.
  disc('practice_arena_edge',31,34,11.5,0,.14,'wood')
  walk.append('C_practice_arena_edge');ramp('practice_threshold_ramp',17.82,19.5,32,36,.14)
  for j,a in enumerate((-.9,.9,2.2,4.1)):
   u=31+12*math.cos(a);v=34+12*math.sin(a)
   base=disc('gravity_frame_foot'+str(j),u,v,.8,0,.3,'staff')
   post=rod('gravity_frame_stem'+str(j),(u,.3,v),(u-1,6.3,v),.22,'staff',base.name)
   rod('gravity_frame_cantilever'+str(j),(u-1,6.3,v),(u-4,7.1,v),.18,'staff',post.name)
   for k,h in enumerate((1,1.8,2.6,3.4,4.2)):rod('gravity_grip'+str(j)+'_'+str(k),(u-(h-.3)/6-.65,h,v-.7),(u-(h-.3)/6+.65,h,v+.7),.08,'wood',post.name)
  wall('gravity_control_back',39,57,.28,13,4.3);workbench('gravity_observation',35,57,6,2);bench('gravity_rest',18,53,math.pi/2)
  service('practice_support',10,61)
  for j,v in enumerate((19,49)):lamp('arena_perimeter_light'+str(j),16,v,3.4)
  routes=[[(1,34),(16,34),(16,12),(16,63)],[(16,10),(8.3,10),(8.3,8)],[(16,34,0),(17.82,34,0),(19.5,34,.14),(31,34,.14),(35,34,.14)],[(16,57),(31,57)]]
  views=[('arrival',(1,34),(31,34)),('practice',(25,34,.14),(40,34,.14)),('frame_rhythm',(31,27,.14),(41,41)),('service',(18,61),(10,61))]
  purpose='A single-deck tall practice clearing is circled by grounded inclined frames and layered grips, with a separate observation/control edge and practical support store. Its maximum service top stays below43.45m. Static construction proposes no altered gravity, multi-deck void, climbing certification or gameplay.'
  counts={'registered_destinations_preserved':1,'static_grounded_frames':4,'registered_occupancy':None}
 else:
  raise RuntimeError('Index outside the exclusive ten-section batch.')
 return dict(routes=routes,views=views,purpose=purpose,counts=counts,walkable_groups=walk)
