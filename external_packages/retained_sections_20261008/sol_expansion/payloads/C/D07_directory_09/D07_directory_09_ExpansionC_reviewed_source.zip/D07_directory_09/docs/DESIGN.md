# Activity terrace

Two productive activity platforms at0.45m and0.9m are reached by separate broad1:12 source ramps. A level branching arrival remains clear and a fitted review edge anchors the centre. Resting edges face the activity clearings. Platforms are dedicated programme construction, not a common receiving floor; no activity gameplay or capacity is asserted.

No gameplay, capacity, live collision, species-wide traversal, performance or installed Godot acceptance is implied. No shared registry entry, hull opening, exterior view, working door or receiving floor was changed. Small signs are editable; no controls are rebound. RMB-focus/E vocabulary is retained.
