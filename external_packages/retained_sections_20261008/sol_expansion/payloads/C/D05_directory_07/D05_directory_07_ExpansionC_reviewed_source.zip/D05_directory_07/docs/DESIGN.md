# Consultation pods

Six proposed opaque consultation chambers form staggered paired banks around a branching level common route. Deep open source thresholds, supported roofs and adaptable support furnishing preserve privacy and staffed care. No moving door, treatment gameplay, species certification or clinical occupancy is claimed.

No gameplay, capacity, live collision, species-wide traversal, performance or installed Godot acceptance is implied. No shared registry entry, hull opening, exterior view, working door or receiving floor was changed. Small signs are editable; no controls are rebound. RMB-focus/E vocabulary is retained.
