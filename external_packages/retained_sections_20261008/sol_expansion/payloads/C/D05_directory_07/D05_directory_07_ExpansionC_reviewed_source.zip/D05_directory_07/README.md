# Consultation pods - D05_directory_07

Reviewed isolated construction base, not installed ship acceptance. Editable native: source/section.blend. Actual embedded-resource GLB: exports/section.glb. World placement is identity [0,0,0], floor datum 21m and source cap 26.45m. No shared/common/preview receiving floor, hull opening or runtime controller is included. Local activity terraces, where explicitly authored, are source programme geometry and are identified separately.

Rebuild from the archive root with installed Blender4.3.2 through `python heavy.py build.py 3`. Builder includes independently reloaded native/export checks and four 1.65m ordinary-eye source views. `heavy.py` holds Local\Astraea_SolBatch_20261008_HeavyBuild, limits Blender CPU to4 and releases the named mutex in finally. Its installed executable locator is workspace-specific; update only that locator on another machine.

Root owns receiving slab, shared doors and external connections, structural adoption, enclosure/finish passes, lighting budget and actual Godot import/traversal/cart/species/CRT/performance acceptance. Sparse furnishing is intentional at the construction-first milestone. Source count proposals are distinct from unknown registered occupancy. No new capacity is claimed and no existing count or datum changed.

The self-contained archive includes exact build/design/QA source snapshots, all pinned inputs and their byte/SHA256 manifest, source/reference application notes, placement and floor proposals, source support/contact and body/cart clearance tests, actual GLB UV/normal value checks and four reviewed eye views tied to final native/export hashes. Preview slab and documented inspection fills are only in the unsaved QA render context. Failed evidence is retained when present.

Earlier Windows packages, Communications trials and Batch C five-section source/Library outputs were preserved. No live registry, engine, controller, Game, original Catalogue, backup publisher or credentials were edited. This archive is staged locally; root coordinates future private Library transfer.
