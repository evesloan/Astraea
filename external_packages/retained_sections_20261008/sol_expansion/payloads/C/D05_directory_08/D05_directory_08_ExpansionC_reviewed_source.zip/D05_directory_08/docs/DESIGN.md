# Quiet care

Five inward-facing rest bays are nested behind staggered opaque acoustic/privacy returns. A level shared path and separate practical staff edge support quiet assisted care without adding guest berths, a medical procedure or assumptions about alien treatment.

No gameplay, capacity, live collision, species-wide traversal, performance or installed Godot acceptance is implied. No shared registry entry, hull opening, exterior view, working door or receiving floor was changed. Small signs are editable; no controls are rebound. RMB-focus/E vocabulary is retained.
