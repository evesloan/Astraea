# Atmosphere research

Three sealed static sample columns and supported manifolds organize an atmosphere research procession. A protected control edge and distinct calibration/filter corner preserve operational separation. Transparent shells are internal research vessels, with no hull opening, gas simulation or life-support certification.

No gameplay, capacity, live collision, species-wide traversal, performance or installed Godot acceptance is implied. No shared registry entry, hull opening, exterior view, working door or receiving floor was changed. Small signs are editable; no controls are rebound. RMB-focus/E vocabulary is retained.
