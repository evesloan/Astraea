D03_directory_02 / Custodian breakroom

source/native.blend is editable Blender4.3.2 source. exports/section.glb is the actual tested exchange. placements.json records exact placement. Rebuild with python B/heavy_job.py 06_custodian_breakroom full, using bundled sources/dependencies/inputs and installed Blender. Shared Windows heavy mutex and4 CPU threads required. Root owns receiving floor, external connection, doors, structural adoption and installed acceptance. No new registry records or operation/capacity claim.
