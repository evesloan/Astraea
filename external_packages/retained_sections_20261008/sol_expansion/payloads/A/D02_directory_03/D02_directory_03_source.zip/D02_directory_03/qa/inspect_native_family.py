import bpy,bmesh,sys
from pathlib import Path
p=Path(sys.argv[sys.argv.index('--')+1]);bpy.ops.wm.open_mainfile(filepath=str(p));dg=bpy.context.evaluated_depsgraph_get()
for o in bpy.context.scene.objects:
 if o.type!='MESH':continue
 me=bpy.data.meshes.new_from_object(o.evaluated_get(dg),preserve_all_data_layers=True,depsgraph=dg)
 bm=bmesh.new();bm.from_mesh(me);bad=[e for e in bm.edges if not e.is_manifold];tiny=[f for f in bm.faces if f.calc_area()<1e-10]
 if bad or tiny:print(o.name,dict(o.items()),'nonmanifold',len(bad),'boundary',sum(e.is_boundary for e in bad),'tiny',len(tiny),[(tuple(e.verts[0].co),len(e.link_faces)) for e in bad[:8]])
 bm.free()
