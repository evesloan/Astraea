D01_directory_09 Shuttle concourse
Isolated construction source; world origin identity. No exported/common/preview floor. Root receiving slabs, support, interfaces, final furnishing and installed Godot acceptance remain open.
Rebuild with Blender 4.3.2 --background --threads 4 --python source/build.py. Validate/render via qa/pipeline.py under ../heavy_job.py Windows mutex.
Original reference counts are illustrative, not newly registered capacity. No simulated operations; no hull windows.
Requested Sol6.1 medium; runtime model/effort unavailable.
