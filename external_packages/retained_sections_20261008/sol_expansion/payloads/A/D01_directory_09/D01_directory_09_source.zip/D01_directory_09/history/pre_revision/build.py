"""Editable section construction, actual retained allocation, no shared slabs or simulation."""
import sys,json,math
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
import kit as k
import bpy,bmesh
from mathutils import Matrix,Vector
P=Path(__file__).resolve().parents[1];C=json.loads((P/'allocation.json').read_text());KEY=C['programme_key'];k.init(__file__,KEY)
entry=C['portals'][0]['xyz'];E=entry[0];Z=entry[2];S=1 if E>0 else -1
def pos(u,y,v):return (E+S*u,y,Z+v)
def box(n,u,y,v,w,h,d,m='blue',sup='shared_floor',zone='architecture',bev=.04):return k.box(n,pos(u,y,v),(w,h,d),m,sup,zone,bev)
def wall(n,u,v,w,d,h=4.7):return box(n,u,h/2,v,w,h,d,'blue')
def table(n,u,v,w=3,d=1.2,zone='handover'):
 return k.table(n,E+S*u,Z+v,w,d,zone)
def seat(n,u,v,w=3,angle=0,zone='rest'):
 k.seat(n,E+S*u,Z+v,w,zone,angle)
def roof(n,u,v,w,d,sup,h=4.65):box(n,u,h,v,w,.22,d,'white',sup)
def cabinet(n,u,v,w=1.2,d=3,h=2.3,zone='work'):
 return k.cabinet(n,E+S*u,Z+v,w,d,zone,h)
def asset(n,key,u,v,angle=0):
 paths=list((P/'dependencies/catalogue').rglob(key+'*.blend'));assert len(paths)==1
 before=set(bpy.context.scene.objects)
 with bpy.data.libraries.load(str(paths[0]),link=False) as (src,dst):dst.objects=src.objects
 for ob in dst.objects:
  if ob:bpy.context.collection.objects.link(ob)
 bpy.context.view_layer.update();dg=bpy.context.evaluated_depsgraph_get()
 original=[o for o in dst.objects if o and o.type in ['MESH','FONT']];obs=[];fonts=[]
 for source in original:
  transform=source.matrix_world.copy()
  if source.type=='FONT':
   source.parent=None;source.matrix_world=transform;fonts.append(source);continue
  me=bpy.data.meshes.new_from_object(source.evaluated_get(dg),preserve_all_data_layers=True,depsgraph=dg)
  ob=bpy.data.objects.new('PLACEMENT_'+source.name,me);bpy.context.collection.objects.link(ob);ob.matrix_world=transform;obs.append(ob)
 # Native semantic solids avoid GLB UV seam welding across touching manufactured pieces.
 bpy.ops.object.select_all(action='DESELECT')
 for o in obs:o.select_set(True)
 bpy.context.view_layer.objects.active=obs[0];bpy.ops.object.join();o=bpy.context.object
 bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
 low=min(v.co.z for v in o.data.vertices);rot=Matrix.Rotation(-angle,4,'Z')
 for vertex in o.data.vertices:vertex.co=rot@vertex.co;vertex.co.z-=low
 o.location=k.xyz(pos(u,0,v));o.name='A_'+n;o['section_key']=KEY;o['support']='shared_floor';o['zone']='original_catalogue_work_edge';o['role']='retained_catalogue_asset';o['original_catalogue_id']=key
 bm=bmesh.new();bm.from_mesh(o.data);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(o.data);bm.free();k.PARTS.append(o)
 placement=Matrix.Translation(Vector(k.xyz(pos(u,0,v))))@Matrix.Rotation(-angle,4,'Z')@Matrix.Translation(Vector((0,0,-low)))
 for j,font in enumerate(fonts):
  font.matrix_world=placement@font.matrix_world;font.name='A_'+n+'_original_text'+str(j);font['section_key']=KEY;font['support']=o.name;font['zone']='original_catalogue_work_edge';font['role']='original_editable_label';k.PARTS.append(font)
 for ob in list(bpy.context.scene.objects):
  if ob not in before and ob!=o and ob not in fonts:bpy.data.objects.remove(ob,do_unlink=True)
 return o
def court(n,v,w=18,depth=14,h=2.6,roofed=False):
 # Three-sided working enclosure faces the main dry pedestrian/cart spine.
 wall(n+'_rear',40,v,.24,depth,h)
 wall(n+'_side_a',31,v-depth/2,w,.24,h)
 wall(n+'_side_b',31,v+depth/2,w,.24,h)
 if roofed:roof(n+'_insulated_cap',31,v,w,depth,n+'_rear',h+.11)
def frame(n,v):
 for u in [4.5,42]:box(n+'_post'+str(u),u,2.14,v,.35,4.28,.40,'zinc')
 box(n+'_beam',23.25,4.32,v,37.85,.22,.40,'blue',n+'_post4.5')
 k.light(n+'_task',E+S*23.25,Z+v,4.15,36.9,.35,n+'_beam','circulation',2600)

# Chamfered back turns and a wide internal arrival opening; containment is not a prescribed room box.
wall('back',43.5,0,.3,58,4.8)
for sign in [-1,1]:
 wall('edge'+str(sign),25,sign*31,35,.3,4.8)
 poly=[(E+S*42.5,Z+sign*31),(E+S*43.65,Z+sign*29.85),(E+S*43.35,Z+sign*29.55),(E+S*42.2,Z+sign*30.7)]
 k.prism('folded_return'+str(sign),poly,0,4.8,'blue','shared_floor','architecture')
 wall('inward_screen'+str(sign),3,sign*17.5,.28,27,3.3)
 # Supported deep reveal does not occupy root's portal reservation.
 wall('arrival_reveal'+str(sign),5,sign*4.2,4,.25,3.3)
roof('arrival_lintel',5,0,4,8.65,'arrival_reveal-1',3.40)
k.light('arrival_task',E+S*5,Z,3.23,3.8,7.9,'arrival_lintel','arrival',900)
for j,v in enumerate([-24,-8,8,24]):frame('working_rib'+str(j),v)
table('handover',9,7,4,1.6)
k.chart('handover_grid',E+S*9,Z+7,2.9,1.0,'handover_top','handover')
seat('rest_bench',8,-16,4,zone='staff_rest')
table('rest_table',8,-18,2,1,zone='staff_rest')
care_start=len(k.PARTS);k.care('care',E+S*5,Z+19,'staff_care')
if S<0:k.rotate_group(k.PARTS[care_start:],E+S*5,Z+19,math.pi)
cabinet('locker',5,-24,1.2,4,2.3,'staff_rest')

name=C['name'];description=[]
if KEY=='D01_directory_09':
 description=['Folded arrival reveal into a long cross-aisle; two screened waiting courts, baggage work edge and separate rear staging lane. No dock or hull opening authored.']
 for j,v in enumerate([-18,18]):
  court('waiting'+str(j),v,h=2.15)
  for u in [27,36]:seat('waiting_bench'+str(j)+'_'+str(u),u,v+3,5,zone='waiting')
  table('waiting_table'+str(j),31,v,3,1.2,'waiting')
  cabinet('baggage'+str(j),38,v-3,1.3,5,1.8,'baggage')
  wall('queue_wing'+str(j),24,v-5,3,.25,1.05)
 asset('dispatch_cabinet','AST-STF-007',10,26)
 sup=table('concourse_release_desk',34,0,9,2.1,'boarding_handover')
 k.chart('release_manifest',E+S*34,Z,6,1.3,sup,'boarding_handover')
 for j,u in enumerate([30,38]):k.terminal('release_terminal'+str(j),E+S*u,Z,sup,'boarding_handover',y=.87)
elif KEY=='D01_directory_02':
 description=['Two insulated stores with recessed clear mouths, transfer inspection court and dry staff bypass; upper structure stays below the retained 5.31m underside. Reference 12000m3 is not a capacity claim.']
 for j,v in enumerate([-18,18]):
  court('cold_store'+str(j),v,h=3.9,roofed=True)
  for u in [28,36]:
   k.shelf('cold_rack'+str(j)+'_'+str(u),E+S*u,Z+v+4,5,1.2,'cold_store',3.1)
   cabinet('sealed_bank'+str(j)+'_'+str(u),u,v-4,2.2,5,2.8,'cold_store')
 table('inspection',31,0,8,2.5,'transfer_inspection')
 asset('inspection_cabinet','AST-STF-007',36,4)
elif KEY=='D01_directory_04':
 description=['Three cargo group staging courts, central inspection edge and wide rear cart bypass. A-C are illustrative holding-group identities, not new registered holds or a tonnage claim.']
 for j,v in enumerate([-20,0,20]):
  court('exchange_group'+str(j),v,depth=10,h=1.25)
  for u in [28,36]:
   box('rack_post'+str(j)+'_'+str(u),u,1.8,v+3,.3,3.6,.3,'zinc')
  box('rack_beam'+str(j),32,3.65,v+3,8.3,.2,.3,'blue','rack_post'+str(j)+'_28')
  box('staging_shoe'+str(j),33,.08,v,8,.16,5,'rubber')
  box('staging_cradle'+str(j),33,.34,v,7.6,.52,4.6,'zinc','staging_shoe'+str(j))
 table('inspection',23,10,5,1.5,'inspection')
 asset('exchange_work','AST-STF-007',10,26)
elif KEY=='D01_directory_06':
 description=['Four separate repair work courts with tool-return cross-aisle, dirty-work screens and a clear central cart transfer. Four is an illustrative source arrangement, not registered workshop capacity.']
 for j,(u,v) in enumerate([(26,-20),(37,-20),(26,20),(37,20)]):
  wall('repair_screen'+str(j),u,v+5,8,.18,2.3)
  table('repair_bench'+str(j),u,v,7,2,'repair_work')
  asset('repair_cabinet'+str(j),'AST-STF-007',u,v+3)
  box('vice_foot'+str(j),u,.91,v,1,.08,.7,'zinc','repair_bench'+str(j)+'_top')
  box('vice_jaw'+str(j),u,1.09,v,.55,.28,.4,'blue','vice_foot'+str(j))
 table('tool_return',31,0,8,2.0,'tool_return')
elif KEY=='D01_directory_07':
 description=['Four screened reclamation candidate cells with dry inspection faces and separate incoming/outgoing staging. Waste processing and reclamation remain one programme; no operating process simulated.']
 for j,(u,v) in enumerate([(27,-20),(37,-20),(27,20),(37,20)]):
  wall('process_screen'+str(j),u,v+5,8,.24,3.3)
  box('vessel_shoe'+str(j),u,.1,v,4,.2,4,'zinc')
  k.disc('recovery_body'+str(j),E+S*u,Z+v,.2,1.65,2.9,'blue','vessel_shoe'+str(j),'reclamation_cell')
  k.disc('recovery_lid'+str(j),E+S*u,Z+v,3.1,1.5,.20,'white','recovery_body'+str(j),'reclamation_cell')
  asset('process_pump'+str(j),'AST-ENG-001',u,v-3)
 for j,v in enumerate([-9,9]):table('sort_work'+str(j),33,v,6,2,'dry_inspection')
elif KEY=='D01_directory_08':
 description=['Dispatch fan with three screened cart staging lanes, end checking benches and a dry document/handover edge; no additional cargo holds created.']
 for j,v in enumerate([-20,0,20]):
  court('dispatch_lane'+str(j),v,depth=10,h=1.1)
  for u in [27,35]:
   box('dock_foot'+str(j)+'_'+str(u),u,.05,v,4,.1,4,'rubber')
   for zz in [-1.7,1.7]:box('cart_guide'+str(j)+'_'+str(u)+'_'+str(zz),u,.2,v+zz,3.8,.3,.16,'zinc','dock_foot'+str(j)+'_'+str(u))
  table('dispatch_check'+str(j),39,v,2,6,'checking')
 asset('dispatch_work','AST-STF-007',10,26)
elif KEY=='D02_directory_03':
 description=['Two paired filter courts around a dry service cross-aisle; four actual original filter placements with pumps and supported overhead service bars. No atmosphere simulation or registered capacity claim.']
 for j,v in enumerate([-18,18]):
  court('filter_court'+str(j),v,h=2.5)
  for l,u in enumerate([27,36]):
   asset('filter'+str(j)+str(l),'AST-ENG-002',u,v)
   asset('filter_pump'+str(j)+str(l),'AST-ENG-001',u,v-3)
  box('service_bar'+str(j),32,3.4,v+6,17,.22,.32,'zinc','filter_court'+str(j)+'_side_b')
elif KEY=='D02_directory_04':
 description=['Recovery vessel courts with original transfer pump skids, separate dry bench and service approaches; no water/pressure simulation. Four reference modules are illustrative.']
 for j,(u,v) in enumerate([(27,-18),(36,-18),(27,18),(36,18)]):
  box('tank_plinth'+str(j),u,.1,v,4,.2,4,'zinc')
  k.disc('water_tank'+str(j),E+S*u,Z+v,.2,1.6,3.0,'white','tank_plinth'+str(j),'water_recovery')
  k.disc('tank_band'+str(j),E+S*u,Z+v,2.1,1.64,.22,'blue','water_tank'+str(j),'water_recovery')
  asset('water_pump'+str(j),'AST-ENG-001',u,v-4)
 table('water_dry_work',32,0,9,2,'dry_water_inspection')
 asset('water_workbay','AST-STF-007',10,26)
elif KEY=='D02_directory_07':
 description=['Two switchgear courts split into six candidate distribution groups; front maintenance aisle, rear access loop and screened dry staff handover. No power simulation or new registered nodes.']
 for j,v in enumerate([-18,18]):
  court('power_court'+str(j),v,h=2.4)
  for l,u in enumerate([26,32,38]):
   cabinet('switchgear'+str(j)+str(l),u,v,2.2,5,3.5,'power_distribution')
   box('isolator_base'+str(j)+str(l),u+S*1.18,1.4,v,.18,.9,1.2,'rubber','switchgear'+str(j)+str(l)+'_carcass')
 table('lockout_work',32,0,8,1.7,'lockout_document_edge')
elif KEY=='D02_directory_08':
 description=['Oversight and handover work galley facing four screened reference-module work edges, with quieter staff rest/care alcove. No operating simulation and no duplicated D05 plant.']
 for j,v in enumerate([-19,-9,9,19]):
  wall('control_wing'+str(j),37,v+4,10,.22,2.2)
  sup=table('control_edge'+str(j),33,v,9,1.9,'life_support_control')
  for l,u in enumerate([30,36]):k.terminal('control_terminal'+str(j)+str(l),E+S*u,Z+v,sup,'life_support_control',y=.87)
  k.swivel('control_chair'+str(j),E+S*33,Z+v-1.8,'life_support_control')
 table('control_handover',27,0,7,2.2,'control_handover')
 seat('quiet_rest',10,-27,5,zone='quiet_rest')
else:raise RuntimeError(KEY)

# Routes are actual planned candidate approaches, conservatively checked against imported triangles.
def path(ps):return [[E+S*u,Z+v] for u,v in ps]
C['paths']={'arrival':path([(0,0),(15,0),(20,0)]),'negative_work':path([(15,0),(15,-18),(23,-18)]),'positive_work':path([(15,0),(15,18),(23,18)]),'service_bypass':path([(15,-28),(41,-28),(41,28),(15,28)])}
# Some programme courts intentionally enclose the rear edge; service loop remains at the main aisle.
C['paths']['service_bypass']=path([(18,-28),(18,28)])
approaches={'D01_directory_09':(34,-1.7),'D01_directory_02':(31,-1.85),'D01_directory_04':(33,-3.1),'D01_directory_06':(26,-21.6),'D01_directory_07':(33,-10.6),'D01_directory_08':(39,-3.6),'D02_directory_03':(27,-19.4),'D02_directory_04':(32,-1.6),'D02_directory_07':(26,-21.2),'D02_directory_08':(30,-11.25)}
au,av=approaches[KEY]
C['paths']['primary_fixture_approach']=path([(15,0),(15,av),(au,av)])
C['paths']['care_approach']=path([(15,0),(15,18.3 if S>0 else 19.7),(7.05,18.3 if S>0 else 19.7)])
C['paths']['rest_approach']=path([(15,0),(15,-16),(10.7,-16)])
C['views']=[['01_arrival',list(pos(8,1.65,0)),list(pos(32,1.65,0))],['02_negative_programme',list(pos(19,1.65,-25)),list(pos(34,1.65,-18))],['03_positive_programme',list(pos(19,1.65,25)),list(pos(34,1.65,18))],['04_cross_aisle',list(pos(19,1.65,-3)),list(pos(19,1.65,27))],['05_rest_care',list(pos(15,1.65,-8)),list(pos(5,1.65,-17))],['06_service_handover',list(pos(17,1.65,27)),list(pos(6,1.65,17))]]
C['construction_intent']=description;C['capacity_policy']='No new Catalogue IDs, registered counts, capacity or operating simulation. Original reference counts remain illustrative.'
C['receiving_status']='Root reservation confirmed; root-owned slabs, shell/load connections, actual doors and installed Godot acceptance remain held.'
k.save(C)
