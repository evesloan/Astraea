"""Batch E shared deterministic source toolkit. All Godot world coordinates, metres.
Catalogue resources are pinned copies. No Game, Catalogue or registry writes.
"""
import bpy,math,json,hashlib,sys
from pathlib import Path
from mathutils import Vector,Matrix
BASE=Path(__file__).resolve().parents[1]
M={};A=[];LIGHTS=[];ZONE='';P=None;SEC='';F=12;H=6.4

def xyz(p):return (p[0],-p[2],F+p[1])
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def uv(o):
 if o.type!='MESH':return
 me=o.data;me.update()
 if not me.uv_layers:me.uv_layers.new(name='UV0')
 for f in me.polygons:
  ax=max(range(3),key=lambda i:abs(f.normal[i]));axes=[i for i in range(3) if i!=ax]
  for li in f.loop_indices:
   v=me.vertices[me.loops[li].vertex_index].co;me.uv_layers.active.data[li].uv=(v[axes[0]],v[axes[1]])
def tag(o,n,m,sup='receiving_floor_proposal',role='fitted_component',bev=0):
 o.name='E_'+n;o['programme_key']=SEC;o['support']=sup;o['zone']=ZONE;o['role']=role
 if o.type=='MESH':
  if bev:
   bpy.context.view_layer.objects.active=o;mod=o.modifiers.new('Editable edge radius','BEVEL');mod.width=bev;mod.segments=2
   # Retain modifier natively, exporter evaluates it.
  o.data.materials.append(M[m]);uv(o)
 A.append(o);return o

def box(n,p,d,m='blue',sup='receiving_floor_proposal',role='fitted_component',bev=.03):
 bpy.ops.mesh.primitive_cube_add(size=1,location=xyz(p));o=bpy.context.object;o.dimensions=(d[0],d[2],d[1]);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 return tag(o,n,m,sup,role,min(bev,min(d)*.25))
def prism(n,poly,y,h,m='white',sup='receiving_floor_proposal',role='profiled_component'):
 # Godot XZ winding converted to Blender XY; orient after construction.
 v=[xyz((x,y,z)) for x,z in poly]+[xyz((x,y+h,z)) for x,z in poly];N=len(poly)
 faces=[tuple(range(N)),tuple(reversed(range(N,2*N)))]+[(i,i+N,(i+1)%N+N,(i+1)%N) for i in range(N)]
 me=bpy.data.meshes.new(n);me.from_pydata(v,[],faces);me.update();o=bpy.data.objects.new(n,me);bpy.context.scene.collection.objects.link(o)
 bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.normals_make_consistent(inside=False);bpy.ops.object.mode_set(mode='OBJECT');o.select_set(False)
 return tag(o,n,m,sup,role,.035)
def rod(n,a,b,r=.045,m='zinc',sup='receiving_floor_proposal'):
 pa,pb=Vector(xyz(a)),Vector(xyz(b));de=pb-pa;bpy.ops.mesh.primitive_cylinder_add(vertices=12,radius=r,depth=de.length,location=(pa+pb)/2);o=bpy.context.object;o.rotation_euler=de.to_track_quat('Z','Y').to_euler();bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return tag(o,n,m,sup,'visible_support')
def sign(n,body,x,z,y=2.3,size=.16,face='south',sup='wall'):
 cu=bpy.data.curves.new(n,'FONT');cu.body=body;cu.size=size;cu.align_x='CENTER';cu.extrude=.001
 o=bpy.data.objects.new(n,cu);bpy.context.scene.collection.objects.link(o);o.location=xyz((x,y,z));o.rotation_euler=(math.pi/2,0,0) if face=='south' else ((math.pi/2,0,math.pi) if face=='north' else (math.pi/2,0,math.pi/2))
 tag(o,n,'opal',sup,'editable_small_signage')
def linewall(n,a,b,h=2.75,m='white',width=.24):
 dx=b[0]-a[0];dz=b[1]-a[1];o=box(n,((a[0]+b[0])/2,h/2,(a[1]+b[1])/2),(math.hypot(dx,dz),h,width),m,role='partition_floor_contact');o.rotation_euler.z=-math.atan2(dz,dx);return o

def portal(n,x,z,axis='x',w=3.8,h=2.65):
 if axis=='x':
  for i,s in enumerate([-1,1]):box(n+'pier'+str(i),(x,h/2,z+s*(w/2+.2)),(.65,h,.4),'blue',role='portal_floor_contact')
  box(n+'header',(x,h+.17,z),(.65,.34,w+.8),'blue',sup='E_'+n+'pier0')
  for i,s in enumerate([-1,1]):box(n+'reveal'+str(i),(x+.18,h/2,z+s*(w/2+.08)),(.12,h,.16),'zinc',sup='E_'+n+'pier'+str(i))
 else:
  for i,s in enumerate([-1,1]):box(n+'pier'+str(i),(x+s*(w/2+.2),h/2,z),(.4,h,.65),'blue',role='portal_floor_contact')
  box(n+'header',(x,h+.17,z),(w+.8,.34,.65),'blue',sup='E_'+n+'pier0')
 # Open fixed aperture; no operating door installed.

def light(n,x,z,y=None,w=.5,l=2.5):
 if y is None:y=H-.28
 box(n+'mount',(x,(H+y+.14)/2,z),(.10,H-y-.14,.20),'zinc',sup='E_ceiling');box(n+'body',(x,y+.08,z),(w+.16,.12,l+.16),'blue',sup='E_'+n+'mount');box(n+'lens',(x,y,z),(w,.04,l),'opal',sup='E_'+n+'body');LIGHTS.append((n,(x,y-.04,z),w,l,280*l))
def bench(n,x,z,length=4,yaw=0,m='cloth'):
 # Wrapped sitting edge on inset base, raised cap and visible end supports.
 poly=[(-length/2+.2,-.5),(length/2-.2,-.5),(length/2,-.3),(length/2,.4),(-length/2,.4),(-length/2,-.3)]
 def trans(poly):return [(x+u*math.cos(yaw)-v*math.sin(yaw),z+u*math.sin(yaw)+v*math.cos(yaw)) for u,v in poly]
 base=prism(n+'base',trans(poly),0,.36,'blue',role='bench_floor_contact');prism(n+'pad',trans(poly),.36,.12,m,sup=base.name)
 a=(x-length/2*math.cos(yaw)-.4*math.sin(yaw),z-length/2*math.sin(yaw)+.4*math.cos(yaw));b=(x+length/2*math.cos(yaw)-.4*math.sin(yaw),z+length/2*math.sin(yaw)+.4*math.cos(yaw))
 o=linewall(n+'back',a,b,1.0,m,.14);o['support']=base.name

def table(n,x,z,w=3,l=1.6):
 for i,(dx,dz) in enumerate([(-w/2+.2,-l/2+.2),(w/2-.2,-l/2+.2),(-w/2+.2,l/2-.2),(w/2-.2,l/2-.2)]):box(n+'leg'+str(i),(x+dx,.38,z+dz),(.12,.76,.12),'zinc',role='table_floor_contact')
 poly=[(x-w/2+.2,z-l/2),(x+w/2-.2,z-l/2),(x+w/2,z-l/2+.2),(x+w/2,z+l/2-.2),(x+w/2-.2,z+l/2),(x-w/2+.2,z+l/2),(x-w/2,z+l/2-.2),(x-w/2,z-l/2+.2)]
 return prism(n+'top',poly,.76,.10,'white',sup='E_'+n+'leg0')
def chair(n,x,z,yaw=0):
 # Distinct washable staff task chair, editable shaped seat.
 rod(n+'post',(x,.07,z),(x,.42,z),.08,'zinc',sup='E_'+n+'foot');box(n+'foot',(x,.04,z),(.65,.08,.65),'rubber',role='chair_floor_contact')
 o=box(n+'seat',(x,.46,z),(.76,.12,.74),'cloth',sup='E_'+n+'post',bev=.055)
 dx,dz=math.sin(yaw)*.32,-math.cos(yaw)*.32
 rod(n+'backstem',(x+dx,.47,z+dz),(x+dx,1.02,z+dz),.04,'zinc',sup=o.name)
 o=box(n+'back',(x+dx,1.01,z+dz),(.72,.48,.12),'cloth',sup='E_'+n+'backstem',bev=.045);o.rotation_euler.z=-yaw

def shelf(n,x,z,length=5,height=2.4,stock='records'):
 back=box(n+'back',(x,height/2,z),(length,.15 if False else height,.15),'blue',role='shelf_floor_contact')
 for i,s in enumerate([-1,1]):box(n+'end'+str(i),(x+s*(length/2-.06),height/2,z-.42),(.12,height,.9),'blue',sup=back.name)
 for j,y in enumerate([.12,.72,1.32,1.92]):
  box(n+'shelf'+str(j),(x,y,z-.4),(length,.08,.85),'white',sup=back.name)
  for k in range(max(1,int(length/1.2))):
   xx=x-length/2+.65+k*1.15
   box(n+'stored'+str(j)+'_'+str(k),(xx,y+.26,z-.42),(.7,.44,.6),'cloth' if stock=='clean' else 'blue',sup='E_'+n+'shelf'+str(j),bev=.05)
   box(n+'label'+str(j)+'_'+str(k),(xx,y+.26,z-.735),(.33,.08,.025),'white',sup='E_'+n+'stored'+str(j)+'_'+str(k),bev=.004)

def cabinet(n,x,z,yaw=0):
 before=set(bpy.data.objects);bpy.ops.import_scene.gltf(filepath=str(BASE/'dependencies/AST-STF-007_supply_work_cabinet.glb'));obs=set(bpy.data.objects)-before
 T=Matrix.Translation(Vector(xyz((x,0,z))))@Matrix.Rotation(-yaw,4,'Z')
 # Import GLB restores Blender basis, only apply world placement to roots.
 for o in obs:
  if o.parent not in obs:o.matrix_world=T@o.matrix_world
 for i,o in enumerate(obs):
  o.name='E_'+n+'_'+o.name;o['programme_key']=SEC;o['zone']=ZONE;o['support']='Catalogue internal contacts; receiving_floor_proposal';o['role']='retained_AST_STF_007_static_source';A.append(o)

def enclosure(rect,entry_z):
 x0,x1,z0,z1=rect;h=H
 for side,x in [('west',x0+.45),('east',x1-.45)]:
  for idx,(a,b) in enumerate([(z0+.2,entry_z-2.3),(entry_z+2.3,z1-.2)]):linewall('outer_'+side+str(idx),(x,a),(x,b),h)
  portal('outer_'+side+'_opening',x,entry_z,'x',4.2)
 for n,z in [('south',z0+.2),('north',z1-.2)]:linewall('outer_'+n,(x0+.2,z),(x1-.2,z),h)
 box('ceiling',((x0+x1)/2,H+.07,(z0+z1)/2),(x1-x0-.4,.14,z1-z0-.4),'blue',sup='E_outer_west0',role='supported_ceiling_proposal')
 # Perimeter-to-perimeter box beams; a visible grid and bearing posts, all above clear routes.
 for i,z in enumerate(range(int(z0+5),int(z1-3),8)):
  box('roofbeam'+str(i),((x0+x1)/2,H-.08,z),(x1-x0-.8,.16,.2),'zinc',sup='E_roofbearing'+str(i)+'_0',role='ceiling_beam_proposal')
  for j,x in enumerate([x0+.45,x1-.45]):box('roofbearing'+str(i)+'_'+str(j),(x,(H-.12)/2,z),(.25,H-.12,.28),'zinc',role='bearing_floor_contact')
 # Lighting in the main circulation spine.
 for i,x in enumerate(range(int(x0+4),int(x1-2),7)):light('spine_'+str(i),x,entry_z,l=3)

def cell(n,x0,x1,z0,z1,opening='north',height=2.75):
 # All four corners retained, one deep offset open threshold.
 mid=(x0+x1)/2
 linewall(n+'west',(x0,z0),(x0,z1),height);linewall(n+'east',(x1,z0),(x1,z1),height)
 for side,z in [('south',z0),('north',z1)]:
  if side==opening:
   linewall(n+side+'a',(x0,z),(mid-1.9,z),height);linewall(n+side+'b',(mid+1.9,z),(x1,z),height);portal(n+'arrival',mid,z,'z',3.6,2.5)
  else:linewall(n+side,(x0,z),(x1,z),height)
 for j,x in enumerate([x0+3,x1-3]):
  for k,z in enumerate([z0+3,z1-3]):light(n+'light'+str(j)+str(k),x,z,l=2.5)

def init(sec,folder,floor=12,height=6.4):
 global SEC,P,F,H
 F=floor;H=height
 SEC=sec;P=BASE
 for d in ['source','exports','qa/views','docs']:(P/d).mkdir(parents=True,exist_ok=True)
 bpy.ops.wm.read_factory_settings(use_empty=True);bpy.context.scene.unit_settings.system='METRIC'
 spec={'blue':('warm_walnut',(.24,.31,.33),0),'white':('ivory_enamel',(.65,.68,.65),0),'zinc':('champagne_metal',(.38,.43,.44),.65),'rubber':('dark_rubber',(.05,.065,.065),0),'opal':('ivory_enamel',(.7,.8,.8),0),'cloth':('teal_weave',(.16,.32,.31),0),'floor':('warm_stone',(.3,.34,.34),0),'quiet':('oatmeal_weave',(.44,.47,.43),0)}
 for key,(fn,c,metal) in spec.items():
  ma=bpy.data.materials.new('E_'+key);ma.use_nodes=True;ma.diffuse_color=(*c,1);bs=ma.node_tree.nodes.get('Principled BSDF');bs.inputs['Roughness'].default_value=.8;bs.inputs['Metallic'].default_value=metal
  im=bpy.data.images.load(str(BASE/'materials'/(fn+'.png')));im.pack();tx=ma.node_tree.nodes.new('ShaderNodeTexImage');tx.image=im;tx.interpolation='Closest';ma.node_tree.links.new(tx.outputs['Color'],bs.inputs['Base Color'])
  if key=='opal':bs.inputs['Emission Color'].default_value=(.4,.55,.55,1);bs.inputs['Emission Strength'].default_value=.3
  M[key]=ma

def bounds(o):
 if o.type not in ['MESH','FONT']:return None
 dg=bpy.context.evaluated_depsgraph_get();ev=o.evaluated_get(dg);cs=[ev.matrix_world@Vector(c) for c in ev.bound_box]
 return [min(c.x for c in cs),min(c.z for c in cs),-max(c.y for c in cs),max(c.x for c in cs),max(c.z for c in cs),-min(c.y for c in cs)]

def save_export(rect):
 bpy.context.view_layer.update();sc=bpy.context.scene;sc['programme_key']=SEC;sc['source_only']=True;sc['floor_policy']='Separate proposal; native/export contain no floor';sc['no_capacity_or_gameplay_acceptance']=True
 for im in bpy.data.images:
  if im.source=='FILE' and not im.packed_file:im.pack()
 rows=[{'name':o.name,'type':o.type,'bounds_godot':bounds(o),'support':o.get('support'),'zone':o.get('zone'),'role':o.get('role')} for o in A]
 (P/'qa/source_objects.json').write_text(json.dumps(rows,indent=2))
 (P/'qa/fixtures.json').write_text(json.dumps(LIGHTS,indent=2))
 bpy.ops.object.select_all(action='DESELECT');cl=[]
 for o in A:
  if o.type=='FONT':
   c=o.copy();c.data=o.data.copy();sc.collection.objects.link(c);c.name=o.name+'_EXPORT';c.select_set(True);bpy.context.view_layer.objects.active=c;bpy.ops.object.convert(target='MESH');uv(c);cl.append((o,c,o.name));o.name+='_NATIVE';c.name=cl[-1][2];o.select_set(False)
  else:o.select_set(True)
 bpy.ops.export_scene.gltf(filepath=str(P/'exports'/f'{SEC}.glb'),export_format='GLB',use_selection=True,export_yup=True,export_apply=True,export_extras=True,export_texcoords=True)
 for o,c,n in cl:bpy.data.objects.remove(c,do_unlink=True);o.name=n
 bpy.ops.object.select_all(action='DESELECT');bpy.ops.wm.save_as_mainfile(filepath=str(P/'source'/f'{SEC}.blend'))
 (P/'docs/PLACEMENT.json').write_text(json.dumps({'programme_key':SEC,'frame':'GLB Godot world XYZ metres','translation':[0,0,0],'rotation_degrees':[0,0,0],'scale':[1,1,1],'floor_y':F,'roof_top_y':F+H+.14,'native_basis':'x,-z,y','scope':'source proposal only','boundary':rect},indent=2))
 (P/'docs/FLOOR_PROPOSAL.json').write_text(json.dumps({'owner':'Root integration only','status':'required missing receiving slab; not authored or exported','floor_y':F,'boundary':[[rect[0],rect[2]],[rect[1],rect[2]],[rect[1],rect[3]],[rect[0],rect[3]]],'area_m2':(rect[1]-rect[0])*(rect[3]-rect[2]),'preserve_existing_floors':True},indent=2))
 return digest(P/'source'/f'{SEC}.blend'),digest(P/'exports'/f'{SEC}.glb')

def render(rect,views,hashes):
 sc=bpy.context.scene
 # Explicit QA preview only; this floor is created after saving and exporting.
 o=box('QA_ONLY_floor',((rect[0]+rect[1])/2,-.12,(rect[2]+rect[3])/2),(rect[1]-rect[0],.24,rect[3]-rect[2]),'floor',role='QA_ONLY_preview_floor');o['qa_only']=True
 for n,p,w,l,power in LIGHTS:
  da=bpy.data.lights.new('QA_'+n,'AREA');da.energy=power;da.shape='RECTANGLE';da.size=w;da.size_y=l;lo=bpy.data.objects.new(da.name,da);sc.collection.objects.link(lo);lo.location=xyz(p)
 sc.render.engine='CYCLES';sc.cycles.samples=12;sc.cycles.use_denoising=True;sc.render.threads_mode='FIXED';sc.render.threads=4
 sc.render.resolution_x=960;sc.render.resolution_y=540;sc.render.resolution_percentage=100;sc.world=bpy.data.worlds.new('Dim neutral QA world');sc.world.use_nodes=True;sc.world.node_tree.nodes['Background'].inputs[0].default_value=(.12,.15,.17,1);sc.world.node_tree.nodes['Background'].inputs[1].default_value=.1;sc.view_settings.view_transform='AgX';sc.view_settings.exposure=.15
 da=bpy.data.cameras.new('QA_1_65m');cam=bpy.data.objects.new(da.name,da);sc.collection.objects.link(cam);sc.camera=cam;da.lens=22;da.clip_start=.08
 receipt=[]
 for n,cp,tp in views:
  x,z=(cp[0],cp[-1]);cy=cp[1] if len(cp)==3 else 1.65;tx,tz=(tp[0],tp[-1]);ty=tp[1] if len(tp)==3 else 1.45
  cam.location=xyz((x,cy,z));cam.rotation_euler=(Vector(xyz((tx,ty,tz)))-cam.location).to_track_quat('-Z','Y').to_euler();sc.render.filepath=str(P/'qa/views'/(n+'.png'));bpy.ops.render.render(write_still=True);receipt.append({'file':n+'.png','camera_xyz':[x,F+cy,z],'target_xyz':[tx,F+ty,tz],'camera_support_height_m':cy-1.65,'eye_m':1.65,'sha256':digest(sc.render.filepath)})
 (P/'qa/view_receipt.json').write_text(json.dumps({'source_sha256':hashes[0],'export_sha256':hashes[1],'source_only':True,'qa_preview_floor_excluded':True,'fixture_lights_only':True,'views':receipt},indent=2))


def retained(n,filename,x,z,yaw=0,y=0):
 before=set(bpy.data.objects);bpy.ops.import_scene.gltf(filepath=str(BASE/'dependencies'/filename));obs=set(bpy.data.objects)-before
 T=Matrix.Translation(Vector(xyz((x,y,z))))@Matrix.Rotation(-yaw,4,'Z')
 for o in obs:
  if o.parent not in obs:o.matrix_world=T@o.matrix_world
 for o in obs:
  o.name='E_'+n+'_'+o.name;o['programme_key']=SEC;o['zone']=ZONE;o['support']='Retained Catalogue internal contacts; receiving floor proposal';o['role']='retained_static_demonstration_source';A.append(o)
