import sys,pathlib,math,json
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent));import toolkit as t;import assembly as a
R=(52,98,-34,34);t.init('D10_directory_06','03_mineral_broth_hall',61,6.4);t.ZONE='broth_arrival';t.enclosure(R,0)
# Two dining fields flank a direct focal service street; forty six-place settings preserve240.
t.ZONE='broth_dining'
for iz,z in enumerate([-28,-20,-12,-4,4,12,20,28]):
 for ix,x in enumerate([58,66,74,82,90]):a.dining('broth_'+str(iz)+'_'+str(ix),x,z,6)
# Mineral serving ridge: three deep static vessels on a supported clean counter, separate return.
t.ZONE='clean_broth_finishing';base=t.box('broth_service_base',(86,.44,0),(6.4,.88,1.9),'blue',role='counter_floor_contact');t.box('broth_service_cap',(86,.94,0),(6.8,.12,2.2),'white',sup=base.name)
for i,x in enumerate([84,86,88]):
 poly=[(x+.46*math.cos(j*math.pi/8),.46*math.sin(j*math.pi/8)) for j in range(16)];pot=t.prism('broth_vessel_'+str(i),poly,1,.45,'zinc',sup='E_broth_service_cap');t.prism('broth_vessel_rim_'+str(i),[(x+.49*math.cos(j*math.pi/8),.49*math.sin(j*math.pi/8)) for j in range(16)],1.44,.07,'rubber',sup=pot.name)
# Stock and used handling have different fitted islands; no shared clean/used surface.
t.ZONE='used_return';a.family('broth_return','AST-HSP-004.glb',93,0,math.pi/2);t.ZONE='clean_stock';t.shelf('broth_clean_stock',87,32,8,2.4,'clean');t.ZONE='care';t.cabinet('broth_care',95,31,math.pi/2)
# A tapered ridge enclosure rises above the focal counter on four visible bearings.
for i,z in enumerate([-2,2]):
 for j,x in enumerate([82,90]):t.rod('ridge_post'+str(i)+str(j),(x,0,z),(x,3.8,z),.16,'white')
 t.rod('ridge_shoulder_l'+str(i),(82,3.65,z),(86,5.7,z),.18,'white',sup='E_ridge_post'+str(i)+'0');t.rod('ridge_shoulder_r'+str(i),(90,3.65,z),(86,5.7,z),.18,'white',sup='E_ridge_post'+str(i)+'1')
t.box('ridge_service_fascia',(86,5.6,0),(.35,.28,4.2),'blue',sup='E_ridge_shoulder_l0')
for i,z in enumerate([-25,-13,13,25]):
 for j,x in enumerate([60,75,89]):t.light('broth_light_'+str(i)+str(j),x,z,l=3)
t.light('broth_counter_light',86,0,l=4)
t.box('broth_notice_back',(86,2.6,-1.95),(3,.45,.12),'blue',sup='E_ridge_post00');t.sign('broth_notice','MINERAL BROTH',86,-1.875,2.52,.14,sup='E_broth_notice_back')
contract=next(r for r in json.loads((t.BASE/'VISIBLE_SCOPE_AND_HOLDS.json').read_text()) if r['programme_key']==t.SEC);contract.update({'capacity':240,'entry_xyz':[52,61,0],'root_exclusive_reservation':True});(t.P/'docs/CONTRACT.json').write_text(json.dumps(contract,indent=2));a.save_places(240)
h=t.save_export(R);routes=[{'name':'broth_guest_cart','radius_m':.85,'points_xz':[[54,0],[70,0],[80.8,0]]},{'name':'outer_service_cart','radius_m':.85,'points_xz':[[56,0],[56,32.5],[96,32.5],[96,0]]},{'name':'dining_cross_body','radius_m':.65,'points_xz':[[70,0],[78,0],[78,16],[94.5,16]]}];(t.P/'docs/APPROACH_PROPOSALS.json').write_text(json.dumps(routes,indent=2));(t.P/'docs/DESIGN_INTENT.json').write_text(json.dumps({'purpose':'240 existing mineral broth dining places; clean finishing ridge and independent used return','arrival':'Straight level service street, seating fields branch on either side','primary_form':'Tall tapered supported mineral-serving ridge, low durable dining fields and outer staff run','capacity':240,'new_capacity':0,'receiving_holds':['Actual food operation and loaded tray/cart use','Root slab portals structure','Species fit and live places']},indent=2));t.render(R,[('01_arrival',(54.5,0),(86,0)),('02_dining',(70,0),(74,-12)),('03_serving',(80.8,0),(86,0)),('04_service',(95,3),(93,0))],h);print('COMPLETE',t.SEC,h)
