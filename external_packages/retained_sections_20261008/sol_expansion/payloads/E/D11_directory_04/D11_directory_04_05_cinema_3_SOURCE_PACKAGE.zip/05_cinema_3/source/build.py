import pathlib,sys
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
from cinema_source import build
build('D11_directory_04','05_cinema_3',-164,1,'THE PATIENT ORCHARD')
