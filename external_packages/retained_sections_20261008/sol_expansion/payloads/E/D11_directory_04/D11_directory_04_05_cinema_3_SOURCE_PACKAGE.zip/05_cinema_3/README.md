# Cinema3 /200 guarded final

Source-only D11_directory_04. Editable native source/D11_directory_04.blend, actualGLB exports/D11_directory_04.glb. Exact placement and root receiving-floor proposal docs/. Four reviewed eye-level images qa/views/, their native/export hash binding qa/VISUAL_REVIEW.json.

From this extracted package root run: python source/heavy_wrapper.py "C:/Users/cered/Dolphin/AstraeaTools/blender-4.3.2-windows-x64/blender.exe" --background --factory-startup --threads 4 --python-exit-code 2 --python source/build.py. Same named mutex Local\Astraea_SolBatch_20261008_HeavyBuild; no shared-file writes. Packed textures and exact retained dependencies included.

Root retains live structure/connections/runtime; no installed acceptance claim.
