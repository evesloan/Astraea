import sys,pathlib,math,json
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent));import toolkit as t;import assembly as a
R=(-54,-8,398,466);t.init('D11_directory_12','10_immersive_sound',69.5,6.9);t.ZONE='sound_threshold';t.enclosure(R,432)
# Six freestanding curved acoustic walls form a focused oval room, with opposed open level gateways.
t.ZONE='immersive_chamber'
for i,(a0,a1) in enumerate([(20,62),(68,112),(118,160),(200,242),(248,292),(298,340)]):
 poly=[(-31+15*math.cos(math.radians(a)),432+12*math.sin(math.radians(a))) for a in range(a0,a1+1,2)]+[(-31+14.4*math.cos(math.radians(a)),432+11.4*math.sin(math.radians(a))) for a in range(a1,a0-1,-2)];wall=t.prism('acoustic_arc_'+str(i),poly,0,4.8,'quiet',role='acoustic_wall_floor_contact')
 ang=math.radians((a0+a1)/2);x,z=-31+14.4*math.cos(ang),432+11.4*math.sin(ang);t.rod('speaker_stem'+str(i),(x,0,z),(x,2.7,z),.07,'zinc');o=t.box('sound_emitter_'+str(i),(x,2.8,z),(.8,1.0,.55),'rubber',sup='E_speaker_stem'+str(i));o.rotation_euler.z=-ang
# Seats look inward from independent shaped groups; existing capacity is not increased or claimed.
t.ZONE='listening_places'
for i,(x,z) in enumerate([(-38,426),(-34,425),(-28,425),(-24,426),(-38,438),(-34,439),(-28,439),(-24,438)]):a.family('listening_chair_'+str(i),'AST-FUR-002_day_reading_chair.glb',x,z,math.atan2(-31-x,432-z))
# Original spatial reference beacon on a low fitted stage, no invented audio running.
t.ZONE='original_spatial_focus';base=t.prism('focus_plinth',[(-34,430),(-29,429),(-27,432),(-29,435),(-34,434)],0,.45,'blue',role='focus_floor_contact');t.rod('sound_focus_spine',(-31,.45,432),(-31,3.4,432),.13,'zinc',sup=base.name)
for i,y in enumerate([1,1.8,2.6]):t.box('sound_focus_arm'+str(i),(-31,y,432),(3.2-.6*i,.1,.6),'cloth',sup='E_sound_focus_spine')
# A calmer reset edge is spatially separate from the immersive oval.
t.ZONE='quiet_reset';t.bench('sound_reset',-31,407,11,math.pi,'cloth');t.table('sound_reset_table',-31,410,3,1.8)
# Staff control is screened at the north-west end, supply/care on independent east run.
t.ZONE='sound_control';t.linewall('control_screen',(-50,454),(-40,454),2.8,'blue');t.table('sound_control_desk',-45,459,6,1.8);t.chair('sound_operator',-45,457,0);t.shelf('sound_equipment',-45,463,7,2.4,'records');t.cabinet('sound_care',-12,463,math.pi)
for i,z in enumerate([406,419,432,445,459]):
 for j,x in enumerate([-50,-31,-12]):t.light('sound_worklight_'+str(i)+str(j),x,z,l=3)
t.rod('sound_notice_post',(-15.5,0,437),(-15.5,2,437),.07,'zinc');t.box('sound_notice',(-15.5,1.7,437),(3,.45,.12),'blue',sup='E_sound_notice_post');t.sign('sound_name','IMMERSIVE SOUND',-15.5,437.08,1.63,.12,sup='E_sound_notice')
contract=next(x for x in json.loads((t.BASE/'inputs/Game/docs/coordination/sol_fifty_sections_20261008/BATCH_E.json').read_text())['sections'] if x['programme_key']==t.SEC);(t.P/'docs/CONTRACT.json').write_text(json.dumps(contract,indent=2));h=t.save_export(R)
routes=[{'name':'listening_arrival_cart','radius_m':.85,'points_xz':[[-10,432],[-22,432],[-25,432]]},{'name':'quiet_body','radius_m':.65,'points_xz':[[-12,432],[-12,412],[-21,412],[-31,412]]},{'name':'control_care_cart','radius_m':.85,'points_xz':[[-11,432],[-11,459.5],[-36,459.5]]}];(t.P/'docs/APPROACH_PROPOSALS.json').write_text(json.dumps(routes,indent=2));(t.P/'docs/DESIGN_INTENT.json').write_text(json.dumps({'purpose':'Focused immersive listening with separate reset and practical control edge','primary_form':'Six tall segmented oval acoustic walls with level opposed gateways and low original reference focus','capacity_change':False,'audio_status':'Source emitter/control geometry only; no acoustic measurements, media or live playback claims','service':'Screened northwestern control and eastern care run'},indent=2));t.render(R,[('01_arrival',(-10,432),(-31,432)),('02_listening',(-21,432),(-35,429)),('03_quiet_reset',(-21,411),(-31,407)),('04_control',(-37,457),(-45,459))],h);print('COMPLETE',t.SEC,h)
