import pathlib,sys
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
from cinema_source import build
build('D11_directory_07','07_cinema_6',396,3,'CLOUDS THAT BORROW THE SEA')
