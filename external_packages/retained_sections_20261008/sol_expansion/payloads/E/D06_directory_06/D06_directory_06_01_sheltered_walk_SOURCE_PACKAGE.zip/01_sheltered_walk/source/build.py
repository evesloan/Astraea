import sys,pathlib,math,json
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent));import toolkit as t
R=(54,98,-34,34);t.init('D06_directory_06','01_sheltered_walk',27,6.4);t.ZONE='covered_walking_arrival';t.enclosure(R,0)
# Four weighted garden pockets give the sheltered loop a deliberate branching shape.
for i,(x,z) in enumerate([(76,-19),(85,-7),(76,14),(86,24)]):
 poly=[(x-4,z-3),(x+3,z-3),(x+5,z),(x+2,z+3),(x-4,z+3),(x-5,z)]
 base=t.prism('garden_island_'+str(i),poly,0,.55,'blue',role='garden_island_floor_contact');t.prism('garden_soil_'+str(i),[(x-3,z-2),(x+2,z-2),(x+3,z),(x+1,z+2),(x-3,z+2)],.55,.12,'rubber',sup=base.name)
 t.retained('sheltered_canopy_'+str(i),'AST-BOT-001.glb',x,z,0,.67)
 t.bench('island_pause_'+str(i),x-1,z+3.5,5,0,'quiet')
# The walking route is level. Freestanding low fins screen quieter pauses, not the primary route.
t.ZONE='quiet_recesses'
for i,z in enumerate([-25,22]):
 t.linewall('quiet_cheek_'+str(i),(64,z-4),(68,z-1),2.2,'blue',.35);t.bench('sheltered_pause_'+str(i),61.5,z,5,math.pi/2,'cloth')
 t.table('pause_table_'+str(i),65,z,1.8,1.6)
# Offset branching roof ribs supported by perimeter piers, spanning the garden walk.
t.ZONE='sheltered_section'
for i,z in enumerate([-27,-12,12,28]):
 for j,(a,b) in enumerate([((58,0,z),(58,4.0,z)),((94,0,z),(94,4.0,z))]):t.rod('arcade_pier_'+str(i)+str(j),a,b,.30,'white')
 t.rod('branch_left_'+str(i),(58,3.85,z),(74,6.15,z),.22,'white',sup='E_arcade_pier_'+str(i)+'0')
 t.rod('branch_right_'+str(i),(94,3.85,z),(74,6.15,z),.22,'white',sup='E_arcade_pier_'+str(i)+'1')
 t.box('ridge_cap_'+str(i),(74,6.17,z),(2.4,.22,.9),'blue',sup='E_branch_left_'+str(i))
 for j,x in enumerate([62,82,92]):t.light('walk_pool_'+str(i)+str(j),x,z,l=3)
# Practical screened care edge, at the end of the outer service run.
t.ZONE='service_edge';t.linewall('care_screen',(84,30.2),(90,30.2),2.55,'blue');t.cabinet('walk_care',88,31,0)
for i,z in enumerate([-6,7]):t.light('central_walk_'+str(i),62,z,l=4)
# Minimal small editable label on a visible bearing post.
t.box('walk_notice_back',(60,1.7,3.5),(3,.5,.12),'blue',sup='E_walk_notice_post');t.rod('walk_notice_post',(60,0,3.5),(60,2,3.5),.08,'zinc');t.sign('walk_notice','SHELTERED WALK',60,3.575,1.65,.14,sup='E_walk_notice_back')
contract=next(r for r in json.loads((t.BASE/'VISIBLE_SCOPE_AND_HOLDS.json').read_text()) if r['programme_key']==t.SEC);contract.update({'entry_xyz':[54,27,0],'portal_minimum_clear_width_m':3.6,'protected_strip':{'x':[52,54],'z':[-34,34]},'protected_threshold_xz':[[52,-2],[56,-2],[56,2],[52,2]],'root_exclusive_reservation':True,'no_exterior_frontage_claim':True});(t.P/'docs/CONTRACT.json').write_text(json.dumps(contract,indent=2))
h=t.save_export(R);routes=[{'name':'receiving_cart','radius_m':.85,'points_xz':[[56,0],[62,0],[68,0],[72,0]]},{'name':'level_walking_loop','radius_m':.65,'points_xz':[[69,-29],[69,-11],[69,6],[69,19],[69,29.3],[93,29.3],[93,-29],[69,-29]]},{'name':'care_service_cart','radius_m':.85,'points_xz':[[62,0],[96,0],[96,32.6],[88,32.6]]}];(t.P/'docs/APPROACH_PROPOSALS.json').write_text(json.dumps(routes,indent=2));(t.P/'docs/DESIGN_INTENT.json').write_text(json.dumps({'purpose':'Sheltered level promenade with branching planted pauses','arrival':'Protected west threshold opens to the level garden loop','primary_form':'Offset planted islands under forked bearing ribs','quiet_edge':'Screened fitted pauses on the western loop','service':'Outer east run reaches screened care stock','capacity_change':False,'receiving_holds':['Root slab and connections','Actual interface doors','Target species and loaded cart acceptance'],'floor_exported':False},indent=2))
t.render(R,[('01_arrival',(56,0),(77,-4)),('02_covered_walk',(69.5,-30),(77,-12)),('03_quiet_edge',(70,23),(61.5,22)),('04_service',(94,32),(88,31))],h);print('COMPLETE',t.SEC,h)
