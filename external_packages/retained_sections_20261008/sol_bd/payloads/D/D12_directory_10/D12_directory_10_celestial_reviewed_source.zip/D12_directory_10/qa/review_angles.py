import importlib.util,json
from pathlib import Path
P=Path(__file__).resolve().parents[1]
s=importlib.util.spec_from_file_location('section',P/'source/build_section.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);m.LIGHTS=json.loads((P/'qa/fixtures.json').read_text());m.preview()
