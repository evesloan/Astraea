"""Bounded native continuation: remove only five explicitly labelled preview floors."""
import bpy,json,pathlib,hashlib,shutil,struct
R=pathlib.Path(__file__).resolve().parent
if R.name=='source':R=R.parents[1]
T=R/'inputs/BlenderCatalogue/assets/windows_section_source_intake_20261007/packages/WP05'
P=R/'D10_directory_09'
for folder in ['source','exports','docs','dependencies','qa']:(P/folder).mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=T/'source/WP05_moonfruit.blend';assert sha(original)=='bdb585c326a8136f9dba7a3ce9465599906ab4dbde7fde6dee5936426581592e'
bpy.ops.wm.open_mainfile(filepath=str(original))
selected=json.loads((T/'qa/source_geometry.json').read_text())['objects'];names={x['id'] for x in selected}
def digest_selected():
 h=hashlib.sha256();dg=bpy.context.evaluated_depsgraph_get()
 for name in sorted(names):
  o=bpy.data.objects[name];e=o.evaluated_get(dg);me=e.to_mesh();h.update(name.encode());h.update(struct.pack('<16d',*[v for row in o.matrix_world for v in row]))
  for v in me.vertices:h.update(struct.pack('<3d',*v.co))
  for f in me.polygons:h.update(struct.pack('<I',len(f.vertices)));h.update(struct.pack('<'+'I'*len(f.vertices),*f.vertices))
  for layer in me.uv_layers:
   for uv in layer.data:h.update(struct.pack('<2d',*uv.uv))
  if o.type=='FONT':h.update(o.data.body.encode())
  e.to_mesh_clear()
 return h.hexdigest()
before=digest_selected()
preview=[o for o in bpy.data.objects if o.name.startswith('WP05_SOURCE_PREVIEW_ONLY_floor')]
assert len(preview)==5
removed=[o.name for o in preview]
for o in preview:bpy.data.objects.remove(o,do_unlink=True)
assert all(name in bpy.data.objects for name in names)
scene=bpy.context.scene;scene.render.threads_mode='FIXED';scene.render.threads=2
bpy.ops.file.pack_all();native=P/'source/section.blend';bpy.ops.wm.save_as_mainfile(filepath=str(native))
bpy.ops.wm.open_mainfile(filepath=str(native));after=digest_selected();assert before==after
assert not any(o.name.startswith('WP05_SOURCE_PREVIEW_ONLY_floor') for o in bpy.data.objects)
assert all(im.packed_file for im in bpy.data.images if im.source=='FILE')
vertex_bounds={};dg=bpy.context.evaluated_depsgraph_get()
for name in sorted(names):
 o=bpy.data.objects[name];e=o.evaluated_get(dg);me=e.to_mesh();pts=[o.matrix_world@v.co for v in me.vertices]
 vertex_bounds[name]=[[min(p[k] for p in pts) for k in range(3)],[max(p[k] for p in pts) for k in range(3)]];e.to_mesh_clear()
(P/'qa/ACTUAL_SAVED_NATIVE_VERTEX_BOUNDS.json').write_text(json.dumps(vertex_bounds,indent=2))
# The exact retained actual exchange matches the untouched 4208 selected source objects.
# Keep it byte-identical, rather than implying this continuation changes architecture.
export=P/'exports/section.glb';shutil.copyfile(T/'exports/WP05_moonfruit.glb',export)
for folder in ['exports','qa']:
 for fn in ['contact_markers.json','floor_proposal.json','source_geometry.json','source_checks.json']:
  src=T/folder/fn
  if src.exists():shutil.copyfile(src,P/folder/('RETAINED_'+fn))
shutil.copyfile(original,P/'dependencies/retained_WP05_moonfruit.blend')
shutil.copyfile(T/'exports/WP05_moonfruit.glb',P/'dependencies/retained_WP05_moonfruit.glb')
shutil.copyfile(__file__,P/'source/CONTINUE_EXACT.py')
receipt=dict(programme='D10_directory_09',alias='D10_dessert8',original_native_sha256=sha(original),final_native_sha256=sha(native),final_glb_sha256=sha(export),exact_removed_preview_objects=removed,preserved_selected_source_object_count=len(names),before_selected_geometry_UV_text_transform_sha256=before,after_actual_saved_reload_sha256=after,packed_file_images=sum(im.source=='FILE' for im in bpy.data.images),external_libraries=[x.filepath for x in bpy.data.libraries],native_fonts={o.name:o.data.body for o in bpy.data.objects if o.type=='FONT'},retained_GLB_byte_identical=True,architecture_change='None; remove only five preview-floor objects from final native',original_scratch_recipe='Not present in retained intake. Deterministic bounded continuation uses pinned packed original native and actual retained export.',installed_acceptance=False)
(P/'qa/NATIVE_CONTINUATION_RECEIPT.json').write_text(json.dumps(receipt,indent=2))
print('MOONFRUIT_NATIVE_CONTINUED',sha(native),sha(export),flush=True)
