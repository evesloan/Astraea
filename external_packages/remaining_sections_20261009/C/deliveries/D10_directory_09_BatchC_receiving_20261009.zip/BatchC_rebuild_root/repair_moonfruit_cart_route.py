"""Find a conservative cart detour in unchanged Moonfruit; verify actual triangles."""
import pathlib,sys,json,math,heapq,hashlib,shutil
R=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(R));from glb_tools import read_glb,projected_grid,route_check
P=R/'D10_directory_09';file=P/'qa/FRESH_ACTUAL_EXPORT_QA.json';report=json.loads(file.read_text());glb=P/'exports/section.glb';assert hashlib.sha256(glb.read_bytes()).hexdigest()==report['glb_sha256']
g,ns=read_glb(glb);previous=next(x for x in report['cart_source_geometry_routes'] if x['name']=='arrival_to_clean_service');radius=previous['radius'];height=previous['height']
obstacles=[];grid={}
for n in ns:
 b=n['bounds']
 if b[0][1]>height or b[1][1]<0:continue
 k=len(obstacles);obstacles.append((b[0][0],b[1][0],b[0][2],b[1][2]))
 for x in range(math.floor(b[0][0]/3),math.floor(b[1][0]/3)+1):
  for z in range(math.floor(b[0][2]/3),math.floor(b[1][2]/3)+1):grid.setdefault((x,z),[]).append(k)
cache={};step=.25;rr=radius+.05
def safe(cell):
 if cell in cache:return cache[cell]
 x,z=cell[0]*step,cell[1]*step
 if not (-22.1<=x<=22.1 and -33.1<=z<=33.1):cache[cell]=False;return False
 candidates=set()
 for bx in range(math.floor((x-rr)/3),math.floor((x+rr)/3)+1):
  for bz in range(math.floor((z-rr)/3),math.floor((z+rr)/3)+1):candidates.update(grid.get((bx,bz),[]))
 good=all(math.hypot(max(a[0]-x,0,x-a[1]),max(a[2]-z,0,z-a[3]))>=rr for a in (obstacles[k] for k in candidates));cache[cell]=good;return good
start=(88,112);goal=(-46,-7);assert safe(start) and safe(goal)
queue=[(0,start)];cost={start:0};parent={};found=False
while queue:
 _,c=heapq.heappop(queue)
 if c==goal:found=True;break
 for dx,dz in [(1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)]:
  p=(c[0]+dx,c[1]+dz)
  if not safe(p) or (dx and dz and (not safe((c[0]+dx,c[1])) or not safe((c[0],c[1]+dz)))):continue
  v=cost[c]+math.hypot(dx,dz)
  if v<cost.get(p,1e99):cost[p]=v;parent[p]=c;heapq.heappush(queue,(v+math.dist(p,goal),p))
assert found,'No conservative cart route found; preserve and report source hold'
cells=[goal]
while cells[-1]!=start:cells.append(parent[cells[-1]])
cells.reverse();route=[(x*step,z*step) for x,z in cells]
polys,tri_grid=projected_grid(ns,0,height);verified=route_check(polys,tri_grid,route,radius);assert verified['passed'],verified['blocked'][:3]
verified.update(name=previous['name'],route=route,radius=radius,height=height,route_selection='A* over conservative actual-node AABBs with 5cm added margin; verified against actual clipped GLB triangles at 10cm steps')
shutil.copyfile(file,P/'qa/FAILED_SECOND_CLEAN_CART_DETOUR_QA.json');report['cart_source_geometry_routes']=[verified if x['name']==verified['name'] else x for x in report['cart_source_geometry_routes']];report['errors']=[e for e in report['errors'] if e!='cart route arrival_to_clean_service'];report['passed']=not report['errors'];report['targeted_recheck']='Only clean-service route changed; actual final files and all complete source tests are unchanged';file.write_text(json.dumps(report,indent=2))
(P/'docs/CLEAN_CART_ROUTE.json').write_text(json.dumps(dict(local_GLTF_XZ=route,placement_world_xyz=[-31,61,432],corrected_guest_stance_world_xyz=[-42.5,61,430.25],minimum_source_clearance_m=verified['min_actual_source_surface_distance_m'],radius_m=radius,height_m=height,root_floor_and_loaded_physics='Not established'),indent=2))
print('MOONFRUIT_CLEAN_CART_ROUTE_VERIFIED',len(route),verified['min_actual_source_surface_distance_m'],'ALL_SOURCE_QA',report['passed'])
