"""Repair one non-rendering clean-service approach marker; retain all render data."""
import bpy,pathlib,json,hashlib,struct,shutil
R=pathlib.Path(__file__).resolve().parent;P=R/'D10_directory_09';native=P/'source/section.blend';export=P/'exports/section.glb'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
oldn,oldg=sha(native),sha(export);evidence=P/('dependencies/pre_marker_correction_final' if (P/'qa/MARKER_CORRECTION_RECEIPT.json').exists() else 'dependencies/pre_marker_correction');evidence.mkdir(exist_ok=True)
for p in [native,export]:shutil.copyfile(p,evidence/p.name)
bpy.ops.wm.open_mainfile(filepath=str(native));marker=bpy.data.objects['WP05_MARK_clean_handoff'];assert marker.type=='EMPTY';assert abs(marker.location.x+12)<.001 and any(abs(marker.location.y-y)<.001 for y in [3.7,5.0])
marker.location.x=-11.5;marker.location.y=1.75;marker['approach_revision']='C receiving correction: original target intersected counter'
bpy.context.scene.render.threads_mode='FIXED';bpy.context.scene.render.threads=2;bpy.ops.wm.save_as_mainfile(filepath=str(native))
raw=export.read_bytes();n=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+n]);node=next(x for x in g['nodes'] if x.get('name')==marker.name);assert node['translation'] in [[-12,0,-3.700000047683716],[-12,0,-5]]
node['translation']=[-11.5,0,-1.75];node.setdefault('extras',{})['approach_revision']=marker['approach_revision'];tail=raw[20+n:];j=json.dumps(g,separators=(',',':'),ensure_ascii=False).encode();j+=b' '*((-len(j))%4)
new=struct.pack('<III',0x46546c67,2,20+len(j)+len(tail))+struct.pack('<II',len(j),0x4e4f534a)+j+tail;export.write_bytes(new)
assert hashlib.sha256(tail).hexdigest()==hashlib.sha256(new[20+len(j):]).hexdigest()
contacts=json.loads((P/'exports/RETAINED_contact_markers.json').read_text());m=next(x for x in contacts['markers'] if x['id']=='WP05_MARK_clean_handoff');m['superseded_world_xyz']=m['world_xyz'];m['blender_source']=[-11.5,1.75,0];m['local_gltf']=[-11.5,0,-1.75];m['world_xyz']=[-42.5,61,430.25];m['correction']='Guest-side stance outside unchanged pantry; actual source/cart geometry screened'
(P/'exports/contact_markers.json').write_text(json.dumps(contacts,indent=2))
(P/'qa/MARKER_CORRECTION_RECEIPT.json').write_text(json.dumps(dict(old_native_sha256=oldn,old_glb_sha256=oldg,final_native_sha256=sha(native),final_glb_sha256=sha(export),changed_only_empty_marker='WP05_MARK_clean_handoff',old_world_xyz=[-43,61,428.3],new_world_xyz=[-42.5,61,430.25],GLB_binary_chunk_byte_identical=True,binary_chunk_sha256=hashlib.sha256(tail).hexdigest(),renderable_geometry_material_images_lights_unchanged=True,preview_floor_count=0,installed_acceptance=False),indent=2))
print('MOONFRUIT_MARKER_CORRECTED',sha(native),sha(export),flush=True)
import runpy
runpy.run_path(str(R/'verify_saved_moonfruit.py'),run_name='__main__')
