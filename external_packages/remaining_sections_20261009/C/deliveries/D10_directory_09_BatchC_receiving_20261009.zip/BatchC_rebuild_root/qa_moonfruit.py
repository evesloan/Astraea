"""Fresh exact-byte export screens. No physics or root floor support credit."""
import pathlib,json,sys,math,hashlib,collections
R=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(R));from glb_tools import read_glb,projected_grid,route_check
T=R/'inputs/BlenderCatalogue/assets/windows_section_source_intake_20261007/packages/WP05';P=R/'D10_directory_09'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
path=P/'exports/section.glb';g,nodes=read_glb(path);byname={n['name']:n for n in nodes};groups=collections.defaultdict(list)
for n in nodes:
 if n['extras'].get('instance_id'):groups[n['extras']['instance_id']].append(n)
groupbounds=lambda ns:[[min(n['bounds'][0][k] for n in ns) for k in range(3)],[max(n['bounds'][1][k] for n in ns) for k in range(3)]]
chairs={k:v for k,v in groups.items() if any(n['extras'].get('source_catalogue_id')=='AST-DIN-002' for n in v)}
tables={k:v for k,v in groups.items() if any(n['extras'].get('source_catalogue_id')=='AST-DIN-001' for n in v)}
settings={k:v for k,v in groups.items() if any(n['extras'].get('source_catalogue_id')=='AST-DIN-006' for n in v)}
assert len(chairs)==160 and len(tables)==40 and len(settings)==160
native=json.loads((R/'MOONFRUIT_NATIVE_INSPECTION.json').read_text());nb=json.loads((P/'qa/ACTUAL_SAVED_NATIVE_VERTEX_BOUNDS.json').read_text())
parity=[];bad=[]
for n in nodes:
 b=nb.get(n['name']);assert b is not None,n['name'];mapped=[[b[0][0],b[0][2],-b[1][1]],[b[1][0],b[1][2],-b[0][1]]]
 delta=max(abs(mapped[i][k]-n['bounds'][i][k]) for i in range(2) for k in range(3));parity.append(dict(name=n['name'],max_bounds_delta_m=delta))
 if delta>.005:bad.append('native/export bounds '+n['name'])
 b=n['bounds']
 if b[0][0]<-23.0001 or b[1][0]>23.0001 or b[0][2]<-34.0001 or b[1][2]>34.0001 or b[0][1]<-.0001 or b[1][1]>8.26:bad.append('containment '+n['name'])
cb={k:groupbounds(v) for k,v in chairs.items()};tb={k:groupbounds(v) for k,v in tables.items()}
floor_contacts=[dict(id=k,actual_bottom_y=b[0][1],pass_=abs(b[0][1])<.002) for k,b in list(cb.items())+list(tb.items())]
if any(not x['pass_'] for x in floor_contacts):bad.append('chair/table floor-datum contact')
overlaps=[]
for i,(ka,a) in enumerate(cb.items()):
 for kb,b in list(cb.items())[i+1:]:
  if min(a[1][0],b[1][0])-max(a[0][0],b[0][0])>.001 and min(a[1][2],b[1][2])-max(a[0][2],b[0][2])>.001:overlaps.append([ka,kb])
if overlaps:bad.append('actual chair footprint overlap')
contacts=json.loads((T/'exports/contact_markers.json').read_text());markers=[m for m in contacts['markers'] if m['kind']=='dining_seat_contact'];assert len(markers)==160
approaches=[];seatcontacts=[]
for m in markers:
 place=m['id'].removeprefix('WP05_MARK_');b=tb[m['table_id']];centre=[(b[0][k]+b[1][k])/2 for k in [0,2]];p=m['local_gltf'];dx,dz=p[0]-centre[0],p[2]-centre[1];length=math.hypot(dx,dz)
 approaches.append((place,(p[0]+dx/length*1.15,p[2]+dz/length*1.15)))
 cushion=next(n for n in chairs[place] if 'TailoredCushion' in n['name']);gap=abs(cushion['bounds'][1][1]-p[1]);seatcontacts.append(dict(id=place,actual_cushion_top=cushion['bounds'][1][1],marker_y=p[1],gap_m=gap,pass_=gap<.002))
 if gap>.002:bad.append('seat contact '+place)
polys,grid=projected_grid(nodes,0,1.8);body=[]
for label,pos in approaches:
 for radius in [.3,.65]:
  v=route_check(polys,grid,[pos,pos],radius);v.update(id=label,radius=radius);body.append(v)
  if not v['passed']:bad.append('body approach '+label+' r'+str(radius))
cart=json.loads((R/'inputs/Game/data/architecture/cleaning_cart_contacts.json').read_text());radius=0;height=0
for b in cart['boxes']:
 c,h=b['center'],[x/2 for x in b['size']];radius=max(radius,max(math.hypot(c[0]+sx*h[0],c[2]+sz*h[2]) for sx in [-1,1] for sz in [-1,1]));height=max(height,c[1]+h[1])
for w in cart['wheel_contacts']:radius=max(radius,math.hypot(w['center'][0],w['center'][2])+w['radius']);height=max(height,w['center'][1]+w['radius'])
radius=math.ceil((radius+.02)*100)/100;polys,grid=projected_grid(nodes,0,height+.02)
routes={'arrival_to_care':[(22,28),(1,28),(-11,28),(-11,27.5),(-16.5,27.5),(-16.5,30)],'arrival_to_clean_service':[(22,28),(1,28),(1,0),(1,-5),(-12,-5)],'arrival_to_used_return':[(22,28),(1,28),(1,0),(-10,0),(-10,.5),(-11.4,.5)]}
route_file=P/'docs/CLEAN_CART_ROUTE.json'
if route_file.exists():routes['arrival_to_clean_service']=json.loads(route_file.read_text())['local_GLTF_XZ']
cartresults=[]
for name,route in routes.items():
 v=route_check(polys,grid,route,radius);v.update(name=name,route=route,radius=radius,height=height+.02);cartresults.append(v)
 if not v['passed']:bad.append('cart route '+name)
embedded=all('uri' not in x for x in g['buffers']) and all('bufferView' in x for x in g['images']);assert embedded
out=dict(programme='D10_directory_09',input_native_sha256=sha(T/'source/WP05_moonfruit.blend'),final_native_sha256=sha(P/'source/section.blend'),glb_sha256=sha(path),actual_meshes=len(nodes),actual_places=len(chairs),actual_tables=len(tables),actual_settings=len(settings),world_placement=[-31,61,432],world_roof_y=68.5,native_export_bounds=parity,floor_datum_contacts=floor_contacts,actual_seat_contacts=seatcontacts,chair_overlaps=overlaps,body_approaches=body,cart_source_geometry_routes=cartresults,cart_pin_sha256=sha(R/'inputs/Game/data/architecture/cleaning_cart_contacts.json'),packed_GLB_resources=embedded,normal_max_length_error=max(n['normal_error'] for n in nodes),preview_floor_in_actual_export=False,errors=bad,passed=not bad,scope='Actual GLB triangle projection and source datum/pose screens; no loaded cart physics, six-species certification, independent installed receiving floor or Godot acceptance.')
(P/'qa/FRESH_ACTUAL_EXPORT_QA.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print('MOONFRUIT_ACTUAL_QA',not bad,len(bad),bad[:12])
