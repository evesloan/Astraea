import bpy,pathlib,json,hashlib,math
R=pathlib.Path(__file__).resolve().parent;P=R/'D10_directory_09';T=R/'inputs/BlenderCatalogue/assets/windows_section_source_intake_20261007/packages/WP05'
bpy.ops.wm.open_mainfile(filepath=str(P/'source/section.blend'))
names={x['id'] for x in json.loads((T/'qa/source_geometry.json').read_text())['objects']};dg=bpy.context.evaluated_depsgraph_get();rows={};errors=[]
for name in sorted(names):
 o=bpy.data.objects[name];e=o.evaluated_get(dg);me=e.to_mesh();pts=[o.matrix_world@v.co for v in me.vertices]
 rows[name]=[[min(p[k] for p in pts) for k in range(3)],[max(p[k] for p in pts) for k in range(3)]]
 if not all(math.isfinite(x) for p in pts for x in p):errors.append('Nonfinite '+name)
 if o.type=='MESH' and not me.uv_layers:errors.append('No UV '+name)
 e.to_mesh_clear()
assert not any(o.name.startswith('WP05_SOURCE_PREVIEW_ONLY_floor') for o in bpy.data.objects)
(P/'qa/ACTUAL_SAVED_NATIVE_VERTEX_BOUNDS.json').write_text(json.dumps(rows,indent=2))
(P/'qa/SAVED_NATIVE_RESOURCE_QA.json').write_text(json.dumps(dict(native_sha256=hashlib.sha256((P/'source/section.blend').read_bytes()).hexdigest(),selected_source_objects=len(names),preview_floor_count=0,packed_images=sum(bool(im.packed_file) for im in bpy.data.images),external_file_images=[im.name for im in bpy.data.images if im.source=='FILE' and not im.packed_file],external_libraries=[x.filepath for x in bpy.data.libraries],fonts={o.name:o.data.body for o in bpy.data.objects if o.type=='FONT'},errors=errors,passed=not errors),indent=2))
print('SAVED_NATIVE_VERTEX_RESOURCE_QA',len(rows),errors)
