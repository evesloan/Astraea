"""Actual retained terminal GLB review; preview receiving floor is QA-only."""
import bpy,json,pathlib,hashlib,math
from mathutils import Vector
R=pathlib.Path(__file__).resolve().parent
T=R/'inputs/BlenderCatalogue/assets/windows_section_source_intake_20261007/packages/WP05'
P=R/'D10_directory_09';(P/'qa/views_denoised').mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
native=T/'source/WP05_moonfruit.blend';glb=T/'exports/WP05_moonfruit.glb'
assert sha(native)=='bdb585c326a8136f9dba7a3ce9465599906ab4dbde7fde6dee5936426581592e'
assert sha(glb)=='e4dfc671533bf13d0584f55d8730bef516c2d19b723921306a824f115d5b5700'
bpy.ops.wm.open_mainfile(filepath=str(native))
views=[dict(name=o.name,location=list(o.location),rotation=list(o.rotation_euler),lens=o.data.lens) for o in bpy.data.objects if o.type=='CAMERA' and o.name in ['WP05_arrival','WP05_activity','WP05_booth','WP05_quiet','WP05_service']]
assert len(views)==5 and all(abs(v['location'][2]-1.65)<1e-5 for v in views)
bpy.ops.object.select_all(action='SELECT')
# Delete every native object, including hidden family templates, before actual-export import.
for o in list(bpy.data.objects):bpy.data.objects.remove(o,do_unlink=True)
bpy.ops.import_scene.gltf(filepath=str(glb))
imported=list(bpy.data.objects);light_count=sum(o.type=='LIGHT' for o in imported)
assert light_count==124
# Receiving floor is explicitly root-owned and absent from both delivered artifacts.
bpy.ops.mesh.primitive_plane_add(size=1,location=(0,0,-.002));floor=bpy.context.object;floor.name='QA_ONLY_ROOT_RECEIVING_PREVIEW';floor.scale=(46,68,1)
m=bpy.data.materials.new('QA_root_receiving_warmstone');m.use_nodes=True
b=m.node_tree.nodes.get('Principled BSDF');b.inputs['Base Color'].default_value=(.55,.44,.31,1);b.inputs['Roughness'].default_value=.9
im=bpy.data.images.load(str(R/'inputs/Game/assets/textures/warm_stone.png'));tex=m.node_tree.nodes.new('ShaderNodeTexImage');tex.image=im;tex.interpolation='Closest';m.node_tree.links.new(tex.outputs['Color'],b.inputs['Base Color']);floor.data.materials.append(m)
uv=floor.data.uv_layers.active
for face in floor.data.polygons:
 for li in face.loop_indices:
  q=floor.data.vertices[floor.data.loops[li].vertex_index].co;uv.data[li].uv=(q.x*46/2,q.y*68/2)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=16;scene.cycles.use_denoising=True;scene.cycles.max_bounces=6;scene.render.threads_mode='FIXED';scene.render.threads=2
scene.render.resolution_x=960;scene.render.resolution_y=540;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGBA'
scene.world.use_nodes=True;scene.world.node_tree.nodes.get('Background').inputs['Strength'].default_value=.03
scene.view_settings.view_transform='AgX';scene.render.film_transparent=False
records=[]
for v in sorted(views,key=lambda v:v['name']):
 c=bpy.data.cameras.new(v['name']);o=bpy.data.objects.new(v['name'],c);scene.collection.objects.link(o);o.location=v['location'];o.rotation_euler=v['rotation'];c.lens=v['lens'];c.clip_end=200;scene.camera=o
 file=P/'qa/views_denoised'/(v['name']+'.png');scene.render.filepath=str(file);bpy.ops.render.render(write_still=True)
 records.append(dict(**v,path=str(file.relative_to(P)),bytes=file.stat().st_size,sha256=sha(file),eye_height=1.65,scope='Actual terminal GLB source-only, no Godot acceptance'))
 print('REVIEW_RENDER',v['name'],sha(file),flush=True)
(P/'qa/VIEW_MANIFEST_DENOISED.json').write_text(json.dumps(dict(native_sha256=sha(native),glb_sha256=sha(glb),views=records,actual_export_light_count=light_count,render_engine='Blender 4.3.2 Cycles 16 samples, denoised',preview_floor='QA-only root receiving floor, never saved or exported',ambient_strength=.03,added_fill_lights=0,installed_acceptance=False),indent=2),encoding='utf-8')
