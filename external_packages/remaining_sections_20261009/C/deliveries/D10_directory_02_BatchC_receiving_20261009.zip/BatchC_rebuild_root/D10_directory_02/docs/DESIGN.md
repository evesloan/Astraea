# Sunward dining

A four-part faceted crown converges over the broad arrival cross-hall. Forty six-place tables turn gently toward that shared interior focus in four dining neighbourhoods, with individual pendant light, framed end pockets and a continuous separate serving edge. No exterior window or upper occupied level is proposed.

No gameplay, capacity, live collision, species-wide traversal, performance or installed Godot acceptance is implied. No shared registry entry, hull opening, exterior view, working door or receiving floor was changed. Small signs are editable; no controls are rebound. RMB-focus/E vocabulary is retained.
