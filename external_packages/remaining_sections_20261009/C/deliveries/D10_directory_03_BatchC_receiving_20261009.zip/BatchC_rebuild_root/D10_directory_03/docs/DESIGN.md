# Lantern restaurant

Thirty eight-place dining pockets have fitted privacy backs, deep timber cheek-and-lintel thresholds and low warm lanterns. Three vaulted bays gather these pockets around an offset cross-hall; a separate practical clean-service and used-return edge stays readable. All primary geometry stops at Y68.90 beneath retained theater source downstands.

No gameplay, capacity, live collision, species-wide traversal, performance or installed Godot acceptance is implied. No shared registry entry, hull opening, exterior view, working door or receiving floor was changed. Small signs are editable; no controls are rebound. RMB-focus/E vocabulary is retained.
