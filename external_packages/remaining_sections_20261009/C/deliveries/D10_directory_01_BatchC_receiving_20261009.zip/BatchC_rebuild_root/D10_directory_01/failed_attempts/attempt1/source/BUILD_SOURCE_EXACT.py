"""Batch C bounded source authoring. Run one section per shared-mutex wrapper.
Godot world placement identity. Blender XYZ=(ship X,-ship Z,ship Y).
No occupied floor, shared roof, moving door or exterior window is authored.
"""
import bpy,sys,math,json,hashlib,pathlib,random,shutil
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
from mathutils import Vector,Matrix
R=pathlib.Path(__file__).resolve().parent
if R.name=='source':R=R.parents[1]
I=R/'inputs'
N=int(sys.argv[sys.argv.index('--')+1]); random.seed(8600+N)
cfg=json.loads((I/'SECTION_CONTRACTS.json').read_text())[N];KEY,TITLE,SIDE,Z0=cfg['programme_key'],cfg['name'],cfg['side'],cfg['z0'];INNER=cfg['inner_x'];FY=cfg['floor_y'];CAP=cfg['roof_cap_y'];assert CAP is not None,'Missing approved cap';P=R/KEY
for d in ['source','exports','qa','docs','dependencies']: (P/d).mkdir(parents=True,exist_ok=True)
pending=P/'qa/REBUILD_REQUIRED.json'
if pending.exists():pending.unlink()
if pathlib.Path(__file__).resolve()!=P/'source/BUILD_SOURCE_EXACT.py':shutil.copyfile(__file__,P/'source/BUILD_SOURCE_EXACT.py')
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
A=[];M={};GROUPS={};TEMPLATES={};POINTS=[];CART_POINTS=[];LIGHTS=[];ROUTES=[]
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def xyz(p):return Vector((SIDE*(INNER+p[0]),-(Z0+p[2]),FY+p[1]))
def uv(o):
 if o.type!='MESH':return
 if not o.data.uv_layers:o.data.uv_layers.new(name='UV0')
 for f in o.data.polygons:
  axes=[k for k in range(3) if k!=max(range(3),key=lambda i:abs(f.normal[i]))]
  for li in f.loop_indices:
   v=o.data.vertices[o.data.loops[li].vertex_index].co;o.data.uv_layers.active.data[li].uv=(v[axes[0]]*.5,v[axes[1]]*.5)
def material(name,color,texture=None,emit=False):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Roughness'].default_value=.78
 if texture:
  t=m.node_tree.nodes.new('ShaderNodeTexImage');t.image=bpy.data.images.load(str(I/'Game/assets/textures'/(texture+'.png')));t.image.pack();t.interpolation='Closest';m.node_tree.links.new(t.outputs['Color'],p.inputs['Base Color'])
 if emit:p.inputs['Emission Color'].default_value=(*color,1);p.inputs['Emission Strength'].default_value=2
 M[name]=m
for args in [('stone',(.64,.52,.37),'warm_stone'),('wood',(.35,.16,.07),'warm_walnut'),('ivory',(.75,.7,.54),'ivory_enamel'),('brass',(.52,.42,.23),'champagne_metal'),('cloth',(.2,.32,.28),'teal_weave'),('clay',(.55,.24,.12),'clay_weave'),('staff',(.25,.32,.35),'staff_bluegrey_paint'),('soil',(.09,.055,.025),'dark_rubber'),('leaf',(.11,.27,.10),None),('water',(.08,.31,.32),None),('opal',(1,.82,.52),None,True)]:material(*args)
# Original low-resolution loam grain; distinct from black staff rubber.
im=bpy.data.images.new('C_original_loam_64',width=64,height=64);pixels=[]
for y in range(64):
 for x in range(64):
  t=random.Random(x*31+y*337).random();pixels.extend((.28+.10*t,.18+.08*t,.09+.05*t,1))
im.pixels=pixels;im.filepath_raw=str(P/'source/loam.png');im.file_format='PNG';im.save();im.pack();m=M['soil'];node=m.node_tree.nodes.get('Image Texture');node.image=im
def finish(o,n,mat,sup='ROOT_SLAB',group=None,bevel=.035):
 o.name='C_'+n;o['programme_key']=KEY;o['support_group']=sup;o['group']=group or o.name
 if o.type=='MESH':
  if bevel:
   bpy.context.view_layer.objects.active=o;b=o.modifiers.new('Editable edge rounding','BEVEL');b.width=bevel;b.segments=2
   bpy.ops.object.modifier_apply(modifier=b.name)
  o.data.materials.append(M[mat]);uv(o)
 A.append(o);GROUPS.setdefault(o['group'],[]).append(o);return o
def box(n,p,d,mat='stone',sup='ROOT_SLAB',group=None,bev=.035):
 bpy.ops.mesh.primitive_cube_add(size=1,location=xyz(p));o=bpy.context.object;o.dimensions=(d[0],d[2],d[1]);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 return finish(o,n,mat,sup,group,min(bev,min(d)/4))
def rod(n,a,b,r,mat='wood',sup='ROOT_SLAB',group=None):
 pa,pb=xyz(a),xyz(b);v=pb-pa;bpy.ops.mesh.primitive_cylinder_add(vertices=12,radius=r,depth=v.length,location=(pa+pb)/2);o=bpy.context.object;o.rotation_euler=v.to_track_quat('Z','Y').to_euler();bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,n,mat,sup,group,.012)
def disc(n,u,v,r,y,h,mat='stone',sup='ROOT_SLAB'):return rod(n,(u,y,v),(u,y+h,v),r,mat,sup)
def prism(n,poly,y,h,mat='stone',sup='ROOT_SLAB'):
 nvert=len(poly);vs=[xyz((u,y,v)) for u,v in poly]+[xyz((u,y+h,v)) for u,v in poly];faces=[tuple(reversed(range(nvert))),tuple(range(nvert,2*nvert))]+[(j,(j+1)%nvert,(j+1)%nvert+nvert,j+nvert) for j in range(nvert)];me=bpy.data.meshes.new(n);me.from_pydata(vs,[],faces);me.update();o=bpy.data.objects.new(n,me);bpy.context.collection.objects.link(o)
 # Correct winding deterministically for the reflected port coordinate frame.
 if SIDE==1:
  for f in me.polygons:f.flip()
 return finish(o,n,mat,sup)
def shelter(n,points,sup):
 vs=[xyz((u,y-.09,v)) for u,y,v in points]+[xyz((u,y+.09,v)) for u,y,v in points];faces=[(2,1,0),(3,4,5),(0,1,4,3),(1,2,5,4),(2,0,3,5)];me=bpy.data.meshes.new(n);me.from_pydata(vs,[],faces);me.update();o=bpy.data.objects.new(n,me);bpy.context.collection.objects.link(o)
 if SIDE==1:
  for f in me.polygons:f.flip()
 return finish(o,n,'wood',sup)
def asset(id,n,u,v,y=0,scale=1,yaw=0,sup='ROOT_SLAB'):
 if id not in TEMPLATES:
  m=json.loads((I/'BlenderCatalogue/catalogue_manifest.json').read_text());a=next(a for a in m['assets'] if a['catalogue_id']==id);p=I/'BlenderCatalogue'/a['export'];assert sha(p)==a['export_sha256'];before=set(bpy.data.objects);bpy.ops.import_scene.gltf(filepath=str(p));objs=sorted([o for o in set(bpy.data.objects)-before if o.type=='MESH'],key=lambda o:o.name);templates=[]
  for o in objs:
   mw=o.matrix_world.copy();o.parent=None;o.matrix_world=mw;templates.append(o);o.hide_render=True;o.hide_viewport=True
  for o in set(bpy.data.objects)-before:
   if o.type!='MESH':bpy.data.objects.remove(o,do_unlink=True)
  TEMPLATES[id]=templates
  (P/'dependencies'/(id+'.json')).write_text(json.dumps(a,indent=2))
 t=TEMPLATES[id];pts=[o.matrix_world@Vector(c) for o in t for c in o.bound_box];bottom=min(p.z for p in pts)
 transform=Matrix.Translation(xyz((u,y,v)))@Matrix.Rotation(yaw,4,'Z')@Matrix.Scale(scale,4)@Matrix.Translation(Vector((0,0,-bottom)))
 g='C_'+n
 for j,orig in enumerate(t):
  o=orig.copy();o.data=orig.data;bpy.context.collection.objects.link(o);o.name=g+'_'+str(j);o.hide_render=False;o.hide_viewport=False;o.matrix_world=transform@orig.matrix_world;o['programme_key']=KEY;o['group']=g;o['support_group']=sup;o['catalogue_id']=id;A.append(o);GROUPS.setdefault(g,[]).append(o)
 return g
def sign(n,body,u,v,y,sup):
 panel=box(n+'_plate',(u,y,v),(.09,.5,2.8),'staff',sup)
 cu=bpy.data.curves.new(n,'FONT');cu.body=body;cu.size=.19;cu.extrude=.001;cu.align_x='CENTER';o=bpy.data.objects.new('C_'+n,cu);bpy.context.collection.objects.link(o);o.location=xyz((u-.05,y-.08,v));o.rotation_euler=(math.pi/2,0,SIDE*math.pi/2);o.data.materials.append(M['ivory']);o['programme_key']=KEY;o['group']=o.name;o['support_group']=panel.name;A.append(o);GROUPS[o.name]=[o]
def lamp(n,u,v,h=3.3):
 foot=disc(n+'_base',u,v,.26,0,.12,'brass');stem=rod(n+'_stem',(u,.12,v),(u,h,v),.06,'brass',foot.name);housing=disc(n+'_shade',u,v,.48,h,.16,'wood',stem.name);lens=disc(n+'_lens',u,v,.38,h-.05,.05,'opal',housing.name);LIGHTS.append((u,v,h-.12,650))
def bed(n,u,v,w,l,h=.55):
 b=box(n+'_containment',(u,h/2,v),(w,h,l),'stone');soil=box(n+'_soil',(u,h-.06,v),(w-.28,.12,l-.28),'soil',b.name);return soil.name
def circlebed(n,u,v,r,h=.6):
 base=disc(n+'_vessel',u,v,r,0,h,'stone');soil=disc(n+'_soil',u,v,r-.2,h-.1,.1,'soil',base.name);return soil.name
def bench(n,u,v,yaw=0,cart_offset_v=0):
 g=asset('AST-FUR-001',n,u,v,yaw=yaw);POINTS.append((n,(u-1.8,v)));CART_POINTS.append((n+'_cart_park',(u-2.8,v+cart_offset_v)));return g
def care(u=5,v=8):
 back=box('care_back',(u,1.3,v),(.18,2.6,5),'staff');box('care_top',(u+1.1,2.5,v),(2.2,.18,5),'staff',back.name)
 for vv in (v-2.4,v+2.4):box('care_cheek_'+str(vv),(u+1.1,1.2,vv),(2.2,2.4,.18),'staff',back.name)
 for y in (.35,1.02,1.7):
  shelf=box('care_shelf'+str(y),(u+1.1,y,v),(2.1,.12,4.7),'ivory',back.name)
  for k in range(5):
   z=v-1.8+k*.85;can=disc('care_stock'+str(y)+'_'+str(k),u+1.1,z,.16,y+.06,.35,'clay' if k%2 else 'staff',shelf.name);disc('care_stock_cap'+str(y)+'_'+str(k),u+1.1,z,.11,y+.41,.045,'brass',can.name)
  mount_group='C_care_light_mount'+str(y)
  for k,vv in enumerate((v-2.1,v+2.1)):box('care_light_mount'+str(y)+'_'+str(k),(u+2.1,y+.35,vv),(.1,.7,.08),'staff',shelf.name,mount_group)
  box('care_light_lens'+str(y),(u+2.1,y+.65,v),(.15,.07,4.4),'opal',mount_group);LIGHTS.append((u+2.3,v,y+.60,95))
 sign('care_label','CARE / STOCK',u-.1,v,2.1,back.name);lamp('care_task',u+1.3,v+2.2,2.8);POINTS.append(('care_park',(u+3.2,v)));CART_POINTS.append(('care_park',(u+3.2,v)))
def screen(n,poly,h=4.2):
 for j in range(len(poly)-1):
  a,b=poly[j:j+2];rod(n+'_'+str(j),(a[0],h/2,a[1]),(b[0],h/2,b[1]),.12,'wood','C_'+n+'_fin'+str(j)+'_1')
  # substantial screen panels follow purposeful broken perimeter, with real floor contact
  for k in range(1,10):
   t=k/10;u=a[0]+(b[0]-a[0])*t;v=a[1]+(b[1]-a[1])*t;box(n+'_fin'+str(j)+'_'+str(k),(u,h/2,v),(.16,h,.16),'wood')

material('glass',(.36,.62,.68));M['glass'].node_tree.nodes.get('Principled BSDF').inputs['Alpha'].default_value=.28;M['glass'].diffuse_color=(.36,.62,.68,.28);M['glass'].surface_render_method='DITHERED'
shutil.copyfile(R/'designs.py',P/'source/DESIGNS_EXACT.py')
from designs import construct
design=construct(globals(),N);WALKABLE=design.get('walkable_groups',[]);ROUTES=design['routes'];VIEWS=design['views'];PURPOSE=design['purpose']
# Remove temporary source templates, packing every retained image.
for obs in TEMPLATES.values():
 for o in obs:bpy.data.objects.remove(o,do_unlink=True)
for im in bpy.data.images:
 if im.source=='FILE' and not im.packed_file:
  try:im.pack()
  except RuntimeError:pass
for o in A:
 if o.type=='MESH' and not o.data.uv_layers:uv(o)
for j,(u,v,h,power) in enumerate(LIGHTS):
 d=bpy.data.lights.new('C_fixture_source_'+str(j),'SPOT');d.energy=power;d.spot_size=math.radians(145);d.spot_blend=.6;d.shadow_soft_size=.32;d.color=(1,.82,.60);o=bpy.data.objects.new(d.name,d);bpy.context.collection.objects.link(o);o.location=xyz((u,h,v));o.rotation_euler=(math.pi,0,0) if j in globals().get('UPLIGHT_INDICES',set()) else (0,0,0);o['programme_key']=KEY;A.append(o)
scene=bpy.context.scene;scene.unit_settings.system='METRIC';scene.render.engine='CYCLES';scene.cycles.samples=16;scene.cycles.use_denoising=True;scene.render.threads_mode='FIXED';scene.render.threads=2
bpy.ops.wm.save_as_mainfile(filepath=str(P/'source/section.blend'))
# Editable text remains in native; export duplicates converted curves only.
bpy.ops.object.select_all(action='DESELECT');converted=[]
for o in A:
 if o.type=='FONT':
  c=o.copy();c.data=o.data.copy();bpy.context.collection.objects.link(c);c.name=o.name+'_GLB';c.select_set(True);bpy.context.view_layer.objects.active=c;bpy.ops.object.convert(target='MESH');c=bpy.context.object;uv(c);converted.append(c)
 else:o.select_set(True)
bpy.ops.export_scene.gltf(filepath=str(P/'exports/section.glb'),export_format='GLB',use_selection=True,export_apply=True,export_texcoords=True,export_normals=True,export_extras=True,export_cameras=False,export_lights=True)
for o in converted:bpy.data.objects.remove(o,do_unlink=True)
floor=[(SIDE*INNER,Z0),(SIDE*(INNER+46),Z0),(SIDE*(INNER+46),Z0+68),(SIDE*INNER,Z0+68)]
placement=dict(programme_key=KEY,title=TITLE,placement_xyz=[0,0,0],rotation_y=0,scale=[1,1,1],coordinate_contract='Blender=(X,-Z,Y); GLB Y-up world coordinates; identity placement',floor_y=FY,maximum_source_roof_y=CAP,entry_proposal_xyz=[SIDE*INNER,FY,Z0+34],floor_policy='Root-owned receiving slab; no preview floor in native/export',external_connections='Root owned; unbuilt; proposed entry remains a source threshold only',installed_Godot_acceptance=False)
(P/'docs/PLACEMENT.json').write_text(json.dumps(placement,indent=2))
(P/'docs/FLOOR_PROPOSAL.json').write_text(json.dumps(dict(status='Uninstalled root review proposal',boundary=floor,floor_y=FY,thickness=None,policy='Root receiving surface only: Shared Table must reuse protected aquatic roof top at Y61 without adding a downstand. No floor, slab thickness or penetration authored.'),indent=2))
(P/'docs/DESIGN.md').write_text('# '+TITLE+'\n\n'+PURPOSE+'\n\nNo gameplay, capacity, live collision, species-wide traversal, performance or installed Godot acceptance is implied. No shared registry entry, hull opening, exterior view, working door or receiving floor was changed. Small signs are editable; no controls are rebound. RMB-focus/E vocabulary is retained.\n',encoding='utf-8')
(P/'docs/COUNTS.json').write_text(json.dumps(dict(registered_occupancy=cfg['registered_occupancy'],source_proposed_fixture_counts=design['counts'],policy='No ledger mutation or new gameplay/capacity claim'),indent=2))
(P/'qa/PLAN.json').write_text(json.dumps(dict(walkable_groups=WALKABLE,routes=ROUTES,approaches=POINTS,cart_parking=CART_POINTS,views=VIEWS,lights=LIGHTS),indent=2))
print('BUILD_SAVED',KEY,sha(P/'source/section.blend'),sha(P/'exports/section.glb'),len(A),flush=True)
# Keep this section's dependent saved-file inspection and renders in the same
# serialized Blender job; the inspector reloads both actual saved deliverables.
import runpy
runpy.run_path(str(R/'verify_render.py'),run_name='__main__')
