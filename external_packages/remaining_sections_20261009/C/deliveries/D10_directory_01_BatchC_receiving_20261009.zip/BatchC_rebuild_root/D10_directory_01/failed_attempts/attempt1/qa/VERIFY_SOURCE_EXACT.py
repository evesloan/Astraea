"""Independent saved-native + actual-GLB inspection and ordinary eye-level source views."""
import bpy,sys,json,math,pathlib,hashlib,shutil
from mathutils import Vector,Matrix
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
R=pathlib.Path(__file__).resolve().parent;N=int(sys.argv[sys.argv.index('--')+1]);cfg=json.loads((R/'inputs/SECTION_CONTRACTS.json').read_text())[N];KEY=cfg['programme_key'];P=R/KEY;SIDE=cfg['side'];Z0=cfg['z0'];FY=cfg['floor_y'];INNER=cfg['inner_x'];CAP=cfg['roof_cap_y'];shutil.copyfile(__file__,P/'qa/VERIFY_SOURCE_EXACT.py')
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def xyz(u,y,v):return Vector((SIDE*(INNER+u),-(Z0+v),FY+y))
def bounds(o):
 dg=bpy.context.evaluated_depsgraph_get();e=o.evaluated_get(dg);me=e.to_mesh();points=[o.matrix_world@v.co for v in me.vertices];result=[[min(p[k] for p in points) for k in range(3)],[max(p[k] for p in points) for k in range(3)]];e.to_mesh_clear();return result
def geometry(obs):
 vs=[];faces=[];dg=bpy.context.evaluated_depsgraph_get()
 for o in obs:
  e=o.evaluated_get(dg);me=e.to_mesh();offset=len(vs);vs.extend([e.matrix_world@v.co for v in me.vertices]);me.calc_loop_triangles();faces.extend([tuple(offset+i for i in t.vertices) for t in me.loop_triangles]);e.to_mesh_clear()
 return vs,faces,BVHTree.FromPolygons(vs,faces,all_triangles=True)
bpy.ops.wm.open_mainfile(filepath=str(P/'source/section.blend'));source=[o for o in bpy.data.objects if o.type in ['MESH','FONT']];native={o.name:bounds(o) for o in source};groups={};errors=[];uv_missing=[];degenerate=0
packed_native=all(im.packed_file is not None for im in bpy.data.images if im.source=='FILE')
native_text={o.name:o.data.body for o in source if o.type=='FONT'}
native_text_vertices={o.name:geometry([o])[0] for o in source if o.type=='FONT'}
if not packed_native:errors.append('Unpacked saved native image')
for o in source:
 groups.setdefault(o.get('group',o.name),[]).append(o)
 if o.type=='MESH':
  if not o.data.uv_layers:uv_missing.append(o.name)
  o.data.calc_loop_triangles();degenerate+=sum(t.area<1e-10 for t in o.data.loop_triangles)
 if not o.name.startswith('C_'):errors.append('Unexpected native context '+o.name)
 b=native[o.name];worldx=sorted([SIDE*INNER,SIDE*(INNER+46)])
 if b[0][0]<worldx[0]-.002 or b[1][0]>worldx[1]+.002 or b[0][1]<-(Z0+68)-.002 or b[1][1]>-Z0+.002 or b[0][2]<FY-.002 or b[1][2]>CAP+.002:errors.append('Containment '+o.name+str(b))
if uv_missing:errors.append('UV missing '+str(uv_missing))
if degenerate:errors.append('Degenerate triangles '+str(degenerate))
geo={k:geometry(obs) for k,obs in groups.items()};contacts=[]
for k,obs in groups.items():
 sup=obs[0].get('support_group');vs,fs,bvh=geo[k]
 if sup=='ROOT_SLAB':distance=abs(min(p.z for p in vs)-FY)
 elif sup in geo:
  pvs,pfs,pbvh=geo[sup];distances=[pbvh.find_nearest(p)[3] for p in vs];distance=min(distances)
  if distance>.08:distance=min(distance,min(bvh.find_nearest(p)[3] for p in pvs))
  if distance>.08 and bvh.overlap(pbvh):distance=0
 else:distance=999
 contacts.append(dict(group=k,support=sup,minimum_surface_gap_m=distance,pass_=distance<=.16))
 if distance>.16:errors.append('Unsupported '+k+' -> '+str(sup)+' gap '+str(distance))
plan=json.loads((P/'qa/PLAN.json').read_text());walk=set(plan.get('walkable_groups',[]));walkobs=[o for o in source if o.name in walk];obstacles=[o for o in source if o.name not in walk];allvs,allfaces,allbvh=geometry(obstacles);walkbvh=geometry(walkobs)[2] if walkobs else None;route_receipts=[]
def base_at(a,b,t):return (a[2] if len(a)>2 else 0)*(1-t)+(b[2] if len(b)>2 else 0)*t
checks=plan['routes']+[[pos,pos] for name,pos in plan['approaches']]
for ri,route in enumerate(checks):
 for radius in (.3,.5):
  minimum=999;blocked=[];poses=0
  for a,b in zip(route,route[1:]):
   length=math.dist(a[:2],b[:2])
   for q in range(math.ceil(length/.3)+1):
    t=q/max(1,math.ceil(length/.3));u=a[0]+(b[0]-a[0])*t;v=a[1]+(b[1]-a[1])*t;poses+=1
    for h in (.18,.6,1.2,1.8):
     distance=allbvh.find_nearest(xyz(u,base_at(a,b,t)+h,v))[3];minimum=min(minimum,distance)
     if distance<radius-.001:blocked.append([round(u,2),round(v,2),h,round(distance,3)])
  receipt=dict(route_index=ri,envelope_radius_m=radius,sample_heights_m=[.18,.6,1.2,1.8],poses=poses,min_surface_distance_m=minimum,blocked_samples=blocked[:20],pass_=not blocked);route_receipts.append(receipt)
  if blocked:errors.append('Route '+str(ri)+' radius '+str(radius)+' blocked '+str(blocked[:3]))
# Project actual clipped source surfaces across the full body/cart height.
# The cart envelope is derived from every pinned compound box and caster, and
# conservatively supports any in-place orientation, rather than a 1m circle.
cart_file=R/'inputs/Game/data/architecture/cleaning_cart_contacts.json';cart=json.loads(cart_file.read_text());radial=0;cart_height=0
for a in cart['boxes']:
 c,h=a['center'],[x/2 for x in a['size']]
 radial=max(radial,max(math.hypot(c[0]+sx*h[0],c[2]+sz*h[2]) for sx in (-1,1) for sz in (-1,1)));cart_height=max(cart_height,c[1]+h[1])
for a in cart['wheel_contacts']:
 radial=max(radial,math.hypot(a['center'][0],a['center'][2])+a['radius']);cart_height=max(cart_height,a['center'][1]+a['radius'])
cart_radius=math.ceil((radial+.02)*100)/100
def clip_height(poly,h,lower):
 if not poly:return []
 result=[];prev=poly[-1];ip=prev.z>=h if lower else prev.z<=h
 for curr in poly:
  ic=curr.z>=h if lower else curr.z<=h
  if ic!=ip:result.append(prev.lerp(curr,(h-prev.z)/(curr.z-prev.z)))
  if ic:result.append(curr)
  prev=curr;ip=ic
 return result
def projected_grid(height,base=0):
 polygons=[];grid={};cell=3.0
 for f in allfaces:
  p=clip_height(clip_height([allvs[k] for k in f],FY+base-.01,True),FY+base+height,False)
  if not p:continue
  xy=[Vector((v.x,v.y)) for v in p];idx=len(polygons);polygons.append(xy)
  for x in range(math.floor(min(v.x for v in xy)/cell),math.floor(max(v.x for v in xy)/cell)+1):
   for y in range(math.floor(min(v.y for v in xy)/cell),math.floor(max(v.y for v in xy)/cell)+1):grid.setdefault((x,y),[]).append(idx)
 return polygons,grid
def polygon_distance(p,poly):
 crosses=[];minimum=999
 for a,b in zip(poly,poly[1:]+poly[:1]):
  e=b-a;crosses.append(e.x*(p.y-a.y)-e.y*(p.x-a.x));den=e.length_squared;t=max(0,min(1,(p-a).dot(e)/den)) if den else 0;minimum=min(minimum,(p-(a+t*e)).length)
 area=sum(a.x*b.y-b.x*a.y for a,b in zip(poly,poly[1:]+poly[:1]))
 if abs(area)>1e-9 and (all(c>=-1e-8 for c in crosses) or all(c<=1e-8 for c in crosses)):return 0
 return minimum
full_envelopes=[]
for label,radius,height in [('body',.3,1.8),('pinned_compound_cart_all_yaws',cart_radius,cart_height+.02)]:
 cache={}
 envelope_checks=plan['routes']+[[pos,pos] for name,pos in plan['approaches' if label=='body' else 'cart_parking']]
 for ri,route in enumerate(envelope_checks):
  blocked=[];minimum=999;poses=0
  for a,b in zip(route,route[1:]):
   steps=max(1,math.ceil(math.dist(a[:2],b[:2])/.3))
   for q in range(steps+1):
    t=q/steps;u=a[0]+(b[0]-a[0])*t;v=a[1]+(b[1]-a[1])*t;base=base_at(a,b,t);bucket=round(base,2);
    if bucket not in cache:cache[bucket]=projected_grid(height,bucket)
    polygons,grid=cache[bucket];p3=xyz(u,base,v);p=Vector((p3.x,p3.y));poses+=1;candidates=set()
    if walkbvh:
     overhead=walkbvh.ray_cast(xyz(u,CAP-FY+.1,v),Vector((0,0,-1)),CAP-FY+.2)
     if overhead[0] is not None and overhead[0].z>FY+base+.035:errors.append('Route below raised source programme surface '+str((u,v,base,overhead[0].z-FY)))
    if base>.03:
     contact=walkbvh.ray_cast(xyz(u,base+.06,v),Vector((0,0,-1)),.14) if walkbvh else (None,None,None,None)
     if contact[0] is None:errors.append('No local terrace/ramp bearing at '+str((u,v,base)))
    for x in range(math.floor((p.x-radius)/3),math.floor((p.x+radius)/3)+1):
     for y in range(math.floor((p.y-radius)/3),math.floor((p.y+radius)/3)+1):candidates.update(grid.get((x,y),[]))
    distance=min((polygon_distance(p,polygons[k]) for k in candidates),default=999);minimum=min(minimum,distance)
    if distance<radius-.001:blocked.append([round(u,2),round(v,2),round(distance,3)])
  full_envelopes.append(dict(envelope=label,route_index=ri,radius_m=radius,full_height_m=height,poses=poses,min_projected_surface_distance_m=minimum,blocked=blocked[:12],pass_=not blocked))
  if blocked:errors.append('Full-height '+label+' route '+str(ri)+' blocked '+str(blocked[:3]))
# Compare independently loaded actual GLB mesh world bounds and attributes.
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);bpy.ops.import_scene.gltf(filepath=str(P/'exports/section.glb'))
actual=[o for o in bpy.data.objects if o.type=='MESH'];export_bounds={o.name:bounds(o) for o in actual};parity=[]
for name,b in native.items():
 n=name if name in export_bounds else name+'_GLB';e=export_bounds.get(n);delta=max(abs(b[i][j]-e[i][j]) for i in range(2) for j in range(3)) if e else 999;parity.append(dict(native=name,export=n,max_bound_delta_m=delta))
 if delta>.005:errors.append('Native/GLB bounds '+name+' delta '+str(delta))
for o in actual:
 if not o.data.uv_layers:errors.append('Export UV missing '+o.name)
 if any(not math.isfinite(v.co[k]) for v in o.data.vertices for k in range(3)):errors.append('Export nonfinite '+o.name)
text_parity=[]
for name,pts in native_text_vertices.items():
 ob=next((o for o in actual if o.name in [name,name+'_GLB']),None);got=geometry([ob])[0] if ob else []
 if not got:errors.append('Missing exported text '+name);continue
 def directed(a,b):
  tree=KDTree(len(b))
  for j,p in enumerate(b):tree.insert(p,j)
  tree.balance();return max(tree.find(p)[2] for p in a)
 gap=max(directed(pts,got),directed(got,pts));text_parity.append(dict(name=name,body=native_text[name],symmetric_vertex_hausdorff_m=gap))
 if gap>.003:errors.append('Text geometry parity '+name+' '+str(gap))
if len(actual)!=len(source):errors.append('Native/export count mismatch '+str((len(source),len(actual))))
# inspect actual embedded glTF buffer/image references
import struct
raw=(P/'exports/section.glb').read_bytes();jlen,jtype=struct.unpack_from('<II',raw,12);gltf=json.loads(raw[20:20+jlen]);resources=all('uri' not in a for a in gltf.get('buffers',[])) and all('bufferView' in a for a in gltf.get('images',[]))
if not resources:errors.append('External GLB resource')
normal_attributes=all('NORMAL' in p['attributes'] and 'TEXCOORD_0' in p['attributes'] for m in gltf.get('meshes',[]) for p in m['primitives'])
if not normal_attributes:errors.append('GLB normals/UV attributes missing')
protected=[]
# Saved-native bounds are tested against actual pinned protected plan volumes.
volumes=json.loads((R/'inputs/PROTECTED_VOLUMES.json').read_text())
for a in volumes['voids']:
 if cfg['deck'] not in a.get('decks',[]):continue
 poly=a['boundary'];xs=[p[0] for p in poly];zs=[p[1] for p in poly];hits=[]
 for name,bb in native.items():
  if min(bb[1][0],max(xs))-max(bb[0][0],min(xs))>1e-5 and min(-bb[0][1],max(zs))-max(-bb[1][1],min(zs))>1e-5:hits.append(name)
 protected.append(dict(id=a['id'],native_AABB_intersections=hits,policy='Conservative protected plan AABB; no new void or source overlap'))
 if hits:errors.append('Protected void intersection '+a['id']+' '+str(hits[:5]))
for a in volumes['core_reservations']+volumes['staff_riser_reservations']:
 if cfg['deck'] not in a.get('decks',[]):continue
 xs=a.get('lobby_x',a.get('x'));zs=a.get('lobby_z',a.get('z'));hits=[name for name,bb in native.items() if min(bb[1][0],xs[1])-max(bb[0][0],xs[0])>1e-5 and min(-bb[0][1],zs[1])-max(-bb[1][1],zs[0])>1e-5]
 protected.append(dict(id=a['id'],native_AABB_intersections=hits,policy='Full root core/lobby protected envelope'))
 if hits:errors.append('Protected core '+a['id']+' '+str(hits[:5]))
for name,bb in native.items():
 u=sorted([SIDE*bb[0][0]-INNER,SIDE*bb[1][0]-INNER]);v=sorted([-bb[0][1]-Z0,-bb[1][1]-Z0])
 if min(u[1],2)-max(u[0],0)>1e-5 and min(v[1],36)-max(v[0],32)>1e-5 and bb[0][2]<FY+2.65:errors.append('Root portal keep-clear obstruction '+name)
receipt=dict(section=KEY,native_sha256=sha(P/'source/section.blend'),glb_sha256=sha(P/'exports/section.glb'),native_objects=len(source),export_meshes=len(actual),containment_cap_y=CAP,uv_missing=uv_missing,degenerate_triangles=degenerate,packed_native_images=packed_native,embedded_GLB_resources=resources,normal_attributes=normal_attributes,native_text_bodies=native_text,text_geometry_parity=text_parity,native_export_parity=parity,contacts=contacts,local_programme_walkable_groups=sorted(walk),local_programme_walk_bearing_scope='Every elevated body/cart route sample ray-tested against actual saved native terrace/ramp surfaces; no floor route may pass below raised programme geometry.',root_slab_contacts_are_proposed=True,root_slab_contact_scope='Floor datum and bounded floor proposal only; actual receiving slab and supported runtime traversal remain root work',routes=route_receipts,full_height_envelope_checks=full_envelopes,pinned_cart_envelope=dict(source_sha256=sha(cart_file),compound_boxes=len(cart['boxes']),caster_spheres=len(cart['wheel_contacts']),actual_max_corner_radius_m=radial,test_radius_with_margin_m=cart_radius,actual_max_height_m=cart_height,orientation_scope='Conservative all-yaw circle; full source surface projection across actual compound cart height'),protected_neighbour_geometry=protected,errors=errors,passed=not errors,scope='Saved native and actual GLB source checks. Sampled body/cart geometric approaches; no loaded physics or installed Godot acceptance.')
(P/'qa/validation.json').write_text(json.dumps(receipt,indent=2));print('SOURCE_QA',KEY,'PASS' if not errors else 'FAIL',errors[:30],flush=True)
if errors:sys.exit(2)
# Render reloaded final native. All preview floor/lighting/cameras exist only in this unsaved QA scene.
bpy.ops.wm.open_mainfile(filepath=str(P/'source/section.blend'))
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=12;scene.cycles.use_denoising=True;scene.render.threads_mode='FIXED';scene.render.threads=2;scene.render.resolution_x=960;scene.render.resolution_y=540;scene.render.resolution_percentage=100
scene.world.use_nodes=True;scene.world.node_tree.nodes.get('Background').inputs['Color'].default_value=(.3,.36,.4,1);scene.world.node_tree.nodes.get('Background').inputs['Strength'].default_value=.03
bpy.ops.mesh.primitive_cube_add(size=1,location=xyz(23,-.12,34));floor=bpy.context.object;floor.name='QA_ONLY_ROOT_SLAB';floor.dimensions=(46,.24,68) if False else (46,68,.24);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);floor.data.materials.append(bpy.data.materials['stone'])
# soften room context with diffuse receiving slab; no invented shared ceiling or window
# Render only actual native fixture sources; no supplemental fill.
camera_data=bpy.data.cameras.new('QA_EYE_1_65');camera=bpy.data.objects.new('QA_EYE_1_65',camera_data);bpy.context.collection.objects.link(camera);scene.camera=camera;camera_data.lens=24
views=[]
for name,pos,target in plan['views']:
 eye=1.65+(pos[2] if len(pos)>2 else 0);aim=1.65+(target[2] if len(target)>2 else 0);camera.location=xyz(pos[0],eye,pos[1]);direction=xyz(target[0],aim,target[1])-camera.location;camera.rotation_euler=direction.to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(P/'qa'/(name+'.png'));bpy.ops.render.render(write_still=True);views.append(dict(file=name+'.png',camera_world_xyz=[SIDE*(INNER+pos[0]),FY+eye,Z0+pos[1]],look_world_xyz=[SIDE*(INNER+target[0]),FY+aim,Z0+target[1]],sha256=sha(P/'qa'/(name+'.png'))))
(P/'qa/view_receipt.json').write_text(json.dumps(dict(native_sha256=receipt['native_sha256'],glb_sha256=receipt['glb_sha256'],eye_height_m=1.65,lens_mm=24,views=views,source_only=True,preview_context='QA-only root receiving slab and actual saved-native source lights, no supplemental fill. Nothing saved back into native.'),indent=2))
print('FOUR_EYE_VIEWS_SAVED',KEY,flush=True)
