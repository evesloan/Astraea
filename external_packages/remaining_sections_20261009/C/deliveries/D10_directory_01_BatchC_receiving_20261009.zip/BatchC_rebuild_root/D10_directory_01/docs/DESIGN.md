# The shared table

Three inhabited timber vaults organize 24 ten-place communal tables. The central cross-hall reveals all three gathering naves before guests choose a long-table group; quiet end pockets and a fitted clean/used service edge retain a single level receiving surface.

No gameplay, capacity, live collision, species-wide traversal, performance or installed Godot acceptance is implied. No shared registry entry, hull opening, exterior view, working door or receiving floor was changed. Small signs are editable; no controls are rebound. RMB-focus/E vocabulary is retained.
