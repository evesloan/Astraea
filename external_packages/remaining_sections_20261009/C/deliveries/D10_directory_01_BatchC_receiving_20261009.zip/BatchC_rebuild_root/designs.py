"""Three original dining compositions, each with 240 actual furnished places."""
import math,json
def construct(g,N):
 b,r,pr,sh,a,d,sign=[g[k] for k in ['box','rod','prism','shelter','asset','disc','sign']]
 SIDE=g['SIDE'];FY=g['FY'];cap=g['CAP']-FY;points=g['POINTS'];parks=g['CART_POINTS'];lights=g['LIGHTS']
 seats=[];tables=[];settings=[]
 def wall(n,u,v,w,l,h=7.7):return b(n,(u,h/2,v),(w,h,l),'ivory')
 # Thick inward boundaries preserve the exact four-metre public portal.
 wall('arrival_fore',.2,16,.4,32,cap-.15);wall('arrival_aft',.2,52,.4,32,cap-.15)
 fore_reveal=b('deep_arrival_fore',(1,1.8,31.8),(2,3.6,.4),'wood')
 b('deep_arrival_aft',(1,1.8,36.2),(2,3.6,.4),'wood')
 b('deep_arrival_lintel',(1,3.7,34),(2,.2,4.4),'wood',fore_reveal.name)
 sign('identity',['SHARED TABLE','SUNWARD DINING','LANTERN'][N],.45,30.2,2.4,'C_arrival_fore')
 wall('fore',23,.2,46,.4,cap-.15);wall('aft',23,67.8,46,.4,cap-.15)
 # Root owns the external continuation of two bounded service wall contacts.
 for j,(lo,hi) in enumerate([(0,7.3),(10.7,47.3),(50.7,68)]):wall('service_boundary_'+str(j),45.8,(lo+hi)/2,.4,hi-lo,cap-.15)
 # Local finishing/clean stock and used-return have different guest stances and rear extraction paths.
 for j,v in enumerate([6,8.4,10.8,13.2,15.6]):
  base=a('AST-HSP-001','clean_pantry_'+str(j),42.3,v,yaw=-SIDE*math.pi/2)
  if j in [1,3]:a('AST-HSP-003','beverage_'+str(j),42.3,v,y=.9,yaw=-SIDE*math.pi/2,sup=base)
 a('AST-HSP-005','clean_service_credenza',42.3,22,yaw=-SIDE*math.pi/2)
 a('AST-HSP-004','used_return',42.3,48,yaw=-SIDE*math.pi/2)
 a('AST-HSP-006','used_trolley',44.5,53,yaw=-SIDE*math.pi/2)
 wall('service_screen_fore',41.5,25.5,.25,7,3.2);wall('service_screen_aft',41.5,55.5,.25,3,3.2)
 clean_mast=r('clean_sign_mast',(41.85,0,12),(41.85,2.7,12),.065,'brass','ROOT_SLAB')
 used_mast=r('used_sign_mast',(41.85,.9,48),(41.85,2.4,48),.065,'brass','C_used_return')
 sign('clean_sign','FINISH / CLEAN SERVICE',41.85,12,2.5,clean_mast.name)
 sign('return_sign','USED DISHES',41.85,48,2.2,used_mast.name)
 g['care'](41.5,63)
 points.extend([('clean_guest',(40,12)),('used_guest',(40,48))]);parks.extend([('clean_rear',(44.4,12)),('used_rear',(44.4,48))])
 def pendant(n,u,v,top,support,low=3.7,power=950):
  stem=r(n+'_drop',(u,low+.12,v),(u,top,v),.035,'brass',support)
  housing=d(n+'_hood',u,v,.38,low,.12,'wood',stem.name)
  d(n+'_opal',u,v,.31,low-.035,.035,'opal',housing.name);lights.append((u,v,low-.07,power))
  d(n+'_upper_opal',u,v,.29,low+.12,.025,'opal',housing.name)
  g.setdefault('UPLIGHT_INDICES',set()).add(len(lights));lights.append((u,v,low+.17,power*.4))
 def chair(table,u,v,yaw,approach):
  name='place_%03d'%(len(seats)+1);group=a('AST-DIN-002',name,u,v,yaw=yaw)
  seats.append(dict(id=g['KEY']+'-'+name,group=group,local_uv=[u,v],seat_height=.49,table=table,source_catalogue_id='AST-DIN-002'))
  points.append((name,approach));return group
 def plate(table,n,u,v):
  o=d('setting_'+n,u,v,.16,.791,.018,'ivory',table)
  cup=d('cup_'+n,u+.20,v,.065,.791,.14,'clay',table)
  settings.append(dict(plate=o.name,cup=cup.name,table=table))
 if N==0:
  # Three parallel communal naves, with a shared cross-hall at the actual arrival.
  columns={}
  for u in [7,17,19,29,31,41]:
   columns[u]=[]
   for v in [1,18,50,67]:columns[u].append(wall('nave_pier_'+str(u)+'_'+str(v),u,v,.55,.6,6.2))
  roof_groups=[]
  for j,(lo,hi) in enumerate([(7,17),(19,29),(31,41)]):
   mid=(lo+hi)/2
   for k,(va,vb) in enumerate([(1,34),(34,67)]):
    for t,pts in enumerate([[(lo,6.2,va),(mid,7.2,va),(mid,7.2,vb)],[(lo,6.2,va),(mid,7.2,vb),(lo,6.2,vb)],[(mid,7.2,va),(hi,6.2,va),(hi,6.2,vb)],[(mid,7.2,va),(hi,6.2,vb),(mid,7.2,vb)]]):
     base='C_shared_vault_'+str(j)+'_'+str(k)+'_'
     support=base+'1' if t==0 else base+'2' if t==3 else 'C_nave_pier_'+str(lo if t==1 else hi)+'_'+str(18 if k==0 else 50)
     roof_groups.append(sh('shared_vault_'+str(j)+'_'+str(k)+'_'+str(t),pts,support).name)
   for v in [5,13,21,29,39,47,55,63]:
    table=a('AST-DIN-007','communal_%02d'%len(tables),mid,v,yaw=math.pi/2);tables.append(table)
    for side in [-1,1]:
     for z in [-2.1,-1.05,0,1.05,2.1]:
      chair(table,mid+side*1.15,v+z,-side*SIDE*math.pi/2,(mid+side*2.25,v+z));plate(table,str(len(seats)),mid+side*.48,v+z)
    pendant('shared_pendant_'+str(len(tables)),mid,v,7.11,roof_groups[j*8+(0 if v<34 else 4)],3.8,1200)
  purpose='Three inhabited timber vaults organize 24 ten-place communal tables. The central cross-hall reveals all three gathering naves before guests choose a long-table group; quiet end pockets and a fitted clean/used service edge retain a single level receiving surface.'
  routes=[[(0,34),(4,34),(39.7,34)],[(4,34),(4,4)],[(4,34),(4,64)],[(39.7,34),(39.7,12),(40,12)],[(39.7,34),(39.7,48),(40,48)],[(39.7,34),(39.7,59),(44.7,59),(44.7,63)],[(39.7,34),(44.4,34),(44.4,12)],[(44.4,34),(44.4,48)]]
  views=[('arrival',[3,34],[24,39]),('communal_nave',[20,35],[12,21]),('shared_tables',[4,14],[24,21]),('clean_threshold',[40,18],[42.3,12]),('quiet_end',[25,66],[24,55])]
 elif N==1:
  # Faceted radial crown and four fan-shaped neighbourhoods; no upper occupied deck.
  for u,v in [(1,1),(45,1),(45,67),(1,67)]:wall('sunward_corner_'+str(u)+'_'+str(v),u,v,.6,.6,6.8)
  roof=[];corners=[(1,6.8,1),(45,6.8,1),(45,6.8,67),(1,6.8,67)]
  for j in range(4):roof.append(sh('sunward_fan_'+str(j),[corners[j],corners[(j+1)%4],(23,7.85,34)],'C_sunward_corner_'+str(corners[j][0])+'_'+str(corners[j][2])).name)
  # Retained six-place source derivative stays inside its registered parent family.
  catalogue=json.loads((g['I']/'BlenderCatalogue/catalogue_manifest.json').read_text());row=next(x for x in catalogue['assets'] if x['catalogue_id']=='AST-DIN-001')
  variant=g['I']/'BlenderCatalogue/assets/vesper_dining_furniture/exports/AST-DIN-001_six.glb'
  assert g['sha'](variant)=='f22ad268b06e8e57b7cae316ab1d290890d92f6bc1c17eb8ab5bc9594f641509'
  assert g['sha'](g['I']/'BlenderCatalogue/assets/vesper_dining_furniture/source/AST-DIN-001_six.blend')=='db01ad1026337ef400c1378cbc17497fc2fcef1275d527a846d07cf2ade73fab'
  before=set(g['bpy'].data.objects);g['bpy'].ops.import_scene.gltf(filepath=str(variant));obs=[]
  imported=set(g['bpy'].data.objects)-before
  for o in sorted([o for o in imported if o.type=='MESH'],key=lambda o:o.name):
   mw=o.matrix_world.copy();o.parent=None;o.matrix_world=mw;o.hide_render=True;o.hide_viewport=True;obs.append(o)
  for o in imported:
   if o.type!='MESH':g['bpy'].data.objects.remove(o,do_unlink=True)
  g['TEMPLATES']['AST-DIN-001']=obs
  (g['P']/'dependencies/AST-DIN-001_six.json').write_text(json.dumps(dict(parent_id='AST-DIN-001',source='assets/vesper_dining_furniture/source/AST-DIN-001_six.blend',source_sha256=g['sha'](g['I']/'BlenderCatalogue/assets/vesper_dining_furniture/source/AST-DIN-001_six.blend'),export=str(variant.relative_to(g['I']/'BlenderCatalogue')),export_sha256=g['sha'](variant),count=6),indent=2))
  for ci,u in enumerate([10,19,28,37]):
   for vi,v in enumerate([5,11,17,23,29,39,45,51,57,63]):
    angle=math.radians((-1 if ci<2 else 1)*(12 if v<34 else -12));table=a('AST-DIN-001','sunward_table_%02d'%len(tables),u,v,yaw=angle);tables.append(table)
    # Transform each exact six-place family contact with the tabletop.
    for sx,sy in [(-.62,-1.08),(.62,-1.08),(-.62,1.08),(.62,1.08),(-1.54,0),(1.54,0)]:
     X=sx*math.cos(angle)-sy*math.sin(angle);Y=sx*math.sin(angle)+sy*math.cos(angle)
     U=u+SIDE*X;V=v-Y;direction=math.atan2(-X,Y)
     norm=math.hypot(X,Y);chair(table,U,V,direction,(U+SIDE*X/norm*1.05,V-Y/norm*1.05));plate(table,str(len(seats)),u+SIDE*X*.43,v-Y*.43)
    top=6.8+1.05*(1-max(abs(u-23)/22,abs(v-34)/33))-.09
    # Contact is to the actual sloped crown, not an invented receiving ceiling.
    support=roof[0 if v<34 and abs(v-34)/33>=abs(u-23)/22 else 2 if v>=34 and abs(v-34)/33>=abs(u-23)/22 else 1 if u>=23 else 3]
    pendant('sunward_pendant_'+str(len(tables)),u,v,top,support,3.9,1000)
  purpose='A four-part faceted crown converges over the broad arrival cross-hall. Forty six-place tables turn gently toward that shared interior focus in four dining neighbourhoods, with individual pendant light, framed end pockets and a continuous separate serving edge. No exterior window or upper occupied level is proposed.'
  routes=[[(0,34),(4,34),(40,34)],[(4,34),(4,4)],[(4,34),(4,64)],[(40,34),(40,12)],[(40,34),(40,48)],[(40,34),(40,59),(44.7,59),(44.7,63)],[(40,34),(44.4,34),(44.4,12)],[(44.4,34),(44.4,48)]]
  views=[('arrival',[3,34],[28,29]),('fan_dining',[5,20],[28,23]),('crown_focus',[23,34],[37,39]),('serving_edge',[40,20],[42.3,12]),('restful_end',[21,66],[19,57])]
 else:
  # Five lines of enclosed dining pockets, gathered beneath three lantern bays.
  for u in [1,15,31,45]:
   for v in ([1,67] if u==1 else [1,34,67]):wall('lantern_pier_'+str(u)+'_'+str(v),u,v,.6,.7,6.1)
  roof=[]
  for j,(lo,hi) in enumerate([(1,15),(15,31),(31,45)]):
   mid=(lo+hi)/2
   for k,(va,vb) in enumerate([(1,34),(34,67)]):
    for t,pts in enumerate([[(lo,6.1,va),(mid,7.2,va),(mid,7.2,vb)],[(lo,6.1,va),(mid,7.2,vb),(lo,6.1,vb)],[(mid,7.2,va),(hi,6.1,va),(hi,6.1,vb)],[(mid,7.2,va),(hi,6.1,vb),(mid,7.2,vb)]]):
     base='C_lantern_vault_'+str(j)+'_'+str(k)+'_'
     support=base+'1' if t==0 else base+'2' if t==3 else 'C_lantern_pier_'+str(lo if t==1 else hi)+'_'+str(67 if t==1 and lo==1 and va==34 else va)
     roof.append(sh('lantern_vault_'+str(j)+'_'+str(k)+'_'+str(t),pts,support).name)
  for u in [8,15,22,29,36]:
   for v in [6,16,26,42,52,62]:
    table=a('AST-DIN-007','lantern_table_%02d'%len(tables),u,v,yaw=math.pi/2);tables.append(table)
    for side in [-1,1]:
     wall('booth_back_'+str(len(tables))+'_'+str(side),u+side*3,v,.14,6.2,1.35)
     for z in [-1.8,-.6,.6,1.8]:chair(table,u+side*1.4,v+z,-side*SIDE*math.pi/2,(u+side*2.4,v+z));plate(table,str(len(seats)),u+side*.48,v+z)
    # Low lantern mounts meet their local timber pier/header frame directly.
    header=wall('booth_header_'+str(len(tables)),u,v-3.1,6.0,.2,3.0)
    # Replace solid header infill with two standing cheeks and a genuinely deep overhead lintel.
    g['A'].remove(header);g['GROUPS'].pop(header['group']);g['bpy'].data.objects.remove(header,do_unlink=True)
    left=wall('booth_cheek_'+str(len(tables))+'_L',u-3,v-3.1,.2,.3,3.0)
    wall('booth_cheek_'+str(len(tables))+'_R',u+3,v-3.1,.2,.3,3.0)
    lintel=b('booth_lintel_'+str(len(tables)),(u,2.92,v-3.1),(6,.16,.3),'wood',left.name)
    pendant('lantern_'+str(len(tables)),u,v-3.1,2.84,lintel.name,2.55,450)
  purpose='Thirty eight-place dining pockets have fitted privacy backs, deep timber cheek-and-lintel thresholds and low warm lanterns. Three vaulted bays gather these pockets around an offset cross-hall; a separate practical clean-service and used-return edge stays readable. All primary geometry stops at Y68.90 beneath retained theater source downstands.'
  routes=[[(0,34),(3,34),(3,35.5),(40,35.5)],[(3,35.5),(3,4)],[(3,35.5),(3,64)],[(40,35.5),(40,12)],[(40,35.5),(40,48)],[(40,35.5),(40,59),(44.7,59),(44.7,63)],[(40,35.5),(44.4,35.5),(44.4,12)],[(44.4,35.5),(44.4,48)]]
  views=[('arrival',[3,34],[22,42]),('lantern_pockets',[11.5,35.5],[22,26]),('fitted_table',[22,35.5],[22,42]),('used_return',[40,44],[42.3,48]),('quiet_bay',[26,65],[22,62])]
 assert len(seats)==240 and len(settings)==240
 for name,pos in [('clean_guest',(40,12)),('used_guest',(40,48)),('care',(44.7,63))]:pendant('service_light_'+name,pos[0],pos[1],3.8,'C_service_boundary_1',2.8,500)
 # Service pendant transfer brackets meet the owned service wall above body clearance.
 for name,pos in [('clean_guest',(40,12)),('used_guest',(40,48)),('care',(44.7,63))]:
  stem=next(o for o in g['A'] if o.name=='C_service_light_'+name+'_drop');stem['support_group']='C_service_mount_'+name
  r('service_mount_'+name,(45.6,3.8,51 if name=='used_guest' else pos[1]),(pos[0],3.8,pos[1]),.07,'brass','C_service_boundary_1' if name=='clean_guest' else 'C_service_boundary_2')
 (g['P']/'docs/PLACE_CROSSWALK.json').write_text(json.dumps(dict(programme=g['KEY'],actual_modeled_places=seats,tables=tables,settings=settings,capacity=240,counts_are_source_only=True,six_species_and_operating_use='Not tested'),indent=2))
 return dict(purpose=purpose,routes=routes,views=views,counts=dict(modeled_dining_places=240,tables=len(tables),settings=240,clean_service_counters=5,beverage_stations=2,used_return=1,service_trolley=1),walkable_groups=[])
