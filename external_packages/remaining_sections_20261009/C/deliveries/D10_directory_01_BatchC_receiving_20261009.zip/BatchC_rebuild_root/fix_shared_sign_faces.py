"""Bounded FONT-only correction; unchanged non-text source geometry is proved."""
import bpy, pathlib, sys, math, json, hashlib, struct, runpy
R=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(R));P=R/'D10_directory_01'
def digest():
 h=hashlib.sha256()
 for o in sorted([o for o in bpy.data.objects if o.type=='MESH'],key=lambda o:o.name):
  h.update(o.name.encode());h.update(struct.pack('<16d',*[x for row in o.matrix_world for x in row]))
  for v in o.data.vertices:h.update(struct.pack('<3d',*v.co))
  for f in o.data.polygons:h.update(struct.pack('<I',len(f.vertices)));h.update(struct.pack('<'+'I'*len(f.vertices),*f.vertices))
  for layer in o.data.uv_layers:
   for uv in layer.data:h.update(struct.pack('<2d',*uv.uv))
 return h.hexdigest()
def uv(o):
 if not o.data.uv_layers:o.data.uv_layers.new(name='UV0')
 for f in o.data.polygons:
  axes=[k for k in range(3) if k!=max(range(3),key=lambda i:abs(f.normal[i]))]
  for li in f.loop_indices:
   v=o.data.vertices[o.data.loops[li].vertex_index].co;o.data.uv_layers.active.data[li].uv=(v[axes[0]]*.5,v[axes[1]]*.5)
bpy.ops.wm.open_mainfile(filepath=str(P/'source/section.blend'));before=digest();fonts=[]
for o in bpy.data.objects:
 if o.type=='FONT':
  fonts.append(dict(name=o.name,body=o.data.body,before=list(o.rotation_euler)));o.rotation_euler=(math.pi/2,0,math.pi/2)
assert digest()==before
bpy.ops.wm.save_as_mainfile(filepath=str(P/'source/section.blend'))
bpy.ops.wm.open_mainfile(filepath=str(P/'source/section.blend'));assert digest()==before
bpy.ops.object.select_all(action='DESELECT');converted=[]
for o in list(bpy.data.objects):
 if o.type=='FONT':
  c=o.copy();c.data=o.data.copy();bpy.context.collection.objects.link(c);c.name=o.name+'_GLB';c.select_set(True);bpy.context.view_layer.objects.active=c;bpy.ops.object.convert(target='MESH');uv(bpy.context.object);converted.append(bpy.context.object)
 else:o.select_set(True)
bpy.ops.export_scene.gltf(filepath=str(P/'exports/section.glb'),export_format='GLB',use_selection=True,export_apply=True,export_texcoords=True,export_normals=True,export_extras=True,export_cameras=False,export_lights=True)
(P/'qa/SIGN_FACE_CORRECTION.json').write_text(json.dumps(dict(corrected_fonts=fonts,all_nonfont_native_mesh_geometry_topology_UV_transform_sha256=before,nonfont_geometry_unchanged=True,source_fonts_remain_editable=True),indent=2))
runpy.run_path(str(R/'verify_render.py'),run_name='__main__')
