"""Supplemental ordinary-eye geometry views; QA ambient, no source/export mutation."""
from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'review.py').read_text()
s=s.replace("inputs['Strength'].default_value=.03", "inputs['Strength'].default_value=.3")
s=s.replace("for v in C['views']:", "C['views']=[{'name':n,'camera_world':[a[0],F+1.65,a[1]],'target_world':[b[0],F+1.4,b[1]],'eye_height_m':1.65} for n,a,b in [('admission_corridor',(11,-432),(11,-443)),('wash_transfer_ambient',(28,-404),(40,-404))]]\n(P/'qa/diagnostic_views').mkdir(exist_ok=True)\nfor v in C['views']:")
s=s.replace("'qa/views'", "'qa/diagnostic_views'").replace("'path':'qa/views/'", "'path':'qa/diagnostic_views/'")
s=s.replace("'qa/VIEW_MANIFEST.json'", "'qa/DIAGNOSTIC_VIEW_MANIFEST.json'")
s=s.replace("'fixture_preview_count':len", "'qa_world_ambient_strength':.3,'lighting_acceptance':False,'purpose':'Supplemental actual-export geometry visibility; source fixtures unchanged','fixture_preview_count':len")
s=s.replace("for v in C['views']:", "ld=bpy.data.lights.new('QA_ONLY_CAMERA_INSPECTION_LAMP','AREA');ld.energy=600;ld.shape='DISK';ld.size=3;lamp=bpy.data.objects.new(ld.name,ld);sc.collection.objects.link(lamp)\nfor v in C['views']:")
s=s.replace("sc.render.filepath=str", "lamp.location=cam.location;lamp.rotation_euler=cam.rotation_euler;sc.render.filepath=str")
s=s.replace("'qa_world_ambient_strength':.3", "'qa_camera_inspection_lamp_watts':600,'qa_camera_inspection_lamp_exported':False,'qa_world_ambient_strength':.3")
exec(compile(s,str(p/'review.py'),'exec'))
