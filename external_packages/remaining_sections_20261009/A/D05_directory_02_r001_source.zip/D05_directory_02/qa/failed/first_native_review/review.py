"""Source geometry checks and honest eye-level actual-export views. Blender 4.3.2."""
import bpy,bmesh,json,hashlib,sys,math
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
P=Path(__file__).resolve().parents[1]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
C=json.loads((P/'contract.json').read_text());F=C['allocation']['floor_y'];SEC=P.name
native=P/'source/native.blend';before=sha(native)
bpy.ops.wm.open_mainfile(filepath=str(native));deps=bpy.context.evaluated_depsgraph_get();records={};groups={};normal=[]
for o in bpy.context.scene.objects:
 if o.type!='MESH':continue
 ev=o.evaluated_get(deps);me=ev.to_mesh();vs=[o.matrix_world@v.co for v in me.vertices];polys=[list(p.vertices) for p in me.polygons]
 records[o.name]={'vertices':vs,'bvh':BVHTree.FromPolygons(vs,polys),'support':o.get('support'),'assembly':o.get('assembly'),'role':o.get('role')}
 if o.get('assembly'):groups.setdefault(o['assembly'],[]).append(o.name)
 bm=bmesh.new();bm.from_mesh(me);closed=all(e.is_manifold for e in bm.edges);vol=bm.calc_volume(signed=True);bm.free()
 normal.append({'name':o.name,'closed':closed,'signed_volume':vol,'authored':not bool(o.get('assembly'))});ev.to_mesh_clear()
def distance(a,b):
 best=999
 for v in a['vertices']:
  hit=b['bvh'].find_nearest(v)
  if hit[0] is not None:best=min(best,hit[3])
  if best<.001:return best
 return best
contacts=[]
for name,r in records.items():
 sup=r['support']
 if r['assembly']:continue
 if sup=='shared_floor':gap=abs(min(v.z for v in r['vertices'])-F);kind='proposed_parent_floor_plane'
 elif sup in records:gap=min(distance(r,records[sup]),distance(records[sup],r));kind='actual_surface_nearest_distance'
 elif sup in groups:gap=min(min(distance(r,records[n]),distance(records[n],r)) for n in groups[sup]);kind='registered_assembly_surface'
 else:gap=999;kind='unresolved_support'
 contacts.append({'name':name,'support':sup,'gap_m':gap,'within_0_06m':gap<=.06,'method':kind})
assembly=[]
for name,ns in groups.items():
 low=min(v.z for n in ns for v in records[n]['vertices']);assembly.append({'name':name,'lowest_y':low,'floor_gap_m':abs(low-F),'within_0_06m':abs(low-F)<=.06})
images=[{'name':i.name,'packed':bool(i.packed_file),'filepath':i.filepath} for i in bpy.data.images if i.type!='RENDER_RESULT']
fonts=[o.name for o in bpy.context.scene.objects if o.type=='FONT']
receipt={'native_sha256':before,'support_tolerance_m':.06,'contacts':contacts,'assembly_floor_contacts':assembly,'failed_contacts':[x for x in contacts+assembly if not x['within_0_06m']],'normals':normal,'authored_inward_closed':[x for x in normal if x['authored'] and x['closed'] and x['signed_volume']<-1e-7],'packed_images':images,'external_libraries':[x.filepath for x in bpy.data.libraries],'native_font_names':fonts,'source_only':True,'floor_bearing_and_load_certification_held':True}
(P/'qa/NATIVE_GEOMETRY.json').write_text(json.dumps(receipt,indent=2))
# Render the deliverable, not the scene used to produce it. Preview context excluded from all exports.
bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(P/'exports'/(SEC+'.glb')))
if SEC=='D05_directory_01':
 prior=set(bpy.context.scene.objects);bpy.ops.import_scene.gltf(filepath=str(P/'dependencies/retained_triage010/exports/D05_medical_connected_architecture_010.glb'))
 for o in set(bpy.context.scene.objects)-prior:
  if o.parent is None:o.location+=Vector((-28,446,21))
for i,(x0,x1,z0,z1) in enumerate(C['floor_proposal_rectangles']):
 bpy.ops.mesh.primitive_plane_add(size=1,location=((x0+x1)/2,-(z0+z1)/2,F-.001));o=bpy.context.object;o.name='QA_ONLY_PROPOSED_PARENT_FLOOR_'+str(i);o.scale=(x1-x0,z1-z0,1)
 m=bpy.data.materials.get('QA_parent_floor') or bpy.data.materials.new('QA_parent_floor');m.use_nodes=True;m.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=(.24,.27,.28,1);m.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value=.8;o.data.materials.append(m)
if SEC=='D05_directory_01':
 host=json.loads((P/'docs/HOST_FLOOR_SNAPSHOT.json').read_text());vs=[];fs=[]
 for r in host['regions']:
  if r['id'] not in ['D05_forward_waiting_support_floor','D05_connected_triage_wing_floor']:continue
  assert abs(r['floor_y']-F)<1e-6
  for tri in r['triangles']:
   j=len(vs);vs.extend([(x,-z,F-.001) for x,z in tri]);fs.append((j,j+1,j+2))
 me=bpy.data.meshes.new('QA_ONLY_RETAINED_PARENT_FLOOR_CONTEXT');me.from_pydata(vs,[],fs);me.update();o=bpy.data.objects.new(me.name,me);scn=bpy.context.scene;scn.collection.objects.link(o);o.data.materials.append(bpy.data.materials['QA_parent_floor'])
for n,p,w,l,power in C['authored_fixture_preview']:
 ld=bpy.data.lights.new('QA_ONLY_FIXTURE_'+n,'AREA');ld.energy=power;ld.shape='RECTANGLE';ld.size=w;ld.size_y=l;o=bpy.data.objects.new(ld.name,ld);bpy.context.scene.collection.objects.link(o);o.location=(p[0],-p[2],F+p[1]-.03)
sc=bpy.context.scene;sc.render.engine='CYCLES';sc.cycles.samples=12;sc.cycles.use_denoising=True;sc.cycles.max_bounces=5;sc.render.threads_mode='FIXED';sc.render.threads=2;sc.render.resolution_x=960;sc.render.resolution_y=540;sc.render.resolution_percentage=100;sc.render.image_settings.file_format='PNG';sc.view_settings.view_transform='AgX';sc.world.use_nodes=True;sc.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.03
d=bpy.data.cameras.new('QA_eye_165');cam=bpy.data.objects.new(d.name,d);sc.collection.objects.link(cam);sc.camera=cam;d.lens=24;d.clip_end=200;views=[]
if SEC=='D05_directory_01':C['views'].append({'name':'retained_pods_cross_corridor','camera_world':[-11,F+1.65,-448],'target_world':[-28,F+1.4,-453],'eye_height_m':1.65,'scope':'preserved triage010 source context, not additive geometry'})
for v in C['views']:
 a=v['camera_world'];b=v['target_world'];cam.location=(a[0],-a[2],a[1]);target=Vector((b[0],-b[2],b[1]));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();sc.render.filepath=str(P/'qa/views'/(v['name']+'.png'));bpy.ops.render.render(write_still=True)
 views.append({**v,'path':'qa/views/'+v['name']+'.png','sha256':sha(sc.render.filepath)});print('SOURCE_VIEW_DONE',SEC,v['name'],flush=True)
assert sha(native)==before
(P/'qa/VIEW_MANIFEST.json').write_text(json.dumps({'views':views,'scope':'actual delivered GLB plus explicitly unbuilt parent-floor proposal and source-fixture preview lights; source-only','fixture_preview_count':len(C['authored_fixture_preview']),'installed_Godot_acceptance':False,'native_unchanged_sha256':before},indent=2))
