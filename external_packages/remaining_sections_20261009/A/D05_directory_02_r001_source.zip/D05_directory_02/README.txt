D05_directory_02 r001: isolated editable source and actual GLB.

Native: source\native.blend
SHA256 0727e5fa6c648b0e1d17485dd7645bf4cdd7ca76e0bce54ec14f551fc40c336e
Export: exports\D05_directory_02.glb
SHA256 873df2ff3857d3f7c6860d30e11eff0275842bf53e84118d39111c49d06d31db

Use Blender 4.3.2, serialize heavy jobs and use two threads. From this package:
blender --background --threads 2 --python-exit-code 2 --python source/build.py

Actual source checks and individually inspected 1.65m views are retained under qa/. Failed earlier evidence remains under qa/failed or named prior logs. The export omits shared floors. QA-only parent-floor proposals and fixture preview lights do not constitute installed acceptance.

Receiving holds:
- No live integration or installed Godot route/collider/lighting/species/clinical/loaded-cart acceptance.
- Parent owns actual shared floors, outer routes, controlled clean/soiled crossings and relevant lift stops.
- The floor snapshot is a pinned local context, not a frozen final receiving baseline.
- Supplemental views use an explicit 600W QA camera inspection lamp and ambient strength 0.3; they establish geometry visibility, not installed lighting acceptance.
- Medical fit remains plain and repetitive. Clinical equipment, bed adaptation, species fit and capacity acceptance require review.
- Five fixture-only views and the failed arrival framing are retained. Parent floors and service crossings remain receiving holds.
- Source-only construction. No installed Godot, moving loaded cart, species fit, clinical operation, occupancy, whole-ship routing or load certification.
- Root owns shared floors, outer routes, controlled medical clean/soiled crossings and D03-D05 lift stops.
- Surgical suite gross rectangles narrowed at the center to retain a 5m internal transfer spine. Twenty general-bed identities remain unchanged; bed adaptations and clinical operation are unapproved.
