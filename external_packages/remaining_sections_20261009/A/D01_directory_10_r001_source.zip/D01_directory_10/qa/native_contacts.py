"""Audit independently retained native assemblies and fixture contacts; never save source."""
import bpy,json,hashlib
from pathlib import Path
from mathutils.bvhtree import BVHTree
P=Path(__file__).resolve().parents[1];path=P/'source/WP09_custodial_depot.blend';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();before=sha(path)
bpy.ops.wm.open_mainfile(filepath=str(path));deps=bpy.context.evaluated_depsgraph_get();instances=json.loads((P/'docs/instances.json').read_text());names=[r['name'] for r in instances];vs=[];fs=[];owned={n:[] for n in names}
for o in bpy.context.scene.objects:
 if o.type!='MESH' or not o.get('export_enabled'):continue
 ev=o.evaluated_get(deps);me=ev.to_mesh();vertices=[o.matrix_world@v.co for v in me.vertices];name=next((n for n in names if o.name.startswith(n+'__')),None)
 if name:owned[name].extend(vertices)
 else:
  offset=len(vs);vs.extend(vertices);fs.extend([[offset+i for i in face.vertices] for face in me.polygons])
 ev.to_mesh_clear()
bvh=BVHTree.FromPolygons(vs,fs);rows=[]
for inst in instances:
 name=inst['name'];vertices=owned[name];isfixture=inst['catalogue_id'] in ['AST-STF-004','AST-STF-005','AST-STF-006'];ground=min((abs(v.z) for v in vertices),default=999);near=999
 level=(max if isfixture else min)(v.z for v in vertices);bearing=[v for v in vertices if abs(v.z-level)<.015]
 for v in bearing:
  hit=bvh.find_nearest(v)
  if hit[0] is not None:near=min(near,hit[3])
  if near<.001:break
 gap=near if isfixture else min(ground,near)
 rows.append({'name':name,'catalogue_id':inst['catalogue_id'],'fixture':isfixture,'vertices_checked':len(bearing),'bearing_surface':'ceiling mount plate top' if isfixture else 'assembly bottom','actual_authored_mesh_contact_gap_m':near,'proposed_parent_floor_gap_m':ground,'contact_gap_m':gap,'within_0_06m':gap<=.06,'scope':'actual retained bearing-vertex mesh contact or unbuilt parent floor plane; no load certification'})
assert sha(path)==before
report={'native_sha256':before,'native_unchanged':True,'blender_version':bpy.app.version_string,'native_fonts':[o.name for o in bpy.context.scene.objects if o.type=='FONT'],'packed_images':[{'name':i.name,'packed':bool(i.packed_file)} for i in bpy.data.images if i.type!='RENDER_RESULT'],'external_libraries':[i.filepath for i in bpy.data.libraries],'assemblies':rows,'failed_contacts':[r for r in rows if not r['within_0_06m']],'source_only':True}
(P/'qa/NATIVE_CONTACTS.json').write_text(json.dumps(report,indent=2));print('DEPOT_CONTACT_AUDIT',len(rows),'failures',[(r['name'],r['contact_gap_m']) for r in report['failed_contacts']],flush=True)
