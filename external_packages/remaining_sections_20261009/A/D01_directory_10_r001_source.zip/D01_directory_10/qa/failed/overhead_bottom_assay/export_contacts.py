"""Actual retained export bearing contacts; paired native packed/font proof from fresh export reopen."""
import json,math,hashlib,sys
from pathlib import Path
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'qa'));import geometry as G
def sub(a,b):return tuple(a[i]-b[i] for i in range(3))
def dot(a,b):return sum(a[i]*b[i] for i in range(3))
def dist(p,a,b,c):
 ab=sub(b,a);ac=sub(c,a);ap=sub(p,a);d1=dot(ab,ap);d2=dot(ac,ap)
 if d1<=0 and d2<=0:return math.dist(p,a)
 bp=sub(p,b);d3=dot(ab,bp);d4=dot(ac,bp)
 if d3>=0 and d4<=d3:return math.dist(p,b)
 vc=d1*d4-d3*d2
 if vc<=0 and d1>=0 and d3<=0:
  v=d1/(d1-d3);return math.dist(p,tuple(a[i]+v*ab[i] for i in range(3)))
 cp=sub(p,c);d5=dot(ab,cp);d6=dot(ac,cp)
 if d6>=0 and d5<=d6:return math.dist(p,c)
 vb=d5*d2-d1*d6
 if vb<=0 and d2>=0 and d6<=0:
  w=d2/(d2-d6);return math.dist(p,tuple(a[i]+w*ac[i] for i in range(3)))
 va=d3*d6-d5*d4
 if va<=0 and d4-d3>=0 and d5-d6>=0:
  w=(d4-d3)/((d4-d3)+(d5-d6));return math.dist(p,tuple(b[i]+w*(c[i]-b[i]) for i in range(3)))
 den=va+vb+vc
 if abs(den)<1e-20:return min(math.dist(p,a),math.dist(p,b),math.dist(p,c))
 v=vb/den;w=vc/den;return math.dist(p,tuple(a[i]+v*ab[i]+w*ac[i] for i in range(3)))
gd,gb=G.load_glb(P/'exports/WP09_custodial_depot.glb');parts=G.geometry(gd,gb);instances=json.loads((P/'docs/instances.json').read_text());groups={r['name']:[] for r in instances};struct=[]
for part in parts:
 n=next((name for name in groups if part['name'].startswith(name+'__')),None)
 if n:groups[n].append(part)
 else:struct.append(part)
triangles=[];grid={};cell=1
for part in struct:
 for t in part['triangles']:
  bb=[min(v[i] for v in t) for i in range(3)]+[max(v[i] for v in t) for i in range(3)];idx=len(triangles);triangles.append((part['name'],t,bb))
  for x in range(math.floor(bb[0]),math.floor(bb[3])+1):
   for y in range(math.floor(bb[1]),math.floor(bb[4])+1):
    for z in range(math.floor(bb[2]),math.floor(bb[5])+1):grid.setdefault((x,y,z),[]).append(idx)
rows=[]
for r in instances:
 members=groups[r['name']];assert members,r['name'];vertices=set(v for p in members for t in p['triangles'] for v in t);fixture=r['catalogue_id']=='AST-STF-006';level=(max if fixture else min)(v[1] for v in vertices);bearing=[v for v in vertices if abs(v[1]-level)<.015];near=.5;nearest=None
 for v in bearing:
  ids=set()
  for x in range(math.floor(v[0]-.5),math.floor(v[0]+.5)+1):
   for y in range(math.floor(v[1]-.5),math.floor(v[1]+.5)+1):
    for z in range(math.floor(v[2]-.5),math.floor(v[2]+.5)+1):ids.update(grid.get((x,y,z),[]))
  for idx in ids:
   name,t,bb=triangles[idx];lower=math.sqrt(sum(max(bb[i]-v[i],v[i]-bb[i+3],0)**2 for i in range(3)))
   if lower>near:continue
   distance=dist(v,*t)
   if distance<near:near=distance;nearest=name
 ground=abs(min(v[1] for v in vertices));gap=near if fixture else min(ground,near)
 rows.append({'name':r['name'],'catalogue_id':r['catalogue_id'],'fixture':fixture,'bearing_vertices_checked':len(bearing),'assembly_component_meshes':len(members),'actual_authored_mesh_contact_gap_m_capped_at_0_5':near,'nearest_authored_mesh':nearest,'proposed_parent_floor_gap_m':ground,'contact_gap_m':gap,'within_0_06m':gap<=.06,'method':'actual exported bearing vertices to authored triangles; mount-top for fixtures, bottom for other native assemblies; unbuilt parent floor plane eligible only for floor assemblies'})
source=json.loads((P/'qa/EXPORT_ONLY_RECEIPT.json').read_text());native=P/'source/WP09_custodial_depot.blend';assert G.sha(native)==source['native_sha256_unchanged'];assert G.sha(P/'exports/WP09_custodial_depot.glb')==source['successor_glb_sha256']
report={'native_sha256':G.sha(native),'native_unchanged':True,'geometry_check_source':'actual corrected GLB; native reopened unchanged and FONT/material packed proof from EXPORT_ONLY_RECEIPT.json','native_fonts':list(source['native_text_inventory']),'packed_images':source['native_packed_images'],'external_libraries':source['external_libraries'],'assemblies':rows,'failed_contacts':[r for r in rows if not r['within_0_06m']],'source_only':True,'load_or_photometric_acceptance':False}
(P/'qa/NATIVE_CONTACTS.json').write_text(json.dumps(report,indent=2));print('DEPOT_ACTUAL_EXPORT_CONTACTS',len(rows),'failed',[(r['name'],round(r['contact_gap_m'],4)) for r in report['failed_contacts']],flush=True)
