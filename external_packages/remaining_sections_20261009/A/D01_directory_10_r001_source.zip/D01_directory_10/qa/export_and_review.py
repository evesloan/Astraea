"""Retained source, export-only label correction, actual-export eye views. No native save."""
from pathlib import Path
import runpy,bpy,json,hashlib,math
from mathutils import Vector
P=Path(__file__).resolve().parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(P/'source/WP09_custodial_depot.blend')=='98c13dd2d18bec5c8e5cdb5f8be84b02f86e45990d4e573d96d0af1bc66d308d'
runpy.run_path(str(P/'source/export_signage_successor.py'),run_name='__main__')
expected='076365a7d65e5b6381799fab3cd3e3d75ad75aca4370291150dac8e78df0c299'
actual=sha(P/'exports/WP09_custodial_depot.glb')
(P/'qa/CORRECTED_EXPORT_PIN.json').write_text(json.dumps({'expected':expected,'actual':actual,'matches_retained_corrected_export':actual==expected},indent=2))
assert actual==expected,'Corrected retained export mismatch; hold replacement and keep evidence'
for o in list(bpy.data.objects):bpy.data.objects.remove(o,do_unlink=True)
bpy.ops.import_scene.gltf(filepath=str(P/'exports/WP09_custodial_depot.glb'))
lights=[o for o in bpy.context.scene.objects if o.type=='LIGHT'];assert len(lights)==35
# Root receiving floor is a bounded proposal, deliberately absent from delivered GLB/native.
bpy.ops.mesh.primitive_plane_add(size=1,location=(23,28,0));floor=bpy.context.object;floor.name='QA_ONLY_PROPOSED_PARENT_FLOOR';floor.scale=(46,68,1)
m=bpy.data.materials.new('QA_root_floor');m.use_nodes=True;bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(.34,.37,.38,1);bs.inputs['Roughness'].default_value=.85;floor.data.materials.append(m)
sc=bpy.context.scene;sc.render.engine='CYCLES';sc.cycles.samples=12;sc.cycles.use_denoising=True;sc.cycles.max_bounces=5;sc.render.threads_mode='FIXED';sc.render.threads=2;sc.render.resolution_x=960;sc.render.resolution_y=540;sc.render.resolution_percentage=100;sc.render.image_settings.file_format='PNG';sc.view_settings.view_transform='AgX'
sc.world.use_nodes=True;sc.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.03
camd=bpy.data.cameras.new('QA_eye_165');cam=bpy.data.objects.new(camd.name,camd);sc.collection.objects.link(cam);sc.camera=cam;camd.lens=24;camd.clip_end=200
views=json.loads((P/'docs/cameras.json').read_text());records=[];(P/'qa/views').mkdir(exist_ok=True)
for name in ['01_arrival','03_cart_spine','04_cart_work','05_ready_stock','07_used_carriers']:
 a,b=views[name];cam.location=(a[0]-8,460-a[1],a[2]);target=Vector((b[0]-8,460-b[1],b[2]));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();sc.render.filepath=str(P/'qa/views'/(name+'.png'));bpy.ops.render.render(write_still=True)
 records.append({'name':name,'world_camera':[a[0],a[2],a[1]],'eye_height_m':1.65,'path':'qa/views/'+name+'.png','sha256':sha(Path(sc.render.filepath))});print('DEPOT_VIEW_DONE',name,flush=True)
(P/'qa/VIEW_MANIFEST.json').write_text(json.dumps({'scope':'Actual corrected GLB source-only views; parent floor preview proposal; no installed acceptance','views':records,'actual_export_light_count':35,'added_fill_lights':0,'source_native_unchanged':sha(P/'source/WP09_custodial_depot.blend')},indent=2))
