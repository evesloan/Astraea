D01_directory_10 r001: isolated editable source and actual GLB.

Native: source\WP09_custodial_depot.blend
SHA256 98c13dd2d18bec5c8e5cdb5f8be84b02f86e45990d4e573d96d0af1bc66d308d
Export: exports\WP09_custodial_depot.glb
SHA256 076365a7d65e5b6381799fab3cd3e3d75ad75aca4370291150dac8e78df0c299

Use Blender 4.3.2, serialize heavy jobs and use two threads. From this package:
blender --background --threads 2 --python-exit-code 2 --python source/export_signage_successor.py
This command regenerates the exact corrected export from the unchanged packed native. Do not run the historical architectural builder on this frozen source.

Actual source checks and individually inspected 1.65m views are retained under qa/. Failed earlier evidence remains under qa/failed or named prior logs. The export omits shared floors. QA-only parent-floor proposals and fixture preview lights do not constitute installed acceptance.

Receiving holds:
- No live integration or installed Godot route/collider/lighting/species/clinical/loaded-cart acceptance.
- Parent owns actual shared floors, outer routes, controlled clean/soiled crossings and relevant lift stops.
- The floor snapshot is a pinned local context, not a frozen final receiving baseline.
- Exact retained custodial native stock, fixtures and lights preserved. Font export correction only; no architectural rebuild.
- External X4..8 connector at Z460 remains parent-owned and unbuilt.
