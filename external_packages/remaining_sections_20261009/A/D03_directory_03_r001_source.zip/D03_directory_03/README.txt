D03_directory_03 r001: isolated editable source and actual GLB.

Native: source\native.blend
SHA256 78beb0bb0a0a32c77565a17fc9f9bf3045e43a43894f9e10000629e81dcb242e
Export: exports\D03_directory_03.glb
SHA256 75b158772963f78eedd2e1a5391580267d7ca009e734dcb978cb507046758c22

Use Blender 4.3.2, serialize heavy jobs and use two threads. From this package:
blender --background --threads 2 --python-exit-code 2 --python source/build.py

Actual source checks and individually inspected 1.65m views are retained under qa/. Failed earlier evidence remains under qa/failed or named prior logs. The export omits shared floors. QA-only parent-floor proposals and fixture preview lights do not constitute installed acceptance.

Receiving holds:
- No live integration or installed Godot route/collider/lighting/species/clinical/loaded-cart acceptance.
- Parent owns actual shared floors, outer routes, controlled clean/soiled crossings and relevant lift stops.
- The floor snapshot is a pinned local context, not a frozen final receiving baseline.
- The generous depot remains sparse, particularly the unloaded stock and receiving apron; this is source construction, not accepted inventory or capacity.
- QA parent floor and fixture preview lighting are not delivered installed floor or lighting acceptance.
- Source-only construction. No installed Godot, moving loaded cart, species fit, clinical operation, occupancy, whole-ship routing or load certification.
- Root owns shared floors, outer routes, controlled medical clean/soiled crossings and D03-D05 lift stops.
- Retained crew-platform gate/stub stays unchanged. Door mechanism and source platform installation remain root-owned. No second player cart.
