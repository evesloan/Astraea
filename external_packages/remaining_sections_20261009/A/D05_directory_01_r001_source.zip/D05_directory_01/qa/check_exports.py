"""Portable standard-library actual GLB checks; identity world frame unless retained depot."""
import sys,json,hashlib,math
from pathlib import Path
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'qa'));import geometry as G
SEC=P.name;old=SEC=='D01_directory_10'
path=P/'exports'/('WP09_custodial_depot.glb' if old else SEC+'.glb')
d,b=G.load_glb(path);parts=G.geometry(d,b)
def translate(parts,t):
 for p in parts:
  p['bounds']=[v+t[i%3] for i,v in enumerate(p['bounds'])];p['triangles']=[tuple(tuple(v[i]+t[i] for i in range(3)) for v in tri) for tri in p['triangles']]
if old:
 translate(parts,[8,0,460]);F=0;bounds=[8,54,398,466]
 routes=[{'name':'arrival_to_handover','xz':[[8.6,460],[27,460]]},{'name':'cart_spine','xz':[[26.5,453],[26.5,411]]},{'name':'workcab_approach','xz':[[26.5,439],[19.4,439]]},{'name':'ready_stock_approach','xz':[[26.5,449],[39,449]]},{'name':'used_hold_approach','xz':[[26.5,405],[19.5,405]]}]
else:
 c=json.loads((P/'contract.json').read_text());F=c['allocation']['floor_y'];bounds=c['allocation']['bounds'];routes=c['routes']
actual=[min(p['bounds'][i] for p in parts) for i in range(3)]+[max(p['bounds'][i+3] for p in parts) for i in range(3)]
outside=[p['name'] for p in parts if p['bounds'][0]<bounds[0]-.025 or p['bounds'][3]>bounds[1]+.025 or p['bounds'][2]<bounds[2]-.025 or p['bounds'][5]>bounds[3]+.025 or p['bounds'][1]<F-.06]
# Uniform broadphase index. A 2m neighbourhood proves both envelopes; greater clearances capped at 2m.
def fast_routes(parts,routes,height,radius):
 obs=G.obstacles(parts,F,height);grid={};cell=2
 for idx,(_,_,r) in enumerate(obs):
  for x in range(math.floor(r[0]/cell),math.floor(r[2]/cell)+1):
   for z in range(math.floor(r[1]/cell),math.floor(r[3]/cell)+1):grid.setdefault((x,z),[]).append(idx)
 result=[]
 for route in routes:
  minimum=2.;nearest=None;samples=0
  for a,b in zip(route['xz'],route['xz'][1:]):
   count=max(1,math.ceil(math.dist(a,b)/.1))
   for j in range(count+1):
    pt=tuple(a[k]+(b[k]-a[k])*j/count for k in range(2));samples+=1;ids=set()
    for x in range(math.floor((pt[0]-2)/cell),math.floor((pt[0]+2)/cell)+1):
     for z in range(math.floor((pt[1]-2)/cell),math.floor((pt[1]+2)/cell)+1):ids.update(grid.get((x,z),[]))
    for idx in ids:
     name,poly,r=obs[idx];lower=math.hypot(max(r[0]-pt[0],pt[0]-r[2],0),max(r[1]-pt[1],pt[1]-r[3],0))
     if lower>minimum:continue
     dist=min(G.segdist(pt,a,b) for a,b in zip(poly,poly[1:]+poly[:1]))
     if len(poly)>=3 and G.inside(pt,poly):dist=0
     if dist<minimum:minimum=dist;nearest=name
  result.append({'name':route['name'],'passed':minimum>=radius+.005,'minimum_mesh_margin_m':minimum-radius,'nearest_mesh':nearest,'samples':samples,'diameter_m':radius*2,'height_m':height,'clearance_capped_at_m':2,'scope':'actual export mesh projection sampled every 0.1m; source only, no movement or installed collision acceptance'})
 return result
body=fast_routes(parts,routes,1.85,.30);cart=fast_routes(parts,routes,2.10,.50)
reserved=[]
if SEC=='D03_directory_03':reserved=[{'name':'retained_gate_stub','rect':[-54,-217.8,-48,-214.2],'height':2.65}]
elif SEC.startswith('D05'):
 positive=SEC=='D05_directory_02'
 reserved.append({'name':'parent_controlled_crossing','rect':[53,-406,61,-398] if positive else [-61,-406,-53,-398],'height':4.5})
 for z in [-462,-402]:
  reserved.append({'name':'parent_leaf_pocket_'+str(z),'rect':[53.6,z-3.7,54.4,z+3.7] if positive else [-54.4,z-3.7,-53.6,z+3.7],'height':2.65})
  reserved.append({'name':'parent_internal_turn_'+str(z),'rect':[50,z-1.8,53.6,z+1.8] if positive else [-53.6,z-1.8,-50,z+1.8],'height':2.10})
protection=[]
for r in reserved:
 collisions=set();rect=[r['rect'][0]+.0001,r['rect'][1]+.0001,r['rect'][2]-.0001,r['rect'][3]-.0001]
 for name,poly,_ in G.obstacles(parts,F,r['height']):
  if G.intersects_rect(poly,rect):collisions.add(name)
 protection.append({**r,'actual_export_intruding_meshes':sorted(collisions),'passed':not bool(collisions),'method':'actual triangle projection clipped to protected Y band; 0.1mm boundary tolerance'})
expected_hold=None
if SEC=='D05_directory_01':
 pd,pb=G.load_glb(P/'dependencies/retained_triage010/exports/D05_medical_connected_architecture_010.glb');context=G.geometry(pd,pb);translate(context,[-28,21,-446])
 expected_hold=fast_routes(parts+context,[{'name':'retained_entry_to_addition_blocked','xz':[[-11,-432],[-11,-428.6]]}],1.85,.30)
resources=G.resource_receipt(d,b)
native_check=P/'qa'/('NATIVE_CONTACTS.json' if old else 'NATIVE_GEOMETRY.json')
fontparity=None;winding=[]
if native_check.exists():
 nr=json.loads(native_check.read_text());fonts=nr.get('native_font_names',nr.get('native_fonts',[]));fontparity={'native_font_names':fonts,'export_mesh_names_present':[n for n in fonts if any(p['name']==n for p in parts)],'missing_export_mesh_names':[n for n in fonts if not any(p['name']==n for p in parts)]}
 closed={r['name'] for r in nr.get('normals',[]) if r['authored'] and r['closed']}
 for part in parts:
  if part['name'] not in closed:continue
  centre=[(part['bounds'][i]+part['bounds'][i+3])/2 for i in range(3)];volume=0
  for tri in part['triangles']:
   a,bv,cv=[tuple(v[i]-centre[i] for i in range(3)) for v in tri];cross=(bv[1]*cv[2]-bv[2]*cv[1],bv[2]*cv[0]-bv[0]*cv[2],bv[0]*cv[1]-bv[1]*cv[0]);volume+=sum(a[i]*cross[i] for i in range(3))/6
  winding.append({'name':part['name'],'actual_export_signed_volume':volume,'outward':volume>=-1e-7})
report={'export_path':str(path.relative_to(P)),'sha256':G.sha(path),'bytes':path.stat().st_size,'actual_bounds_xyz':actual,'allocation_outside_meshes':outside,'mesh_count':len(parts),'triangle_count':sum(len(p['triangles']) for p in parts),'body_routes':body,'cart_routes':cart,'failed_routes':[r for r in body+cart if not r['passed']],'retained_entry_hold_evidence':expected_hold,'resources':resources,'font_to_mesh':{'remaining_export_font_types':0,'note':'GLB mesh format; compare native FONT names in NATIVE_GEOMETRY or retained export-only receipt'},'runtime_acceptance':False}
report['font_to_mesh']['actual_name_parity']=fontparity;report['authored_closed_actual_export_winding']=winding;report['inward_authored_export_meshes']=[r for r in winding if not r['outward']]
report['protected_interface_prisms']=protection;report['protected_interface_failures']=[r for r in protection if not r['passed']]
(P/'qa/ACTUAL_EXPORT_CHECKS.json').write_text(json.dumps(report,indent=2));print(SEC,'bounds',actual,'outside',len(outside),'route failures',[(r['name'],r['diameter_m'],round(r['minimum_mesh_margin_m'],3),r['nearest_mesh']) for r in report['failed_routes']],flush=True)
