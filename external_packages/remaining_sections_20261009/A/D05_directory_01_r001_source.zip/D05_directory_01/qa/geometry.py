import pathlib, json, struct, hashlib, math, datetime, copy

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def write(name, value):
    f = P / name
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_text(json.dumps(value, indent=2))

def identity():
    return [[float(i == j) for j in range(4)] for i in range(4)]

def mul(a, b):
    return [[sum((a[i][k] * b[k][j] for k in range(4))) for j in range(4)] for i in range(4)]

def transform(m, v):
    return tuple((sum((m[i][j] * v[j] for j in range(3))) + m[i][3] for i in range(3)))

def local(n):
    if 'matrix' in n:
        return [[n['matrix'][j * 4 + i] for j in range(4)] for i in range(4)]
    x, y, z, w = n.get('rotation', [0, 0, 0, 1])
    s = n.get('scale', [1, 1, 1])
    t = n.get('translation', [0, 0, 0])
    m = identity()
    r = [[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)], [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)], [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]]
    for i in range(3):
        for j in range(3):
            m[i][j] = r[i][j] * s[j]
        m[i][3] = t[i]
    return m

def load_glb(path):
    raw = path.read_bytes()
    magic, version, total = struct.unpack_from('<4sII', raw)
    assert magic == b'glTF' and version == 2 and (total == len(raw))
    pos = 12
    doc = None
    binary = None
    while pos < len(raw):
        size, kind = struct.unpack_from('<II', raw, pos)
        pos += 8
        if kind == 1313821514:
            doc = json.loads(raw[pos:pos + size])
        elif kind == 5130562:
            binary = raw[pos:pos + size]
        pos += size
    assert doc is not None and binary is not None
    return (doc, binary)

def access(d, b, index):
    a = d['accessors'][index]
    assert not a.get('sparse')
    v = d['bufferViews'][a['bufferView']]
    assert v.get('buffer', 0) == 0
    fmt, size = {5126: ('f', 4), 5125: ('I', 4), 5123: ('H', 2), 5121: ('B', 1)}[a['componentType']]
    count = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4}[a['type']]
    start = v.get('byteOffset', 0) + a.get('byteOffset', 0)
    stride = v.get('byteStride', count * size)
    return [struct.unpack_from('<' + fmt * count, b, start + i * stride) for i in range(a['count'])]

def geometry(d, b):
    worlds = {}

    def visit(idx, parent):
        assert idx not in worlds
        worlds[idx] = mul(parent, local(d['nodes'][idx]))
        for child in d['nodes'][idx].get('children', []):
            visit(child, worlds[idx])
    for idx in d['scenes'][d.get('scene', 0)]['nodes']:
        visit(idx, identity())
    result = []
    for idx, n in enumerate(d['nodes']):
        if 'mesh' not in n:
            continue
        triangles = []
        vertices = []
        for prim in d['meshes'][n['mesh']]['primitives']:
            assert prim.get('mode', 4) == 4
            vs = [transform(worlds[idx], v) for v in access(d, b, prim['attributes']['POSITION'])]
            vertices.extend(vs)
            inds = [i[0] for i in access(d, b, prim['indices'])] if 'indices' in prim else list(range(len(vs)))
            assert len(inds) % 3 == 0
            triangles.extend([tuple((vs[inds[j + k]] for k in range(3))) for j in range(0, len(inds), 3)])
        bounds = [min((v[i] for v in vertices)) for i in range(3)] + [max((v[i] for v in vertices)) for i in range(3)]
        result.append({'name': n['name'], 'extras': n.get('extras', {}), 'bounds': bounds, 'triangles': triangles})
    return result

def clip_y(poly, y, above):
    result = []
    for a, b in zip(poly, poly[1:] + poly[:1]):
        ia = a[1] >= y if above else a[1] <= y
        ib = b[1] >= y if above else b[1] <= y
        if ia:
            result.append(a)
        if ia != ib:
            u = (y - a[1]) / (b[1] - a[1])
            result.append(tuple((a[j] + u * (b[j] - a[j]) for j in range(3))))
    return result

def obstacles(parts, F, height):
    rows = []
    for part in parts:
        if part['bounds'][4] < F + 0.05 or part['bounds'][1] > F + height:
            continue
        for triangle in part['triangles']:
            poly = clip_y(list(triangle), F + 0.05, True)
            if poly:
                poly = clip_y(poly, F + height, False)
            if poly:
                points = [(v[0], v[2]) for v in poly]
                rows.append((part['name'], points, [min((p[0] for p in points)), min((p[1] for p in points)), max((p[0] for p in points)), max((p[1] for p in points))]))
    return rows

def inside(point, poly):
    x, z = point
    yes = False
    for (a, b), (c, d) in zip(poly, poly[1:] + poly[:1]):
        if (b > z) != (d > z) and x < (c - a) * (z - b) / (d - b) + a:
            yes = not yes
    return yes

def segdist(p, a, b):
    dx, dz = (b[0] - a[0], b[1] - a[1])
    den = dx * dx + dz * dz
    u = 0 if den < 1e-15 else max(0, min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dz) / den))
    return math.hypot(p[0] - a[0] - u * dx, p[1] - a[1] - u * dz)

def route_test(path, obs, radius):
    minimum = math.inf
    nearest = None
    samples = 0
    for a, b in zip(path, path[1:]):
        count = max(1, math.ceil(math.dist(a, b) / 0.1))
        for j in range(count + 1):
            point = tuple((a[i] + (b[i] - a[i]) * j / count for i in range(2)))
            samples += 1
            for name, poly, box in obs:
                lower = math.hypot(max(box[0] - point[0], point[0] - box[2], 0), max(box[1] - point[1], point[1] - box[3], 0))
                if lower > minimum:
                    continue
                distance = min((segdist(point, a, b) for a, b in zip(poly, poly[1:] + poly[:1])))
                if len(poly) >= 3 and inside(point, poly):
                    distance = 0
                if distance < minimum:
                    minimum = distance
                    nearest = name
    return {'passed': minimum >= radius + 0.005, 'samples': samples, 'minimum_mesh_margin_m': minimum - radius, 'nearest_mesh': nearest, 'diameter_m': radius * 2, 'scope': 'Actual retained source asset only. No receiving surface, door, collider, neighbour or current ship acceptance.'}

def intersects_rect(poly, rect):
    x0, z0, x1, z1 = rect
    other = [(x0, z0), (x1, z0), (x1, z1), (x0, z1)]
    axes = [(1, 0), (0, 1)]
    axes.extend(((b[1] - a[1], a[0] - b[0]) for a, b in zip(poly, poly[1:] + poly[:1])))
    for axis in axes:
        if math.hypot(*axis) < 1e-12:
            continue
        a = [p[0] * axis[0] + p[1] * axis[1] for p in poly]
        b = [p[0] * axis[0] + p[1] * axis[1] for p in other]
        if min(max(a), max(b)) - max(min(a), min(b)) < -1e-07:
            return False
    return True

def area(poly):
    return abs(sum((a[0] * b[1] - b[0] * a[1] for a, b in zip(poly, poly[1:] + poly[:1])))) / 2

def resource_receipt(d, b):
    images = []
    for i, im in enumerate(d.get('images', [])):
        assert 'uri' not in im
        view = d['bufferViews'][im['bufferView']]
        start = view.get('byteOffset', 0)
        data = b[start:start + view['byteLength']]
        images.append({'image_index': i, 'name': im.get('name'), 'mime_type': im['mimeType'], 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    assert not any(('uri' in v for v in d.get('buffers', [])))
    return {'embedded_images': images, 'materials': d.get('materials', []), 'textures': d.get('textures', []), 'samplers': d.get('samplers', []), 'extensions_used': d.get('extensionsUsed', []), 'extensions_required': d.get('extensionsRequired', [])}

def verify_manifest(q):
    rows = json.loads((q / 'DELIVERY_MANIFEST.json').read_text())
    bad = []
    for r in rows:
        f = q / r['path']
        if not f.is_file() or f.stat().st_size != r['bytes'] or sha(f) != r['sha256']:
            bad.append(r['path'])
    assert not bad, bad
    return len(rows)