"""Supplemental ordinary-eye geometry views. Explicit QA ambient, no export edits."""
from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'review.py').read_text()
s=s.replace("inputs['Strength'].default_value=.03", "inputs['Strength'].default_value=.3")
s=s.replace("if SEC=='D05_directory_01':C['views'].append", "if False:C['views'].append")
s=s.replace("for v in C['views']:", "C['views']=[{'name':n,'camera_world':[a[0],F+1.65,a[1]],'target_world':[b[0],F+1.4,b[1]],'eye_height_m':1.65} for n,a,b in [('extension_and_escort',(-11,-411),(-11,-399)),('central_spine_ambient',(-28,-411),(-28,-440)),('service_work_edge',(-48,-412),(-48,-432)),('retained_pods_ambient',(-11,-448),(-28,-453))]]\n(P/'qa/diagnostic_views').mkdir(exist_ok=True)\nfor v in C['views']:")
s=s.replace("for i,(x0,x1,z0,z1) in enumerate(C['floor_proposal_rectangles']):", "C['floor_proposal_rectangles']+= [[-42,-8,-466,-450],[-42,-8,-450,-442],[-14,-8,-442,-429],[-8,-7.8,-433.8,-430.2]] # exact retained source floor proposals; not in host snapshot\nfor i,(x0,x1,z0,z1) in enumerate(C['floor_proposal_rectangles']):")
s=s.replace("'qa/views'", "'qa/diagnostic_views'").replace("'path':'qa/views/'", "'path':'qa/diagnostic_views/'")
s=s.replace("'qa/VIEW_MANIFEST.json'", "'qa/DIAGNOSTIC_VIEW_MANIFEST.json'")
s=s.replace("'fixture_preview_count':len", "'qa_world_ambient_strength':.3,'lighting_acceptance':False,'purpose':'Supplemental actual-export geometry visibility; source fixtures unchanged','fixture_preview_count':len")
exec(compile(s,str(p/'review.py'),'exec'))
