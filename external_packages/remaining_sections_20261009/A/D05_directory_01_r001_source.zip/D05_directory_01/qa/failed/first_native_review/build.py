"""Portable additive section construction, Blender 4.3.2; no live project writes."""
import bpy,json,sys,math,hashlib
from pathlib import Path
from mathutils import Vector,Matrix
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'source'));import kit as K
SEC=P.name;AL=json.loads((P/'allocation.json').read_text());K.init(__file__,SEC);F=AL['floor_y'];H=AL['ceiling']-F
CHILDREN=[];ROUTES=[];ASSETS=[];PORTS=[];FLOORS=[];VIEWS=[];PROTECTED=[];HOLDS=['Source-only construction. No installed Godot, moving loaded cart, species fit, clinical operation, occupancy, whole-ship routing or load certification.','Root owns shared floors, outer routes, controlled medical clean/soiled crossings and D03-D05 lift stops.']
def box(n,x0,x1,z0,z1,y0,y1,mat='ivory',sup='shared_floor',zone='architecture',role='partition'):
 return K.box(n,((x0+x1)/2,(y0+y1)/2,(z0+z1)/2),(x1-x0,y1-y0,z1-z0),mat,sup,zone,.012,role)
def wallx(n,x,z0,z1,doors=(),zone='architecture'):
 cursor=z0;pieces=[]
 for i,(z,width,height) in enumerate(sorted(doors)+[(z1,0,0)]):
  a=max(cursor,z-width/2);b=min(z1,z+width/2)
  if a>cursor+.01:pieces.append(box(n+'_pier'+str(i),x-.10,x+.10,cursor,a,0,H,zone=zone))
  if width:
   sup=pieces[-1].name if pieces else 'shared_floor';box(n+'_head'+str(i),x-.10,x+.10,a,b,height,H,'blue',sup,zone,'supported_lintel')
   PORTS.append({'name':n+'_'+str(i),'plane_x':x,'z':z,'clear_width':width,'clear_height':height,'static_source_only':True})
  cursor=b
 return pieces[0].name if pieces else 'shared_floor'
def wallz(n,z,x0,x1,zone='architecture',height=None):return box(n,x0,x1,z-.09,z+.09,0,height or H,zone=zone)
def ceiling(n,rect,owner,zone='architecture'):
 x0,x1,z0,z1=rect;return box(n,x0,x1,z0,z1,H,H+.14,'white',owner,zone,'supported_ceiling_skin')
def fixture(n,x,z,owner,zone='architecture',power=220):
 # Lens, casing and drop all physically meet the ceiling receiver.
 K.rod(n+'_drop',(x,H,z),(x,H-.13,z),.035,'zinc',owner,zone)
 K.light(n,x,z,H-.19,1.6,.50,n+'_drop',zone,power)
def asset(aid,n,x,z,y=0,yaw=0,child=None):
 with bpy.data.libraries.load(str(P/'dependencies/native'/(aid+'.blend')),link=False) as (src,dst):dst.objects=list(src.objects)
 objects=[o for o in dst.objects if o and o.type in {'MESH','CURVE','FONT','EMPTY'}]
 for o in objects:bpy.context.scene.collection.objects.link(o)
 bpy.context.view_layer.update();worlds={o:o.matrix_world.copy() for o in objects}
 root=bpy.data.objects.new('A_'+n+'_placement',None);bpy.context.scene.collection.objects.link(root);root.location=K.xyz((x,y,z));root.rotation_euler.z=-yaw;root['section_key']=SEC;root['catalogue_id']=aid
 for o in objects:
  o.parent=root;o.matrix_parent_inverse=Matrix.Identity(4);o.matrix_basis=worlds[o];o.name='A_'+n+'__'+o.name;o['section_key']=SEC;o['catalogue_id']=aid;o['assembly']=root.name;o['zone']=child or n;o['support']='native_registered_assembly';o['role']='retained_native_family'
  if o.type in {'MESH','CURVE','FONT'}:K.PARTS.append(o)
 ASSETS.append({'id':aid,'placement':root.name,'world_xyz':[x,F+y,z],'yaw_radians':yaw,'child':child,'scale':[1,1,1],'source_sha256':K.sha(P/'dependencies/native'/(aid+'.blend'))});return root
def child(ident,role,rect,entry,dimensions=None):
 CHILDREN.append({'id':ident,'role':role,'rect_x0_x1_z0_z1':rect,'dimensions_m':dimensions or [rect[1]-rect[0],rect[3]-rect[2]],'entry_world_xyz':[entry[0],F,entry[1]],'architecture_fit_only':True,'operational':False});return ident
def route(n,points,kind='body_and_cart'):ROUTES.append({'name':n,'xz':points,'kind':kind,'source_only':True})
def service_edges(sign):
 positive=SEC=='D05_directory_02';xclean,xsupport,xsoiled=(44,48,52) if positive else (-44,-48,-52)
 for x in [46,50] if positive else [-46,-50]:wallx('Service_separator_'+str(x),x,-465.8,-398.2,[(-462,3.6,2.4),(-402,3.6,2.4)],'staff_service')
 for x,name in [(xclean,'clean'),(xsoiled,'soiled')]:
  route(name+'_internal_route',[(x,-462),(x,-402)])
  edge=42 if positive and name=='clean' else 53.5 if positive else -42 if name=='clean' else -53.5
  start=-441.8 if not positive and name=='clean' else -465.8
  if name=='soiled':
   owner=wallx(name+'_back_edge',edge,start,-406,[(-462,3.6,2.4)],'staff_service')
   rear=wallx(name+'_receiving_notch',52.7 if positive else -52.7,-406,-398.2,[(-402,3.6,2.4)],'staff_service')
   c=ceiling(name+'_ceiling',(x-2,x+2,start,-406),owner,'staff_service')
   ceiling(name+'_notched_rear_ceiling',(50,53,-406,-398.3) if positive else (-53,-50,-406,-398.3),rear,'staff_service')
  else:
   owner=wallx(name+'_back_edge',edge,start,-398.2,[(-402,3.6,2.4)] if start>-462 else [(-462,3.6,2.4),(-402,3.6,2.4)],'staff_service')
   c=ceiling(name+'_ceiling',(x-2,x+2,start,-398.3),owner,'staff_service')
  for z in [-454,-438,-422,-408]:fixture(name+'_light_'+str(z),x,z,c.name,'staff_service',180)
 for j,z in enumerate([-450,-436,-418]):
  sup=K.cabinet('Service_store_'+str(j),xsupport,z,1.0,2.6,'staff_service',2.2)
  K.table('Service_transfer_'+str(j),xsupport,z+3,1.4,1.2,'staff_service',.85)
  child(SEC+'_clinical_service_'+str(j+1),'clean_or_soiled_internal_support',[xsupport-1.7,xsupport+1.7,z-2,z+4],(xsupport,z+4))
  if j==2:asset('AST-MED-004','Service_return_carrier',xsupport,z+2,child='staff_service')
 route('support_maintenance_approach',[(xsupport+1.3,-462),(xsupport+1.3,-402)])
 for z,role in [(-462,'clean_contact'),(-402,'soiled_contact')]:
  x=54 if positive else -54;PORTS.append({'name':role,'world_xyz':[x,F,z],'width':3.6,'height':2.4,'parent_owned_controlled_crossing':True,'leaf_pocket_unbuilt':True});route(role+'_turn',[(x-.6 if positive else x+.6,z),(xclean if role=='clean_contact' else xsoiled,z)])
def quarantine():
 # Existing eight pods/waiting/admission are read-only QA context, absent additive export.
 source=P/'dependencies/retained_triage010/source/D05_medical_connected_triage_010.blend'
 assert K.sha(source)=='2f83936023e3b0220673c394aa334c036bcd5f6b483ef96110d271e947175846'
 PROTECTED.extend(['eight triage010 pods','waiting and diagnostic support','both existing floor owners','ADMISSION_south_end'])
 HOLDS.append('Existing ADMISSION_south_end at Z-429 remains solid. Parent must approve/open a 3.6x2.4 receiving portal; incoming entry-to-addition traversal does not pass until that receiving change exists.')
 HOLDS.append('Quarantine child rectangles revised from the aisle-free 4x3 grid to two six-room banks; receiving owner must approve local plan crosswalk before integration.')
 for bank,(x0,x1,face) in enumerate([(-41.8,-30.1,-30),(-25.9,-14.2,-26)]):
  for row in range(6):
   number=bank*6+row+1;z0=-441.8+row*5;z1=z0+5;zc=(z0+z1)/2;ident=f'{SEC}_quarantine_room_{number:02}'
   child(ident,'quarantine_room_fit_target',[x0,x1,z0,z1],(face,zc))
   back=wallx('Q'+str(number)+'_back',x0 if bank==0 else x1,z0,z1,zone=ident)
   if row==0:wallz('Q'+str(number)+'_start',z0,x0,x1,ident)
   wallz('Q'+str(number)+'_end',z1,x0,x1,ident)
   wallx('Q'+str(number)+'_front',face,z0,z1,[(zc,2.4,2.65)],ident)
   # Source-open inward leaf; no controller, pressure seal or operational isolation.
   hinge_x=face-.10 if bank==0 else face+.10
   for h,yy in [('low',.42),('high',2.02)]:K.rod('Q'+str(number)+'_privacy_hinge_'+h,(hinge_x,yy-.10,zc-1.26),(hinge_x,yy+.10,zc-1.26),.045,'zinc','Q'+str(number)+'_front_pier0',ident)
   box('Q'+str(number)+'_static_privacy_return',face-1.4 if bank==0 else face+.09,face-.09 if bank==0 else face+1.4,zc-1.30,zc-1.22,.10,2.48,'blue','Q'+str(number)+'_privacy_hinge_low',ident,'source_open_privacy_return')
   bedx=-34 if bank==0 else -22;asset('AST-MED-003','Q'+str(number)+'_platform',bedx,zc,child=ident);asset('AST-MED-004','Q'+str(number)+'_support',bedx+(1.3 if bank==0 else -1.3),zc+1.4,child=ident)
   asset('AST-MED-002','Q'+str(number)+'_wash',-39 if bank==0 else -17,zc,child=ident)
   c=ceiling('Q'+str(number)+'_ceiling',(x0,x1,z0,z1),back,ident);fixture('Q'+str(number)+'_task',bedx,zc,c.name,ident,240)
   route('Q'+str(number)+'_approach',[(-28,-411),(-28,zc),(face,zc),(-31.9 if bank==0 else -24.1,zc)])
 route('quarantine_central_spine',[(-28,-441),(-28,-403)])
 route('additive_admission_route',[(-11,-428.6),(-11,-411),(-28,-411)])
 # New admission extension begins beyond the protected retained solid cap.
 admission=wallx('New_admission_outer',-8.2,-428.75,-398.2,zone='admission_extension');c=ceiling('New_admission_ceiling',(-13.8,-8.3,-428.75,-398.2),admission,'admission_extension')
 for z in [-425,-417,-405]:fixture('New_admission_'+str(z),-11,z,c.name,'admission_extension')
 escort=child(SEC+'_arrival_privacy_and_escort_01','arrival_privacy_and_escort',[-13.8,-8.3,-407,-398.3],(-11,-404))
 K.seat('Escort_quiet_rest',-12.6,-400.5,2.4,escort,math.pi/2,'oat')
 K.table('Escort_document_edge',-12.4,-403.5,1.2,.7,escort,.65)
 route('escort_rest_approach',[(-11,-411),(-11,-400.5)])
 for x0,x1,n in [(-41.8,-30.1,'telemedicine'),(-25.9,-14.2,'clinical_staff_control')]:
  ident=child(SEC+'_'+n+'_01',n,[x0,x1,-410,-402],(-28,-406))
  back=wallz(n+'_back',-402.1,x0,x1,ident);wallz(n+'_front',-409.9,x0,x1,ident)
  c=ceiling(n+'_ceiling',(x0,x1,-409.9,-402.1),back.name,ident);fixture(n+'_task',(x0+x1)/2,-406,c.name,ident)
  top=K.table(n+'_working_edge',(x0+x1)/2,-403.5,7,1.2,ident,.85);K.terminal(n+'_console',(x0+x1)/2,-403.5,top,ident,.94);K.swivel(n+'_seat',(x0+x1)/2,-405,ident)
  route(n+'_approach',[(-28,-406),((x0+x1)/2,-406)])
 service_edges(-1);FLOORS.extend([[-42,-14,-441.9,-402],[-54,-42,-466,-398],[-14,-8,-428.76,-398],[-30,-26,-442,-402]])
 VIEWS.extend([('ward_arrival',(-11,-427),(-28,-411)),('quarantine_spine',(-28,-411),(-28,-440)),('quarantine_room',(-31.4,-439.3),(-38,-439.3)),('staff_control',(-23,-406),(-20,-403.5)),('service_return',(-52,-412),(-48,-418))])
def medical():
 left=wallx('Admission_outer',8.2,-465.8,-398.2,[(-432,3.6,2.4)],'admission');wardedge=wallx('Ward_admission_edge',14,-465.8,-398.2,[(-442,3.6,2.65)],'admission')
 wallz('Medical_fore',-465.8,8.3,53.7);wallz('Medical_aft',-398.2,8.3,52.6)
 roof=ceiling('Medical_ward_ceiling',(14,42,-465.7,-422),wardedge,'general_beds')
 for row in range(10):
  z=-460+row*4
  for side,(x,x0,x1) in enumerate([(19,14,28),(37,28,42)]):
   number=row*2+side+1;ident=child(f'{SEC}_general_bed_position_{number:02}','general_bed_fit_position',[x0,x1,z-2,z+2],(26 if side==0 else 30,z))
   asset('AST-MED-003','Bed'+str(number),x,z,yaw=math.pi/2,child=ident);asset('AST-MED-004','Bed'+str(number)+'_support',15.6 if side==0 else 40.4,z,child=ident)
   box('Bed'+str(number)+'_mattress',x-1.06,x+1.06,z-.55,z+.55,.75,.89,'ivory','A_Bed'+str(number)+'_placement',ident,'clinical_rest_fit')
   box('Bed'+str(number)+'_pillow',x-.94 if side==0 else x+.50,x-.50 if side==0 else x+.94,z-.49,z+.49,.89,1.00,'cloth','Bed'+str(number)+'_mattress',ident,'head_support')
   if row not in [0,5]:wallz('Bed'+str(number)+'_privacy_fin',z-2,14.3 if side==0 else 33.8,22.2 if side==0 else 41.7,ident,1.35)
   fixture('Bed'+str(number)+'_light',x,z,roof.name,ident,150)
   route('Bed'+str(number)+'_approach',[(28,-442),(28,z),(23 if side==0 else 33,z)])
 route('patient_spine',[(28,-463),(28,-404)]);route('arrival_to_ward',[(8.7,-432),(11,-432),(11,-442),(28,-442)])
 adm=ceiling('Admission_ceiling',(8.3,13.8,-465.7,-398.3),left,'admission')
 for z in [-454,-438,-422,-408]:fixture('Admission_'+str(z),11,z,adm.name,'admission')
 K.table('Admission_handover',9.7,-436,1.8,1.2,'admission',.85);K.seat('Companion_wait',9.6,-418,2.4,'admission',math.pi/2)
 for row in range(2):
  z0=-422+row*8;zc=z0+4
  for side,(x0,x1,front) in enumerate([(14.2,25.4,25.5),(30.6,41.8,30.5)]):
   number=row*2+side+1;ident=child(f'{SEC}_surgical_suite_{number:02}','surgical_suite_fit_target',[x0,x1,z0,z0+8],(front,zc))
   back=wallx('Surgery'+str(number)+'_back',x0 if side==0 else x1,z0,z0+8,zone=ident);wallx('Surgery'+str(number)+'_portal',front,z0,z0+8,[(zc,3.6,2.65)],ident)
   if row==0:wallz('Surgery'+str(number)+'_start',z0,x0,x1,ident)
   wallz('Surgery'+str(number)+'_end',z0+8,x0,x1,ident);c=ceiling('Surgery'+str(number)+'_ceiling',(x0,x1,z0,z0+8),back,ident)
   asset('AST-MED-003','Surgery'+str(number)+'_platform',(x0+x1)/2,zc,child=ident);asset('AST-MED-002','Surgery'+str(number)+'_wash',x0+2 if side==0 else x1-2,zc-2,child=ident);asset('AST-MED-004','Surgery'+str(number)+'_transfer',(x0+x1)/2+2,zc+1.8,child=ident)
   fixture('Surgery'+str(number)+'_task',(x0+x1)/2,zc,c.name,ident,350)
   route('Surgery'+str(number)+'_approach',[(28,-420),(28,zc),(front,zc),(front-1.3 if side==0 else front+1.3,zc)])
 ident=child(SEC+'_wash_transfer_and_treatment_01','wash_transfer_fit',[14.2,41.8,-406,-402],(28,-404));asset('AST-MED-002','Wash_transfer_west',19,-404,child=ident);asset('AST-MED-004','Transfer_east',38,-404,child=ident)
 spine=ceiling('Surgical_transfer_spine_ceiling',(25.4,30.6,-422,-406),'Surgery1_portal_pier0','clinical_transfer')
 for z in [-418,-410]:fixture('Surgical_spine_'+str(z),28,z,spine.name,'clinical_transfer',200)
 washroof=ceiling('Wash_transfer_ceiling',(14,42,-406,-402),wardedge,ident);fixture('Wash_transfer_task',28,-404,washroof.name,ident,220)
 service_edges(1);FLOORS.append([8,54,-466,-398]);VIEWS.extend([('arrival',(11,-432),(28,-442)),('general_beds',(28,-454),(19,-446)),('bed_fit',(24,-448),(19,-448)),('surgical_approach',(28,-418),(19,-418)),('wash_service',(28,-404),(40,-404))])
 HOLDS.append('Surgical suite gross rectangles narrowed at the center to retain a 5m internal transfer spine. Twenty general-bed identities remain unchanged; bed adaptations and clinical operation are unapproved.')
def equipment():
 # Keep the entire retained gate/stub prism X[-54,-48], Z[-217.8,-214.2] empty.
 west=wallx('Depot_internal_receiving_edge',-47.7,-249.6,-182.4,[(-216,3.6,2.65)],'arrival');wallx('Depot_east_skin',-8.3,-249.6,-182.4,zone='stock');wallz('Depot_fore_skin',-249.6,-47.7,-8.3);wallz('Depot_aft_skin',-182.4,-47.7,-8.3)
 roof=ceiling('Depot_fitted_ceiling',(-47.6,-8.4,-249.5,-182.5),west,'equipment_work')
 for x in [-44,-31.2,-10.7]:
  for z in [-247,-225,-206,-185]:
   n='Frame_'+str(x)+'_'+str(z);box(n+'_foot',x-.18,x+.18,z-.18,z+.18,0,.08,'zinc',zone='frame');box(n+'_post',x-.065,x+.065,z-.065,z+.065,.08,H,'zinc',n+'_foot','frame')
 for x in [-38,-22,-12]:
  for z in [-243,-230,-216,-202,-188]:fixture('Depot_'+str(x)+'_'+str(z),x,z,roof.name,'equipment_work',300)
 top=K.table('Issue_handover',-38,-219.5,5.4,1.4,'arrival',.86);K.terminal('Issue_record',-38,-219.5,top,'arrival',.95);K.swivel('Issue_staff_seat',-38,-221,'arrival')
 child(SEC+'_issue_handover','equipment_issue',[-43,-34,-222,-211],(-46,-216))
 for row,z in enumerate([-240,-232,-224]):
  K.shelf('Tool_stock_'+str(row),-21,z,16,1.2,'ready_stock',2.7);child(SEC+'_stock_row_'+str(row+1),'equipment_stock',[-29.2,-12.8,z-1.5,z+.2],(-31,z-3))
 for j,z in enumerate([-244,-235,-203]):asset('AST-STF-007','Workcab_'+str(j),-44.5,z,yaw=-math.pi/2,child='work_edges')
 top=K.table('Assessment_workbench',-22,-205,9,2.2,'assessment',.86);K.chart('Assessment_inset',-22,-205,2.4,1.3,top,'assessment',.955)
 child(SEC+'_assessment_work_edge','equipment_assessment',[-29,-15,-208,-201],(-22,-209))
 K.shelf('Repair_parts',-43,-197,7,1.0,'repair');asset('AST-HSK-003','Equipment_care_station',-12,-193,child='care');asset('AST-HSK-004','Used_only_return',-13,-187,child='used_return')
 K.seat('Staff_pause',-35,-184,3.4,'staff_pause');top=K.table('Staff_shared_table',-35,-186,1.6,1.0,'staff_pause',.55);K.cup('Staff_cup',-35,-186,.64,top,'staff_pause')
 child(SEC+'_care_and_used_return','care_and_used_only_return',[-18,-8.4,-197,-183],(-17,-190));child(SEC+'_staff_pause','staff_rest',[-39,-31,-190,-182.5],(-34,-188))
 route('retained_gate_to_issue',[(-48,-216),(-33,-216)]);route('depot_work_spine',[(-33,-247),(-33,-186)]);route('stock_retrieval',[(-33,-235),(-20,-235)]);route('assessment_approach',[(-33,-216),(-33,-209),(-22,-209)]);route('care_approach',[(-33,-186),(-17,-186),(-17,-193)])
 FLOORS.append([-48,-8,-250,-182]);HOLDS.append('Retained crew-platform gate/stub stays unchanged. Door mechanism and source platform installation remain root-owned. No second player cart.')
 VIEWS.extend([('arrival',(-46,-216),(-37,-219)),('stock',(-32,-236),(-15,-235)),('workbench',(-29,-209),(-21,-205)),('care',(-17,-190),(-12,-193)),('staff_pause',(-34,-188),(-35,-184))])
if SEC=='D05_directory_01':quarantine()
elif SEC=='D05_directory_02':medical()
elif SEC=='D03_directory_03':equipment()
else:raise RuntimeError('Unassigned section')
contract={'programme_key':SEC,'revision':'r001','allocation':AL,'children':CHILDREN,'routes':ROUTES,'native_asset_placements':ASSETS,'portals':PORTS,'floor_proposal_rectangles':FLOORS,'protected':PROTECTED,'holds':HOLDS,'views':[{'name':n,'camera_world':[a[0],F+1.65,a[1]],'target_world':[b[0],F+1.4,b[1]],'eye_height_m':1.65} for n,a,b in VIEWS],'capacity_and_operation_accepted':False}
bpy.context.scene['source_only']=True;K.save(contract)
print('REMAINING_SECTION_BUILT',SEC,'children',len(CHILDREN),'registered_native_placements',len(ASSETS))
