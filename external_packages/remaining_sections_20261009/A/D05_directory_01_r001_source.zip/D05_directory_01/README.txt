D05_directory_01 r001: isolated editable source and actual GLB.

Native: source\native.blend
SHA256 7cef45d70cd5de67ed9a8a7f73d044b21d97f58f24d1149a094a56527925844c
Export: exports\D05_directory_01.glb
SHA256 d1739f98500b96b3e3dd84168db1c6c300c84070cbed5369e50e7ca9743d9e3f

Use Blender 4.3.2, serialize heavy jobs and use two threads. From this package:
blender --background --threads 2 --python-exit-code 2 --python source/build.py

Actual source checks and individually inspected 1.65m views are retained under qa/. Failed earlier evidence remains under qa/failed or named prior logs. The export omits shared floors. QA-only parent-floor proposals and fixture preview lights do not constitute installed acceptance.

Receiving holds:
- No live integration or installed Godot route/collider/lighting/species/clinical/loaded-cart acceptance.
- Parent owns actual shared floors, outer routes, controlled clean/soiled crossings and relevant lift stops.
- The floor snapshot is a pinned local context, not a frozen final receiving baseline.
- Supplemental views use a 600W QA camera inspection lamp and ambient strength 0.3; no installed lighting acceptance is inferred.
- The original arrival continuation is blocked by unchanged ADMISSION_south_end. Root must review the proposed opening.
- Retained waiting and eight-pod floor owner proposals remain byte-identical but are absent from the pinned host snapshot; root reconciliation remains open.
- Two quarantine banks revise the canonical gross arrangement to retain a cart spine; local plan, clinical fit, species and capacity acceptance remain open.
- Earlier ambient-only and coplanar-preview-floor failures are preserved under qa/failed; source/export geometry was unchanged for review corrections.
- Exact prior source owner proposal retained byte-for-byte. These two owners are absent from the pinned local host snapshot; no installed floor preservation or receiving acceptance is inferred. Root must reconcile both records without replacing them.
- Source-only construction. No installed Godot, moving loaded cart, species fit, clinical operation, occupancy, whole-ship routing or load certification.
- Root owns shared floors, outer routes, controlled medical clean/soiled crossings and D03-D05 lift stops.
- Existing ADMISSION_south_end at Z-429 remains solid. Parent must approve/open a 3.6x2.4 receiving portal; incoming entry-to-addition traversal does not pass until that receiving change exists.
- Quarantine child rectangles revised from the aisle-free 4x3 grid to two six-room banks; receiving owner must approve local plan crosswalk before integration.
