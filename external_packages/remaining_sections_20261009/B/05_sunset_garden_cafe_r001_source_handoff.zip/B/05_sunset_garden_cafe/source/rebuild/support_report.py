import pathlib,json,sys,hashlib,struct
B=pathlib.Path(__file__).parent;P=B/sys.argv[1]
meta=json.loads((P/'source/build_metadata.json').read_text());rows=json.loads((P/'qa/imported_objects.json').read_text());errors=[];contacts=[]
for c in meta['contacts']:
    group=[r['bounds'] for n,r in rows.items() if n==c['name']] if c['type']=='authored_root_base' else [r['bounds'] for n,r in rows.items() if n.startswith(c['name']+'__')]
    if not group:errors.append({'contact':c['name'],'error':'missing actual donor group'});continue
    bottom=min(b[2][0] for b in group);support=c['support'];target=0 if support=='ROOT_FLOOR' else rows[support]['bounds'][2][1]
    delta=bottom-target
    contacts.append({'name':c['name'],'support':support,'actual_export_base_h':bottom,'actual_support_top_h':target,'delta_m':delta,'root_owned_support_proposal':support=='ROOT_FLOOR'})
    if abs(delta)>.005:errors.append({'contact':c['name'],'error':'base/support separation','delta_m':delta})
raw=(P/'exports/section_r001.glb').read_bytes();magic,version,length=struct.unpack_from('<III',raw);size,kind=struct.unpack_from('<II',raw,12);g=json.loads(raw[20:20+size]);assert magic==0x46546c67 and version==2 and length==len(raw) and kind==0x4e4f534a
external=[x.get('uri') for x in g.get('images',[])+g.get('buffers',[]) if x.get('uri') and not x['uri'].startswith('data:')]
if external:errors.append({'error':'external GLB resource references','uris':external})
report={'source_sha256':hashlib.sha256((P/'source/section_r001.blend').read_bytes()).hexdigest(),'export_sha256':hashlib.sha256(raw).hexdigest(),'contacts':contacts,'embedded_glb_images':len(g.get('images',[])),'external_glb_resources':external,'errors':errors,'scope':'Actual GLB donor-group base versus actual supporting top plane and embedded-resource closure; root slab remains proposed; structural load and engine acceptance unperformed'}
(P/'qa/support_contacts.json').write_text(json.dumps(report,indent=2));print('Actual donor support contacts',len(contacts),'errors',len(errors))
assert not errors,errors
