from mathutils import Matrix
import bmesh
DONOR_CACHE={}; CONTACTS=[]; ROUTES={}; FIXTURES=[]
DONORS={'tree':'botanical_canopy/AST-BOT-001.blend','under':'botanical_understory/source/AST-BOT-002.blend','flower':'botanical_understory/source/AST-BOT-003.blend','seat':'canopy_terrace/source/AST-GAR-004.blend','drink':'hospitality_stations/source/AST-HSP-003.blend','return':'hospitality_stations/source/AST-HSP-004.blend'}

def donor(n,key,u,v,h=0,scale=1,angle=0,subset=None,sup='ROOT_FLOOR'):
    token=(key,tuple(subset or []))
    if token not in DONOR_CACHE:
        p=BASE/'inputs/BlenderCatalogue/assets'/DONORS[key]
        with bpy.data.libraries.load(str(p),link=False) as (src,dst):
            dst.objects=[x for x in src.objects if not subset or x in subset]
        originals=[o for o in dst.objects if o and o.type in ('MESH','CURVE','FONT')]
        pts=[o.matrix_world@Vector(c) for o in originals for c in o.bound_box]
        centre=Vector(((min(p.x for p in pts)+max(p.x for p in pts))/2,(min(p.y for p in pts)+max(p.y for p in pts))/2,min(p.z for p in pts)))
        # Pinned AST-BOT-001's visible evaluated base is +0.105m above its
        # authored bounds origin, proven by actual GLB donor-group vertices.
        if key=='tree':centre.z+=.105
        DONOR_CACHE[token]=(originals,centre)
    originals,centre=DONOR_CACHE[token]
    reflection=Matrix.Diagonal((C['sign'],1,1,1))
    transform=Matrix.Translation(Vector(xyz(u,h,v)))@reflection@Matrix.Rotation(angle,4,'Z')@Matrix.Scale(scale,4)@Matrix.Translation(-centre)
    for i,orig in enumerate(originals):
        o=orig.copy();o.data=orig.data.copy();COL.objects.link(o);o.parent=None;o.matrix_world=transform@orig.matrix_world
        o.name=n+'__'+orig.name;o.hide_viewport=False;o.hide_render=False;o.hide_select=False;o.hide_set(False)
        if key=='drink' and orig.name in ['rear_service_panel_gasket','rear_service_panel','dark_control_fascia']:
            bpy.context.view_layer.update();dg=bpy.context.evaluated_depsgraph_get();evaluated=bpy.data.meshes.new_from_object(o.evaluated_get(dg));lo=[min(v.co[k] for v in evaluated.vertices) for k in range(3)];hi=[max(v.co[k] for v in evaluated.vertices) for k in range(3)];materials=list(o.data.materials);bpy.data.meshes.remove(evaluated)
            for k in range(3):
                if hi[k]-lo[k]<.0001:mid=(hi[k]+lo[k])/2;lo[k]=mid-.00005;hi[k]=mid+.00005
            vs=[(lo[0] if x<0 else hi[0],lo[1] if y<0 else hi[1],lo[2] if z<0 else hi[2]) for x,y,z in [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),(-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]];me=bpy.data.meshes.new(o.name+'_clean_native_panel');me.from_pydata(vs,[],[(3,2,1,0),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]);me.update();o.modifiers.clear();o.data=me
            for ma in materials:me.materials.append(ma)
            uv(o);o['source_repair']='Copied native panel rebuilt as closed solid at evaluated local bounds; original Catalogue untouched'
        o['programme_key']=C['key'];o['support']=sup;o['role']='botanical_foliage' if key in ['tree','under','flower'] else 'reused_fixture';o['donor_key']=key;o['donor_original']=orig.name;A.append(o)
    CONTACTS.append({'name':n,'type':'native_donor_base','support':sup,'root_local_uvh':[u,v,h],'source_file':DONORS[key],'subset':subset,'scale':scale})

def soil_mat():
    ma=bpy.data.materials.new('D06_growing_medium');ma.use_nodes=True;bs=ma.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(.055,.038,.020,1);bs.inputs['Roughness'].default_value=.95;M['soil']=ma
    ma=bpy.data.materials.new('D06_still_water_source');ma.use_nodes=True;bs=ma.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(.045,.19,.16,1);bs.inputs['Roughness'].default_value=.27;bs.inputs['Metallic'].default_value=.15;M['water']=ma

def bed(n,u,v,w,d,height=.55,trees=0,under=0,flower=0):
    # Four walls leave a genuine growing opening; bottom and medium rest above Y27.
    box(n+'_bottom',u,.06,v,w,.12,d,'stone',role='floor_contact')
    for vv in [v-d/2+.13,v+d/2-.13]:box(n+'_coping_v'+str(vv),u,height/2,vv,w,height,.26,'stone',n+'_bottom')
    for uu in [u-w/2+.13,u+w/2-.13]:box(n+'_coping_u'+str(uu),uu,height/2,v,.26,height,d-.5,'stone',n+'_bottom')
    box(n+'_medium',u,height-.08,v,w-.54,.16,d-.54,'soil',n+'_bottom','growing_medium',0)
    for j in range(trees):
        uu=u+(j-(trees-1)/2)*min(3.6,(w-3)/max(1,trees-1));donor(n+'_tree'+str(j),'tree',uu,v,height,1.45 if C['kind']=='living' else 1.05,j*.65,sup=n+'_medium')
    for j in range(under):
        uu=u-w/2+1+(j%max(1,int(w/2)))*1.65;vv=v-d/2+1+(j//max(1,int(w/2)))*1.5
        donor(n+'_under'+str(j),'under',uu,vv,height,1.0,j*.7,sup=n+'_medium')
    for j in range(flower):donor(n+'_flower'+str(j),'flower',u-w/2+.8+j*(w-1.6)/max(1,flower-1),v+d/2-.9,height,1,j*.4,sup=n+'_medium')

def reused_rest(n,u,v):
    # Reuse one existing integrated-seat part; the Canopy Terrace shell/floor is excluded.
    box(n+'_bearing',u,.05,v,2.8,.1,.75,'wood',role='floor_contact')
    donor(n,'seat',u,v,.1,subset=['CAN_NicheRest_0'],sup=n+'_bearing')
    box(n+'_back',u,.79,v+.34,2.8,.90,.12,'cloth',n+'_bearing')

def service():
    # Bounded internal bay; external service link remains a closed named contact.
    box('Tending_bay_screen',41.9,1.45,55.8,.18,2.9,6,'cool',role='floor_contact')
    counter('Tending_work',[(38,59),(41,59),(41,60.5),(38,60.5)],'cool','zinc',.92)
    shelf('Tending_store',40.3,57,2.4,2.2,items='supplies',mat='cool')
    for j in range(3):box('Tending_bin'+str(j),38.6+j*.7,.92+.14,59.75,.50,.28,.50,'ivory','Tending_work_top','inert_tending_supplies')
    box('Maintenance_contact_closed',43.7,1.3,59,.18,2.6,2.3,'cool',role='floor_contact')
    lamp('Tending_task',36.8,59,2.8,cool=True)
    FIXTURES.append({'name':'maintenance_room_side_contact','world_xyz':[C['sign']*(C['x']+43.7),27,C['z']+59],'width_m':2.3,'height_m':2.6,'status':'closed source-only face; external route/door/root floor unverified'})

def shell(poly,height):
    global POLY
    POLY=poly
    for j,(a,b) in enumerate(zip(poly,poly[1:]+poly[:1])):
        if a[0]==b[0]==0:continue
        edge('Enclosure_'+str(j),a,b,0,height if C['kind']=='fern' else C['ceiling'],.22,'ivory',role='floor_contact')
        edge('Wall_base_'+str(j),a,b,0,.35,.30,'wood',role='floor_contact')
    for vv in [31.15,36.85]:box('Entry_cheek'+str(vv),3.0,1.50,vv,6,3,.32,'wood',role='floor_contact')
    box('Entry_head',3,3.10,34,6,.20,6,'wood','Entry_cheek31.15')
    box('Identity_mount',5.8,2.0,30.6,.15,.5,1.25,'brass','Entry_cheek31.15');text('Identity',C['name'].upper(),5.7,2.0,30.6,.105,'Identity_mount')
    ceiling_light('Threshold_light',3,34,2.82,'Entry_head',500)

def lid(n,poly,h):
    return prism(n,poly,h,.18,'ivory','Enclosure_2','opaque_supported_roof',0)

def living():
    shell([(0,31),(7,31),(7,14),(15,6),(36,6),(44,14),(44,61),(39,64),(15,62),(7,54),(7,37),(0,37)],4.8)
    # Low perimeter shoulders and a higher, longitudinal garden lantern, entirely opaque.
    lid('Garden_opaque_roof',POLY,5.9)
    for u,v in [(11,18),(40,18),(11,49),(40,49)]:
        box('Garden_pier'+str((u,v)),u,2.90,v,.55,5.8,.55,'wood',role='floor_contact');rod('Garden_haunch'+str((u,v)),(u,4.2,v),(25,5.88,v),.16,'wood','Garden_pier'+str((u,v)))
    bed('First_island',19,20,9,9,.55,trees=2,under=6,flower=4)
    bed('Quiet_island',29,48,11,9,.70,trees=3,under=8,flower=5)
    bed('Focal_island',37,25,7,8,.42,trees=1,under=4,flower=3)
    for j,(u,v) in enumerate([(15,14),(20,27),(23,55),(34,40)]):reused_rest('Grove_rest'+str(j),u,v);lamp('Grove_light'+str(j),u-2,v,3.3)
    table('Study_pause',18,30,2.4,1.2)
    for j,(u,v) in enumerate([(16,34),(30,34),(26,14),(24,57)]):ceiling_light('Garden_light'+str(j),u,v,4.7,'Garden_opaque_roof',1600)
    service()
    ROUTES.update(arrival=[(1,34),(13,34),(30,34)],planted_visit=[(13,34),(27,34),(27,10),(29,10),(29,18)],rest=[(13,34),(23,34),(23,38),(34,38)],maintenance=[(13,34),(17,34),(17,58),(35,58),(35,60),(36,60)])

def orchard():
    shell([(0,31),(7,31),(7,8),(37,8),(44,15),(44,61),(7,61),(7,37),(0,37)],4.2)
    lid('Orchard_opaque_lid',POLY,5.6)
    for j,v in enumerate([12,25,43,56]):
        for u in [10,42]:box('Orchard_post'+str((u,v)),u,2.8,v,.35,5.6,.35,'wood',role='floor_contact')
        rod('Orchard_trellis'+str(j),(10,5.55,v),(42,5.55,v),.15,'wood','Orchard_post'+str((10,v)))
    for j,(u,v,w,d) in enumerate([(19,18,9,8),(34,18,9,8),(19,49,9,8),(33,48,9,8)]):
        bed('Orchard_row'+str(j),u,v,w,d,.52,trees=2,under=5,flower=3)
        # Restrained inert fruit silhouettes: no harvesting or biological claim.
        # Botanical specimens remain unclaimed cultivar proposals; no floating fruit props.
    counter('Botanical_demonstration',[(15,28),(21,28),(21,30),(15,30)],'wood','stone',.9)
    for j in range(3):box('Seed_tray'+str(j),16+j*1.5,.95,29,1.0,.10,.6,'ivory','Botanical_demonstration_top')
    for j,(u,v) in enumerate([(11,20),(11,49),(29,58)]):reused_rest('Orchard_pause'+str(j),u,v);lamp('Orchard_pause_light'+str(j),u+2,v,3.1)
    for j,(u,v) in enumerate([(17,34),(32,34),(25,12),(25,55)]):ceiling_light('Orchard_fixture'+str(j),u,v,4.4,'Orchard_opaque_lid',1400)
    service();ROUTES.update(arrival=[(1,34),(38,34)],rows=[(12,34),(27,34),(27,13),(36,13)],demonstration=[(12,34),(18,34),(18,32)],maintenance=[(12,34),(27,34),(27,56),(35,56),(35,60),(36,60)])

def fern(n,u,v,h=.60,scale=1,sup='ROOT_FLOOR'):
    # Original editable pinnate fronds; curved spine plus paired leaflets.
    disc(n+'_root',u,h,v,.20,.16,'wood',sup,'botanical_root')
    CONTACTS.append({'name':n+'_root','type':'authored_root_base','support':sup,'root_local_uvh':[u,v,h]})
    for j in range(7):
        a=j*math.tau/7
        def pt(t):return (u+scale*2.0*t*math.cos(a),h+scale*(2.8*t-1.1*t*t),v+scale*2.0*t*math.sin(a))
        for k in range(8):rod(n+'_spine'+str((j,k)),pt(k/8),pt((k+1)/8),.022*scale,'green',n+'_root','botanical_foliage',8)
        for k in range(1,8):
            p=pt(k/8);size=scale*.46*math.sin(math.pi*k/9)
            for side in [-1,1]:
                end=(p[0]+side*size*math.cos(a+math.pi/2)+.08*scale*math.cos(a),p[1]-.12*scale,p[2]+side*size*math.sin(a+math.pi/2)+.08*scale*math.sin(a))
                mid=tuple((p[t]+end[t])/2 for t in range(3));width=.11*scale
                leaf=[p,(mid[0]+width*math.cos(a),mid[1]+.025*scale,mid[2]+width*math.sin(a)),end,(mid[0]-width*math.cos(a),mid[1]-.015*scale,mid[2]-width*math.sin(a))]
                vs=[xyz(q[0],q[1]+offset,q[2]) for offset in [-.006,.006] for q in leaf];me=bpy.data.meshes.new('Tapered_pinna');me.from_pydata(vs,[],[(3,2,1,0),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]);o=bpy.data.objects.new(n+'_leaflet'+str((j,k,side)),me);COL.objects.link(o);finish(o,o.name,'green',n+'_spine'+str((j,k-1)),'botanical_foliage',0)

def cathedral():
    shell([(0,31),(8,31),(8,10),(42,10),(44,16),(44,62),(8,62),(8,37),(0,37)],4.5)
    lid('Nave_entry_roof',[(0,31),(8,31),(8,37),(0,37)],4.5)
    # Close the upper side walls against the sloped opaque roof. Shared
    # indices preserve outward shell winding even at the triangular end bays.
    for uu in [8,44]:
        for v0,v1,ha,hb in [(10,20,4.5,5.2),(20,34,5.2,6.9),(34,48,6.9,5.2),(48,62,5.2,4.5)]:
            coords=[xyz(u,h,v) for u,h,v in [(uu-.11,4.5,v0),(uu+.11,4.5,v0),(uu+.11,4.5,v1),(uu-.11,4.5,v1),(uu-.11,ha,v0),(uu+.11,ha,v0),(uu+.11,hb,v1),(uu-.11,hb,v1)]]
            verts=[];index=[]
            for co in coords:
                if co not in verts:verts.append(co)
                index.append(verts.index(co))
            faces=[]
            for face in [(3,2,1,0),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]:
                f=list(dict.fromkeys(index[i] for i in face))
                if len(f)>=3:faces.append(f)
            me=bpy.data.meshes.new('Nave_upper_enclosure');me.from_pydata(verts,[],faces)
            o=bpy.data.objects.new('Nave_upper_enclosure'+str((uu,v0)),me);COL.objects.link(o);finish(o,o.name,'ivory','Enclosure_2','roof_closure',0)
    # Solid roof panels meet a pointed ridge; no open skylight and no ceiling cut.
    for v0,v1,ha,hb in [(10,20,4.5,5.2),(20,34,5.2,6.9),(34,48,6.9,5.2),(48,62,5.2,4.5)]:
        poly=[(8,v0),(44,v0),(44,v1),(8,v1)];vs=[xyz(u,h,v) for u,h,v in [(8,ha,v0),(44,ha,v0),(44,hb,v1),(8,hb,v1)]];vs+= [(x,y,z+.16) for x,y,z in vs];me=bpy.data.meshes.new('Nave_roof');me.from_pydata(vs,[],[(3,2,1,0),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]);o=bpy.data.objects.new('Nave_roof'+str(v0),me);COL.objects.link(o);finish(o,o.name,'ivory','Enclosure_2','opaque_supported_roof',0)
    for j,u in enumerate([10,20,30,42]):
        for v in [12,60]:box('Nave_pier'+str((j,v)),u,2.2,v,.6,4.4,.6,'stone',role='floor_contact')
        pts=[(u,4.4,12),(u,5.1,20),(u,6.8,34),(u,5.1,48),(u,4.4,60)]
        for k in range(4):rod('Pointed_rib'+str((j,k)),pts[k],pts[k+1],.14,'wood','Nave_pier'+str((j,12)))
    for j,(u,v) in enumerate([(15,21),(26,21),(37,21),(15,48),(26,48),(37,48)]):
        bed('Fern_bed'+str(j),u,v,7,9,.6,under=5,flower=2)
        fern('Fern_crown'+str(j),u,v,.6,1.2,sup='Fern_bed'+str(j)+'_medium')
    for j,(u,v) in enumerate([(14,13),(27,13),(15,57)]):reused_rest('Quiet_transept'+str(j),u,v);lamp('Quiet_nave_lamp'+str(j),u+2,v,3.2)
    for j,u in enumerate([13,25,38]):ceiling_light('Nave_fixture'+str(j),u,34,5.1,'Nave_roof20',1700)
    service();ROUTES.update(arrival=[(1,34),(39,34)],transept=[(10,34),(10,15.1),(25,15.1)],plants=[(10,34),(25,34),(25,40)],maintenance=[(10,34),(10,58.7),(35,58.7),(35,60),(36,60)])

def basin(n,u,v,w,d):
    box(n+'_bottom',u,.10,v,w,.20,d,'stone',role='floor_contact')
    for vv in [v-d/2+.15,v+d/2-.15]:box(n+'_bank'+str(vv),u,.35,vv,w,.7,.30,'stone',n+'_bottom')
    for uu in [u-w/2+.15,u+w/2-.15]:box(n+'_return'+str(uu),uu,.35,v,.30,.7,d-.60,'stone',n+'_bottom')
    box(n+'_still_water',u,.54,v,w-.65,.025,d-.65,'water',n+'_bottom','inert_still_water_visual',0)

def waterside():
    shell([(0,31),(8,31),(8,11),(18,6),(40,6),(44,16),(44,63),(33,63),(8,58),(8,37),(0,37)],4.6)
    lid('Cove_opaque_roof',POLY,5.6)
    for j,(u,v) in enumerate([(13,13),(41,13),(13,56),(41,54)]):box('Cove_pier'+str(j),u,2.8,v,.55,5.6,.55,'stone',role='floor_contact')
    basin('First_reflecting_basin',24,20,16,9);basin('Upper_reflecting_basin',29,47,13,10)
    bed('Water_garden_first',23,12,14,4,.6,trees=3,under=5,flower=5);bed('Water_garden_second',28,56,12,4,.6,trees=3,under=4,flower=4)
    for j,(u,v) in enumerate([(18,27),(34,29),(22,40),(39,47)]):reused_rest('Cove_rest'+str(j),u,v);lamp('Cove_lamp'+str(j),u+2,v,3.1)
    for j,(u,v) in enumerate([(15,34),(32,34),(34,12),(15,52)]):ceiling_light('Cove_fixture'+str(j),u,v,4.2,'Cove_opaque_roof',1400)
    service();FIXTURES.append({'name':'WATER_MAINTENANCE_ROOM_SIDE','local_uvh':[41,59,.6],'status':'proposal only; no connection, flow or extension to root aquatic/cascade system'})
    ROUTES.update(arrival=[(1,34),(36,34)],waterside=[(12,34),(12,20),(14,20)],pause=[(12,34),(22,34),(22,38)],maintenance=[(12,34),(12,54),(17,54),(17,58),(23,60),(35,60),(37,60.1)])

def cafe():
    shell([(0,31),(7,31),(7,11),(18,6),(40,6),(44,15),(44,63),(19,63),(7,56),(7,37),(0,37)],4.4)
    lid('Cafe_opaque_roof',POLY,5.6)
    # Serving core and a fitted preparation edge; distinct front and back circulation.
    counter('Ordering_island',[(18,25),(23,25),(25,29),(25,39),(23,42),(18,42)],'wood','stone',.96)
    donor('Beverage_station','drink',21,29,.96,angle=math.pi/2,sup='Ordering_island_top')
    donor('Dirty_return','return',27,44,0,angle=math.pi/2)
    counter('Preparation_edge',[(37,18),(41,18),(41,35),(37,35)],'cool','zinc',.92)
    shelf('Cafe_service_stock',40.2,39,4.5,2.5,items='supplies',mat='cool')
    for j in range(3):box('Preparation_tray'+str(j),39,.96,22+j*3.2,2,.08,1.6,'ivory','Preparation_edge_top')
    edge('Prep_screen',(35.4,14),(35.4,39),0,2.6,.18,'wood',role='floor_contact')
    for j,(u,v) in enumerate([(13,16),(25,15),(13,50),(26,53),(34,52)]):
        table('Cafe_table'+str(j),u,v,2.2,1.2)
        for k,vv in enumerate([v-1.45,v+1.45]):bench('Cafe_booth'+str((j,k)),u,vv,2.6,'south' if k==0 else 'north')
        lamp('Cafe_light'+str(j),u+2,v,3.0)
    bed('Cafe_garden_first',25,8.5,16,3,.52,trees=3,under=4,flower=4)
    bed('Cafe_garden_pause',16,58,11,3,.52,trees=2,under=4,flower=4)
    for j,u in enumerate([12,25,42]):box('Cafe_roof_pier'+str(j),u,2.8,11,.45,5.6,.45,'wood',role='floor_contact')
    for j,(u,v) in enumerate([(13,34),(21,34),(30,20),(32,45)]):ceiling_light('Cafe_fixture'+str(j),u,v,4.0,'Cafe_opaque_roof',1600)
    service();ROUTES.update(arrival_order=[(1,34),(15,34)],garden_pause=[(12,34),(12,24),(25,24),(25,19)],dirty_return=[(12,34),(12,45),(23,45)],staff_work=[(30,45),(30,40),(32,40),(32,12.7),(39,12.7),(39,17.1)],maintenance=[(12,34),(12,45.8),(30,45.8),(30,60),(37,60.1)])

VIEWS={
 'living':[('arrival',(1.5,34),(29,34)),('grove',(13,30),(23,20)),('branch_walk',(27,34),(30,49)),('rest',(28,39),(34,40)),('maintenance',(34.5,59),(40,59))],
 'orchard':[('arrival',(1.5,34),(30,34)),('rows',(27,30),(29,18)),('demonstration',(17,33),(18,29)),('pause',(25,55),(29,58)),('maintenance',(35,59),(40,59))],
 'fern':[('arrival',(1.5,34),(35,34)),('nave',(12,34),(38,34)),('fronds',(25,40),(28,48)),('transept',(25,16),(26,21)),('maintenance',(35,59),(40,59))],
 'waterside':[('arrival',(1.5,34),(30,34)),('basin',(14,24),(26,20)),('water_cove',(20,38),(29,47)),('pause',(30,34),(34,29)),('maintenance',(35,59),(40,59))],
 'cafe':[('arrival',(1.5,34),(23,34)),('order',(15,34),(21,29)),('garden_pause',(18,24),(25,15)),('return',(23,45),(27,44)),('preparation',(39,16),(39,26))]
}

def bbox(o):
    pts=[o.matrix_world@Vector(c) for c in o.bound_box];return [[min(p[i] for p in pts),max(p[i] for p in pts)] for i in range(3)]
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def export():
    bpy.ops.object.select_all(action='DESELECT');copies=[]
    bpy.context.view_layer.update();depsgraph=bpy.context.evaluated_depsgraph_get()
    for orig in A:
        me=bpy.data.meshes.new_from_object(orig.evaluated_get(depsgraph),preserve_all_data_layers=True,depsgraph=depsgraph)
        me.transform(orig.matrix_world)
        if orig.matrix_world.to_3x3().determinant()<0:me.flip_normals()
        if orig.type=='FONT':
            bm=bmesh.new();bm.from_mesh(me);bmesh.ops.dissolve_degenerate(bm,dist=0.0001,edges=list(bm.edges));bmesh.ops.triangulate(bm,faces=list(bm.faces));tiny=[f for f in bm.faces if f.calc_area()<0.00000001]
            if tiny:bmesh.ops.delete(bm,geom=tiny,context='FACES')
            bm.to_mesh(me);bm.free()
        me.update();o=bpy.data.objects.new(orig.name+'__EXPORT',me);COL.objects.link(o)
        for key in orig.keys():o[key]=orig[key]
        o['source_native_name']=orig.name
        if not me.uv_layers:uv(o)
        copies.append(o);o.select_set(False)
    for o in copies:o.select_set(True)
    bpy.ops.export_scene.gltf(filepath=str(P/'exports/section_r001.glb'),export_format='GLB',use_selection=True,export_apply=True,export_extras=True,export_texcoords=True,export_normals=True,export_cameras=False,export_lights=False)
    for o in copies:bpy.data.objects.remove(o,do_unlink=True)

def validate():
    bpy.context.view_layer.update();rows=[];errors=[]
    for o in A:
        bb=bbox(o);rows.append({'name':o.name,'type':o.type,'bounds_blender':bb,'support':o.get('support'),'role':o.get('role'),'donor_key':o.get('donor_key')})
        if bb[0][0]<(-46 if C['sign']<0 else 0)-.005 or bb[0][1]>(0 if C['sign']<0 else 46)+.005 or bb[1][0]<-68-.005 or bb[1][1]>.005 or bb[2][0]<-.005 or bb[2][1]>C['roof']-27+.005:errors.append({'name':o.name,'containment':bb})
        if o.type=='MESH' and not o.data.uv_layers:errors.append({'name':o.name,'error':'UV missing'})
    images=[{'name':im.name,'packed':bool(im.packed_file)} for im in bpy.data.images if im.source=='FILE']
    if any(not x['packed'] for x in images):errors.append({'error':'unpacked image'})
    (P/'qa/objects.json').write_text(json.dumps(rows,indent=2));report={'errors':errors,'objects':len(A),'source_sha256':digest(P/'source/section_r001.blend'),'export_sha256':digest(P/'exports/section_r001.glb'),'images':images,'floor_in_native':any('QA_FLOOR' in o.name for o in bpy.context.scene.objects),'scope':'Saved native source/actual export containment and packed-resource screen; live acceptance pending'};(P/'qa/validation.json').write_text(json.dumps(report,indent=2))
    if errors:raise RuntimeError('Source validation failed '+str(errors[:5]))

def render():
    sc=bpy.context.scene;sc.render.engine='BLENDER_EEVEE_NEXT';sc.render.resolution_x=960;sc.render.resolution_y=540;sc.render.resolution_percentage=100;sc.render.threads_mode='FIXED';sc.render.threads=2;sc.render.image_settings.file_format='PNG';sc.world=sc.world or bpy.data.worlds.new('Source low ambient');sc.world.color=(.07,.07,.07);sc.view_settings.view_transform='AgX'
    preview=prism('QA_FLOOR_PROPOSAL',POLY,-.12,.12,'stone',role='qa_only_preview_floor',bev=0);A.remove(preview)
    # Closed extrusions have shared vertex indices; normal recalculation sees welded shells.
    for l in LIGHTS:
        ld=bpy.data.lights.new('QA_'+l['name'],'AREA');ld.energy=l['power'];ld.color=l['color'];ld.shape='DISK';ld.size=l['size'];o=bpy.data.objects.new(ld.name,ld);sc.collection.objects.link(o);o.location=xyz(*l['pos'])
    data=bpy.data.cameras.new('QA_NORMAL_EYE');cam=bpy.data.objects.new(data.name,data);sc.collection.objects.link(cam);sc.camera=cam;data.lens=21;data.clip_end=130
    views=[]
    for n,(u,v),(tu,tv) in VIEWS[C['kind']]:
        cam.location=xyz(u,1.65,v);cam.rotation_euler=(Vector(xyz(tu,1.65,tv))-cam.location).to_track_quat('-Z','Y').to_euler();sc.render.filepath=str(P/'qa/views'/(n+'.png'));bpy.ops.render.render(write_still=True);views.append({'name':n,'eye_local_uvh':[u,v,1.65],'target_local_uvh':[tu,tv,1.65],'sha256':digest(sc.render.filepath)})
    (P/'qa/view_receipt.json').write_text(json.dumps({'source_sha256':digest(P/'source/section_r001.blend'),'export_sha256':digest(P/'exports/section_r001.glb'),'views':views,'scope':'normal-height source preview; proposed root slab only in renders; no Godot acceptance'},indent=2))

def run():
    global COL
    bpy.ops.wm.read_factory_settings(use_empty=True);COL=bpy.data.collections.new('Remaining Batch B '+C['name']);bpy.context.scene.collection.children.link(COL);bpy.context.scene.unit_settings.system='METRIC';materials();soil_mat()
    {'living':living,'orchard':orchard,'fern':cathedral,'waterside':waterside,'cafe':cafe}[C['kind']]()
    for im in bpy.data.images:
        if im.source=='FILE' and not im.packed_file:im.pack()
    bpy.context.scene['programme_key']=C['key'];bpy.context.scene['placement_xyz']=[C['sign']*8,27,C['z']];bpy.context.scene['root_floor_external_routes_pending']=True
    (P/'source/build_metadata.json').write_text(json.dumps({'section':C,'polygon':POLY,'lights':LIGHTS,'routes':ROUTES,'contacts':CONTACTS,'fixtures':FIXTURES,'source_frame':'Blender(signed u,-v,h); GLB(signed u,h,v)','no_preview_floor_in_native_or_export':True},indent=2))
    bpy.ops.wm.save_as_mainfile(filepath=str(P/'source/section_r001.blend'));export();validate();render()
run()
# Reopen the saved native and actual GLB after rendering, within this same
# live heavy wrapper. Later rooms need one queued job rather than two.
USED_VERIFY=(BASE/'verify_sections.py').read_bytes()
(P/'source/verify_used.py').write_bytes(USED_VERIFY)
exec(USED_VERIFY.decode('utf-8'))
