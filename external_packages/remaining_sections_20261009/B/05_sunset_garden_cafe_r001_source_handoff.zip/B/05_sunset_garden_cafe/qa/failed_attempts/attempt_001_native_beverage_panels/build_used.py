"""Batch B original fitted source proposals. Blender 4.3.2; metres.
Each rebuild is independent. Root owns structural adoption, floors, doors and runtime.
Run via heavy_job.py so all heavy work holds the shared Windows mutex.
"""
import bpy,math,json,sys,hashlib,random,bmesh
from pathlib import Path
from mathutils import Vector
BASE=Path(__file__).resolve().parent
USED_SOURCE=Path(__file__).read_bytes()
USED_PROFILES=(BASE/'section_profiles.json').read_bytes()
CONFIG=json.loads(USED_PROFILES)
section=sys.argv[sys.argv.index('--')+1];mode=sys.argv[sys.argv.index('--')+2];C=CONFIG[section];P=BASE/section
for n in ['source','exports','qa/views','docs']: (P/n).mkdir(parents=True,exist_ok=True)
M={};A=[];LIGHTS=[];POLY=[];COL=None
if not mode.startswith('render'):
 (P/'source/build_used.py').write_bytes(USED_SOURCE)
 (P/'source/profiles_used.json').write_bytes(USED_PROFILES)
else:(P/'qa/render_used.py').write_bytes(USED_SOURCE)

def xyz(u,h,v):return (C['sign']*u,-v,h)
def uv(o):
 if o.type!='MESH':return
 o.data.update();layer=o.data.uv_layers.active or o.data.uv_layers.new(name='UV0')
 for f in o.data.polygons:
  drop=max(range(3),key=lambda i:abs(f.normal[i]));axes=[i for i in range(3) if i!=drop]
  for li in f.loop_indices:
   co=o.data.vertices[o.data.loops[li].vertex_index].co;layer.data[li].uv=(co[axes[0]]*.8,co[axes[1]]*.8)

def finish(o,n,mat,support='ROOT_FLOOR',role='fitted',bev=.025):
 o.name=n
 for c in list(o.users_collection):c.objects.unlink(o)
 COL.objects.link(o)
 if o.type=='MESH':
  bm=bmesh.new();bm.from_mesh(o.data)
  if bev:bmesh.ops.bevel(bm,geom=list(bm.edges),offset=bev,segments=2,affect='EDGES',clamp_overlap=True)
  bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(o.data);bm.free();o.data.update()
  uv(o)
 o.data.materials.append(M[mat]);o['programme_key']=C['key'];o['support']=support;o['role']=role;A.append(o);return o

def box(n,u,h,v,w,ht,d,mat='wood',support='ROOT_FLOOR',role='fitted',bev=.025):
 vs=[(x*w/2,y*d/2,z*ht/2) for x,y,z in [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),(-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]];me=bpy.data.meshes.new(n);me.from_pydata(vs,[],[(3,2,1,0),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]);o=bpy.data.objects.new(n,me);o.location=xyz(u,h,v);COL.objects.link(o);return finish(o,n,mat,support,role,min(bev,min(w,ht,d)*.3))
def prism(n,poly,h,ht,mat,sup='ROOT_FLOOR',role='fitted',bev=.025):
 vs=[xyz(u,h,v) for u,v in poly]+[xyz(u,h+ht,v) for u,v in poly];count=len(poly);faces=[tuple(reversed(range(count))),tuple(range(count,2*count))]+[(i,(i+1)%count,(i+1)%count+count,i+count) for i in range(count)]
 me=bpy.data.meshes.new(n);me.from_pydata(vs,[],faces);me.update();o=bpy.data.objects.new(n,me);COL.objects.link(o);return finish(o,n,mat,sup,role,bev)
def rod(n,a,b,r,mat='brass',sup='ROOT_FLOOR',role='support',vertices=12):
 pa=Vector(xyz(*a));pb=Vector(xyz(*b));delta=pb-pa;q=delta.to_track_quat('Z','Y');vs=[q@Vector((r*math.cos(j*math.tau/vertices),r*math.sin(j*math.tau/vertices),h)) for h in [-delta.length/2,delta.length/2] for j in range(vertices)];faces=[tuple(reversed(range(vertices))),tuple(range(vertices,2*vertices))]+[(j,(j+1)%vertices,(j+1)%vertices+vertices,j+vertices) for j in range(vertices)];me=bpy.data.meshes.new(n);me.from_pydata(vs,[],faces);o=bpy.data.objects.new(n,me);o.location=(pa+pb)/2;COL.objects.link(o);return finish(o,n,mat,sup,role,.007)
def disc(n,u,h,v,r,ht,mat,sup='ROOT_FLOOR',role='fitted'):
 return rod(n,(u,h,v),(u,h+ht,v),r,mat,sup,role,24)
def edge(n,a,b,h,ht,width,mat,sup='ROOT_FLOOR',role='enclosure'):
 du,dv=b[0]-a[0],b[1]-a[1];ln=math.hypot(du,dv);nu,nv=-dv/ln*width/2,du/ln*width/2
 return prism(n,[(a[0]+nu,a[1]+nv),(b[0]+nu,b[1]+nv),(b[0]-nu,b[1]-nv),(a[0]-nu,a[1]-nv)],h,ht,mat,sup,role)
def arc(n,u,v,r,a0,a1,h,ht,width,mat,sup='ROOT_FLOOR',role='fitted',steps=16):
 outer=[(u+(r+width/2)*math.cos(a0+(a1-a0)*i/steps),v+(r+width/2)*math.sin(a0+(a1-a0)*i/steps)) for i in range(steps+1)];inner=[(u+(r-width/2)*math.cos(a0+(a1-a0)*i/steps),v+(r-width/2)*math.sin(a0+(a1-a0)*i/steps)) for i in reversed(range(steps+1))];return prism(n,outer+inner,h,ht,mat,sup,role,.018)
def text(n,body,u,h,v,size=.18,sup='ROOT_FLOOR',face='entry'):
 cu=bpy.data.curves.new(n,'FONT');cu.body=body;cu.size=size;cu.align_x='CENTER';cu.extrude=.001;o=bpy.data.objects.new(n,cu);COL.objects.link(o);o.location=xyz(u,h,v);o.rotation_euler=(math.pi/2,0,-C['sign']*math.pi/2) if face=='entry' else (math.pi/2,0,0);o.data.materials.append(M['ivory']);o['support']=sup;o['role']='editable_sign';o['programme_key']=C['key'];A.append(o)
def lamp(n,u,v,h=3.2,sup='ROOT_FLOOR',cool=False):
 disc(n+'_foot',u,0,v,.22,.08,'brass');rod(n+'_stem',(u,.08,v),(u,h,v),.045,'brass',n+'_foot');disc(n+'_shade',u,h-.15,v,.33,.28,'cool' if cool else 'orange',n+'_stem');disc(n+'_lens',u,h-.18,v,.27,.04,'light',n+'_shade');LIGHTS.append(dict(name=n,pos=(u,h-.23,v),power=130 if cool else 180,color=(.72,.86,1) if cool else (1,.72,.40),size=1.0))
def ceiling_light(n,u,v,h,sup,power=350):
 rod(n+'_suspension',(u,h+.02,v),(u,C['ceiling']+.04,v),.04,'brass',sup);box(n+'_housing',u,h,v,1.7,.12,.85,'brass',n+'_suspension');box(n+'_lens',u,h-.075,v,1.55,.04,.7,'light',n+'_housing');LIGHTS.append(dict(name=n,pos=(u,h-.11,v),power=power,color=(1,.80,.58),size=2.5))
def counter(n,poly,mat='orange',top='stone',height=1.02):
 prism(n+'_base',poly,0,height-.1,mat,role='floor_contact');prism(n+'_top',poly,height-.1,.1,top,n+'_base',role='work_surface',bev=.045);return n+'_top'
def table(n,u,v,w=1.8,d=1.4,game=False):
 box(n+'_foot',u,.045,v,w*.58,.09,d*.65,'brass',role='floor_contact');box(n+'_stem',u,.42,v,.22,.68,.22,'brass',n+'_foot');box(n+'_top',u,.80,v,w,.12,d,'wood',n+'_stem','activity_surface',.055)
 if game:
  box(n+'_board',u,.876,v,w*.62,.035,d*.64,'teal',n+'_top','inert_tabletop_display',.015)
  for i in range(5):
   disc(n+'_piece'+str(i),u-.42+i*.21,.895,v-.18+(i%2)*.34,.065,.08,'ivory' if i%2 else 'orange',n+'_board','inert_tabletop_piece')
 return n+'_top'
def chair(n,u,v,angle=0):
 disc(n+'_foot',u,0,v,.35,.07,'brass',role='floor_contact');disc(n+'_stem',u,.07,v,.08,.33,'brass',n+'_foot');box(n+'_seat',u,.46,v,.78,.12,.78,'cloth',n+'_stem','supported_rest',.05)
 du,dv=math.cos(angle)*.33,math.sin(angle)*.33;back=box(n+'_back',u+du,.87,v+dv,.16,.79,.72,'cloth',n+'_seat','supported_rest',.05)
 if True:back.rotation_euler[2]=-C['sign']*angle
def bench(n,u,v,length=3.8,back='north'):
 box(n+'_plinth',u,.19,v,length,.38,.92,'wood',role='floor_contact');box(n+'_cushion',u,.46,v,length-.12,.16,.88,'cloth',n+'_plinth','supported_rest',.065);box(n+'_back',u,.92,v+.41 if back=='north' else v-.41,length,1.00,.18,'cloth',n+'_plinth','supported_rest',.055)
def shelf(n,u,v,length=4.0,height=2.6,items='books',mat='wood',reverse=False):
 box(n+'_back',u+(-.5 if reverse else .5),height/2,v,.16,height,length,mat,role='floor_contact');box(n+'_plinth',u,.08,v,1.15,.16,length,mat,role='floor_contact')
 for j in range(4):
  h=.32+j*.64;box(n+'_shelf'+str(j),u,h,v,1.1,.08,length,mat,n+'_back','stock_surface')
  for i in range(int(length/.45)-1):
   vv=v-length/2+.4+i*.45;hh=.36 if items=='books' else .30
   if items=='bread':
    disc(n+'_tray'+str(j)+'_'+str(i),u,h+.04,vv,.20,.035,'brass',n+'_shelf'+str(j));box(n+'_loaf'+str(j)+'_'+str(i),u,h+.04+.035+hh/2,vv,.42,hh,.27,'oatmeal',n+'_tray'+str(j)+'_'+str(i),'display_bakery_food',.09)
   else:
    box(n+'_stock'+str(j)+'_'+str(i),u,h+.04+hh/2,vv,.50,hh,.22 if items=='books' else .36,['teal','orange','ivory'][i%3],n+'_shelf'+str(j),'book_stock' if items=='books' else 'parcel_stock',.015)
 for vv in [v-length/2+.06,v+length/2-.06]:box(n+'_end'+str(vv),u,height/2,vv,1.1,height,.12,mat,n+'_plinth')
def plant(n,u,v):
 disc(n+'_pot',u,0,v,.55,.65,'orange',role='floor_contact');rod(n+'_stem',(u,.65,v),(u,1.75,v),.065,'wood',n+'_pot')
 for i in range(6):
  a=i*math.tau/6;bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1,radius=.7,location=xyz(u+.32*math.cos(a),1.4+.20*(i%2),v+.32*math.sin(a)));o=bpy.context.object;o.scale=(.7,.5,1.0);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);finish(o,n+'_leaf'+str(i),'green',n+'_stem','plant',0)
def catalogue(n,id,u,v,angle=0):
 cat=json.loads((BASE/'dependencies/catalogue_manifest.json').read_text());rec=next(a for a in cat['assets'] if a['catalogue_id']==id);path=BASE/'dependencies/catalogue'/rec['source'];loaded=[]
 with bpy.data.libraries.load(str(path),link=False) as (src,dst):dst.objects=[o for o in src.objects]
 objs=[o for o in dst.objects if o and o.type=='MESH']; pts=[o.matrix_world@Vector(c) for o in objs for c in o.bound_box];minz=min(p.z for p in pts);cx=(min(p.x for p in pts)+max(p.x for p in pts))/2;cy=(min(p.y for p in pts)+max(p.y for p in pts))/2
 for i,o in enumerate(objs):
  COL.objects.link(o);o.hide_viewport=False;o.hide_render=False;o.hide_select=False;o.hide_set(False);world=o.matrix_world.copy();o.parent=None;me=o.data.copy();o.data=me
  for vert in me.vertices:
   q=world@vert.co;xx=q.x-cx;yy=q.y-cy;uu=u+xx*math.cos(angle)-yy*math.sin(angle);vv=v-xx*math.sin(angle)-yy*math.cos(angle);vert.co=xyz(uu,q.z-minz,vv)
  o.matrix_world.identity();
  if world.to_3x3().determinant()*C['sign']<0:me.flip_normals()
  me.update();o.name=n+'_'+str(i);o['support']='ROOT_FLOOR' if min((o.matrix_world@Vector(c)).z for c in o.bound_box)<.02 else n+'_0';o['role']='catalogue_'+id;o['programme_key']=C['key'];uv(o);A.append(o)
 for im in bpy.data.images:
  if im.source=='FILE' and not im.packed_file:
   try:im.pack()
   except Exception:pass

def materials():
 specs={'wood':'warm_walnut','brass':'champagne_metal','cloth':'clay_weave','oatmeal':'oatmeal_weave','ivory':'ivory_enamel','rubber':'dark_rubber','stone':'warm_stone','teal':'teal_weave','cool':'staff_bluegrey_paint','zinc':'staff_zinc','white':'staff_white_paint','light':'staff_opal','orange':'ivory_enamel','green':'teal_weave'}
 for key,fn in specs.items():
  ma=bpy.data.materials.new('B_'+key);ma.use_nodes=True;bs=ma.node_tree.nodes.get('Principled BSDF');bs.inputs['Roughness'].default_value=.78;bs.inputs['Metallic'].default_value=.45 if key in ['brass','zinc'] else 0;im=bpy.data.images.load(str(BASE/'dependencies/materials'/(fn+'.png')),check_existing=True);im.pack();tx=ma.node_tree.nodes.new('ShaderNodeTexImage');tx.image=im;tx.interpolation='Closest'
  if key in ['orange','green']:
   mix=ma.node_tree.nodes.new('ShaderNodeMixRGB');mix.blend_type='MULTIPLY';mix.inputs[0].default_value=1;mix.inputs[2].default_value=(.85,.24,.045,1) if key=='orange' else (.22,.55,.25,1);ma.node_tree.links.new(tx.outputs['Color'],mix.inputs[1]);ma.node_tree.links.new(mix.outputs['Color'],bs.inputs['Base Color'])
  else:ma.node_tree.links.new(tx.outputs['Color'],bs.inputs['Base Color'])
  if key=='light':bs.inputs['Emission Color'].default_value=(1,.7,.35,1);bs.inputs['Emission Strength'].default_value=2
  M[key]=ma

USED_COMPOSE=(BASE/'compose.py').read_bytes()
(P/'source/compose_used.py').write_bytes(USED_COMPOSE)
exec(USED_COMPOSE.decode('utf-8'))

