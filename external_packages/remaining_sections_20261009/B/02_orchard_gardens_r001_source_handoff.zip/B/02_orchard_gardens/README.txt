D06_directory_07 / Orchard gardens r001
Editable native, actual GLB, exact placement and floor/contact proposals.
Source-only construction base; root adoption and all installed gates remain open.
Rebuild: unpack archive, set cwd to B, run python heavy_job.py build_sections.py 02_orchard_gardens full (includes saved-native/actual-GLB verification); then python support_report.py 02_orchard_gardens.
Blender 4.3.2 path is configured in heavy_job.py; use the installed tool, shared named mutex and two CPU threads.
No preview floor is saved/exported.
