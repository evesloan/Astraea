import pathlib,json,sys,math,hashlib
B=pathlib.Path(__file__).parent;P=B/sys.argv[1]
meta=json.loads((P/'source/build_metadata.json').read_text());C=meta['section'];rt=json.loads((P/'qa/roundtrip.json').read_text());rows=json.loads((P/'qa/imported_objects.json').read_text())
assert rt['source_sha256']==hashlib.sha256((P/'source/section_r001.blend').read_bytes()).hexdigest()
assert rt['export_sha256']==hashlib.sha256((P/'exports/section_r001.glb').read_bytes()).hexdigest()
errors=[e for e in rt['errors'] if 'route' not in e]
s=(B/'verify_sections.py').read_text();start=s.index("poly=meta['polygon']");end=s.index("report={'source_sha256'")
exec(s[start:end])
rt['routes']=route_reports;rt['errors']=errors
rt['route_recheck_scope']='Updated source-only route proposals against unchanged actual imported geometry; native/export byte hashes checked before reusing evaluated bounds'
(P/'qa/roundtrip.json').write_text(json.dumps(rt,indent=2));print(json.dumps(errors[:10],indent=2));assert not errors,errors[:10]
