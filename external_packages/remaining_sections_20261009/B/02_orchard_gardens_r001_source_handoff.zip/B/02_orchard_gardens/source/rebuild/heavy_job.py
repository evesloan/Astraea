import ctypes,subprocess,sys,pathlib,json,datetime,os
from ctypes import wintypes
B=pathlib.Path(__file__).resolve().parent
k=ctypes.WinDLL('kernel32',use_last_error=True)
k.CreateMutexW.argtypes=[ctypes.c_void_p,wintypes.BOOL,wintypes.LPCWSTR];k.CreateMutexW.restype=wintypes.HANDLE
k.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD];k.WaitForSingleObject.restype=wintypes.DWORD
k.ReleaseMutex.argtypes=[wintypes.HANDLE];k.CloseHandle.argtypes=[wintypes.HANDLE]
h=k.CreateMutexW(None,False,r'Local\Astraea_SolBatch_20261008_HeavyBuild');owned=False
if not h:raise ctypes.WinError(ctypes.get_last_error())
try:
 print('Waiting for shared heavy mutex',flush=True)
 while True:
  status=k.WaitForSingleObject(h,30000)
  if status in (0,0x80):owned=True;break
  if status!=0x102:raise RuntimeError('Mutex wait failure '+str(status))
  print('Still queued on shared heavy mutex',flush=True)
 cmd="Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(blender|godot.*)\\.exe$' } | Select-Object ProcessId,Name,CommandLine | ConvertTo-Json -Compress"
 check=subprocess.run(['powershell','-NoProfile','-Command',cmd],capture_output=True,text=True,check=True)
 if check.stdout.strip():
  (B/'heavy_process_blocker.json').write_text(check.stdout);raise RuntimeError('Surviving heavy process; no process stopped')
 script=sys.argv[1];args=sys.argv[2:]
 log=B/('heavy_'+script.replace('.py','')+'_'+('_'.join(args) or 'inspect')+'.log')
 receipt={'mutex':r'Local\Astraea_SolBatch_20261008_HeavyBuild','wait_status':status,'pid':os.getpid(),'threads':2,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 print('Acquired heavy mutex: '+str(log),flush=True)
 with log.open('w',encoding='utf-8') as f:
  p=subprocess.Popen([r'C:/Users/cered/Dolphin/AstraeaTools/blender-4.3.2-windows-x64/blender.exe','--background','--factory-startup','--threads','2','--python-exit-code','1','--python',str(B/script),'--']+args,stdout=f,stderr=subprocess.STDOUT)
  code=p.wait()
 receipt.update(exit_code=code,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 log.with_suffix('.mutex.json').write_text(json.dumps(receipt,indent=2))
 print('Finished '+script+' exit '+str(code),flush=True)
 if code:raise SystemExit(code)
finally:
 if owned:k.ReleaseMutex(h)
 k.CloseHandle(h)
