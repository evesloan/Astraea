import bpy,pathlib,json,sys,math,hashlib,bmesh
from mathutils import Vector
B=pathlib.Path(__file__).parent;section=sys.argv[sys.argv.index('--')+1];P=B/section
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta=json.loads((P/'source/build_metadata.json').read_text());C=meta['section'];errors=[];DG=None
def evaluated_bounds(o):
    me=bpy.data.meshes.new_from_object(o.evaluated_get(DG));points=[o.matrix_world@v.co for v in me.vertices];bpy.data.meshes.remove(me)
    return [[min(p[i] for p in points),max(p[i] for p in points)] for i in range(3)] if points else None
def native_record():
    global DG
    bpy.ops.wm.open_mainfile(filepath=str(P/'source/section_r001.blend'));bpy.context.view_layer.update();obs=[o for o in bpy.context.scene.objects if o.type in ['MESH','CURVE','FONT']]
    DG=bpy.context.evaluated_depsgraph_get()
    assert not any('QA_FLOOR' in o.name for o in obs)
    rows={o.name:{'bounds':evaluated_bounds(o),'role':o.get('role'),'support':o.get('support'),'type':o.type} for o in obs}
    signs=[{'name':o.name,'body':o.data.body} for o in obs if o.type=='FONT']
    return rows,signs
native,signs=native_record();print('Actual native evaluated bounds',len(native),flush=True);bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(P/'exports/section_r001.glb'));bpy.context.view_layer.update();DG=bpy.context.evaluated_depsgraph_get()
imported=[o for o in bpy.context.scene.objects if o.type=='MESH'];rows={};winding=[];uv_missing=[];normal_errors=[];floor_contacts=[]
for o in imported:
    n=o.get('source_native_name');bb=evaluated_bounds(o)
    if bb[0][0]<(-46 if C['sign']<0 else 0)-.005 or bb[0][1]>(0 if C['sign']<0 else 46)+.005 or bb[1][0]<-68-.005 or bb[1][1]>.005 or bb[2][0]<-.005 or bb[2][1]>C['roof']-27+.005:errors.append({'name':n,'error':'actual imported containment','bounds':bb})
    if not n or n in rows:errors.append({'node':o.name,'error':'missing/duplicate native identity'})
    rows[n]={'bounds':bb,'role':o.get('role'),'support':o.get('support')}
    if not o.data.uv_layers:uv_missing.append(o.name)
    if any(not math.isfinite(float(x)) for v in o.data.vertices for x in v.co):normal_errors.append(o.name)
    if any(p.area<1e-10 or p.normal.length<.9 for p in o.data.polygons):normal_errors.append(o.name)
    if o.get('role')=='floor_contact':
        bottom=bb[2][0];floor_contacts.append({'name':n,'bottom_h':bottom,'proposal_only_root_slab':True})
        if abs(bottom)>.004:errors.append({'name':n,'error':'floor contact datum','height':bottom})
for n,row in native.items():
    if n not in rows:errors.append({'name':n,'error':'native missing in export'});continue
    delta=max(abs(row['bounds'][i][j]-rows[n]['bounds'][i][j]) for i in range(3) for j in range(2))
    if delta>.004:errors.append({'name':n,'error':'native/export bound divergence','delta':delta})
if len(rows)!=len(native):errors.append({'error':'native/export count parity','native':len(native),'export':len(rows)})
if uv_missing or normal_errors:errors.append({'uv_missing':uv_missing,'normal_errors':normal_errors})
poly=meta['polygon']
def inside(u,v):
    result=False
    for (x,y),(xx,yy) in zip(poly,poly[1:]+poly[:1]):
        if (y>v)!=(yy>v) and u<(xx-x)*(v-y)/(yy-y)+x:result=not result
    return result
def edge_dist(u,v,a,b):
    dx,dy=b[0]-a[0],b[1]-a[1];t=max(0,min(1,((u-a[0])*dx+(v-a[1])*dy)/(dx*dx+dy*dy)));return math.hypot(u-a[0]-t*dx,v-a[1]-t*dy)
cart=json.loads((B/'inputs/Game/data/architecture/cleaning_cart_contacts.json').read_text())
radius=0
for x in cart['boxes']:
    cx,cy,cz=x['center'];sx,sy,sz=x['size'];radius=max(radius,math.hypot(abs(cx)+sx/2,abs(cz)+sz/2))
for x in cart.get('spheres',[]):radius=max(radius,math.hypot(x['center'][0],x['center'][2])+x['radius'])
profiles=[('retained_cart_all_yaw_disc',radius+.02,2.35),('proposed_broad_body',.80,2.5)]
route_reports=[]
for name,path in meta['routes'].items():
    for profile,r,h in profiles:
        samples=[];fail=[];minimum=100
        for a,b in zip(path,path[1:]):
            count=max(1,math.ceil(math.dist(a,b)/.25))
            for j in range(count+1):
                t=j/count;u=a[0]+(b[0]-a[0])*t;v=a[1]+(b[1]-a[1])*t;x=C['sign']*u;y=-v
                if not inside(u,v):fail.append({'at':[u,v],'outside_floor_proposal':True});continue
                edgeclear=min(edge_dist(u,v,a,b) for a,b in zip(poly,poly[1:]+poly[:1]));minimum=min(minimum,edgeclear)
                if edgeclear<r-.01:fail.append({'at':[u,v],'floor_edge_clearance':edgeclear})
                for n,row in rows.items():
                    bb=row['bounds']
                    if bb[2][0]>=h or bb[2][1]<=.035:continue
                    dx=max(bb[0][0]-x,0,x-bb[0][1]);dy=max(bb[1][0]-y,0,y-bb[1][1]);distance=math.hypot(dx,dy);minimum=min(minimum,distance)
                    if distance<r-.01:fail.append({'at':[u,v],'name':n,'conservative_aabb_clearance':distance})
                samples.append([u,v])
        route_reports.append({'name':name,'profile':profile,'radius_m':r,'height_m':h,'samples':len(samples),'minimum_conservative_clearance_m':minimum,'failures':fail[:30],'failure_count':len(fail),'scope':'actual reimported visual bounds; proposed floor polygon; source disc sweep only, not engine collision/body acceptance'})
        if fail:errors.append({'route':name,'profile':profile,'failures':fail[:5],'count':len(fail)})
raw_source=(B/'raw_glb_topology.py').read_bytes();raw_namespace={'__file__':str(B/'raw_glb_topology.py'),'__name__':'raw_glb_topology'};exec(raw_source,raw_namespace);raw_topology=raw_namespace['inspect_glb'](P,C);errors.extend(raw_topology['errors']);winding=raw_topology['closed_mesh_winding'];(P/'source/raw_topology_used.py').write_bytes(raw_source)
report={'source_sha256':digest(P/'source/section_r001.blend'),'export_sha256':digest(P/'exports/section_r001.glb'),'errors':errors,'native_objects':len(native),'export_objects':len(rows),'editable_signs':signs,'text_parity':'FONT evaluated geometry included under exact native identity','closed_mesh_winding':winding,'floor_contact_datums':floor_contacts,'routes':route_reports,'actual_cart_radius_without_margin':radius,'unperformed':['Godot import/navigation/collision','species rig and occupied use','root floor/contact adoption','fixture lighting adaptation and target-device acceptance']}
(P/'qa/roundtrip.json').write_text(json.dumps(report,indent=2));(P/'qa/imported_objects.json').write_text(json.dumps(rows,indent=2));print('ROUNDTRIP',len(native),'source objects; errors',len(errors));print(json.dumps(errors[:10],indent=2))
if errors:raise RuntimeError('Source export QA failed; evidence preserved')
