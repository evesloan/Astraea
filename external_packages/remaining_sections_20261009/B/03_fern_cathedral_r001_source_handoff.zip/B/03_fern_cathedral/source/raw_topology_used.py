import pathlib,json,struct,math,collections,hashlib

def inspect_glb(P,C):
    raw=(P/'exports/section_r001.glb').read_bytes();size=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+size]);blob=raw[28+size:];errors=[];winding=[];records=[]
    def arr(i):
        a=g['accessors'][i];v=g['bufferViews'][a['bufferView']];fmt={5126:'f',5125:'I',5123:'H',5121:'B'}[a['componentType']];n={'VEC3':3,'SCALAR':1}[a['type']];width=struct.calcsize('<'+fmt*n);stride=v.get('byteStride',width);off=v.get('byteOffset',0)+a.get('byteOffset',0)
        return [struct.unpack_from('<'+fmt*n,blob,off+j*stride) for j in range(a['count'])]
    def cross(a,b):return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
    critical={'floor_contact','opaque_supported_roof','roof_closure','work_surface','growing_medium','botanical_root'}
    for node in g['nodes']:
        if 'mesh' not in node:continue
        n=node.get('extras',{}).get('source_native_name');role=node.get('extras',{}).get('role');coords=[];faces=[]
        if node.get('translation',[0,0,0])!=[0,0,0] or node.get('rotation',[0,0,0,1])!=[0,0,0,1] or node.get('scale',[1,1,1])!=[1,1,1] or 'matrix' in node:errors.append({'name':n,'error':'unexpected transform in flattened GLB'})
        for pr in g['meshes'][node['mesh']]['primitives']:
            if pr.get('mode',4)!=4:continue
            pos=arr(pr['attributes']['POSITION']);idx=[x[0] for x in arr(pr['indices'])] if 'indices' in pr else list(range(len(pos)));base=len(coords);coords+=pos;faces += [tuple(base+i for i in idx[j:j+3]) for j in range(0,len(idx),3)]
            if 'NORMAL' not in pr['attributes'] or any(not all(math.isfinite(x) for x in normal) or math.sqrt(sum(x*x for x in normal))<.9 for normal in arr(pr['attributes'].get('NORMAL',pr['attributes']['POSITION']))):errors.append({'name':n,'error':'raw GLB normal field'})
        keys={p:i for i,p in enumerate(dict.fromkeys(coords))};edges=collections.Counter();direction=collections.Counter();volume=0;bad=0
        for f in faces:
            p,q,r=[coords[i] for i in f];u=tuple(q[i]-p[i] for i in range(3));v=tuple(r[i]-p[i] for i in range(3));cr=cross(u,v)
            if math.sqrt(sum(x*x for x in cr))/2<1e-10:bad+=1
            qr=cross(q,r);volume+=sum(p[i]*qr[i] for i in range(3))/6
            for j in range(3):
                a,b=keys[coords[f[j]]],keys[coords[f[(j+1)%3]]];edge=tuple(sorted((a,b)));edges[edge]+=1;direction[edge]+=1 if a<b else -1
        boundary=sum(c!=2 for c in edges.values());orientation=sum(direction[e]!=0 for e,c in edges.items() if c==2);closed=bool(faces) and not boundary
        records.append({'name':n,'role':role,'triangles':len(faces),'unique_exact_positions':len(keys),'unpaired_geometric_edges':boundary,'inconsistent_paired_edge_winding':orientation,'signed_volume':volume,'closed':closed})
        if bad:errors.append({'name':n,'error':'raw degenerate triangles','count':bad})
        if role in critical and (boundary or orientation):errors.append({'name':n,'error':'raw authored solid closure/winding','boundary_edges':boundary,'orientation_edges':orientation})
        if closed:
            winding.append({'name':n,'signed_volume':volume,'method':'Exact raw GLB geometric edge pairing and unchanged triangle winding; UV/normal seam duplicates share identical positions'})
            if volume< -1e-8:errors.append({'name':n,'error':'raw closed mesh inward winding','volume':volume})
    report={'source_sha256':hashlib.sha256((P/'source/section_r001.blend').read_bytes()).hexdigest(),'export_sha256':hashlib.sha256(raw).hexdigest(),'inspector_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'errors':errors,'closed_mesh_winding':winding,'objects':records,'scope':'Actual GLB binary triangle coordinates, exact seam position pairing, edge orientation and signed volume; no source mutation or installed acceptance'}
    (P/'qa/raw_glb_topology.json').write_text(json.dumps(report,indent=2));print('RAW_GLTF_TOPOLOGY',len(records),'objects; errors',len(errors));return report

if __name__=='__main__':
    import sys
    B=pathlib.Path(__file__).parent;P=B/sys.argv[1];C=json.loads((P/'source/build_metadata.json').read_text())['section'];r=inspect_glb(P,C);assert not r['errors'],r['errors'][:12]
