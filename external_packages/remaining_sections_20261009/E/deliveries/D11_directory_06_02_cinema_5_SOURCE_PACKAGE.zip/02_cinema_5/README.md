# Cinema 5 — reviewed source construction

Programme D11_directory_06. Editable native: source/D11_directory_06.blend. Actual exchange: exports/D11_directory_06.glb. Exact placement: docs/PLACEMENT.json. Independent checks and final hash-bound views: qa/. Root-owned receiving slab is proposed separately and omitted from export. Remaining interfaces and function are described in docs/. Failed evidence is explicitly named and preserved; it is not a delivered candidate.

Rebuild from extracted package root with installed Blender 4.3.2:

`python source/heavy_wrapper.py "C:/Users/cered/Dolphin/AstraeaTools/blender-4.3.2-windows-x64/blender.exe" --background --factory-startup --threads 2 --python-exit-code 2 --python source/build.py`

The live ctypes wrapper holds Local\Astraea_SolBatch_20261008_HeavyBuild, defers surviving heavy processes, and releases in finally. Two source threads. Rebuild is deterministic in geometry, identities and dependency bytes; Blender container bytes may vary with saving. This is construction/source review, with live installation and occupied body/cart acceptance held by root.
