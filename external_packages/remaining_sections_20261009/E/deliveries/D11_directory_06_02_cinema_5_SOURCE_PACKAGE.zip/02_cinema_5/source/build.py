import pathlib,sys
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
from cinema_source import build
build('D11_directory_06','02_cinema_5',244,0,'THE LAST LANTERN HOME')
