"""Saved-native explicit box winding and triangle ray surfaces. No collision workaround."""
import bpy,json,hashlib,sys
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
P=Path(sys.argv[sys.argv.index('--')+1]);key=P.name;bpy.ops.wm.open_mainfile(filepath=str(P/'source/section.blend'));rows=[]
for o in bpy.context.scene.objects:
 if o.type!='MESH' or o.get('source_primitive') not in ['closed_box_shared_vertices','closed_prism_shared_vertices']:continue
 eo=o.evaluated_get(bpy.context.evaluated_depsgraph_get());me=eo.to_mesh();me.calc_loop_triangles();vs=[o.matrix_world@v.co for v in me.vertices];ts=[tuple(t.vertices) for t in me.loop_triangles];center=sum(vs,Vector())/len(vs);volume=sum((vs[a]-center).dot((vs[b]-center).cross(vs[c]-center))/6 for a,b,c in ts);lo=min(v.z for v in vs);hi=max(v.z for v in vs);bv=BVHTree.FromPolygons(vs,ts,all_triangles=True)
 flat=[(vs[a]+vs[b]+vs[c])/3 for a,b,c in ts if abs(vs[a].z-hi)<.001 and abs(vs[b].z-hi)<.001 and abs(vs[c].z-hi)<.001]
 probe=flat[0] if flat else center
 top=bv.ray_cast(Vector((probe.x,probe.y,hi+1)),Vector((0,0,-1)));bottom=bv.ray_cast(Vector((probe.x,probe.y,lo-1)),Vector((0,0,1)));edges={}
 for f in me.polygons:
  ids=list(f.vertices)
  for a,b in zip(ids,ids[1:]+ids[:1]):q=tuple(sorted((a,b)));edges[q]=edges.get(q,0)+1
 row=dict(name=o.name,signed_volume_m3=volume,shared_boundary_edges=len(edges),non_two_face_edges=sum(v!=2 for v in edges.values()),top_hit_y=top[0].z if top[0] else None,top_normal_y=top[1].z if top[1] else None,bottom_hit_y=bottom[0].z if bottom[0] else None,bottom_normal_y=bottom[1].z if bottom[1] else None)
 row['pass']=volume>0 and not row['non_two_face_edges'] and top[0] is not None and bottom[0] is not None and top[1].z>.001 and bottom[1].z<-.001;rows.append(row);eo.to_mesh_clear()
out=dict(status='PASS' if rows and all(r['pass'] for r in rows) else 'FAIL',scope='Actual saved-native closed shared-vertex boxes: signed winding volume, paired boundary edges and physical triangle top/bottom rays. Root receiving slabs are absent and not certified.',native_sha256=hashlib.sha256((P/'source/section.blend').read_bytes()).hexdigest(),rows=rows)
(P/'qa/explicit_surface_winding.json').write_text(json.dumps(out,indent=2));print(out['status'],'EXPLICIT_BOX_WINDING',len(rows),[r for r in rows if not r['pass']][:5]);assert out['status']=='PASS'
