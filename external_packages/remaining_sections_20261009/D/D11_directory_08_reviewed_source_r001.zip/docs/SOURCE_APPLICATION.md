# The music room — construction base r001

A low deep entrance splits into a fan-shaped listening room and a quiet rehearsal branch. A level performance focus with recognizable instrument proxies faces staggered fitted listening banks beneath converging acoustic ribs. The rear working arc gives performers and caretakers a separate local approach.

Original master image4 pixels: separated public/service edges and generous active volume; historical printed deck/capacity numbers are not adopted. Image8: readable low-poly material grain and useful stocked shelving; not a copied pantry. Image11: integrated sheltered furnishing and enclosing rhythm. Master chapters7,8,14,19,21,22,23,24,28,30,32 govern purpose, support, species uncertainty and source acceptance.

No exterior window is proposed: frontage and adjoining ownership are unproven. No controller, registry, named live door, neighbouring volume or ordinary floor is changed. RMB-focus/E vocabulary remains with root. Source views show actual GLB plus a separately proposed receiving floor.

Remaining gates: current installed owner reconciliation, root slabs/connectors/door mechanisms, actual loaded-cart drive and six-species rig/pose fit, Godot collision/audio/performance and final normal-play art acceptance. Sport dimensions and acoustic ribs are authored geometry, not sport or acoustic certification.
