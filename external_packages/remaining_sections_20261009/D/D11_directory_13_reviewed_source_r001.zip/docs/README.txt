Source construction base r001: Backstage workshop
Programme D11_directory_13; global XYZ metres; GLB identity placement, no offset. Native basis Blender(X,-Z,Y).
Floor/entry proposal in docs/floor_proposal.json is separate: root owns shared slabs, portals, connectors and runtime adoption.
Source acceptance only. Six-species fit, operating sport/audio, loaded-cart driving, collision, Godot/CRT/performance and final art are pending.
Rebuild with installed Blender4.3.2 under source/heavy_job.py, --background --threads 2 --python-exit-code 1 --python source/build_section.py. All heavy jobs must hold Local\Astraea_SolBatch_20261008_HeavyBuild.
Independent source input retention is recorded; actual native packed resources and export embedded resources are checked. Previous packages and live sources were not modified.
