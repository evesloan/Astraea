# Backstage workshop — construction base r001

A practical T-shaped working sequence: broad receiving/turn bay, sorted storage branches, then a long supported fabrication/repair hall. A separate side workbench and shielded cue bench face an unobstructed cart spine. Closed material racks and a work-height light gantry define cool service character.

Original master image4 pixels: separated public/service edges and generous active volume; historical printed deck/capacity numbers are not adopted. Image8: readable low-poly material grain and useful stocked shelving; not a copied pantry. Image11: integrated sheltered furnishing and enclosing rhythm. Master chapters7,8,14,19,21,22,23,24,28,30,32 govern purpose, support, species uncertainty and source acceptance.

No exterior window is proposed: frontage and adjoining ownership are unproven. No controller, registry, named live door, neighbouring volume or ordinary floor is changed. RMB-focus/E vocabulary remains with root. Source views show actual GLB plus a separately proposed receiving floor.

Remaining gates: current installed owner reconciliation, root slabs/connectors/door mechanisms, actual loaded-cart drive and six-species rig/pose fit, Godot collision/audio/performance and final normal-play art acceptance. Sport dimensions and acoustic ribs are authored geometry, not sport or acoustic certification.

Original master image3 staff-reference pixels were inspected again before this section. Its separated receiving/work/storage edges and cool practical character inform the T-shaped local sequence; historical printed deck/capacity quantities are not adopted. The retained AST-ENG-001 donor is a non-operating received repair sample, not an extra installed life-support system.
