"""Bounded source successor; never edits original PLAN or live Game data."""
import json,hashlib,copy
from pathlib import Path
from shapely.geometry import shape,box,mapping
from shapely.geometry.polygon import orient
from shapely import constrained_delaunay_triangles
R=Path(__file__).resolve().parents[4]; O=Path(__file__).resolve().parents[1]
S=R/'BlenderCatalogue/assets/residential_hotels/tidal_garden_20261007_r001/residential-neighborhood-courts-20261007/tidal_garden_house/outputs/house_r001/PLAN.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(S)=='8e24bc241ad7aea468bde011526a3a20d6a6b34bc5fb831dcbaa94a99adcd198'
p=json.loads(S.read_text()); result=copy.deepcopy(p); removed=[]; added=[]
def slab(name,poly,lo,hi,role,category):
 assert poly.geom_type=='Polygon' and poly.is_valid
 poly=orient(poly,sign=1); vs=[]; fs=[]
 for tri in constrained_delaunay_triangles(poly).geoms:
  # CCW in XZ gives downward world-Y normal, hence reverse the top.
  q=list(orient(tri,sign=1).exterior.coords)[:3]; k=len(vs)
  vs.extend([(x,lo,z) for x,z in q]+[(x,hi,z) for x,z in q]);fs.extend([(k,k+1,k+2),(k+5,k+4,k+3)])
 for ring in [poly.exterior,*poly.interiors]:
  for a,b in zip(ring.coords,list(ring.coords)[1:]):
   k=len(vs);vs.extend([(a[0],lo,a[1]),(a[0],hi,a[1]),(b[0],hi,b[1]),(b[0],lo,b[1])]);fs.append((k,k+1,k+2,k+3))
 d=dict(name=name,kind='mesh',verts=vs,faces=fs,role=role,category=category,owner=name,plan_area_m2=poly.area);added.append(d);return d
parts=[]
for q in p['parts']:
 name=q['name']
 if name.startswith('TG_PrincipalCourtBase_') or any(s in name for s in ['_LiftDoorLeft_','_LiftDoorRight_','_LiftHeader_','_LiftClosedGate_']):
  removed.append(name);continue
 if name.startswith('TG_PublicRim_') and q['kind']=='beam' and abs(q['a'][2]+377.73)<.001 and abs(q['b'][2]+377.73)<.001:
  a,b=q['a'],q['b']; low,high=sorted([a[0],b[0]])
  if high>-76.46 and low<-72.54:
   removed.append(name)
   if abs(a[0]-b[0])>.001:
    for i,(x0,x1) in enumerate([(low,min(high,-76.46)),(max(low,-72.54),high)]):
     if x1-x0<.03:continue
     child=copy.deepcopy(q);child['name']=name+'_LiftRecess_'+str(i);child['a'][0]=x0;child['b'][0]=x1;added.append(child)
   continue
 parts.append(q)
assert sum('LiftClosedGate' in n for n in removed)==5
region=next(r for r in result['floor_regions'] if r['name']=='TG_PrincipalCourtBase')
base=shape(region['geometry']);pit=box(-76.8,-382.8,-72.2,-377.8)
assert base.covers(pit)
cut=base.difference(pit);region['geometry']=mapping(cut)
slab('TG_PrincipalCourtBase_LiftRecess',cut,83.76,84,'warm_stone','floor')
# Lower pit base is within original base depth and entirely below the moving platform.
slab('TG_LiftPitBase',pit,83.76,83.79,'warm_stone','architecture')
for y,d in zip([84,88.5,93,97.5,102],range(13,18)):
 for suffix,x0,x1,lo,hi,role in [('Left',-76.75,-76.44,y,y+3.8,'ivory_enamel'),('Right',-72.56,-72.25,y,y+3.8,'ivory_enamel'),('Header',-76.44,-72.56,y+2.88,y+3.8,'warm_walnut')]:
  slab(f'D{d}_LiftOuterFrame_{suffix}',box(x0,-377.84,x1,-377.68),lo,hi,role,'architecture')
result['parts']=parts+added;result['status']='LIFT_GEOMETRY_CANDIDATE_NOT_RUNTIME_ADOPTED';result['predecessor_plan_sha256']=sha(S)
result['lift_successor']={'removed_source_parts':removed,'added_source_parts':[a['name'] for a in added],'preserved_source_parts':len(parts),'root_ship_xyz':[-74.5,0,-377.90],'root_yaw_degrees':90,'gate_origin_xz':[0,0],'cabin_file':'AST-CIR-003_five_stop.glb','floor_heights':[84,88.5,93,97.5,102],'limits':'Requires operating mechanism and closed-gate fall protection before any runtime adoption. Full travel/cart/input/visual checks outstanding.'}
assert len({a['name'] for a in result['parts']})==len(result['parts'])
for a in parts:assert a==next(b for b in p['parts'] if b['name']==a['name'])
(O/'LIFT_GEOMETRY_PLAN.json').write_text(json.dumps(result,indent=2)+'\n')
(O/'PLAN_CHANGE_RECEIPT.json').write_text(json.dumps(result['lift_successor'],indent=2)+'\n')
print(json.dumps({'removed':len(removed),'added':len(added),'unchanged':len(parts),'base_area_removed':base.area-cut.area,'status':'PLAN_ONLY_NOT_ADOPTED'}))
