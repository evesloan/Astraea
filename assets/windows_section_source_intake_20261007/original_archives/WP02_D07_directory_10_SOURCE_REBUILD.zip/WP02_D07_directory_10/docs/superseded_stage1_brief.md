# Section 02 — Sports care & changing

Status: isolated dimensioned design proposal; awaiting Higgins's current allocation/interface confirmation and geometry release. No geometry, engine import, runtime edits or construction acceptance is claimed.

## Authority and retained dimensions

Canonical parent `D07_directory_10`, audit `AME-014`. Retained local programme footprint is X 8–54 m, Z 398–466 m (46 x 68 m; 3,128 m²); finished floor datum is Y 35.5 m. D06 Sunset garden cafe occupies the same allocation below at Y 27; D08 Towels & care occupies it above at Y 44. The 8.5 m datum separation is not clear ceiling height. These records require confirmation against Higgins's current build.

Read the complete master chapter blocks 4, 5, 7, 8, 13, 19, 21, 24, 30, 32 and 33 in `Game/docs/master_source/MASTER_FULL_CONTENT_INDEX.json`, current application overrides, architectural delivery rules, whole-ship coordination, and catalogue coordinate contract. Dated implementation and exact old berth claims are superseded by the current application overlay. Sports remains D07 despite the blueprint's printed D08 sports label. No new species needs, biological dimensions or quantitative admission capacity are invented.

`AME-014` specifies this parent programme but no named child rooms or counts. The implementation below therefore supplies its changing/care purpose with **proposed subspaces**, not new canonical programmes or asserted blueprint requirements. Precise demand, locker/cubicle quantities and fixture counts remain open. D07 sports care must not silently become a D05 medical clinic or D08 bath facility.

## Reference pixels actually inspected

- `REF-1d51d4a06e`, `BlenderCatalogue/references/aquatic_program/public_blueprint.png`, SHA256 `1d51d4a06e33657c395408ef96ea2e28cf6571ebc6b9313b7525c4fa04779a0c`: full original image opened. Sports strip shows a legible principal route with smaller support clusters alongside active destinations; legend identifies changing rooms, family/accessibility, medical/first aid and service circulation, but it does not assign counts or exact subrooms to this programme. Translate the separation of active and support edges. Reject printed elevation/deck/capacity numbers as replacements for current canon.
- `REF-10dc8358ad`, `DesignArchive/References/Historical_Concepts_And_Blueprints/image-gen-1(1).png`, SHA256 `10dc8358ad4060128c8cedc24239bbf749c9805e45a71f9d4eb0325359b27324`: full original image opened. Thick textured piers visibly meet deep ceiling rims; orange recessed thresholds, inhabited curved edges and framed routes create depth. Translate supported threshold and edge composition at this destination's smaller scale. No atrium opening, extra balcony, exterior window or retail identity is imported.
- `REF-523733d277`, `DesignArchive/References/Uploaded_46/10/image(5).png`, SHA256 `523733d277a726a6caa5d65b4335a1a3bfd20e56a89bf2a77fc3303000edb5de`: full original image opened. Practical enclosure, visible overhead utilities, recessed storage and lights embedded in built-ins guide the screened care edge. Do not copy its cabin bed, theme props or photoreal finish.

## Composition and dimensioned plan

The destination is a **quiet changing court between sports and care**, entered from the west through a deep, offset portal. A faceted central orientation hall gives an immediate view of lockers, a staffed-care threshold and two privacy vestibules; no view continues directly into a changing or washing compartment. The quieter west pockets and substantial east wet/service block make the purpose readable without signs. The hall has a higher supported ceiling; lower peripheral canopies create intimate retreat, not an empty double-height spectacle.

All coordinates below use ship/Godot metres, X/Z plan, Y up. Envelopes reserve space; their rectangles do not prescribe final walls. The final partition profiles must retain the clear route reservations in `plan_contract.json`.

| Proposed subspace | X range | Z range | Role |
|---|---:|---:|---|
| Recessed public entry and orientation | 8–20 | 423–441 | 4 m clear portal at Z 430–434; deep turn before private branches |
| Faceted changing court | 20–38 | 420–444 | Main orientation and dry circulation; corners clipped 3 m |
| Forward changing gallery | 22–50 | 400–420 | Offset private/family/adaptive cells around locker bays; exact cell count deferred |
| Aft changing gallery | 22–50 | 444–459 | Second legible changing wing; no gender/species segregation assumed |
| Quiet care/rest pocket | 10–20 | 401–420 | Private rest and assistance, not diagnosis/treatment gameplay |
| Companion waiting edge | 10–20 | 444–459 | Built-in seating with parked mobility-space reservations |
| Enclosed hygiene block | 38–50 | 422–442 | Proposed wash/WC/drying support with opaque dogleg approaches |
| Screened service spine | 50–54 | 400–466 | Local cleaning, clean supply and soiled-return approach, 3 m net lane |
| Screened service crosslink | 20–54 | 459–466 | North/aft connection candidate and distinct stock/return alcoves |

The 2 m edge bands at Z 398–400 and elsewhere are allocated to perimeter wall/support/maintenance junctions and wing transitions, not counted as vacant floor or occupancy. Route continuity, partition thickness and all fixtures are to be resolved in the next geometry stage; envelopes alone do not prove fit. The west arrival and central hall overlap at their shared interface; all actual floor pieces must be unioned rather than layered.

Use one continuous level throughout guest and care routes. Initial design reservations: main dry lanes at least 3 m net, public aperture 4 m wide x 3.2 m high, internal private approaches 2 m net, private openings initially 1.5 m net, turning bays 3 x 3 m, service lanes 3 m net. These are project design targets pending actual capsule, loaded cart and broad-body/appendage envelope testing, not certified accessibility or universal species-fit claims. Private cells need user-controlled opacity, nearby storage and real changing supports; a bath model cannot pass as a changing function.

## Section, structure and fixture mount resolution

- Y 35.5: level finished floor; final loadbearing support/underside owned only after Higgins resolves floor ownership and D06 ceiling separation. Do not drop an arbitrary slab into the cafe below.
- Y 38.7: 3.2 m high private-wing soffits, with ceilings closed above privacy partitions. Wet partitions have continuous opaque enclosure and sealed service penetrations; no open overlook from D08.
- Y 39.3: 3.8 m clear public threshold canopy. A 0.35 m fascia returns into weighted jamb/piers. Its curved/faceted lining has backing rails fixed to transverse ribs; no unsupported timber sheet.
- Y 40.7: 5.2 m clear central hall ceiling. Proposed 0.45 m deep visible transverse ribs on 6 m nominal centres bear on perimeter piers/wall returns; intermediate member positions avoid reserved lanes. Curved infill terminates into recessed perimeter channels with end caps and deliberate joints. This is a visual construction proposal, not structural certification.
- Y 41.15–43.2: reserved ceiling/utility assembly envelope; no parts cross Y 43.2 in this proposal. The remaining 0.8 m to D08 datum is a provisional protected receiving buffer, not approval of a slab thickness or service zone.
- Sconces use visible backing plates mechanically joined to piers; local task fittings sit in cabinet undersides with actual housings. If any pendant is retained, its rod/cable, canopy and ceiling attachment must be modeled continuously. Show source light from these fixtures; emission-only brightness does not establish lighting.

Warm muted guest enamel, timber only in dry fitted edges, muted metal and practical wet surfaces follow existing material roles. Utilitarian service edges have visible fittings and cooler task lighting. Exact library material IDs and fixture families remain for Higgins's current dependency manifest. No new shared palette or registry.

## Interfaces and ownership gates

1. **Public edge:** candidate aperture at X 8, Z 430–434, Y 35.5. Retained aft-core floor reaches only X 7.8, leaving a 0.2 m gap to this allocation, and the core's `lateral_portal_decks` is empty. Higgins must confirm a legal side opening, receiving approach and single owner for the gap/floor seam. No core walls or collision may be cut by this package.
2. **Service edge:** candidate aperture at Z 466, X 23.5–26.5. The retained starboard service riser 5 lobby begins at Z 484; the intervening 18 m external route is outside this package. Higgins must allocate and own that concealed connection. No working staff access is claimed.
3. **Sports access:** other sports destinations are reached through the confirmed D07 public network. Do not cut a speculative direct connection through neighbouring land.
4. **Floor:** retained programme reports zero structural-floor overlap. Reserve one compiler-owned finished-floor polygon once approved; the asset package should supply no duplicate walkable slab. If Higgins chooses asset-owned floor instead, record that mutually exclusive ownership before export. Wet finishes must use same collision plane; no unapproved drains below floor.
5. **Ceiling:** D08 owns its slab and contents. This package owns only the approved internal soffit/enclosure below the agreed underside. D06 is protected below. No inter-deck void, lift or external window is proposed.
6. **Care:** segregate clean supply/soiled returns in screened local alcoves; protect real cart turns, parking and reachable stock. No infection or hazardous-material system is inferred from residue canon.

## Release prerequisites and later evidence

Higgins must confirm current bounds, floor/ceiling/structure and collision ownership, west core portal plus seam, service connection, applicable source families/material roles, supported body/cart envelopes, and changing demand/essential fixture counts. Until then, this plan is reviewable but geometry is held.

After release: generate source and portable export only within this package; check actual source-to-GLB transformed geometry; test all junctions and mounts visually; review approach, reverse arrival, both privacy turns, care approach, wet exit and section cutaway. Live receiving integration must separately test capsule/cart/control traversal, privacy sightlines with doors open/closed, supported floors and visual quality. No stage below the plan has been completed.
