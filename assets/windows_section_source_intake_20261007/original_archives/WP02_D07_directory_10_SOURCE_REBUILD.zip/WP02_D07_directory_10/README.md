# WP02 D07 Sports care & changing

Isolated source-construction candidate for Higgins. Not integrated or accepted in the ship.

Rebuild with Blender4.3.2 from this directory:

```powershell
& 'C:/Users/cered/Dolphin/AstraeaTools/blender-4.3.2-windows-x64/blender.exe' --background --factory-startup --threads 2 --python source/build_section.py
& 'C:/Users/cered/Dolphin/AstraeaTools/blender-4.3.2-windows-x64/blender.exe' --background --factory-startup --threads 2 --python source/review_section.py -- --render 01_arrival,03_changing_spine,05_locker_gallery,06_wash_threshold,07_service_stock,08_ceiling_mounts --samples 20
```

The executable path can be replaced by another Blender4.3.2 installation; generator inputs resolve relative to this package. Source textures and all8 approved native dependencies are bundled, with hashes enforced at build time. `docs/BRIEF.md` states current dimensions and claims. Origin at world[8,35.5,460], identity rotation and unit scale. Export excludes the preview floor. Receiving floor and the external4m route connector remain Higgins-owned and unbuilt.
