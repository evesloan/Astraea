"""Name physical blockers around failed source approaches. Read-only source records."""
from pathlib import Path
import json,math
P=Path(__file__).resolve().parents[1]
# Reuse the same collision screen without running/reporting the acceptance checks.
base=(P/'tests/check_source.py').read_text();ns={}
exec(base[:base.index('nav_results={}')] .replace("P=Path(__file__).resolve().parents[1]", "P=Path("+repr(str(P))+")"),ns)
report=json.loads((P/'qa/source_checks.json').read_text());data=ns['data'];tables=ns['table_byid'];obs=ns['obstacles']
result={}
def blocked(p,r):
    # Include source-grid quantization envelope, exactly as nav() discretizes it.
    out=[]
    gx,gy=ns['grid_index'](*p)
    for o in obs:
        x0=math.floor((o['lo'][0]-r+23)/.2);x1=math.ceil((o['hi'][0]+r+23)/.2)
        y0=math.floor((o['lo'][1]-r+34)/.2);y1=math.ceil((o['hi'][1]+r+34)/.2)
        if x0<=gx<=x1 and y0<=gy<=y1:out.append(o['id'])
    return out
for r in [.30,.65]:
    reach,_=ns['nav'](r);fail=set(report['navigation'][str(r)]['unreachable_seat_approaches']);rows=[]
    for s in data['seats']:
        if s['id'] not in fail:continue
        x,y,_=s['floor_source'];tx,ty,_=tables[s['table_id']]['tabletop_source'];dx,dy=x-tx,y-ty;n=math.hypot(dx,dy);dx/=n;dy/=n
        ps=[(x+dx*1.35,y+dy*1.35),(x-dy*1.35,y+dx*1.35),(x+dy*1.35,y-dx*1.35)]
        rows.append({'seat':s['id'],'table':s['table_id'],'center_uv':s['chair_center_uv'],'probes':[{'uv':[round(p[0]+23,3),round(34-p[1],3)],'blockers':blocked(p,r),'connected':reach(p)} for p in ps]})
    result[str(r)]=rows
result['used_return']={'target_uv':[7,36.7],'blockers':blocked((7-23,34-36.7),.65),'note':'If free but disconnected, inspect the full dirty-room boundary and approach.'}
result['used_return']['opening_barrier_objects']=[{'id':o['id'],'lo':o['lo'],'hi':o['hi']} for o in obs if 'WP05_bearing_' in o['id'] and abs((o['lo'][0]+o['hi'][0])/2+12.9)<.05 and abs((o['lo'][1]+o['hi'][1])/2+2)<.05]
result['used_return']['barrier_explanation']='Primary pier/plinth at local(u10.1,v36) occupies the dirty-room opening. Together with dirty-return body and wall restarting atv38, inflated bounds disconnect the room. Move bearing to opaque wall atv39, retaining longitudinal support.'
(P/'qa/route_obstructions.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'ordinary':result['0.3'][:2],'broad':result['0.65'][:6],'service':result['used_return']},indent=2))
