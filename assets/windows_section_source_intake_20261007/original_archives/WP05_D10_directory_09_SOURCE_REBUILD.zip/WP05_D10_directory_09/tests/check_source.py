"""Plain Python source-record checks; run after parent builds. Conservative AABB path screen.
It does not claim loaded-cart physics, seating animation or species-wide acceptance.
"""
import json,math,hashlib
from pathlib import Path
from collections import deque
P=Path(__file__).resolve().parents[1]
geo=json.loads((P/'qa/source_geometry.json').read_text())
data=json.loads((P/'exports/contact_markers.json').read_text())
records=geo['objects'];byid={r['id']:r for r in records}
fail=[];checks={}
def record(name,condition,detail=None):
    checks[name]={'pass':bool(condition),'detail':detail}
    if not condition:fail.append(name)
def merged(names):
    rs=[byid[n] for n in names]
    return([min(r['lo'][j] for r in rs) for j in range(3)],[max(r['hi'][j] for r in rs) for j in range(3)])
record('exact160_chairs',len(data['seats'])==160)
record('unique160_ids',len({s['id'] for s in data['seats']})==160)
record('unique160_contact_positions',len({tuple(round(x,4) for x in s['contact_source']) for s in data['seats']})==160)
record('40_tables',len(data['tables'])==40)
record('no_neighbour_intrusion',not geo['bounds_violation_ids'],geo['bounds_violation_ids'])
seat_fail=[];seat_ranges=[]
for s in data['seats']:
    lo,hi=merged(s['objects']);p=s['contact_source'];seat_ranges.append((s['id'],lo,hi))
    if not (abs(lo[2])<.006 and .48<p[2]<.50 and lo[0]<p[0]<hi[0] and lo[1]<p[1]<hi[1] and hi[2]>.9):seat_fail.append(s['id'])
record('actual_chair_contact_and_floor_bounds',not seat_fail,seat_fail)
overlap=[]
for i,(aid,al,ah) in enumerate(seat_ranges):
    for bid,bl,bh in seat_ranges[i+1:]:
        if min(ah[0],bh[0])>max(al[0],bl[0])+.001 and min(ah[1],bh[1])>max(al[1],bl[1])+.001:overlap.append([aid,bid])
record('no_chair_chair_bounds_overlap',not overlap,overlap)
table_byid={t['id']:t for t in data['tables']};setting_fail=[]
for s in data['settings']:
    lo,hi=merged(s['objects']);t=table_byid[s['table_id']];tx,ty,_=t['tabletop_source']
    # Outer setting corners within actual round tabletop radius; lowest visible support at stone inset.
    far=max(math.hypot(x-tx,y-ty) for x in [lo[0],hi[0]] for y in [lo[1],hi[1]])
    if not(abs(lo[2]-.787)<.006 and far<=.79):setting_fail.append({'setting':s['id'],'lowest_z':lo[2],'farthest_corner_radius':far})
record('160_settings_supported_by_real_tabletops',len(data['settings'])==160 and not setting_fail,setting_fail)

# All geometry below2m counts, including imported legs and screens, ignoring small z=0 support marks.
# AABBs are conservative and may falsely reject curved geometry; failures are reviewable, never suppressed.
obstacles=[r for r in records if r['lo'][2]<2.0 and r['hi'][2]>.06]
STEP=.2;W=231;H=341
def grid_index(x,y):return(round((x+23)/STEP),round((y+34)/STEP))
def nav(radius):
    blocked=bytearray(W*H)
    for r in obstacles:
        x0=max(0,math.floor((r['lo'][0]-radius+23)/STEP));x1=min(W-1,math.ceil((r['hi'][0]+radius+23)/STEP))
        y0=max(0,math.floor((r['lo'][1]-radius+34)/STEP));y1=min(H-1,math.ceil((r['hi'][1]+radius+34)/STEP))
        for y in range(y0,y1+1):blocked[y*W+x0:y*W+x1+1]=b'\1'*(x1-x0+1)
    start=grid_index(21,-28);q=deque([start]);seen={start}
    while q:
        x,y=q.popleft()
        for p in [(x+1,y),(x-1,y),(x,y+1),(x,y-1)]:
            a,b=p
            if 0<=a<W and 0<=b<H and p not in seen and not blocked[b*W+a]:seen.add(p);q.append(p)
    def reachable(p):
        # Quantization allowance only0.3m; avoid jumping walls to nearest distant open cell.
        x,y=grid_index(p[0],p[1]);return any((a,b) in seen for a in range(x-1,x+2) for b in range(y-1,y+2))
    return reachable,len(seen)
nav_results={}
for radius in [.30,.65]:
    reach,count=nav(radius);bad=[]
    for s in data['seats']:
        x,y,_=s['floor_source'];t=table_byid[s['table_id']];tx,ty,_=t['tabletop_source'];dx,dy=x-tx,y-ty;length=math.hypot(dx,dy);dx/=length;dy/=length
        # Behind and both side approaches; at least one physical stance near each chair must connect.
        # Standing outside the chair's actual rear/side extents plus radius.
        # The older0.95m side probe sat inside a0.35m chair half-width +0.65m query.
        # A1.35m approach is still local; BFS proves a connected physical stance.
        probes=[(x+dx*1.35,y+dy*1.35),(x-dy*1.35,y+dx*1.35),(x+dy*1.35,y-dx*1.35)]
        if not any(reach(p) for p in probes):bad.append(s['id'])
    nav_results[str(radius)]={'unreachable_seat_approaches':bad,'reachable_grid_cells':count,'scope':'conservative static2D AABB screen, no capsule or loaded-cart simulation'}
    record('seat_approaches_radius_'+str(radius),not bad,bad)
reach,count=nav(.65)
service_targets={'clean_finishing':[7.0-23,34-28.5],'used_return':[7.0-23,34-36.7],'care_cart':[6.5-23,34-64],'drinks':[31.4-23,34-33],'host':[38-23,34-63.5]}
service_bad=[n for n,p in service_targets.items() if not reach(p)]
record('broad_body_service_targets',not service_bad,service_bad)
report={'status':'PASS_SOURCE_SCREENS' if not fail else 'SOURCE_REVIEW_REQUIRED','failed_checks':fail,'checks':checks,'navigation':nav_results,
 'source_record_sha256':hashlib.sha256((P/'qa/source_geometry.json').read_bytes()).hexdigest(),
 'not_established':['actual Godot capsule/loaded-cart traversal','animation and six-species body fit','floor adoption','external4m receiver','operational food service','architectural visual acceptance','GPU performance']}
(P/'qa/source_checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'failed_checks':fail,'seat_approach_failures':{r:len(v['unreachable_seat_approaches']) for r,v in nav_results.items()}}))
raise SystemExit(1 if fail else 0)
