"""Hypothetical clearance screen, explicitly NOT rebuilt geometry acceptance."""
import json,copy
from pathlib import Path
P=Path(__file__).resolve().parents[1]
g=json.loads((P/'qa/source_geometry.json').read_text());d=json.loads((P/'exports/contact_markers.json').read_text())
# Proposed removal of floor-level transverse booth dividers and half-metre inward east row move.
g['objects']=[r for r in g['objects'] if 'WP05_booth_screen_' not in r['id']]
move=set()
for t in d['tables']:
    if abs(t['uv'][0]-41)<.01:
        move.add(t['id']);t['uv'][0]-=.5;t['tabletop_source'][0]-=.5
for s in d['seats']:
    if s['table_id'] in move:
        move.add(s['id']);s['contact_source'][0]-=.5;s['floor_source'][0]-=.5;s['chair_center_uv'][0]-=.5
for s in d['settings']:
    if s['table_id'] in move:move.add(s['id']);s['uv'][0]-=.5
for r in g['objects']:
    if r.get('instance_id') in move:r['lo'][0]-=.5;r['hi'][0]-=.5
    if 'WP05_bearing_' in r['id'] and abs((r['lo'][0]+r['hi'][0])/2+12.9)<.05 and abs((r['lo'][1]+r['hi'][1])/2+2)<.05:
        r['lo'][1]-=3;r['hi'][1]-=3
code=(P/'tests/check_source.py').read_text().replace("geo=json.loads((P/'qa/source_geometry.json').read_text())","geo=forecast_geo").replace("data=json.loads((P/'exports/contact_markers.json').read_text())","data=forecast_data")
code=code.replace("(P/'qa/source_checks.json').write_text(json.dumps(report,indent=2)+'\\n')", "report['status']='HYPOTHETICAL_ONLY_'+report['status']; (P/'qa/hypothetical_clearance_forecast.json').write_text(json.dumps(report,indent=2)+'\\n')")
ns={'__file__':str(P/'tests/check_source.py'),'forecast_geo':g,'forecast_data':d}
try:exec(code,ns)
except SystemExit:pass
