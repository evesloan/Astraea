# Moonfruit parlor — first-stage plan package

Status: **plan proposal prepared for architectural review; no geometry, Blender export, live integration or visual acceptance.** Dedicated section owner05 retains this package for construction follow-up. The final Higgins revision2 staging namespace is `external_packages/windows/WP05_D10_directory_09/`; the earlier WP03 label is superseded. All files presently remain inside this exclusively owned planning directory.

## Binding identity and interface

Programme `D10_directory_09`, historical alias `D10_dessert8`, **exactly160 individually located dining places**. The revised Higgins handoff resolves the initial directory's ambiguous `/160` suffix as dining places. These are neither a standing-room allowance nor extra ship capacity. Master chapter9 establishes the independent shipwide2200 dining-place limit; Moonfruit contributes its existing160.

World allocation X−54…−8, Z398…466, finished floor Y61; next datum Y69.5. Gross allocation46×68m=3128m² is not finished useful area. Starlight bakery `D09_directory_09` below and Immersive sound `D11_directory_12` above remain protected. No borrowed space, interdeck openings, hull penetrations or exterior views.

Higgins portal proposal is world(−8,61,460), local(u46,v62). Reserve a proposed4m clear opening,3.6m headroom and4.4m deep arrival corridor inside the allocation. The4m interval X−8…−4 toward installed axial circulation is **unbuilt and parent-owned**. The package stops at X−8. Current service links are likewise unbuilt; outer service walls remain sealed.

The local retained source records agree on the envelope and vertical neighbours. They are explicitly old snapshot evidence. **The current hash manifest, current row files, atlas p12 inspection image and reusable-asset receipts must be checked before geometry is released.** Parent is obtaining them. The current handoff and coordinator's revision2 correction guide this proposal; it does not certify source-manifest parity.

## Plan and capacity

Read [plan_section.svg](plan_section.svg) with [plan_contract.json](plan_contract.json). Local plan coordinates are u=X+54 and v=Z−398. All dimensions below are proposals inside the frozen allocation, not recovered finished geometry.

The composition is a long dessert parlor with an inhabited, screened service-side edge and a more open dining field. Entry arrives at an oblique view along the dining spine and toward the middle finishing counter. The plan establishes three different experiences without changing capacity:

| Subarea | Plan arrangement | Dining places |
|---|---|---:|
| Screened booth edge |16 four-place groups in two ranks, centres u13.5/19.5, eight longitudinal positions |64|
| Quiet fore parlor |12 four-place groups, centres u29/35/41, v7/13/19/25 |48|
| Sociable aft parlor |12 four-place groups, same transverse rhythm, v39/45/51/57 |48|
| Total |40 groups, four explicitly scheduled positions each |160|

Individual IDs `D10_dessert8-place-001`…`160`, world locations, proposed seat-contact heights, table association and facing are in the contract. They are provisional authoring markers, not installed runtime IDs. No extra waiting seats, host seats, drink stools or staff positions are credited as dining capacity.

Every table has a4.6×4.6m reservation cell around a candidate1.4×1.8m top. The two opposed seat pairs each have distinct coordinates. This is an allocation proof, not a confirmed species-body solution: exact body envelopes, four-arm clearance, foot/contact support and furniture dimensions remain open. A seat may be widened or changed to a suitable support without adding a fifth dining place. Mindos are guests; neither charging nor a synthetic diet is invented.

Main spine u22…26 gives4m clear width; the mid-room aisle v32…36 gives4m; arrival v59.8…64.2 gives4.4m. Table reservation cells do not overlap these rectangles. Inter-group gaps are1.4m longitudinally and at least1.4m across comparable fields. Those smaller gaps are candidate table approaches, **not claimed broad-body/cart routes**. The real source check must include pulled-out seats and screens, and all160 approaches; enlarge or rearrange groups within the generous envelope if it fails. No reduction to capacity or hiding inaccessible seats is permitted.

The main spine reaches a4m turning area toward the fore end. A3×3m cart parking zone is reserved inside the separate care room. Loading a cart into this proposal has not been simulated. No emergency egress compliance is implied by these widths or the single current public portal.

## Shape, section and support

Avoid turning the gross rectangle into the finished wall language. The booth edge uses thick folded screen piers and deep recesses, closed-return canopy pieces and differentiated shared/quiet entries. At the right-hand dining fields, a shallow faceted enclosing wall and alternating recessed end bays produce a different silhouette from the booth bank. Their offsets stay outside table cells and circulation reservations. The full enclosing wall/ceiling mesh must resolve these junctions in the next stage; the plan diagram is an allocation diagram rather than final wall geometry.

Proposed main clear ceiling6.4m above floor, primary enclosure/support top7.5m, leaving1m to the protected next datum. Screened booth and quiet canopies descend to3.6m; service ceiling3.4m. Thus the central passage reveals a taller volume while occupied edges are intimate. This is one deck, without mezzanine or skylight.

Booth-side supporting piers at u10.4/21.9 sit outside the central spine. Canopy beams meet those piers with modeled bearing/end caps; curved or faceted facing returns into a boxed beam instead of stopping as a loose timber ribbon. Main ceiling members require an explicit wall-pilaster/bearing layout; dimensions in this proposal establish an architectural envelope, not a structural calculation. Verify spans before final source design.

Pendant bottoms are proposed at2.7m. Every pendant has a visible stem and rose fixed to real ceiling backing or beam. Glowing geometry alone is insufficient. Model the actual light source, light its nearby table/route and verify it under the existing renderer later. Protect the opaque boundary below Immersive sound; acoustic separation is an architectural intention, not measured isolation.

Finished floor remains exactlyY61. **Floor thickness and structural ownership are unresolved.** Do not raise it to fit an arbitrary slab or push geometry into bakery space. Parent must assign structural floor ownership and eliminate duplicate layers at integration.

## Hospitality and care routes

West-side service band u0.6…10 contains clean received stock/finishing v1…31, used-return/wash v33…57, and a screened local care/cart room v58…67. The2m interval between clean and dirty rooms supports the separating wall/controlled transition and must be dimensioned with the actual counter family. Food preparation is a finishing/service provision; no new cooking minigame or full plumbing simulation is promised.

Clean sequence: received stock → clean crockery/finishing bench → counter u10…20.5,v29.3…31.5 → dining aisles → table. Dirty sequence: tables → public cross aisle → separate return hatch u10…11,v34…36 → used-tray/wash room. The two back-of-house holdings and hatches are physically separated. **Table delivery and collection share public aisles**; this is not falsely labeled a wholly separate clean/dirty circulation network. Actual handoff/reach checks may require changed hatch positioning.

Drink point u29…35,v29.3…31.5 receives an approach outside the main spine. Host desk u36…40,v65…66.8 stays off the entry route. Care storage includes visible shelves, cleaning supplies and cart parking; its screened staff access must be drawn and checked with actual fixtures before the room is enclosed. External replenishment remains a future parent interface, not an invented door into neighbouring space.

## Sources actually read and images inspected

- Complete relevant master chapters4,5,7,8,9,21,23,30,32,33, including their tables, are retained in `master_chapters.txt`; source is `Game/docs/master_source/MASTER_FULL_CONTENT_INDEX.json`. Historical implementation claims are not transferred to this rebuild.
- `MASTER_CURRENT_APPLICATION.json`: reviewed current overrides, particularly species, admitted versus physical capacity, Godot4.6.3 Compatibility, low-poly/CRT direction, curated real views and production sequencing.
- `ARCHITECTURAL_DELIVERY_RULES.md`, `WHOLE_SHIP_SECTION_COORDINATION.md`, `FULL_SHIP_SCOPE_INDEX.md`, `COORDINATE_CONTRACT.md`, and parent `COORDINATION.md` were read.
- Local extraction in `source_evidence.json`: programme/ledger identity, datums, neighbours, AME-042, source hashes. The audit associates one parent programme requirement and no separately mapped engineering child records; it does not exempt service provision.
- Full-size `REF-32858f7ec1`, hospitality/vibe_dining_edge.jpg,1200×675, and corresponding larger `REF-3c524e22a5`, Uploaded_46/12/image(7).png,1920×1080: inspected real pixels. Applicable features are coordinated booth/screen rhythm, deep piers, layered ceiling/pendant lane and a clear continuous circulation edge. Reject the reference exterior window, exact lattice ornament, glossy realism and literal repetition.
- Full-size `REF-d0f54a5bb3`, salon/vibe_observation_lounge.jpg,1200×750, and `REF-72c49c565c`, Uploaded_46/11/image(6).png,1440×900: inspected real pixels. Conversation-sized groups, reachable tables and coordinated ceiling outline support the quiet fore parlor. Exterior view is explicitly not adopted.
- Full-size `REF-48fd2aa4fe`, Historical_Concepts_And_Blueprints/image-gen-3.png: inspected public-sheet pixels, including dining/service legend. Its printed D10/retail combined programme, heights and2400+1200 dining figures conflict with current canonical allocations/2200 total and are not imported.
- Reference identities/copy paths/hashes are retained in `reference_sources.json`. Some entries in that extraction were not opened; only the explicit IDs above are claimed inspected. Current Q quality benchmark and current atlas p12 await received verification; this packet does not claim those pixel checks.

Reuse candidates from Higgins are AST-DIN-001/002/006, AST-HSP-001…006, AST-LGT-001. Current source identity/version and dimensions must be verified before reuse; no asset has yet been copied, edited or claimed to fit. Keep semantic materials and original parent identities. No new catalogue ID has been registered.

## Evidence and next gate

`python build_plan_packet.py` regenerates the contract, diagram and `plan_check.json`. The check passed160 unique planned position IDs/coordinates,40 nonoverlapping table reservation cells inside the allocation, and zero table-cell overlap with the reserved route rectangles. It deliberately does not certify walls, bodies, collisions, actual furniture, dynamic leaves or live movement.

Before geometry: receive and verify current manifest/rows/images and atlas p12; parent review this dimensional plan; confirm floor ownership, door/counter/body inputs and support layout. Then construct in final WP05 staging only after coordinator release, using compatible Blender4.3.2, and review normal-height arrival, booth corner, central cross aisle, quiet parlor, service hatch and cutaway. Package complete furnished/materialled source and mounted lights, then perform actual source/export checks. All source captures remain SOURCE ONLY until Higgins integrates and verifies current live routes, CRT views and regression.
