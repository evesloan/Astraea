# Moonfruit parlor — WP05 source candidate

Programme `D10_directory_09`, alias `D10_dessert8`, exactly160 individually identified dining places. This is an isolated source package for Higgins; it does not modify or certify the live ship.

## Current state

Portable source and GLB have been built and independently reviewed as a source candidate. The coordinator accepted all five source views; the final service image confirms readable ivory lettering and physical sign mounts. Fresh actual source checks pass all160 place approaches at0.30/0.65m and service targets. Fresh actual GLB resource/containment review also passes. This package is prepared for Higgins's receiving review; live integration remains open. `docs/BRIEF.md` retains the historical initial plan checkpoint; this README, `root_review.json` and `docs/current_assignment.json` describe the final source-candidate scope.

All10 native component sources were copied byte-for-byte into `dependencies/native/` and independently verified against the current Higgins source hashes. `dependencies/receipt.json` preserves provenance. Approved original material textures are bundled and packed when the builder runs. The builder resolves no machine-specific input paths.

## Build and review

From any relocated copy of this package, run Blender4.3.2:

```powershell
& '<Blender4.3.2 path>/blender.exe' --background --python '<package>/source/build_moonfruit.py'
python '<package>/tests/check_source.py'
```

An optional `-- --render arrival activity booth quiet service section` requests source-only views after build/export. The parent can instead render the saved source with its scheduled review helper. Ordinary cameras are at1.65m eye height. The diagnostic section camera is explicitly elevated. Parent should preserve failed runs and correct significant visual or geometric defects before labeling this ready for review.

**Only `source/build_moonfruit.py` is the clean construction entry point.** It imports `source/signage_spec.py` and already incorporates every accepted correction. The `patch_*.py` scripts, route diagnostics and hypothetical forecast are preserved repair history, not prerequisite rebuild steps. Do not run them after a clean rebuild. For compact reconstruction, run its bundled `copy_dependencies.py` first to restore hash-matched native sources/textures from the original catalogue, then the builder and checks above.

The generated source `source/WP05_moonfruit.blend` remains editable, including materials, linked repeated components, architectural modifiers and text. Its portable `exports/WP05_moonfruit.glb` excludes **all SOURCE_PREVIEW_ONLY floor surfaces and cameras**. Instance identities, source assets, contact markers and lighting proposals accompany it. Output manifests bind actual native/export hashes after execution.

## Reconciled construction plan

The40 groups retain64 screened-edge places,48 quiet-fore places and48 sociable-aft places. Each now uses one unchanged AST-DIN-001 round table with four unchanged AST-DIN-002 chairs at cardinal offsets1.32m. This supersedes the plan's hypothetical opposed-pair rectangular table. Exact native `DATUM_seat_contact`/`DATUM_floor_contact` records locate each place; the chair's actual seat-contact height is0.49m. AST-DIN-006 settings rest on the actual0.787m stone inset. Species-wide support/pose compatibility remains unverified and is not inferred from these human-scale component dimensions.

The architectural first pass includes deep booth screens, deliberately open1.8m inner booth access, closed-end low canopies, visible piers and beams, a taller axial passage, quieter coffered dining, faceted wall niches, restrained textured materials, mounted opal pendant fixtures with actual source lights, service and identity signs, furnishing, clean finishing/drink/used-return stations and local care stocks. Screens and fixtures are real construction, not emissive strips used to hide a bare shell. Parent must judge the actual resulting images, not this design description.

Clean supplies and used dish holdings occupy separate rooms with distinct public counter/return interfaces. Table delivery and dirty collection share the public dining aisles; no fully segregated operational kitchen network is claimed. Staff door openings, shelf reaches and cart stances are source candidates. External replenishment remains a future parent interface.

## Receiving contract

- Source coordinates are centered Blender Z-up: `(u−23,34−v,h)` where local plan `u=X+54`, `v=Z−398`.
- GLB mapping is `(x,z,−y)`; placement translation is world `(-31,61,432)`, no extra rotation or scale. Do not convert twice.
- Allocation is X[-54,-8], Z[398,466]; finish Y61; next datum69.5. Geometry remains below local7.5m, leaving a1m upper buffer. Starlight bakery below and Immersive sound above remain opaque/protected.
- Public boundary portal is world(-8,61,460). Its external4m link toward X−4 is UNBUILT and Higgins-owned. This package creates no receiver floor, neighbour opening or external staff link.
- **No adopted floor is supplied.** Source floor exists only to review furniture and lighting. Higgins owns structural-floor/collision assignment at exactlyY61; `exports/floor_proposal.json` specifies material regions for the receiving floor. Do not import a second slab or raise the finish datum.
- No external glazing or skylight. No new global catalogue identities, controller, registry, material-library mutation, engine import or publication.

## Evidence limits

`tests/check_source.py` checks actual evaluated object bounds,160 unique contact locations, floor-level chair support, chair-to-chair overlap,160 tabletop setting supports and conservative radius0.30/0.65m static approach screens. It reports failures instead of suppressing them. The AABB screens are conservative2D planning checks and cannot replace the real capsule, dynamic door, loaded-cart and six-species tests.

Parent acceptance still requires source reload/GLB geometric checks, independent ordinary-height image comparison, receiving floor and link construction, live arrival/traversal/collision, source-backed effective lighting under Godot4.6.3 Compatibility, CRT on/off review, relevant regressions and retention. Food service, crowds, dietary biology, plumbing and measured acoustics are not established by furnished geometry.

Full-size current reference P(public sheet) and Q(retro atrium threshold) were opened during construction preparation. P guides legible guest/service planning but its conflicting labels/counts do not override this assignment. Q guides substantial architectural hierarchy, deep thresholds and warm mounted light; its multilevel atrium, stairs and exterior sky are not imported into this internal one-deck allocation. Dining and lounge original reference pixels were inspected in the preceding plan stage. Parent retains current atlas p12 verification; its historical rectangle does not prescribe a box interior.

## Source clearance correction after evaluated review

The first exported build's actual source screen exposed inaccessible chair pockets. `qa/route_obstructions.json` names blocking geometry for every failed target. Transverse low booth partitions prevented going around north/south chairs; therefore the64-place edge now consists of **supported canopied dining bays with service-side screens**, rather than enclosed booths. Canopy hierarchy, thick joined returns, piers, materials and mounted fixtures remain. All160 chair positions retain actual original assets. The west table rank is at u14.0 and eastmost rank at u40.5, giving more wall-side passage. A primary pier incorrectly sitting in the dirty-room opening moves fromv36 tov39 onto the opaque wall.

`qa/hypothetical_clearance_forecast.json` records a fast projected-bounds check of these specific corrections; it is explicitly hypothetical and does not replace a rebuilt source check. It forecasts zero unreachable places at the unchanged0.30/0.65m query radii and all service targets reachable. Only the next Blender run and fresh source records can confirm that result. Failed actual receipts remain actual evidence and have not been relabeled as passing.

## Preview-only review correction

The subsequent actual rebuilt source check passes: all160 place approaches are connected at both0.30m and0.65m query radii, and service targets pass. This remains a source screen, not live traversal acceptance.

Rendered review found coplanar preview surfaces: the backing slab and material inlays both ended atZ0. The generator now lowers only the preview backing top toZ−0.01, leaving inlays atZ0. The activity camera moves to a clear1.65m-eye position beside the bearing line so a pier does not obscure the dining composition. `source/patch_preview_only.py` applies these two changes to the existing native source after the parent's current render job ends. It saves a matching native receipt and explicitly verifies that the already accepted geometry GLB hash remains unchanged. All affected preview objects stay excluded from that GLB. Fresh images still require review.

The preview-only patch was superseded before execution by the authorized `source/patch_review.py`, which also fixes sign geometry and therefore legitimately reexports the GLB. `source/signage_spec.py` is shared with the full generator. Finishing/drink signs have real backboards bracketed to the existing support columns; return/care signs face public+X and are backed and suspended from the actual service ceiling; host signs face the arrival and mount on the aft wall. The fore identity is attached directly to its display back. All plaques clear the2m source route screen. No dining place or route allocation changed.

The executed native patch reports `WP05_REVIEW_PATCH_EXPORT_OK`. Fresh `qa/source_checks.json` passes with0/160 unreachable at each radius. `qa/export_review_after_signage.json` verifies470560 actual triangles, embedded textures, no preview-floor mesh and no bounds violation. The GLB SHA256 is `1b783fc83a233f47547e8f473c1e7efc8e7d37ee4fefb96d897626f531e3e8e8`. These checks establish source/exchange scope only. The parent must review newly rendered views of this exact source before acceptance.

## Final lettering contrast pass

Parent reviewed all five corrected source views and accepted their architectural/floor/camera composition, requesting only higher-contrast lettering. All seven sign text objects now use the existing approved ivory enamel material. Backboards, mounts, transforms, geometry, lighting and160-place layout remain unchanged; this was verified against evaluated native mesh bounds/counts. Generator and native source agree via `signage_spec.py`.

`qa/sign_contrast_patch.json` records the executed material-only patch. Fresh source screens still pass with0/160 blocked places at both radii, and `qa/export_review_final.json` passes with unchanged470560 triangles and10 embedded textures. Final GLB SHA256 is `fa66f01c186c178e855126262ecaf70401f60334f2d950f0b691099a5d02d660`, superseding the preceding signage-layout hash. Arrival/activity/booth/quiet images retain accepted architectural evidence; their lettering material predates this final correction. The coordinator inspected and accepted the fresh final service image, confirming readable correctly facing cream lettering, physical backboards/mounts, stocked counters and a legible floor. `root_review.json` binds exactly these five ordinary-height views and records the lettering-only revision distinction.
