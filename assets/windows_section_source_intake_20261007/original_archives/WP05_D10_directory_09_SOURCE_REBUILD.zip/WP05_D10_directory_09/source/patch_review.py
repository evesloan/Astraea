"""Small parent-authorized native patch: preview, activity camera, mounted signs, fresh GLB."""
import bpy,json,hashlib,sys
from pathlib import Path
from mathutils import Vector
P=Path(__file__).resolve().parents[1]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
source=P/'source/WP05_moonfruit.blend';export=P/'exports/WP05_moonfruit.glb'
before={'source':sha(source),'export':sha(export)}
floor=bpy.data.objects['WP05_SOURCE_PREVIEW_ONLY_floor'];assert floor.get('SOURCE_PREVIEW_ONLY')
floor.location.z=-.13
camera=bpy.data.objects['WP05_activity'];camera.location=(4.6,-13.4,1.65)
camera.rotation_euler=(Vector((13.4,-11,1.6))-camera.location).to_track_quat('-Z','Y').to_euler()
sys.path.insert(0,str(P/'source'));from signage_spec import apply_signage
apply_signage();scene=bpy.context.scene;bpy.context.view_layer.update()
records=[];dg=bpy.context.evaluated_depsgraph_get()
for o in scene.objects:
    if o.type not in {'MESH','FONT'} or o.get('SOURCE_PREVIEW_ONLY'):continue
    ev=o.evaluated_get(dg);me=ev.to_mesh();pts=[ev.matrix_world@v.co for v in me.vertices]
    if pts:records.append({'id':o.name,'lo':[min(v[j] for v in pts) for j in range(3)],'hi':[max(v[j] for v in pts) for j in range(3)],'instance_id':o.get('instance_id'),'source_catalogue_id':o.get('source_catalogue_id'),'vertex_count':len(me.vertices)})
    ev.to_mesh_clear()
invalid=[r['id'] for r in records if any(r['lo'][j]<[-23,-34,0][j]-.005 or r['hi'][j]>[23,34,7.51][j]+.005 for j in range(3))]
assert not invalid,invalid
geometry_path=P/'qa/source_geometry.json';geometry=json.loads(geometry_path.read_text());geometry.update({'objects':records,'bounds_violation_ids':invalid,'object_count':len(records),'revision':'mounted-public-signs01'})
geometry_path.write_text(json.dumps(geometry,indent=2)+'\n')
for im in bpy.data.images:
    if im.source=='FILE' and im.has_data and not im.packed_file:im.pack()
bpy.ops.wm.save_as_mainfile(filepath=str(source))
bpy.ops.object.select_all(action='DESELECT')
for o in list(scene.objects):
    if o.type=='FONT':o.select_set(True);bpy.context.view_layer.objects.active=o;bpy.ops.object.convert(target='MESH');o.select_set(False)
bpy.ops.object.select_all(action='DESELECT')
for o in scene.objects:
    if not o.get('SOURCE_PREVIEW_ONLY'):o.select_set(True)
bpy.ops.export_scene.gltf(filepath=str(export),export_format='GLB',use_selection=True,export_apply=True,export_yup=True,export_extras=True,export_lights=True,export_cameras=False)
mp=P/'exports/manifest.json';manifest=json.loads(mp.read_text())
manifest.update({'source_sha256':sha(source),'glb_sha256':sha(export),'generator_sha256':sha(P/'source/build_moonfruit.py'),'signage_spec_sha256':sha(P/'source/signage_spec.py'),'actual_objects':len(records),'native_review_patch':'mounted-public-signs01_preview-floor-camera01','status':'native and GLB updated; fresh source checks and source-image review required'})
mp.write_text(json.dumps(manifest,indent=2)+'\n')
(P/'qa/review_patch.json').write_text(json.dumps({'before':before,'after':{'source':sha(source),'export':sha(export)},'changed':'Preview floor/camera; legible publicly facing finishing/drink/return/care/host signs with real backboards and column/wall/ceiling mounts','unchanged':'All160 dining positions and route layout; no live ship edit','source_bounds_violations':invalid,'rendered':False},indent=2)+'\n')
print('WP05_REVIEW_PATCH_EXPORT_OK')
