"""Portable Moonfruit whole-section source candidate. Run in Blender4.3.2.
Package-relative dependencies only. Source floor excluded from architecture export.
Optional -- --render arrival activity booth quiet service section. Parent schedules execution.
"""
import bpy, math, json, hashlib, sys
from pathlib import Path
from mathutils import Matrix, Vector
P=Path(__file__).resolve().parents[1]
PK='WP05_D10_directory_09'
for folder in ['source','exports','qa']: (P/folder).mkdir(exist_ok=True)
for r in json.loads((P/'dependencies/receipt.json').read_text()):
    assert hashlib.sha256((P/r['file']).read_bytes()).hexdigest()==r['expected_sha256'],r['id']
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene; scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=1
scene.render.engine='CYCLES';scene.cycles.samples=24;scene.cycles.use_denoising=True
scene.render.resolution_x=1280;scene.render.resolution_y=800;scene.render.resolution_percentage=100
scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.11,.13,.17,1)
scene.world.node_tree.nodes['Background'].inputs[1].default_value=.09;scene.view_settings.view_transform='AgX'
mat_contract=json.loads((P/'dependencies/materials/material_manifest.json').read_text())['materials']
mats={};objects=[];markers=[];lights=[];instances=[];tables=[];seats=[];settings=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def xyz(u,v,h=0):return(u-23,34-v,h)
def gltf(p):return[p[0],p[2],-p[1]]
def world(p):q=gltf(p);return[q[0]-31,q[1]+61,q[2]+432]
for role,r in mat_contract.items():
    m=bpy.data.materials.new('WP05_'+role);m.use_nodes=True;m['astraea_material_role']=role
    m['meters_per_tile_uv']=r['meters_per_tile_uv']; b=m.node_tree.nodes.get('Principled BSDF')
    b.inputs['Roughness'].default_value=r['roughness'];b.inputs['Metallic'].default_value=r['metallic']
    im=bpy.data.images.load(str(P/'dependencies/materials'/r['base_color_file']),check_existing=True);im.pack()
    n=m.node_tree.nodes.new('ShaderNodeTexImage');n.image=im;n.interpolation='Closest';m.node_tree.links.new(n.outputs['Color'],b.inputs['Base Color']);mats[role]=m
m=bpy.data.materials.new('WP05_opal');m.use_nodes=True;b=m.node_tree.nodes.get('Principled BSDF');b.inputs['Base Color'].default_value=(1,.79,.49,1);b.inputs['Emission Color'].default_value=(1,.72,.36,1);b.inputs['Emission Strength'].default_value=1.6;mats['opal']=m

def finish(o,name,role,bevel=0,solid=True):
    o.name='WP05_'+name;o['package_id']=PK;o['semantic_role']=role;o['source_collision_candidate']=solid
    if o.type=='MESH':
        o.data.materials.append(mats[role]);uv=o.data.uv_layers.new(name='PhysicalScaleUV') if not o.data.uv_layers else o.data.uv_layers.active
        scale=mat_contract.get(role,{}).get('meters_per_tile_uv',[1,1])
        for poly in o.data.polygons:
            ax=max(range(3),key=lambda j:abs(poly.normal[j]));ij=[j for j in range(3) if j!=ax]
            for li in poly.loop_indices:
                v=o.data.vertices[o.data.loops[li].vertex_index].co;uv.data[li].uv=(v[ij[0]]/scale[0],v[ij[1]]/scale[1])
        if bevel:
            mo=o.modifiers.new('Editable softened edges','BEVEL');mo.width=bevel;mo.segments=2
            o.modifiers.new('Weighted corner normals','WEIGHTED_NORMAL')
    objects.append(o);return o
def box(name,u,v,h,su,sv,sh,role,bevel=.025,solid=True):
    bpy.ops.mesh.primitive_cube_add(size=1,location=xyz(u,v,h));o=bpy.context.object;o.dimensions=(su,sv,sh)
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,name,role,bevel,solid)
def cyl(name,u,v,h,r,depth,role,n=24,solid=True):
    bpy.ops.mesh.primitive_cylinder_add(vertices=n,radius=r,depth=depth,location=xyz(u,v,h));return finish(bpy.context.object,name,role,.012,solid)
def mesh(name,verts,faces,role,bevel=.025):
    me=bpy.data.meshes.new(name);me.from_pydata([xyz(*p) for p in verts],[],faces);me.update();o=bpy.data.objects.new(name,me);scene.collection.objects.link(o);return finish(o,name,role,bevel)
def beam(name,a,b,width,depth,role):
    pa=Vector(xyz(*a));pb=Vector(xyz(*b));bpy.ops.mesh.primitive_cube_add(size=1,location=(pa+pb)/2);o=bpy.context.object
    o.dimensions=(width,depth,(pb-pa).length);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    o.rotation_euler=(pb-pa).to_track_quat('Z','Y').to_euler();return finish(o,name,role,.03)
def marker(name,loc,kind,**extra):
    o=bpy.data.objects.new('WP05_MARK_'+name,None);scene.collection.objects.link(o);o.location=loc;o.empty_display_size=.12;o['package_id']=PK;o['kind']=kind
    markers.append({'id':o.name,'kind':kind,'blender_source':list(loc),'local_gltf':gltf(loc),'world_xyz':world(loc),**extra});return o
def sign(name,body,u,v,h,size=.22,yaw=0):
    c=bpy.data.curves.new(name,'FONT');c.body=body;c.size=size;c.align_x='CENTER';c.extrude=.004
    o=bpy.data.objects.new('WP05_'+name,c);scene.collection.objects.link(o);o.location=xyz(u,v,h);o.rotation_euler=(math.pi/2,0,yaw);o.data.materials.append(mats['champagne_metal']);o['package_id']=PK;return o
def light(name,u,v,h,power,spread=115):
    d=bpy.data.lights.new('WP05_'+name,'SPOT');d.energy=power;d.color=(1,.78,.53);d.spot_size=math.radians(spread);d.spot_blend=.72;d.shadow_soft_size=.3
    o=bpy.data.objects.new('WP05_'+name,d);scene.collection.objects.link(o);o.location=xyz(u,v,h);o['package_id']=PK
    lights.append({'id':o.name,'position':list(o.location),'power_w':power,'source_fixture':name.rsplit('_source',1)[0]});return o
def pendant(name,u,v,mount,bottom=2.85,power=180):
    cyl(name+'_rose',u,v,mount-.055,.16,.11,'champagne_metal')
    cyl(name+'_stem',u,v,(mount+bottom+.14)/2,.025,mount-bottom-.14,'champagne_metal',12)
    cyl(name+'_shade',u,v,bottom+.13,.34,.21,'warm_walnut')
    cyl(name+'_lip',u,v,bottom+.045,.36,.045,'champagne_metal')
    cyl(name+'_opal',u,v,bottom,.30,.045,'opal')
    light(name+'_source',u,v,bottom-.04,power*3.2)
    # A modeled opal aperture in the shade's top supplies warm ceiling bounce.
    # Offset from the stem prevents the stem occluding its own upward light.
    cyl(name+'_upper_opal_aperture',u+.20,v,bottom+.244,.075,.022,'opal',16)
    up=light(name+'_uplight_source',u+.20,v,bottom+.268,power*1.5,145)
    up.rotation_euler=(math.pi,0,0)
    lights[-1]['direction']='upward from visible upper opal aperture'
    marker(name+'_mount',xyz(u,v,mount),'fixture_mount',member='explicit canopy or primary beam')

# Full hierarchy linked and evaluated before caching matrices: no stale matrix_world.
templates={}
for receipt in json.loads((P/'dependencies/receipt.json').read_text()):
    aid=receipt['id'];col=bpy.data.collections.new('SOURCE_TEMPLATE_'+aid);scene.collection.children.link(col)
    with bpy.data.libraries.load(str(P/receipt['file']),link=False) as (available,loaded):loaded.objects=available.objects
    for o in loaded.objects:
        if o is not None:col.objects.link(o)
    bpy.context.view_layer.update();cache=[];datum={};pts=[]
    for o in col.objects:
        if o.type=='MESH':
            cache.append((o,o.matrix_world.copy()))
            pts.extend(o.matrix_world@Vector(v) for v in o.bound_box)
        elif o.type=='EMPTY':datum[o.name.split('.')[0]]=list(o.matrix_world.translation)
    templates[aid]={'objects':cache,'datums':datum,'lo':[min(v[j] for v in pts) for j in range(3)],'hi':[max(v[j] for v in pts) for j in range(3)]}
    scene.collection.children.unlink(col)
# Relink image dependencies by original basename; never depend on old absolute paths.
for im in bpy.data.images:
    if im.source!='FILE':continue
    basename=im.filepath.replace('\\','/').rsplit('/',1)[-1]
    candidates=list((P/'dependencies/materials').rglob(basename))
    if candidates:
        im.filepath=str(candidates[0])
        if not im.packed_file:im.reload();im.pack()
    elif not im.packed_file:raise RuntimeError('Unbundled image '+im.filepath)
def instance(aid,iid,u,v,h=0,yaw=0):
    template=templates[aid];T=Matrix.Translation(xyz(u,v,h))@Matrix.Rotation(math.radians(yaw),4,'Z');obs=[]
    for proto,transform in template['objects']:
        o=proto.copy();o.data=proto.data;o.parent=None;o.matrix_world=T@transform;o.name='WP05_'+iid+'_'+proto.name
        scene.collection.objects.link(o);o['package_id']=PK;o['source_catalogue_id']=aid;o['instance_id']=iid;o['source_collision_candidate']=True;obs.append(o)
    datums={n:list(T@Vector(p)) for n,p in template['datums'].items()}
    instances.append({'id':iid,'source_catalogue_id':aid,'source_sha256':next(r['sha256'] for r in json.loads((P/'dependencies/receipt.json').read_text()) if r['id']==aid),'position':list(T.translation),'yaw_degrees':yaw,'objects':[o.name for o in obs],'datums':datums})
    return obs,datums

# Preview surfaces have actual top Y61 after placement; NOT a delivered duplicate slab.
o=box('SOURCE_PREVIEW_ONLY_floor',23,34,-.13,46,68,.24,'warm_stone',0);o['SOURCE_PREVIEW_ONLY']=True
for u,v,su,sv,role in [(16.3,33,11.2,60,'clay_weave'),(35,16,17,26,'teal_weave'),(35,47,17,26,'oatmeal_weave'),(24,34,4,66,'warm_walnut')]:
    o=box('SOURCE_PREVIEW_ONLY_floor_finish',u,v,-.004,su,sv,.008,role,0);o['SOURCE_PREVIEW_ONLY']=True
# Opaque boundary, deep inward portal; no exterior views.
box('west_enclosure',.25,34,3.7,.5,68,7.4,'ivory_enamel');box('fore_enclosure',23,.25,3.7,45,.5,7.4,'ivory_enamel');box('aft_enclosure',23,67.75,3.7,45,.5,7.4,'ivory_enamel')
box('east_wall_fore',45.75,29.85,3.7,.5,59.7,7.4,'ivory_enamel')
box('east_wall_aft',45.75,66.1,3.7,.5,3.8,7.4,'ivory_enamel')
box('portal_head',45.75,62,5.6,.5,4.6,3.6,'ivory_enamel')
for v in [59.7,64.3]:box('entry_portal_pier',44.9,v,1.85,1.2,.6,3.7,'warm_walnut',.09)
box('entry_portal_lintel',44.9,62,3.85,1.2,5.2,.4,'warm_walnut',.06)
marker('public_portal',xyz(46,62,0),'portal',clear_width_m=4,clear_height_m=3.6,external_link='HELD_UNBUILT_parent_owned')
box('opaque_ceiling_cap',23,34,7.35,45,67,.3,'ivory_enamel',0)

# Visible roof-bearing hierarchy: deep axial edge beams carried by segmented piers.
for u in [10.1,21.6,26.4,44.5]:
    box('primary_longitudinal_beam',u,33.8,6.75,.48,66.4,.8,'warm_walnut',.04)
    for v in [3.2,10,16,22,29.3,36,42,48,54,60,65.6]:
        if u in [21.6,26.4] and v in [60]:continue # preserve arrival cross-route
        if u==10.1 and v==36:v=39 # bearing seats on opaque wall, never in dirty-room opening
        box('bearing_pier',u,v,3.19,.34,.42,6.38,'ivory_enamel',.055)
        box('bearing_capital',u,v,6.28,.6,.65,.25,'warm_walnut')
        box('bearing_plinth',u,v,.22,.48,.56,.44,'warm_stone')
for v in [3.2,16,28.5,42,54,65.6]:
    box('roof_cross_member',27.3,v,7.0,35,.45,.5,'warm_walnut')
# Tall spine ceiling has faceted haunches that meet real bearing members.
for v0,v1 in [(3.2,28.5),(36,60)]:
    for a,b in [((21.6,v0,6.55),(23.1,v0,7.08)),((24.9,v0,7.08),(26.4,v0,6.55))]:
        # Long extruded quadrilateral return; no unsupported decorative ribbon.
        u0,_,h0=a;u1,_,h1=b
        verts=[(u0,v0,h0),(u1,v0,h1),(u1,v1,h1),(u0,v1,h0),(u0,v0,h0+.18),(u1,v0,h1+.18),(u1,v1,h1+.18),(u0,v1,h0+.18)]
        mesh('spine_haunch',verts,[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)],'warm_walnut')

# Articulated west edge: screens at bay ends, joined canopy + thick fascia + end returns.
rows=[7,13,19,25,39,45,51,57]
for n,v in enumerate(rows):
    box('booth_shared_canopy',16.1,v,3.78,11.0,5.8,.34,'warm_walnut',.065)
    box('booth_canopy_inset',16.1,v,3.585,10.3,5.15,.06,'ivory_enamel',.035)
    for u in [10.55,21.65]:box('booth_closed_fascia',u,v,3.65,.22,5.8,.56,'warm_walnut',.035)
    for vv in [v-2.8,v+2.8]:
        box('booth_closed_canopy_end',16.1,vv,3.65,11.3,.20,.56,'warm_walnut',.035)
        # Unbroken floor-level ring routes around cardinal chairs. Transverse low
        # partitions isolated otherwise clear chair stances and were removed after
        # the actual0.30/0.65m source screen. The canopy edge retains closed returns.
    box('service_edge_canopy_screen',10.35,v,2.91,.18,5.1,1.29,'teal_weave',.05)
    # Paired canopy table lamps are genuinely fixed into the common canopy.
    for u in [14.0,19.5]:pendant('booth_'+str(n)+'_'+str(u),u,v,3.555,2.75,165)

# Quiet fore room: low coffered field, sloping ends seated on piers, no extra gallery.
box('quiet_canopy',35.1,16,4.35,17.4,26,.32,'ivory_enamel',.1)
for u in [26.55,43.65]:box('quiet_canopy_edge',u,16,4.20,.32,26,.60,'warm_walnut',.06)
for v in [3.2,10,16,22,28.5]:
    box('quiet_canopy_cross_rib',35.1,v,4.11,17.4,.2,.22,'warm_walnut',.03)
    for u in [26.55,43.65]:box('quiet_canopy_post',u,v,2.0,.27,.32,4.0,'warm_walnut')
# Right outer wall recessed upholstered bays; angled jambs create deliberate depth.
for v in rows:
    box('east_inhabited_niche_back',45.39,v,1.85,.13,4.7,3.4,'teal_weave',.06)
    for vv in [v-2.4,v+2.4]:
        # Rotated member's lower corner must stay above datum; bear on a real plinth.
        box('east_niche_facet_foot',44.7,vv,.065,.48,.42,.13,'warm_stone')
        beam('east_niche_facet',(44.7,vv,.10),(45.3,vv,3.55),.28,.32,'warm_walnut')
    box('east_niche_head',45.0,v,3.63,.65,5.2,.26,'warm_walnut')
# Aft sociable area ceiling stays higher and carries fan-like primary beams.
for v in [36,42,48,54,60]:
    beam('social_ceiling_rib',(26.4,v,6.4),(35,v,6.95),.34,.38,'warm_walnut')
    beam('social_ceiling_rib',(35,v,6.95),(44.5,v,6.4),.34,.38,'warm_walnut')
for v in [39,45,51,57]:box('social_fixture_cross_member',35.45,v,6.43,18.1,.34,.16,'warm_walnut')

#160 usable-place candidates use unchanged approved source components and exact markers.
for ri,v in enumerate(rows):
    for ci,u in enumerate([14.0,19.5,29,35,40.5]):
        tid='T%02d'%(len(tables)+1);obs,dm=instance('AST-DIN-001',tid,u,v)
        tabletop=dm.get('DATUM_table_surface',list(xyz(u,v,.79)))
        tables.append({'id':tid,'uv':[u,v],'tabletop_source':tabletop,'radius_m':.85,'objects':[o.name for o in obs]})
        for du,dv,yaw in [(1.32,0,-90),(-1.32,0,90),(0,1.32,180),(0,-1.32,0)]:
            sid='D10_dessert8-place-%03d'%(len(seats)+1);obs,dm=instance('AST-DIN-002',sid,u+du,v+dv,yaw=yaw)
            contact=dm['DATUM_seat_contact'];floor=dm['DATUM_floor_contact']
            marker(sid,contact,'dining_seat_contact',table_id=tid,source_catalogue_id='AST-DIN-002')
            seats.append({'id':sid,'table_id':tid,'contact_source':contact,'floor_source':floor,'world_contact':world(contact),'chair_center_uv':[u+du,v+dv],'yaw':yaw,'objects':[o.name for o in obs]})
            # Setting rests on actual stone inset top0.787, below ornamental rim0.790.
            pu,pv=u+du/1.32*.48,v+dv/1.32*.48
            obs,_=instance('AST-DIN-006',sid+'_setting',pu,pv,.787-templates['AST-DIN-006']['lo'][2],yaw=yaw)
            settings.append({'id':sid+'_setting','table_id':tid,'uv':[pu,pv],'support_h':.787,'objects':[o.name for o in obs]})
        if ci>=2:pendant('dining_'+tid,u,v,4.19 if ri<4 else 6.35,3.1 if ri<4 else 3.5,200 if ri<4 else 260)

# West support rooms. Internal service passage u6..9; wall has explicit public access apertures.
for va,vb in [(1,27),(31.8,33.5),(38,58),(63,67)]:box('service_public_wall',10.1,(va+vb)/2,1.7,.3,vb-va,3.4,'ivory_enamel')
for v in [32.6,57.6]:box('service_clean_dirty_partition',5.15,v,1.7,9.6,.25,3.4,'ivory_enamel')
for va,vb in [(1,32.4),(32.8,57.4),(57.8,67)]:
    box('service_ceiling',5.15,(va+vb)/2,3.55,9.6,vb-va,.25,'ivory_enamel')
    for v in range(int(va)+3,int(vb),7):pendant('service_'+str(v),6.8,v,3.425,2.8,135)
# Finishing/public counter backed by its own open clean handling zone; two counter units.
for i,u in enumerate([12,14.4,16.8,19.2]):instance('AST-HSP-001','finish_'+str(i),u,30.35,yaw=180)
instance('AST-HSP-002','finish_return',20.8,30.35,yaw=180)
for u in [12,14.4,16.8]:
    cyl('covered_dessert_plinth',u,30.35,1.00,.28,.18,'warm_stone')
    for a in range(5):
        t=math.tau*a/5;cyl('moonfruit_pastry',u+.15*math.cos(t),30.35+.15*math.sin(t),1.13,.065,.075,'clay_weave',12)
for u in [12,16.8,19.2]:pendant('finishing_'+str(u),u,30.35,6.3,3.05,200)
box('finishing_header',15.9,30.35,6.42,11.0,.65,.3,'warm_walnut')
for u in [10.45,21.35]:box('finishing_header_support',u,30.35,3.13,.30,.40,6.26,'warm_walnut')
sign('finishing_sign','MOONFRUIT / FRESHLY FINISHED',15.8,31,2.5,.26)
# Drink point deliberately off spine, fully supported dispenser units.
for i,u in enumerate([30.2,32.6]):
    instance('AST-HSP-001','drink_base_'+str(i),u,30.35,yaw=180)
    instance('AST-HSP-003','drink_station_'+str(i),u,30.35,.90,yaw=180)
    pendant('drink_'+str(i),u,30.35,6.3,3.0,180)
box('drink_header',31.4,30.35,6.42,5.6,.65,.3,'warm_walnut')
for u in [28.65,34.15]:box('drink_support',u,30.35,3.13,.26,.36,6.26,'warm_walnut')
sign('drinks_sign','DRINKS',31.4,31,2.30,.26)
instance('AST-HSP-004','dirty_return',10.3,34.5,yaw=-90)
instance('AST-HSP-005','clean_plate_stock',3.2,28,yaw=90)
instance('AST-HSP-006','used_service_trolley',3.2,38,yaw=90)
instance('AST-HSP-001','washing_bench',2.6,44,yaw=90)
sign('return_sign','USED DISHES',10.5,34.5,2.1,.20,-math.pi/2)
for v in [6,12,18,24,40,47,53,63]:
    box('service_shelf_case',1.6,v,1.3,1.0,3.2,2.6,'ivory_enamel',.055)
    for h in [.35,1.0,1.7,2.4]:
        box('service_reachable_shelf',2.12,v,h,.65,3.0,.08,'warm_walnut')
        for dv in [-1,0,1]:box('service_stock_box',2.2,v+dv,h+.19,.48,.65,.30,'oatmeal_weave',.025)
marker('care_cart_parking',xyz(6.5,64,0),'cart_parking_proposal',clear_uv=[5,62.5,8,65.5])
marker('clean_handoff',xyz(11,30.3,0),'clean_service_approach')
marker('dirty_handoff',xyz(11.6,34.5,0),'dirty_return_approach')
marker('care_access',xyz(10.1,61.5,0),'screened_care_opening',clear_width_m=4.7)
box('care_dogleg_screen',8,60,1.4,1.7,.28,2.8,'warm_walnut',.06)
sign('care_sign','CARE / LOCAL STOCK',9.9,58.8,2.1,.19,-math.pi/2)
# Actual integrated shelf display provides end focus without an invented exterior window.
box('fore_display_back',24,1.05,2.0,6.0,.6,4.0,'warm_walnut',.15)
for h in [1.0,1.9,2.8]:
    box('fore_display_shelf',24,1.6,h,5.2,.75,.10,'champagne_metal')
    for u in [22,23,24,25,26]:
        cyl('moonfruit_display_jar',u,1.65,h+.23,.18,.36,'ivory_enamel',16)
        cyl('moonfruit_display_lid',u,1.65,h+.44,.20,.06,'champagne_metal',16)
sign('fore_identity','MOONFRUIT',24,1.43,3.40,.40)
# Host face is visible on arrival; no extra counted stool.
instance('AST-HSP-001','host_counter',38,65.8,yaw=180)
sign('welcome','MOONFRUIT PARLOR',38,66.7,2.7,.33)
sign('host_capacity','160 DINING PLACES',38,66.7,2.25,.20)
for u in [24,38,44]:
    box('arrival_mounting_member',u,62,6.4,.65,4.5,.3,'warm_walnut')
    pendant('arrival_'+str(u),u,62,6.25,3.2,330)
for v in [7,19,33.5,45,57]:
    box('spine_fixture_backing',24,v,6.4,4,.4,.25,'warm_walnut')
    pendant('spine_'+str(v),24,v,6.27,4.0,430)

sys.path.insert(0,str(P/'source'))
from signage_spec import apply_signage
apply_signage()

marker('origin',(0,0,0),'placement_datum',world_xyz_override=[-31,61,432])
def camera(name,u,v,h,target,lens=24):
    d=bpy.data.cameras.new('WP05_'+name);o=bpy.data.objects.new('WP05_'+name,d);scene.collection.objects.link(o);o.location=xyz(u,v,h)
    o.rotation_euler=(Vector(xyz(*target))-o.location).to_track_quat('-Z','Y').to_euler();d.lens=lens;d.clip_end=220;o['SOURCE_PREVIEW_ONLY']=True;return o
cameras={
 'arrival':camera('arrival',44,62,1.65,(26,55,2),23),
 'activity':camera('activity',27.6,47.4,1.65,(36.4,45,1.6),24),
 'booth':camera('booth',23.5,14.6,1.65,(16,13,1.6),23),
 'quiet':camera('quiet',24,11,1.65,(35,16,1.65),24),
 'service':camera('service',22.7,34,1.65,(12,31,1.6),25),
 'section':camera('section',66,91,58,(23,34,1),34)}
scene.camera=cameras['arrival'];bpy.context.view_layer.update()
# Actual evaluated mesh records; these form the independent QA input.
records=[];dg=bpy.context.evaluated_depsgraph_get()
for o in scene.objects:
    if o.type not in {'MESH','FONT'} or o.get('SOURCE_PREVIEW_ONLY'):continue
    ev=o.evaluated_get(dg);me=ev.to_mesh();pts=[ev.matrix_world@v.co for v in me.vertices]
    if pts:records.append({'id':o.name,'lo':[min(v[j] for v in pts) for j in range(3)],'hi':[max(v[j] for v in pts) for j in range(3)],'instance_id':o.get('instance_id'),'source_catalogue_id':o.get('source_catalogue_id'),'vertex_count':len(me.vertices)})
    ev.to_mesh_clear()
invalid=[r['id'] for r in records if any(r['lo'][j]<[-23,-34,0][j]-.005 or r['hi'][j]>[23,34,7.51][j]+.005 for j in range(3))]
def write(rel,data):(P/rel).write_text(json.dumps(data,indent=2)+'\n')
write('qa/source_geometry.json',{'scope':'evaluated source geometry, not engine acceptance','objects':records,'bounds_violation_ids':invalid,'object_count':len(records),'lights':len(lights)})
write('exports/contact_markers.json',{'package':PK,'programme':'D10_directory_09','alias':'D10_dessert8','frame':'Blender Z-up local centered; glTF mapping(x,z,-y)','placement_world_xyz':[-31,61,432],'markers':markers,'lights':lights,'tables':tables,'seats':seats,'settings':settings,'instances':instances})
write('exports/floor_proposal.json',{'status':'receiver-owned structural floor proposal only','surface_y':61,'polygon_world_xz':[[-54,398],[-8,398],[-8,466],[-54,466]],'floor_mesh_exported':False,'collision_owner':'Higgins_pending','external_receiver':'4m gap UNBUILT parent-owned','material_regions_uv':[{'u':[10.7,21.9],'v':[3,63],'role':'clay_weave'},{'u':[26.5,43.5],'v':[3,29],'role':'teal_weave'},{'u':[26.5,43.5],'v':[34,60],'role':'oatmeal_weave'},{'u':[22,26],'v':[1,67],'role':'warm_walnut'},{'otherwise':'warm_stone'}]})
for im in bpy.data.images:
    if im.source=='FILE' and im.has_data and not im.packed_file:im.pack()
bpy.ops.wm.save_as_mainfile(filepath=str(P/'source/WP05_moonfruit.blend'))
if invalid:raise RuntimeError('Out-of-allocation meshes: '+str(invalid))
# Preserve editable text in native source, triangulate glyphs only for portable exchange.
bpy.ops.object.select_all(action='DESELECT')
for o in list(scene.objects):
    if o.type=='FONT':o.select_set(True);bpy.context.view_layer.objects.active=o;bpy.ops.object.convert(target='MESH');o.select_set(False)
bpy.ops.object.select_all(action='DESELECT')
for o in scene.objects:
    if not o.get('SOURCE_PREVIEW_ONLY'):o.select_set(True)
bpy.ops.export_scene.gltf(filepath=str(P/'exports/WP05_moonfruit.glb'),export_format='GLB',use_selection=True,export_apply=True,export_yup=True,export_extras=True,export_lights=True,export_cameras=False)
write('exports/manifest.json',{'package':PK,'programme':'D10_directory_09','historical_alias':'D10_dessert8','source':'source/WP05_moonfruit.blend','source_sha256':sha(P/'source/WP05_moonfruit.blend'),'glb':'exports/WP05_moonfruit.glb','glb_sha256':sha(P/'exports/WP05_moonfruit.glb'),'generator_sha256':sha(Path(__file__)),'placement_world_xyz':[-31,61,432],'placement_rotation':[0,0,0],'units':'metres','axes':'Blender(x,y,z) -> glTF(x,z,-y)','dining_places':len(seats),'actual_objects':len(records),'floor_exported':False,'dependencies':'dependencies/receipt.json','status':'source/export generated; independent QA/render review pending; not integrated'})
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
if '--render' in args:
    for key in args[args.index('--render')+1:]:
        scene.camera=cameras[key];hidden=[]
        if key=='section':
            for o in scene.objects:
                if any(s in o.name for s in ['opaque_ceiling','canopy','ceiling_rib','roof_cross','east_wall','aft_enclosure','portal_head','pendant','_stem','_shade','spine_haunch']):
                    if not o.hide_render:hidden.append(o);o.hide_render=True
        scene.render.filepath=str(P/'qa'/('SOURCE_ONLY_'+key+'.png'));bpy.ops.render.render(write_still=True)
        for o in hidden:o.hide_render=False
print('WP05_BUILD_EXPORT_OK')
