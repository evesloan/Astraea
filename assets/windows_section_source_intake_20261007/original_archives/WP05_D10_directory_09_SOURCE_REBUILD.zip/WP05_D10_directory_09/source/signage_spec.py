"""Mounted public-side sign specification shared by generator and native review patch."""
import bpy,math
TAG='WP05_SIGNAGE_REVIEW_FIX'
def apply_signage():
    scene=bpy.context.scene
    for o in list(scene.objects):
        if o.get(TAG):bpy.data.objects.remove(o,do_unlink=True)
    def box(name,u,v,h,su,sv,sh,role='warm_walnut'):
        bpy.ops.mesh.primitive_cube_add(size=1,location=(u-23,34-v,h));o=bpy.context.object
        o.name='WP05_SIGN_'+name;o.dimensions=(su,sv,sh);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
        o.data.materials.append(bpy.data.materials['WP05_'+role]);o[TAG]=True;o['package_id']='WP05_D10_directory_09';o['semantic_role']=role
        uv=o.data.uv_layers.new(name='PhysicalScaleUV') if not o.data.uv_layers else o.data.uv_layers.active
        scale=o.data.materials[0].get('meters_per_tile_uv',[1,1])
        for poly in o.data.polygons:
            ax=max(range(3),key=lambda j:abs(poly.normal[j]));ij=[j for j in range(3) if j!=ax]
            for li in poly.loop_indices:
                p=o.data.vertices[o.data.loops[li].vertex_index].co;uv.data[li].uv=(p[ij[0]]/scale[0],p[ij[1]]/scale[1])
        m=o.modifiers.new('Soft sign edge','BEVEL');m.width=.02;m.segments=2;o.modifiers.new('Sign corner normals','WEIGHTED_NORMAL');return o
    def font(name,u,v,h,yaw,size=None):
        o=bpy.data.objects['WP05_'+name];assert o.type=='FONT';o.location=(u-23,34-v,h);o.rotation_euler=(math.pi/2,0,yaw)
        if size:o.data.size=size
        o.data.materials.clear();o.data.materials.append(bpy.data.materials['WP05_ivory_enamel'])
        o['sign_face']='public side';o['mounted_sign_review_revision']='01'
    # Public counter fascias physically bracket to the existing column pair.
    for name,u,width,ends,caption in [('finishing',15.9,10.6,[10.45,21.35],'finishing_sign'),('drinks',31.4,5.3,[28.65,34.15],'drinks_sign')]:
        box(name+'_backboard',u,30.88,2.48,width,.14,.70)
        for eu in ends:box(name+'_column_bracket',eu,30.615,2.48,.32,.67,.18,'champagne_metal')
        font(caption,u,30.965,2.39,0,.24 if name=='finishing' else .26)
    # Return and care labels hang from actual service ceiling, clear of floor routes.
    for name,v,width,caption,size in [('return',34.5,2.2,'return_sign',.20),('care',61.5,2.7,'care_sign',.16)]:
        box(name+'_backboard',10.39,v,2.55,.12,width,.60)
        for vv in [v-width*.34,v+width*.34]:
            box(name+'_ceiling_socket',9.70,vv,3.39,.17,.17,.07,'champagne_metal')
            box(name+'_ceiling_drop',9.70,vv,3.13,.05,.05,.58,'champagne_metal')
            box(name+'_cantilever',10.045,vv,2.855,.74,.05,.055,'champagne_metal')
        font(caption,10.463,v,2.38,math.pi/2,size)
    # Fore identity sits on the display back; the aft host plaque faces arrivals.
    font('fore_identity',24,1.362,3.40,0)
    box('host_backboard',38,67.35,2.65,6.8,.20,.95)
    for u in [35.1,40.9]:box('host_wall_standoff',u,67.49,2.65,.25,.40,.18,'champagne_metal')
    font('welcome',38,67.235,2.70,math.pi)
    font('host_capacity',38,67.235,2.28,math.pi)
    bpy.context.view_layer.update()
