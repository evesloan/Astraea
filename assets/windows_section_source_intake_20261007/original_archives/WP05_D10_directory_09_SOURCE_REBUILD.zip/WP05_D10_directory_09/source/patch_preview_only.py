"""Parent-run only, AFTER existing render job ends. No GLB or architecture mutation.
blender --background source/WP05_moonfruit.blend --python source/patch_preview_only.py
"""
import bpy,json,hashlib
from pathlib import Path
from mathutils import Vector
P=Path(__file__).resolve().parents[1]
source=P/'source/WP05_moonfruit.blend';export=P/'exports/WP05_moonfruit.glb'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
before_source=sha(source);before_export=sha(export)
floor=bpy.data.objects['WP05_SOURCE_PREVIEW_ONLY_floor']
assert floor.get('SOURCE_PREVIEW_ONLY') is True
assert abs(floor.dimensions.z-.24)<.001
floor.location.z=-.13 # actual base top-.01, inlay top0; remove coplanar overlap
camera=bpy.data.objects['WP05_activity'];assert camera.type=='CAMERA'
assert camera.get('SOURCE_PREVIEW_ONLY') is True
camera.location=(4.6,-13.4,1.65)
camera.rotation_euler=(Vector((13.4,-11,1.6))-camera.location).to_track_quat('-Z','Y').to_euler()
bpy.context.view_layer.update()
bpy.ops.wm.save_as_mainfile(filepath=str(source))
assert sha(export)==before_export,'Unexpected export mutation'
manifest_path=P/'exports/manifest.json';manifest=json.loads(manifest_path.read_text())
manifest['source_sha256']=sha(source)
manifest['generator_sha256']=sha(P/'source/build_moonfruit.py')
manifest['preview_only_patch']='preview-base-top-minus0.01_activity-camera-offset01'
manifest['glb_unchanged_after_preview_patch']=before_export
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
(P/'qa/preview_patch.json').write_text(json.dumps({
 'scope':'SOURCE_PREVIEW_ONLY base floor and activity camera only; architecture GLB unchanged',
 'source_before_sha256':before_source,'source_after_sha256':sha(source),'export_sha256_unchanged':before_export,
 'base_floor_top_z':-.01,'inlay_top_z':0,'activity_camera_xyz':[4.6,-13.4,1.65],
 'live_scene_modified':False,'review':'fresh source renders required; geometry source QA remains scoped to unchanged delivered meshes'},indent=2)+'\n')
print('WP05_PREVIEW_ONLY_PATCH_OK')
