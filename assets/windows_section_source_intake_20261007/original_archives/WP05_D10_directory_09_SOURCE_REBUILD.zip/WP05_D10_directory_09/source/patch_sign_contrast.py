"""Authorized lettering material-only correction; no lighting or layout change."""
import bpy,json,hashlib
from pathlib import Path
P=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
source=P/'source/WP05_moonfruit.blend';export=P/'exports/WP05_moonfruit.glb'
before={'source':sha(source),'export':sha(export)}
names=['finishing_sign','drinks_sign','return_sign','care_sign','fore_identity','welcome','host_capacity']
for name in names:
    o=bpy.data.objects['WP05_'+name];assert o.type=='FONT'
    o.data.materials.clear();o.data.materials.append(bpy.data.materials['WP05_ivory_enamel'])
    o['sign_text_material_review']='approved ivory enamel for contrast'
bpy.context.view_layer.update();scene=bpy.context.scene;dg=bpy.context.evaluated_depsgraph_get()
geometry=json.loads((P/'qa/source_geometry.json').read_text());previous={r['id']:r for r in geometry['objects']};changes=[]
for o in scene.objects:
    if o.type not in {'MESH','FONT'} or o.get('SOURCE_PREVIEW_ONLY'):continue
    ev=o.evaluated_get(dg);me=ev.to_mesh();pts=[ev.matrix_world@v.co for v in me.vertices]
    if pts:
        lo=[min(v[j] for v in pts) for j in range(3)];hi=[max(v[j] for v in pts) for j in range(3)];old=previous[o.name]
        if max(abs(lo[j]-old['lo'][j]) for j in range(3))>1e-6 or max(abs(hi[j]-old['hi'][j]) for j in range(3))>1e-6 or len(me.vertices)!=old['vertex_count']:changes.append(o.name)
    ev.to_mesh_clear()
assert not changes,changes
bpy.ops.wm.save_as_mainfile(filepath=str(source))
bpy.ops.object.select_all(action='DESELECT')
for o in list(scene.objects):
    if o.type=='FONT':o.select_set(True);bpy.context.view_layer.objects.active=o;bpy.ops.object.convert(target='MESH');o.select_set(False)
bpy.ops.object.select_all(action='DESELECT')
for o in scene.objects:
    if not o.get('SOURCE_PREVIEW_ONLY'):o.select_set(True)
bpy.ops.export_scene.gltf(filepath=str(export),export_format='GLB',use_selection=True,export_apply=True,export_yup=True,export_extras=True,export_lights=True,export_cameras=False)
mp=P/'exports/manifest.json';manifest=json.loads(mp.read_text());manifest.update({'source_sha256':sha(source),'glb_sha256':sha(export),'generator_sha256':sha(P/'source/build_moonfruit.py'),'signage_spec_sha256':sha(P/'source/signage_spec.py'),'lettering_revision':'ivory-contrast01','status':'material-only sign contrast correction; fresh source/export checks and service image review pending'});mp.write_text(json.dumps(manifest,indent=2)+'\n')
(P/'qa/sign_contrast_patch.json').write_text(json.dumps({'scope':'Seven text material slots changed from champagne metal to approved ivory enamel; backboards/mounts, transforms, light output and layout unchanged','before':before,'after':{'source':sha(source),'export':sha(export)},'source_geometry_changed':changes,'changed_text_objects':['WP05_'+n for n in names],'image_retention':'Previous arrival/activity/booth/quiet images retain architectural evidence; sign-letter material in those views predates this correction. Fresh service image required.'},indent=2)+'\n')
print('WP05_SIGN_CONTRAST_PATCH_OK')
