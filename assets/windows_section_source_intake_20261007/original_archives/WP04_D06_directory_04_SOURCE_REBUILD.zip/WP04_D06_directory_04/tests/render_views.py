"""Parent-scheduled source-only image evidence. -- <camera> [samples]"""
from pathlib import Path
import bpy,sys,json,hashlib
P=Path(__file__).resolve().parents[1]
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else ['arrival']
name=args[0];samples=int(args[1]) if len(args)>1 else 24
src=P/'source/WP04_botanical_nursery.blend'
bpy.ops.wm.open_mainfile(filepath=str(src));sc=bpy.context.scene
sc.camera=bpy.data.objects['SOURCE_ONLY_'+name]
sc.render.engine='CYCLES';sc.cycles.samples=samples
sc.render.image_settings.file_format='PNG';sc.render.filepath=str(P/'tests/views'/f'SOURCE_ONLY_{name}.png')
sc.render.use_stamp=True;sc.render.use_stamp_note=True;sc.render.stamp_note_text='SOURCE ONLY | WP04 Botanical nursery | no live ship adoption';sc.render.stamp_font_size=14
if name=='section':
    for o in sc.objects:
        if o.name.startswith(('Protected_opaque_overhead_enclosure','Barrel_soffit_','Work_ceiling_panel','Service_ceiling_panel','Opaque_end_-249.8')):o.hide_render=True
bpy.ops.render.render(write_still=True)
receipt={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'camera':name,'image':Path(sc.render.filepath).name,'engine':sc.render.engine,'samples':samples,'eye_height_m':1.65 if name!='section' else None,'section_visibility_override':name=='section','status':'rendered, independent pixel review pending','png_sha256':hashlib.sha256(Path(sc.render.filepath).read_bytes()).hexdigest()}
(P/'tests/views'/f'{name}_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
