"""Scheduled Blender QA. Reloads source, then native GLB into a fresh scene."""
from pathlib import Path
import bpy,json,math,hashlib
from mathutils import Vector
P=Path(__file__).resolve().parents[1]
manifest=json.loads((P/'manifest.json').read_text())
blend=P/'source/WP04_botanical_nursery.blend';glb=P/'exports/WP04_botanical_nursery.glb'
assert hashlib.sha256(blend.read_bytes()).hexdigest()==manifest['source_sha256']
assert hashlib.sha256(glb.read_bytes()).hexdigest()==manifest['glb_sha256']
bpy.ops.wm.open_mainfile(filepath=str(blend))
assert 'SOURCE_PREVIEW_ONLY_floor' in bpy.data.objects
assert bpy.data.objects['SOURCE_PREVIEW_ONLY_floor'].get('export_excluded')
images=[i for i in bpy.data.images if i.source=='FILE' and i.has_data]
assert all(i.packed_file for i in images),'unpacked texture dependency'
lights=[o for o in bpy.data.objects if o.type=='LIGHT'];assert len(lights)>=20
source_mesh_count=sum(o.type=='MESH' for o in bpy.data.objects)
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=str(glb))
assert not any('SOURCE_PREVIEW_ONLY' in o.name for o in bpy.data.objects)
assert not any('TEMPLATE_' in o.name for o in bpy.data.objects)
errors=[];points=[];meshcount=0
bpy.context.view_layer.update()
for o in bpy.data.objects:
    if o.type!='MESH':continue
    meshcount+=1
    # Blender reimports native glTF Y-up into source Z-up. Verify actual positions after import.
    for v in o.data.vertices:
        p=o.matrix_world@v.co
        if not all(math.isfinite(q) for q in p):errors.append(o.name+' nonfinite')
        points.append(p)
lo=[min(p[i] for p in points) for i in range(3)];hi=[max(p[i] for p in points) for i in range(3)]
assert lo[0]>=-.003 and hi[0]<=46.003 and lo[1]>=-34.003 and hi[1]<=34.003 and lo[2]>=-.003 and hi[2]<=7.8,(lo,hi)
assert not errors,errors[:10]
result={'scope':'reopened editable source and Blender import of actual exported GLB; not Godot','status':'pass','source_sha256':manifest['source_sha256'],'glb_sha256':manifest['glb_sha256'],'packed_source_images':len(images),'source_mesh_count':source_mesh_count,'actual_imported_mesh_count':meshcount,'native_roundtrip_bounds_source_basis':[lo,hi],'preview_floor_absent_from_glb':True,'source_effective_lights':len(lights),'limitations':['No floor or receiving link adopted','Source lights require receiver adaptation','Actor/cart sweeps and engine collisions remain pending']}
(P/'tests/reload_export_receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print('WP04_RELOAD_EXPORT_PASS')
