# First source review corrections

Six actual r01 views inspected: arrival, observation, propagation, service, potting and ceiling mount. Parent source/native/export checks passed containment, but source visual review failed: frosted interior panes defeated the nursery's observed activity; high exposure/light finishes erased hierarchy; the public edge was too empty; the potting bench had no tools/stock; pale labels were unbacked or unreadable.

The generator now uses **open framed interior observation bays**. The low solid planted-edge divider and actual structural frames remain. No glass or environmental separation is claimed. This is a deliberate revision to the initial glazing proposal, and cannot be represented as a sealed conservatory environment.

Local textured sage work enamel, darker timber roof and shelf surfaces, muted stone and a darker source-preview floor restore the visual hierarchy. Original source texture pixels and shared materials remain unchanged. Exposure reduces from +0.5 to −0.65; fixture power to 70%, with emission reduced. Actual area emitters remain on modeled mounting stems. Both runtime material interpretation and effective light adaptation still require receiving review.

The resting edge gains additional catalogue planted-seat modules, floor-supported tendable plant vessels and interpretation stands placed wholly outside the X18…23 clear public band. Interpretation text and store/bay signage have physical dark backboards, columns or wall fixings. Work stations gain trays, spare pots, lower stock, station labels, and a real potting-tool board with mounted implements. Propagation seats and planters retain native-source provenance.

Source scripts compile. These corrections have **not yet been rebuilt or rendered**; r01 source/export/views are retained under tests/revision01_before_visual_corrections. No visual pass is claimed. Parent should rebuild, run the source reload/export check, then re-render ordinary views, including service/potting and the unchanged-supported ceiling.
