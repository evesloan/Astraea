# WP04 — Botanical nursery

Planning candidate for Higgins, 6 October 2026. Programme **D06_directory_04**, no historical alias. Dedicated section owner: section_owner_04. Final construction namespace is `external_packages/windows/WP04_D06_directory_04/`; this preliminary record remains in the coordinator's isolated planning folder.

**Stage: document/reference review and proposed dimensioned plan/section completed for coordinator review. Geometry/export held.** Higgins's current handoff supplies the allocation and portal; its current row/reference/component hash receipt is still pending verification. No Blender, runtime, registry, shared material, source family, floor compiler, external link or backup publisher has been modified.

## Governing evidence and precise scope

- `Game/docs/master_source/MASTER_FULL_CONTENT_INDEX.json`: complete chapters 4, 5, 7, 8, 21, 30 and 32 read; retained in `reviewed_master_chapters.json`. Relevant exact body blocks: 123 (datums), 133–145 (spatial hierarchy and tested routes), 165–173 (service and care), 177–188 (species limits), 365–380 (form, planting, light, materials), 518/540/541 (reference interpretation), 556–571 (boundaries, modular craft and evidence).
- `MASTER_CURRENT_APPLICATION.json`: all current overrides read. Later admission/accommodation decisions override old exact-bed statements; historical implementation claims do not prove current operation. Current species are Koblins, Mantelids, Humans, Baelins, Munkos and Mindos; no plant biology, body dimensions, guest capacity, synthetic charging or new environment mechanics are invented here.
- `FULL_SHIP_SCOPE_INDEX.md`, `ARCHITECTURAL_DELIVERY_RULES.md`, `WHOLE_SHIP_SECTION_COORDINATION.md`, `BLUEPRINT_AMENITY_SCOPE_AUDIT.md` AME-006 and its JSON row reviewed. AME-006 establishes the plant nursery parent programme; it does not establish a cubicle or plant count.
- Higgins's `HIGGINS_CURRENT_HANDOFF.txt`, original WP05 nursery row, adds explicit programme content: planted observation edge, propagation benches/trays, potting/work bay, soil/tool store, cleaning point, screened service returns. The coordinator relayed Higgins revision 2 renumbering this section to final **WP04**; programme identity and assignment are unchanged. Those functions are required by the current assigned scope. Their dimensions and subdivision in this package remain proposed. It is neither childcare nor D09 Living Gifts.
- `BlenderCatalogue/standards/COORDINATE_CONTRACT.md` read. All numbers below are **Godot world metres**. Eventual source mapping is Blender `(x,y,z)` to GLB `(x,z,-y)` with a declared global placement transform and actual-node verification, not a second transform applied blindly.
- `source_evidence.json` is the retained local snapshot, with hashes, exact ledger/audit entries and reservations; it is not a current-build certification. `reviewed_input_hashes.json` similarly identifies locally inspected bytes, not Higgins source-manifest verification.

## Fixed allocation and receiving boundary

| Item | Record |
|---|---|
| Allocation | X **8…54**, Z **−250…−182**, 46 × 68 m, 3,128 m² gross allocation |
| Floor datum | D06 **Y27** |
| Next datum | D07 **Y35.5**, difference **8.5 m**, not a certified clear height |
| Below | D05_directory_04, Pharmacy stores, Y21, same allocation |
| Above | D07_directory_04, Sports viewing, Y35.5, same allocation |
| Across public axis | D06_directory_03, Moss sanctuary, X−54…−8, Z−250…−182; separate destination, no shared nursery wall |
| Public portal | Higgins-proposed centre **[8,27,−216]**, outward normal −X |
| Existing circulation | D06_fore_route, X−4…4, Z−530…−80, floor Y27 |
| Receiving gap | **X4…8: 4 m UNBUILT, HELD, parent-owned.** Width is not granted. Worker does not bridge it. |
| Exterior views | Internal allocation. No hull window, skylight, false sky surface, deck cut, or fabricated view through neighbouring programmes. |

Higgins reports a current triangle check with zero positive-area installed-floor overlap in this allocation. That does not grant slab thickness or collision ownership. This package's entire floor remains a candidate pending his explicit assignment. The current handoff does not identify immediate exterior neighbours along the north/south/starboard allocation faces: preserve opaque enclosure there and do not treat apparent empty plan space as available territory.

## Proposed plan: a working nursery that can be observed

`plan_contract.json` contains machine-readable bounds and `PLAN_SECTION.svg` presents the plan and section together. Its rectangles are functional reservations, not the finished wall shape or net-floor accounting. Wall offsets, supports, opening clearances and bench modules must be resolved inside those reservations after current inputs are verified.

The nursery has a quieter public planted edge facing real propagation work. The arrival is aligned to the actual proposed portal, but its deep reveal and a broad inward-facing planted recess prevent the full 68 m room from reading as a single blank hall. Two propagation volumes flank a central tending focus. A separate screened spine connects potting, supplies, cleaning and returns. Different ceiling heights express observation and work rather than repeating the conservatory design.

| Functional reservation | Proposed world bounds | Architectural purpose |
|---|---|---|
| Nested arrival | X8…20, Z−222…−210, 12 × 12 m | Clear turning, readable onward route, framed view of supported work benches |
| Public observation / rest | X10…23, Z−246…−186, 13 × 60 m | Continuous clear spine X18…23; supported seats and tended planted pockets X10…17, interrupted around arrival |
| Propagation A | X25…42, Z−246…−226, 17 × 20 m | Bench/tray rhythm and actual tending approach, differing planting height |
| Central visible tending | X25…42, Z−222…−210, 17 × 12 m | Work as the focal activity; equipment and substrate belong on supported surfaces |
| Propagation B | X25…42, Z−206…−186, 17 × 20 m | Complementary nursery scale and useful access, not a second decorative tree hall |
| Screened staff spine | X43…47, Z−246…−186, nominal 4 m | Continuous stock/return route with parking kept outside passage |
| Soil/tool store | X47…53, Z−246…−232, 6 × 14 m | Usable shelving and floor-supported carts/material staging |
| Potting/work | X47…53, Z−228…−216, 6 × 12 m | Physical bench, source-backed task lights and useful work stance |
| Cleaning point | X47…53, Z−212…−200, 6 × 12 m | Enclosed care stock, shelf depth, task light and parking bay |
| Returns/staging | X47…53, Z−196…−186, 6 × 10 m | Screened route and sealed future-service marker |

Two nominal 4 m staff cross-aisles occupy Z−226…−222 and −210…−206, X23…47. The central work threshold is proposed at [23,27,−216], nominal 4 m wide; it is controlled staff access, not an invitation for every visitor to enter storage. Public visitors can see real tending/propagation volumes through framed interior glazing; opaque cupboards and baffle returns prevent an entry sightline into service returns. Glazing has thickness, frames and visible presence.

Opening dimensions are proposals: 6 m clear public width and 4.2 m clear height, inside a 12 × 12 m arrival. These are not cart or species acceptance. No admission or plant count is asserted. Actual bench quantities follow usable spans, reachable worktops and later reviewed component dimensions; signs must not invent a capacity. Workbench proposals use 0.75 m reach depth where single-sided and 1.5 m only where both sides remain accessible; around 0.9 m top height is a provisional human-reference work surface, not universal-species fit. Keep accessible alternate-height work positions unresolved until actual supported users/poses are checked.

## Proposed section and construction detail

Keep one floor at Y27 with no steps in the principal public or staff routes. No mezzanine or inter-deck opening is included. Floor slab underside is deliberately unset pending Higgins's floor/structural ownership instruction.

The public observation soffit rises from Y32.6 at its edges to Y33.8 locally; the lower work volumes have underside Y31.6…32.2. Package geometry has a proposed maximum top at Y34.8, leaving 0.7 m to D07's datum. These are design reservations, not knowledge of the actual D07 slab underside or proof of loads. Revise downward if current interface data requires it.

Use a legible family of eased piers, beams and short faceted/curved soffit segments. Every curved timber segment terminates in a beam pocket or closed reveal with a modeled end piece. Avoid a continuous curved strip running through a pier, an unsupported edge, or a cap that crosses the neighbouring deck. Proposed piers at the public/work/service division must sit outside clear route bands; the section SVG is diagrammatic, not exact pier placement.

Work luminaires are proposed down to Y30.8, with real mounting plates and rigid stems from actual utility beams. Mount the public fixtures to the corresponding pier/reveal family. First-pass delivery includes effective illumination, visible fixture construction and purposeful textured materials; emission alone is insufficient. Final source previews must expose at least one soffit termination and fixture-to-beam join from ordinary approach height.

Planting uses groundcover, shrubs, and small canopy specimens, maximum proposed height 4 m above the nursery floor. Roots meet actual soil/tray surfaces; stem support is continuous. Keep leaf masses out of paths and essential internal view cones. Do not scale a hero tree into the allocation or bury trays inside decorative foliage. Plant handling/irrigation biology and structural loading are not certified.

## Reference pixels inspected at original size

1. **REF-f84205f20a** — `BlenderCatalogue/references/botanical/atrium_reference.png` (1448 × 1086). Observed branching crowns, varied canopy/shrub/low planting, substantial planter edges, purposeful pause spaces and gaps through vegetation. Application: three planting scales, tended and reachable display edges, framed views into real propagation bays. Reject the giant central tree, multilevel void, roof and water as allocation authority.
2. **REF-48cca6e8b3** — `BlenderCatalogue/references/salon/vibe_vertical_atrium.jpg` (1200 × 676). Observed piers visibly carrying layered overhead construction and local seating within wider circulation. Application: clear pier/beam/soffit hierarchy and rest pockets; no copied ornament, chandelier, branded forms or extra floor.
3. **Owner retro benchmark** — `Game/docs/references/cruise_atrium_20261006/retro_atrium_quality_benchmark.png` (1672 × 941). Observed thick cream/warm-metal architecture, deep planted edges, low-resolution legible silhouettes and locally integrated warm light. Application: grounded, modeled transitions and material hierarchy; full chandelier complexity, shops, crowd counts and roof openings do not become requirements.
4. **Retained D06 plan** — `Game/docs/whole_ship_plans/D06.png` (1440 × 650). The nursery sits off the fore axis, separated from the central void and its neighbours. Used for orientation only. This generated retained plan is not Higgins's current compiled-floor proof or the historical atlas page 8.
5. **REF-1d51d4a06e** — `BlenderCatalogue/references/hospitality/public_reference.png` (1491 × 1055). Observed separated public and service flows and differentiated programme support. Printed labels/elevations and counts conflict with canonical text; no numeric nursery requirements inferred from it.

Higgins also names the historical atlas page 8/directory 04/drawing 49 and overview image O as required current packet inputs. Those exact receipt-bound inputs have **not** been supplied to this worker yet. The generated D06 plan is explicitly not a substitute. Obtain, hash-verify and inspect them before geometry release.

## Component and material reuse

Higgins permitted candidates: AST-BOT-002/003/004/006/009, AST-HSP-001, AST-STF-007/006, AST-LGT-001. Use these only after source identity/version verification; preserve originals and copy derivatives into the final isolated package. No new AST identity is allocated. AST-HSP-001 must be inspected for actual workbench suitability rather than assuming a hospitality component is automatically a potting fixture.

Read botanical cluster and planted-seat transition documentation and the current local botanical material manifest. AST-BOT-009 has actual root collars; it must be placed by soil datum, not visual bounding box. Existing botanical roles use opaque original textures, metric bark/soil UV scales and appropriate two-sided leaf roles; reuse these semantics. AST-BOT-007/008/010 were reviewed as useful construction lessons but are not added to Higgins's nursery reuse allowance here.

Use coherent warm guest-facing enclosure and planted seats with muted trim; work/store surfaces and service lights remain practical SunCorp architecture. First pass requires meaningful low-resolution materials, real work fixtures, planting, signs and mounted effective light, in addition to the complete architectural enclosure. Final CRT/lighting approval remains Higgins's in-engine gate.

## Release questions, verification and handoff

Before geometry: verify current row/reference/component input hashes; review this plan; obtain floor thickness/collision assignment; settle portal width and protected ceiling underside; confirm the sealed service marker and final namespace. Parent public receiving link is an external blocker for live connected-route acceptance, not permission to extend this package.

Planned source checks: transformed bounds within allocation; no deck penetration; floor ownership; complete support chains; fixture mounts; usable shelf/bench reach; actual loaded-cart sweeps including corners and parked stock; internal opening/leaf envelopes; non-overlapping floor slabs; roots/trays/soil placement; interior public-to-service sightlines; per-reference ordinary-height views. All current widths remain geometric proposals until these checks exist.

Required source views: portal approach at [12,28.6,−216] toward the work focus; planted observation at [20,28.6,−236]; reverse threshold; service spine at [45,28.6,−234]; potting bench and mounted luminaire detail; longitudinal and transverse cutaways. Review standing and supported seated sightlines after current asset dimensions are known. Every source preview is labeled SOURCE ONLY.

Scoped planning checks currently pass: ten functional reservations lie within the allocation and proposed package top Y34.8 is below the next datum Y35.5. These are arithmetic planning checks only. No geometry, exported assets, rendered construction, live integration, operational doors, staff network, plant simulation, hardware performance or traversal is claimed. I remain the dedicated nursery section owner for construction after the coordinator releases current inputs.
