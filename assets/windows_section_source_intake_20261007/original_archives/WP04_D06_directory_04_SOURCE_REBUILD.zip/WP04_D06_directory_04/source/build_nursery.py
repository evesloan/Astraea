"""Portable WP04 whole-section source candidate. Blender 4.3.2 only.
Run --background --threads 2 --python-exit-code 1 --python source/build_nursery.py
No runtime imports, global registry edits, network reads or external source reads.
"""
from pathlib import Path
import bpy, math, json, hashlib, argparse, sys
from mathutils import Vector,Matrix

P=Path(__file__).resolve().parents[1]
assert bpy.app.version[:2]==(4,3),bpy.app.version_string
for d in ['exports','tests/views']: (P/d).mkdir(parents=True,exist_ok=True)
for record in json.loads((P/'assets/intake_manifest.json').read_text())['files']:
    # Full intake also hashes archival references and historical planning records.
    # Compact reconstruction omits those non-build documents; validate every actual build input.
    if not record['file'].startswith('assets/'):continue
    assert hashlib.sha256((P/record['file']).read_bytes()).hexdigest()==record['sha256'],record['file']
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
sc=bpy.context.scene
sc.unit_settings.system='METRIC';sc.unit_settings.scale_length=1
sc.render.engine='CYCLES';sc.cycles.samples=24;sc.cycles.use_denoising=True
sc.render.resolution_x=1280;sc.render.resolution_y=720;sc.render.resolution_percentage=100
sc.world.color=(0.01,0.01,0.01)
sc.view_settings.view_transform='AgX'
sc.view_settings.exposure=-0.65
EXPORT=[]; CONTACTS=[]; COLLISIONS=[]; FIXTURES=[]; REUSE=[]; COUNTS={}

def xyz(x,z,h): return Vector((x-8,-(z+216),h))
def tag(o,role='architecture',collision=False):
    o['package']='WP04_D06_directory_04';o['role']=role;EXPORT.append(o)
    if collision and o.type=='MESH': COLLISIONS.append(o.name)
    return o

M={}
spec=json.loads((P/'assets/materials/material_manifest.json').read_text())['materials']
spec.update(json.loads((P/'assets/materials/botanical/manifest.json').read_text())['materials'])
for role,s in spec.items():
    mat=bpy.data.materials.new('WP04_'+role);mat.use_nodes=True
    bs=mat.node_tree.nodes.get('Principled BSDF');bs.inputs['Roughness'].default_value=s['roughness'];bs.inputs['Metallic'].default_value=s['metallic']
    f=P/'assets/materials'/('botanical' if role.startswith('botanical_') else '')/s.get('base_color_file',s.get('file',''))
    im=bpy.data.images.load(str(f),check_existing=True);im.pack()
    tx=mat.node_tree.nodes.new('ShaderNodeTexImage');tx.image=im;tx.interpolation='Closest'
    mat.node_tree.links.new(tx.outputs['Color'],bs.inputs['Base Color']);M[role]=mat
def tint_material(new,base,color):
    m=M[base].copy();m.name='WP04_'+new
    bs=m.node_tree.nodes.get('Principled BSDF');old=bs.inputs['Base Color'].links[0].from_socket
    node=m.node_tree.nodes.new('ShaderNodeMixRGB');node.blend_type='MULTIPLY';node.inputs[0].default_value=1;node.inputs[2].default_value=(*color,1)
    m.node_tree.links.new(old,node.inputs[1]);m.node_tree.links.new(node.outputs[0],bs.inputs['Base Color']);M[new]=m
# Package-local finish variants preserve source texture pixels and semantic material provenance.
tint_material('sage_work_enamel','ivory_enamel',(.40,.58,.47))
tint_material('moss_dado','ivory_enamel',(.16,.28,.22))
tint_material('muted_stone','warm_stone',(.63,.66,.59))
tint_material('slate_floor','warm_stone',(.35,.40,.36))
tint_material('dark_walnut','warm_walnut',(.46,.48,.45))
def plain(name,color,metal=0,rough=.7,emission=0):
    m=bpy.data.materials.new('WP04_'+name);m.use_nodes=True;n=m.node_tree.nodes.get('Principled BSDF')
    n.inputs['Base Color'].default_value=(*color,1);n.inputs['Metallic'].default_value=metal;n.inputs['Roughness'].default_value=rough
    if emission:n.inputs['Emission Color'].default_value=(*color,1);n.inputs['Emission Strength'].default_value=emission
    M[name]=m;return m
plain('grow_emitter',(.86,.95,1),emission=3)
plain('warm_emitter',(1,.70,.30),emission=3)
plain('label',(0.83,.80,.64));plain('dark_hardware',(.08,.13,.12),.5)
glass=plain('interior_glass',(.60,.75,.68),rough=.15)
glass.node_tree.nodes.get('Principled BSDF').inputs['Transmission Weight'].default_value=.85
glass.node_tree.nodes.get('Principled BSDF').inputs['IOR'].default_value=1.45

def uv(o):
    if o.type!='MESH':return
    layer=o.data.uv_layers.new(name='UVMap') if not o.data.uv_layers else o.data.uv_layers.active
    for face in o.data.polygons:
        axes=sorted(range(3),key=lambda i:abs(face.normal[i]))[:2]
        for li in face.loop_indices:
            v=o.data.vertices[o.data.loops[li].vertex_index].co
            layer.data[li].uv=(v[axes[0]],v[axes[1]])
def box(name,x,z,h,w,d,t,mat,role='architecture',coll=True,bevel=.025):
    bpy.ops.mesh.primitive_cube_add(size=1,location=xyz(x,z,h));o=bpy.context.object;o.name=name;o.dimensions=(w,d,t)
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    o.data.materials.append(M[mat]);uv(o)
    if bevel:
        q=o.modifiers.new('Crafted eased edges','BEVEL');q.width=min(bevel,min(w,d,t)/5);q.segments=2
        q=o.modifiers.new('Weighted corner normals','WEIGHTED_NORMAL')
    tag(o,role,coll);return o
def rod(name,a,b,r,mat,vertices=10,coll=False):
    a,b=Vector(a),Vector(b);v=b-a
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=r,depth=v.length,location=(a+b)/2)
    o=bpy.context.object;o.name=name;o.rotation_euler=v.to_track_quat('Z','Y').to_euler();o.data.materials.append(M[mat]);uv(o);tag(o,'support' if coll else 'detail',coll);return o
def marker(name,x,z,h,kind):
    o=bpy.data.objects.new(name,None);sc.collection.objects.link(o);o.location=xyz(x,z,h);o['marker_kind']=kind;tag(o,'marker');CONTACTS.append({'name':name,'world':[x,27+h,z],'kind':kind});return o
def label(name,text,x,z,h,size=.25):
    c=bpy.data.curves.new(name,'FONT');c.body=text;c.size=size;c.extrude=.006;c.align_x='CENTER'
    o=bpy.data.objects.new(name,c);sc.collection.objects.link(o);o.location=xyz(x,z,h);o.rotation_euler=(math.pi/2,0,-math.pi/2);o.data.materials.append(M['label'])
    bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.convert(target='MESH');o.select_set(False);tag(o,'sign');return o
def signboard(name,text,x,z,h,width=2.8,size=.22):
    # West-facing text and its board are a real, mechanically mounted assembly.
    box(name+'_backing',x,z,h,.14,width,.66,'moss_dado')
    label(name+'_letters',text,x-.079,z,h-.08,size)
    for zz in [z-width/2+.13,z+width/2-.13]:rod(name+'_fixing',xyz(x-.085,zz,h+.2),xyz(x+.1,zz,h+.2),.035,'champagne_metal')

# Reuse bundled native meshes, retaining their exact immutable .blend as editable dependencies.
TEMPLATES={}
def template(ident):
    if ident in TEMPLATES:return TEMPLATES[ident]
    with bpy.data.libraries.load(str(P/'assets/native'/f'{ident}.blend'),link=False) as (src,dst): dst.objects=src.objects
    loaded=[o for o in dst.objects if o]
    for o in loaded:sc.collection.objects.link(o)
    bpy.context.view_layer.update()
    obs=[o for o in loaded if o.type=='MESH' and not o.name.startswith('EXPORT_')]
    transforms={o.name:o.matrix_world.copy() for o in obs}
    for o in obs:
        o.parent=None;o.matrix_world=transforms[o.name]
    for o in loaded:
        if o not in obs:bpy.data.objects.remove(o,do_unlink=True)
    bpy.ops.object.select_all(action='DESELECT')
    for o in obs:o.select_set(True)
    if not obs:raise RuntimeError('No native meshes '+ident)
    bpy.context.view_layer.objects.active=obs[0]
    bpy.ops.object.convert(target='MESH');bpy.ops.object.join();o=bpy.context.object
    # Bake original source transforms into vertices, preserving soil/floor datum.
    o.data.transform(o.matrix_world);o.matrix_world=Matrix.Identity(4)
    o.name='TEMPLATE_'+ident;o.hide_render=True;o.hide_set(True)
    TEMPLATES[ident]=o;return o
def reuse(ident,name,x,z,h=0,yaw=0,scale=1):
    src=template(ident);o=src.copy();o.data=src.data;sc.collection.objects.link(o);o.name=name;o.hide_render=False;o.hide_set(False)
    o.matrix_world=Matrix.Translation(xyz(x,z,h)) @ Matrix.Rotation(yaw,4,'Z') @ Matrix.Diagonal((scale,scale,scale,1))
    o['parent_catalogue_id']=ident;tag(o,'reused_component');REUSE.append({'object':name,'source_id':ident,'uniform_scale':scale,'world_datum':[x,27+h,z]});return o

# Source preview support only, never exported as adopted floor.
floor=box('SOURCE_PREVIEW_ONLY_floor',31,-216,-.12,46,68,.24,'slate_floor','SOURCE_PREVIEW_ONLY',False,0)
EXPORT.remove(floor);floor['export_excluded']=True
marker('WP04_floor_datum',8,-216,0,'candidate floor support datum')
marker('WP04_public_portal',8,-216,0,'proposed opening centre; parent receiver remains unbuilt')

# Opaque enclosure and deep entry. Boundaries never extend outside the reservation.
for z in [-249.8,-182.2]:box('Opaque_end_'+str(z),31,z,3.85,46,.4,7.7,'sage_work_enamel')
box('Opaque_starboard_boundary',53.8,-216,3.85,.4,67.2,7.7,'ivory_enamel')
for z,d in [(-235,29.6),(-197,29.6)]:box('Inward_boundary_'+str(z),8.2,z,3.85,.4,d,7.7,'ivory_enamel')
box('Protected_opaque_overhead_enclosure',31,-216,7.7,46,68,.15,'ivory_enamel')
box('Entrance_lintel',8.35,-216,5.8,.7,8.4,3.2,'warm_stone')
for z in [-220.2,-211.8]:
    box('Deep_portal_jamb_'+str(z),10,z,2.5,4,.55,5,'warm_stone')
    box('Portal_reveal_metal_'+str(z),10,z+(.3 if z<-216 else -.3),2.4,3.9,.12,4.8,'champagne_metal',coll=False)
box('Deep_entry_coffer',10,-216,4.95,4,8.4,.3,'warm_walnut')
signboard('Nursery_entry_sign','BOTANICAL NURSERY',8.55,-216,4.6,7.0,.40)

# Faceted barrel roof over public garden edge. Coherent closed segments bear on paired piers/ribs.
def arch_segment(name,z0,z1,thick=.22,mat='warm_walnut'):
    pts=[(8.5+i*15/12,5.6+1.5*math.sin(math.pi*i/12)) for i in range(13)]
    verts=[]
    for z in [z0,z1]:
        for x,h in pts:verts.extend([tuple(xyz(x,z,h)),tuple(xyz(x,z,h+thick))])
    n=26;faces=[]
    for i in range(12):
        a=2*i;b=a+2
        faces.extend([(a,b,b+n,a+n),(a+1,a+n+1,b+n+1,b+1),(a,a+1,b+1,b),(a+n,b+n,b+n+1,a+n+1)])
    faces.extend([(0,n,n+1,1),(24,25,51,50)])
    me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new(name,me);sc.collection.objects.link(o);me.materials.append(M[mat]);uv(o);tag(o,'supported_soffit',True)
for z0,z1 in [(-249.6,-239.6),(-239.6,-229.6),(-229.6,-220.5),(-220.5,-211.5),(-211.5,-202.4),(-202.4,-192.4),(-192.4,-182.4)]:
    arch_segment('Barrel_soffit_'+str(z0),z0,z1,mat='dark_walnut')
for z in [-248,-238,-228,-220.5,-211.5,-202,-192,-184]:
    arch_segment('Arch_bearing_rib_'+str(z),z-.19,z+.19,.48,'ivory_enamel')
    for x in [9.1,23.1]:
        box('Public_pier_'+str((x,z)),x,z,2.85,.65,.75,5.7,'warm_stone')
        box('Pier_foot_'+str((x,z)),x,z,.18,.95,1.05,.36,'champagne_metal')
        box('Pier_cap_'+str((x,z)),x,z,5.55,1,1.1,.35,'ivory_enamel')

# Work roof and real support bents, separate lower service band.
box('Work_ceiling_panel',33.5,-216,5.65,19.7,67.2,.3,'ivory_enamel')
box('Service_ceiling_panel',48.6,-216,4.85,10,67.2,.3,'ivory_enamel')
for z in [-248,-238,-228,-208,-198,-188,-184]:
    for x in [24.05,42.6,53.05]:box('Work_column_'+str((x,z)),x,z,2.7,.5,.6,5.4,'ivory_enamel')
    box('Work_crossbeam_'+str(z),33.3,z,5.32,19.3,.42,.4,'champagne_metal')
    box('Service_crossbeam_'+str(z),48.1,z,4.62,10.5,.4,.38,'champagne_metal')

# Real framed observation glazing, low solid base and protected service separation.
for za,zb in [(-248,-222),(-210,-184)]:
    box('Observation_plinth_'+str(za),24, (za+zb)/2,.55,.45,zb-za,1.1,'moss_dado')
    # Open framed observation bays: no opaque/frosted glazing, no claimed climate barrier.
    box('Observation_head_'+str(za),24,(za+zb)/2,3.37,.35,zb-za,.18,'champagne_metal')
    for z in range(int(za+2),int(zb),4):box('Glazing_mullion_'+str(z),24,z,2.2,.18,.14,2.4,'champagne_metal')
for za,zb in [(-249.6,-226),(-222,-218),(-214,-210),(-206,-182.4)]:box('Opaque_service_screen_'+str(za),42.85,(za+zb)/2,2.25,.3,zb-za,4.5,'sage_work_enamel')
for z in [-231,-215,-199]:box('Store_divider_'+str(z),50.2,z,2.1,6.7,.24,4.2,'ivory_enamel')
for za,zb in [(-249.6,-244),(-241,-232),(-230,-226),(-223,-216),(-214,-210),(-207,-200),(-198,-194),(-191,-182.4)]:
    box('Store_front_'+str(za),47.15,(za+zb)/2,2.1,.3,zb-za,4.2,'sage_work_enamel')
    box('Staff_kick_panel_'+str(za),46.98,(za+zb)/2,.55,.05,zb-za,1.1,'moss_dado')
for z,text in [(-242.5,'SOIL / TOOLS'),(-224.5,'POTTING'),(-208.5,'CARE'),(-192.5,'RETURNS')]:
    box('Store_lintel_'+text,47.15,z,3.4,.4,3.1,1.6,'ivory_enamel');signboard('Store_sign_'+text,text,46.89,z,2.96,2.8,.22)

# Fully modelled reusable planter-seat ribbons and plant observations.
for zi in [-243,-240.6,-238.2,-231,-228.6,-208,-205.6,-201,-198.6,-196.2,-193.8]:
    reuse('AST-BOT-004','Planted_seat_'+str(zi),14,zi,yaw=math.pi/2)
    for t,ident in [(.7,'AST-BOT-002'),(1.7,'AST-BOT-003')]:reuse(ident,'Display_'+str((zi,t)),13.49,zi-t,.39)
    marker('Seat_contact_'+str(zi),14.2,zi-1.2,.47,'physical seat surface proposal')
# Close seat rows with actual floor/soil-backed custom local ends; no unapproved mirrored catalogue export.
for z in [-238.13,-245.47,-233.47,-228.53,-210.47,-205.53,-203.47,-193.73]:box('Planted_edge_closed_end_'+str(z),13.8,z,.235,1.54,.14,.47,'warm_stone')

def plant_tree(name,x,z):
    rod(name+'_trunk',xyz(x,z,.46),xyz(x+.12,z,2.65),.12,'botanical_bark')
    for i in range(5):
        a=i*math.tau/5;bx=x+math.cos(a)*.72;bz=z+math.sin(a)*.72
        rod(name+'_bough_'+str(i),xyz(x+.08,z,1.7),xyz(bx,bz,2.9),.055,'botanical_bark')
        reuse('AST-BOT-002',name+'_crown_'+str(i),bx,bz,2.85,yaw=a,scale=.8)
    box(name+'_soil',x,z,.42,2.35,2.35,.12,'botanical_soil',coll=False)
    for xx,zz,w,d in [(x-1.2,z,.18,2.6),(x+1.2,z,.18,2.6),(x,z-1.2,2.3,.18),(x,z+1.2,2.3,.18)]:box(name+'_basin_'+str((xx,zz)),xx,zz,.25,w,d,.5,'warm_stone')
    box(name+'_bearing_base',x,z,.06,2.45,2.45,.12,'warm_stone')
for i,z in enumerate([-234,-205,-189]):plant_tree('Small_canopy_'+str(i),11.3,z)

def pot(name,x,z,h,r=.3,depth=.35,plant=None,scale=.6):
    n=12;verts=[]
    for radius,height in [(r*.75,h),(r,h+depth),(r*.83,h+depth),(r*.6,h+.06)]:
        verts.extend([tuple(xyz(x+radius*math.cos(i*math.tau/n),z+radius*math.sin(i*math.tau/n),height)) for i in range(n)])
    faces=[]
    for ring in range(3):
        for i in range(n):j=(i+1)%n;faces.append((ring*n+i,ring*n+j,(ring+1)*n+j,(ring+1)*n+i))
    faces.extend([tuple(reversed(range(n))),tuple(range(3*n,4*n))])
    # xyz reflects plan Z into source -Y; reverse ring winding for outward vessel normals.
    faces=[tuple(reversed(f)) for f in faces]
    me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new(name,me);sc.collection.objects.link(o);me.materials.append(M['warm_stone']);uv(o);tag(o,'horticultural_vessel',True)
    if plant:
        rod(name+'_soil',xyz(x,z,h+depth-.075),xyz(x,z,h+depth-.045),r*.81,'botanical_soil',vertices=12)
        reuse(plant,name+'_plant',x,z,h+depth-.03,scale=scale)
    return o

# Supported interpretation stations occupy the planted edge, leaving X18..23 clear.
for zi,title in [(-235.7,'GROWING / TENDING'),(-225.2,'ROOT / LEAF / FLOWER'),(-190.2,'THE SHIP GARDENS')]:
    box('Interpretation_plinth_'+str(zi),15.6,zi,.13,2.1,3.3,.26,'muted_stone')
    for zz in [zi-1.4,zi+1.4]:box('Interpretation_upright_'+str(zz),15.6,zz,1.1,.14,.14,2.0,'champagne_metal')
    signboard('Interpretation_title_'+str(zi),title,15.6,zi,1.95,3.1,.21)
    box('Interpretation_shelf_'+str(zi),15.9,zi,.85,.85,2.9,.10,'dark_walnut')
    for j,ident in [(-.85,'AST-BOT-003'),(0,'AST-BOT-002'),(.85,'AST-BOT-003')]:pot('Interpretive_pot_'+str((zi,j)),15.95,zi+j,.90,.22,.27,ident,.50)

# Planted wall recesses carry repeated tendable low and middle growth, never obstructing passage.
for zi in [-245,-240,-229,-207,-198,-185]:
    box('Garden_wall_dado_'+str(zi),8.49,zi,1.05,.15,3.8,2.1,'moss_dado')
    for dz in [-1.15,0,1.15]:pot('Garden_edge_pot_'+str((zi,dz)),10.2,zi+dz,0,.43,.55,'AST-BOT-009',.85)

# Purposeful propagation bench/worktop and trays; all supports reach candidate floor datum.
def workbench(name,x,z,w=4.5,d=1.5,trays=True):
    box(name+'_top',x,z,.92,w,d,.12,'sage_work_enamel')
    for xx in [x-w/2+.2,x+w/2-.2]:
        for zz in [z-d/2+.18,z+d/2-.18]:box(name+'_leg_'+str((xx,zz)),xx,zz,.43,.09,.09,.86,'champagne_metal')
    box(name+'_lower_shelf',x,z,.29,w-.2,d-.2,.08,'dark_walnut')
    marker(name+'_work_surface',x,z,.98,'bench support and reach datum')
    if trays:
        for i in range(3):
            xx=x+(i-1)*1.35
            box(name+'_tray_'+str(i),xx,z,1.04,1.12,1.15,.12,'dark_hardware')
            box(name+'_soil_'+str(i),xx,z,1.11,1.0,1.03,.04,'botanical_soil',coll=False)
            for j in [-.28,.28]:reuse('AST-BOT-003',name+'_seedling_'+str((i,j)),xx+j,z,1.13,scale=.65)
        # Each station has a readable supported label and its own stored working materials.
        signboard(name+'_station_label','PROPAGATION',x-w/2-.01,z,.80,1.25,.10)
        for dz in [-.37,.37]:
            box(name+'_stock_bin_'+str(dz),x,z+dz,.52,1.25,.58,.38,'warm_walnut')
            for dx in [-.4,0,.4]:pot(name+'_empty_pot_'+str((dx,dz)),x+dx,z+dz,.71,.14,.19)
for bay,zs in [('A',[-243,-237,-231]),('B',[-203,-197,-191])]:
    for xi in [28.2,35.7]:
        for zi in zs:workbench('Propagation_'+bay+'_'+str((xi,zi)),xi,zi)
    signboard('Bay_label_'+bay,'PROPAGATION '+bay,24.0,-238 if bay=='A' else -197,3.52,4.0,.26)
for zi in [-219,-213]:
    workbench('Demonstration_'+str(zi),33,zi,6,1.5,False)
    signboard('Demo_label_'+str(zi),'TENDING BENCH',29.99,zi,.80,1.25,.10)
    for dx,ident in [(-2,'AST-BOT-003'),(-.8,'AST-BOT-002'),(.6,'AST-BOT-009')]:pot('Demo_pot_'+str((zi,dx)),33+dx,zi,.98,.28,.32,ident,.6)
reuse('AST-BOT-009','Demonstration_flowering',32,-219,.98)
reuse('AST-BOT-002','Demonstration_understory',34,-219,.98)
workbench('Potting_work',51,-221,4.5,1.5,False)
signboard('Potting_work_label','POTTING',48.74,-221,.80,1.25,.12)
box('Potting_loam_tray',50,-221,1.08,1.3,1.0,.20,'dark_hardware')
box('Potting_loam',50,-221,1.19,1.17,.87,.04,'botanical_soil',coll=False)
for dz in [-.42,.42]:
    for dx in [0,.62]:pot('Potting_spare_'+str((dx,dz)),51+dx,-221+dz,.98,.22,.3)
pot('Potting_tended',52.35,-221,.98,.33,.40,'AST-BOT-002',.7)
box('Tool_board',53.51,-221,2.20,.15,4.3,1.7,'dark_walnut')
signboard('Tool_board_heading','TOOLS / RETURN CLEAN',53.35,-221,3.22,4.1,.22)
for zz in [-222.9,-219.1]:box('Tool_heading_wall_mount_'+str(zz),53.5,zz,3.22,.22,.12,.32,'champagne_metal')
for i in range(5):
    zz=-222.5+i*.7
    rod('Tool_hook_'+str(i),xyz(53.40,zz,2.5),xyz(53.19,zz,2.5),.025,'champagne_metal')
    rod('Tool_handle_'+str(i),xyz(53.19,zz,2.48),xyz(53.19,zz,2.03),.038,'warm_walnut')
    box('Tool_trowel_blade_'+str(i),53.19,zz,1.91,.07,.18,.25,'champagne_metal')
for dz in [-.42,.42]:box('Potting_lower_stock_'+str(dz),50.9,-221+dz,.52,2.3,.64,.36,'warm_walnut')
for z in [-239,-235,-205,-202]:reuse('AST-STF-007','Care_cabinet_'+str(z),51,z,yaw=-math.pi/2)
for z in [-244,-241,-238]:
    for h in [.25,1.1,1.95]:box('Soil_shelf_'+str((z,h)),52.5,z,h,1.8,2.5,.12,'ivory_enamel')
    for zz in [z-1.15,z+1.15]:box('Shelf_standard_'+str(zz),53.15,zz,1.3,.1,.1,2.6,'champagne_metal')
    for h in [.48,1.32]:
        for dz in [-.6,.6]:box('Substrate_bin_'+str((z,h,dz)),52.4,z+dz,h,1.3,.9,.34,'warm_walnut')
for z in [-194,-189]:
    box('Return_trolley_deck_'+str(z),50.5,z,.28,1.5,1.2,.12,'ivory_enamel')
    for xx in [49.95,51.05]:
        for zz in [z-.4,z+.4]:rod('Trolley_wheel',xyz(xx,zz,.12),xyz(xx,zz+.12,.12),.12,'dark_hardware')
    for xx in [49.8,51.2]:box('Trolley_upright',xx,z+.45,.8,.07,.07,1.15,'champagne_metal')
    box('Trolley_handle',50.5,z+.45,1.34,1.45,.07,.07,'champagne_metal')
    box('Return_container',50.5,z,.58,1.2,.9,.48,'warm_walnut')
marker('Sealed_future_service_interface',53.6,-192,1.6,'no opening; parent external staff link unbuilt')

# Source-backed effective fixtures: emitted mesh, stem, mount plate and actual light.
def fixture(name,x,z,ceiling,low,warm=False,power=650):
    box(name+'_mount',x,z,ceiling-.05,.45,.45,.10,'champagne_metal')
    rod(name+'_stem',xyz(x,z,ceiling-.08),xyz(x,z,low+.12),.035,'champagne_metal')
    box(name+'_housing',x,z,low+.09,1.8,.38,.18,'champagne_metal')
    box(name+'_emitter',x,z,low-.01,1.65,.29,.025,'warm_emitter' if warm else 'grow_emitter',coll=False,bevel=0)
    l=bpy.data.lights.new(name+'_effective','AREA');l.energy=power*.70;l.color=(1,.75,.44) if warm else (.86,.92,1);l.shape='RECTANGLE';l.size=1.6;l.size_y=.25
    o=bpy.data.objects.new(name+'_effective',l);sc.collection.objects.link(o);o.location=xyz(x,z,low-.04);tag(o,'effective_fixture_light')
    FIXTURES.append({'fixture':name,'source_position':list(o.location),'world_emitter':[x,27+low,z],'mount_world':[x,27+ceiling,z],'energy_watts':power*.70,'source_type':'AREA','runtime_note':'GLB cannot represent area lights; receiver must implement this light proposal at its physical emitter. Source rendered illumination is not runtime adoption.'})
for z in [-244,-234,-224,-208,-198,-188]:
    # Brackets hang from a modeled longitudinal beam, never empty air.
    for x in [16.5,29,38,45.1,50.3]:
        ceiling=6.65 if x<23 else 5.46 if x<43 else 4.66
        fixture('Luminaire_'+str((x,z)),x,z,ceiling,ceiling-.75,x<23,1100 if x<43 else 700)
for x in [16.5,29,38,45.1,50.3]:
    h=6.7 if x<23 else 5.5 if x<43 else 4.7
    box('Continuous_fixture_bearing_'+str(x),x,-216,h,.24,66,.20,'champagne_metal')
# Beam ends visibly meet transverse ribs; public longitudinal beam uses rigid hangers at ribs.
for z in [-248,-238,-228,-220.5,-211.5,-202,-192,-184]:rod('Public_roof_hanger_'+str(z),xyz(16.5,z,7.12),xyz(16.5,z,6.75),.055,'champagne_metal')

# Ordinary-height cameras; no secret roof removal for eye-level review.
CAMERAS={
 'arrival':([11,-216,1.65],[32,-216,2.0]),
 'observation':([20,-241,1.65],[19,-214,2.3]),
 'propagation':([26,-224,1.65],[34,-242,1.4]),
 'service':([45,-232,1.65],[45,-194,1.8]),
 'potting':([48.5,-226,1.65],[51,-221,1.2]),
 'ceiling_mount':([20,-224,1.65],[16.5,-234,6.2]),
 'section':([31,-258,14],[31,-216,2.0])}
for name,(a,b) in CAMERAS.items():
    data=bpy.data.cameras.new('SOURCE_ONLY_'+name);o=bpy.data.objects.new(data.name,data);sc.collection.objects.link(o);o.location=xyz(*a)
    o.rotation_euler=(xyz(*b)-o.location).to_track_quat('-Z','Y').to_euler();data.lens=23 if name!='ceiling_mount' else 32;data.clip_end=250
    if name=='section':data.type='ORTHO';data.ortho_scale=80

# Inspect evaluated source vertices, not merely object origins or declared dimensions.
bpy.context.view_layer.update();deps=bpy.context.evaluated_depsgraph_get();bounds=[];errors=[]
for o in EXPORT:
    if o.type!='MESH':continue
    ev=o.evaluated_get(deps);me=ev.to_mesh();vs=[ev.matrix_world@v.co for v in me.vertices]
    if vs:
        lo=[min(v[i] for v in vs) for i in range(3)];hi=[max(v[i] for v in vs) for i in range(3)]
        bounds.append({'name':o.name,'min_source':lo,'max_source':hi,'vertices':len(vs),'polygons':len(me.polygons),'collision_proposal':'static evaluated surface candidate' if o.name in COLLISIONS or (o.get('role')=='reused_component' and o.get('parent_catalogue_id') not in ['AST-BOT-002','AST-BOT-003','AST-BOT-009']) else 'none; leaf masses noncolliding'})
        if lo[0]<-.002 or hi[0]>46.002 or lo[1]<-34.002 or hi[1]>34.002 or lo[2]<-.002 or hi[2]>7.8:errors.append(o.name)
    ev.to_mesh_clear()
report={'scope':'actual evaluated source geometry; no engine acceptance','mesh_count':len(bounds),'out_of_bounds':errors,'bounds':bounds,'floor_excluded':floor.name not in [o.name for o in EXPORT],'fixture_count':len(FIXTURES),'reuse_instances':len(REUSE)}
(P/'tests/source_geometry.json').write_text(json.dumps(report,indent=2)+'\n')
if errors:raise RuntimeError('Allocation containment failed: '+str(errors[:30]))
for image in bpy.data.images:
    if image.source=='FILE' and image.has_data:
        try:image.pack()
        except RuntimeError:pass
# Templates are only linked data donors; remove their objects before save/export.
for o in TEMPLATES.values():bpy.data.objects.remove(o,do_unlink=True)
bpy.ops.object.select_all(action='DESELECT')
for o in EXPORT:
    if o.type in ['MESH','EMPTY']:o.select_set(True)
bpy.ops.export_scene.gltf(filepath=str(P/'exports/WP04_botanical_nursery.glb'),export_format='GLB',use_selection=True,export_apply=True,export_yup=True,export_extras=True,export_texcoords=True,export_normals=True,export_cameras=False,export_lights=False)
sc.camera=bpy.data.objects['SOURCE_ONLY_arrival']
bpy.ops.wm.save_as_mainfile(filepath=str(P/'source/WP04_botanical_nursery.blend'),compress=True)
for name,value in [('fixture_lighting_proposal',FIXTURES),('contact_markers',CONTACTS),('reused_components',REUSE),('collision_object_proposals',COLLISIONS)]:
    (P/'docs'/f'{name}.json').write_text(json.dumps(value,indent=2)+'\n')
manifest={'programme':'D06_directory_04','package':'WP04','status':'source/export candidate; independent review and live adoption pending','units':'metres','blender_version':bpy.app.version_string,'source_origin_world':[8,27,-216],'source_to_glb':'(x,y,z)->(x,z,-y)','glb_placement_translation':[8,27,-216],'rotation':'identity','floor':{'source_preview_only':True,'exported':False,'proposed_world_polygon':[[8,-250],[54,-250],[54,-182],[8,-182]],'top_y':27,'thickness':'parent-owned unresolved','collision_owner':'parent-owned unresolved'},'external_link':'X4..8 unbuilt parent-owned; not included','light_delivery':'physical fixtures exported; AREA effective-source lighting proposal separately supplied for engine adaptation','source_sha256':hashlib.sha256((P/'source/WP04_botanical_nursery.blend').read_bytes()).hexdigest(),'glb_sha256':hashlib.sha256((P/'exports/WP04_botanical_nursery.glb').read_bytes()).hexdigest()}
(P/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('WP04_SOURCE_EXPORT_CREATED',len(bounds),'meshes; source preview floor excluded. Run source reload and visual review before delivery.')
