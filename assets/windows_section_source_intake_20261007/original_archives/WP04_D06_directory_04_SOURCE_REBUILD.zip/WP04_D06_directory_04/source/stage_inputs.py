"""One-time read-only intake. Final build script never reads outside its package."""
from pathlib import Path
import hashlib,json,shutil
P=Path(__file__).resolve().parents[1]
R=P.parents[2]
S=R/'local_delivery/higgins_parallel_20261006'
snap=json.loads((S/'coordination_snapshot.json').read_text())
row=next(r for r in snap['rows'] if r['key']=='D06_directory_04')
assert snap['revision']==2 and row['package']=='WP04'
records=[]
def copy(src,dst,expected=None):
    h=hashlib.sha256(src.read_bytes()).hexdigest()
    if expected: assert h==expected,(src,h,expected)
    dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
    records.append({'file':str(dst.relative_to(P)).replace('\\','/'),'sha256':h,'origin':str(src.relative_to(R)).replace('\\','/')})
for a in row['asset_sources']:
    copy(R/'BlenderCatalogue'/a['source'],P/'assets/native'/f"{a['id']}.blend",a['source_sha256_current'])
for folder in [R/'BlenderCatalogue/materials',R/'BlenderCatalogue/materials/botanical']:
    for f in folder.iterdir():
        if f.suffix=='.png' or f.name in ['manifest.json','material_manifest.json']:
            copy(f,P/'assets/materials'/('botanical' if folder.name=='botanical' else '')/f.name)
for n in ['ARCHITECTURAL_DELIVERY_RULES.md','COORDINATE_CONTRACT.md']:
    copy(S/'current_inputs'/n,P/'docs'/n)
for n in ['BRIEF.md','plan_contract.json','PLAN_SECTION.svg','reviewed_master_chapters.json']:
    copy(S/'section04_botanical_nursery'/n,P/'docs/planning'/n)
copy(S/'coordination_snapshot.json',P/'docs/coordination_snapshot.json')
for alias,rel in [('A','DesignArchive/Historical_Design/Additional_Documents/Astraea-current-layout-atlas.pdf'),('O','DesignArchive/References/Uploaded_46/02/image(1).png'),('B','BlenderCatalogue/references/botanical/atrium_reference.png'),('Q','Game/docs/references/cruise_atrium_20261006/retro_atrium_quality_benchmark.png')]:
    f=R/rel;copy(f,P/'docs/references'/f'{alias}{f.suffix}',snap['sources'][alias]['sha256'])
(P/'docs/current_row.json').write_text(json.dumps(row,indent=2)+'\n')
(P/'assets/intake_manifest.json').write_text(json.dumps({'status':'hash-verified package-local inputs','files':records},indent=2)+'\n')
print('Staged',len(records),'immutable inputs; portable build needs no workspace paths.')
