# WP04 Botanical nursery — construction candidate

Programme D06_directory_04. Exact allocation X8…54 / Z−250…−182; source floor datum Y27; D07 Sports viewing above at35.5; Pharmacy stores below. Portal [8,27,−216]. The X4…8 receiver is unbuilt, held and Higgins-owned. No external works are included.

**Current status: source/native/export checks passed; the coordinator inspected all six final corrected ordinary-height views and passed this source candidate for Higgins receiving review.** See `root_review.json` for exact reviewed image/native/export hashes. This is not live engine adoption or final ship acceptance. The section includes an enclosed working nursery, supported timber vault, lower work/service ceiling, open framed internal propagation views, planted resting/interpretation edges, supported propagation/potting benches with trays, stores, cleaning cabinets, return trolleys, backed signs, textured sage/wood/stone finishes and mounted effective source lights. No exterior sky or view crosses occupied neighbours.

Use Blender4.3.2:

```
blender --background --threads 2 --python-exit-code 1 --python source/build_nursery.py
blender --background --threads 2 --python-exit-code 1 --python tests/reload_and_export_check.py
blender --background --threads 2 --python-exit-code 1 --python tests/render_views.py -- arrival 24
```

Render separately: observation, propagation, service, potting, ceiling_mount and section. Ordinary views preserve all roofs. Section view deliberately removes selected top/end enclosure for diagram inspection and is not an ordinary arrival.

The build has **no paths outside this package**. Input `.blend` files and textures have immutable hash receipts; source dependency originals stay editable. `source/stage_inputs.py` documents the one-time workspace intake and is not a rebuild dependency. The full candidate includes original/current required images for review only, never as textures. Compact reconstruction omits non-build archival images and large chapter evidence; the build verifies every actual asset input instead of requiring omitted archival documents. Complete original intake identities remain in `assets/intake_manifest.json`.

The source uses local Blender metres with origin at world [8,27,−216]. Source `(x,y,z)` maps to native glTF `(x,z,−y)`; GLB placement is translation [8,27,−216] with identity rotation. The `SOURCE_PREVIEW_ONLY_floor` is excluded from GLB. `manifest.json` will contain the complete floor polygon proposal and leave thickness/collision assignment to Higgins.

Existing catalogue source components are appended with their full object hierarchy evaluated before transforms are cached; repeated candidates retain parent catalogue ID and scaling records. The original native files remain unmodified in `assets/native/`. Architecture and furnishings created here have package identities only; no AST registration occurs.

Actual source area lights illuminate from modeled luminous fixtures. Area emitters cannot be represented faithfully by core glTF punctual lights, so their effective light proposal is delivered separately and the GLB carries the physical housings/stems/emitters. Higgins must adopt appropriate Godot light types and budgets. Source illumination does not claim runtime lighting adoption. No engine settings or global lighting manager is touched.

Source geometry checks record actual evaluated mesh bounds and candidate collision surfaces, preserving under-bench and leaf gaps. They do not certify actual collision or loaded-cart travel. Source reload checks will open the saved `.blend`, inspect packed images, import the GLB fresh and verify transformed geometry containment and preview-floor exclusion.

Architectural reference review: botanical diorama and owner retro benchmark plus original overview and atlas p08 were inspected. `tests/reference_views/atlas_page08.png` is a rendered historical source: it confirms directory04 as Botanical nursery on D06/Y27, separated from the central atrium and on the starboard fore axis; its drawn historical door/route is not current adoption evidence. Overview's conflicting counts and roof illustration do not supersede canonical data. Earlier planning notes under `docs/planning/` preserve the initial stage; this readme and current row supersede their former input/geometry hold and old first-pass sequencing interpretation.

The original failed visual attempt is retained in `tests/revision01_before_visual_corrections`; earlier notes describe that historical state. Final source construction and source/export checks passed, and the six final images were reviewed by the coordinator after correction. Native source and GLB are unchanged after that review. Packaging narrows the startup verification loop to true asset dependencies only; it makes no construction change. Godot integration, floor/collision ownership, external receiver, actor/cart/door checks, source-to-runtime lights, final CRT on/off review and independent retention remain Higgins's gates.
