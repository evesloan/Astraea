"""Isolated receiving derivative: unique names and inactive source emitters only.
No geometry, material, texture, accessor, transform or binary-buffer changes.
"""
from pathlib import Path
import json,struct,hashlib,copy,re
R=Path(__file__).resolve().parent;S=R/'source_intake/WP10_D06_directory_03/exports/WP10_moss_sanctuary.glb';D=R/'runtime_derivative001';D.mkdir(exist_ok=True)
b=S.read_bytes();sha=lambda x:hashlib.sha256(x).hexdigest();assert sha(b)=='33fe0fddc60734cb401c16ec5e53664c948ff9d28d88b3f2384832898d211202'
n,k=struct.unpack_from('<II',b,12);assert k==0x4e4f534a;j=json.loads(b[20:20+n]);out=copy.deepcopy(j);tail=b[20+n:];mapping=[];lights=[]
for i,node in enumerate(out['nodes']):
 old=node.get('name','');name='WP10_N%04d_'%i+re.sub('[^A-Za-z0-9_]','_',old);node['name']=name;mapping.append({'source_index':i,'source_name':old,'runtime_name':name})
 ext=node.get('extensions',{})
 if 'KHR_lights_punctual' in ext:
  li=ext.pop('KHR_lights_punctual')['light'];lights.append({'source_node_index':i,'source_name':old,'runtime_name':name,'light':j['extensions']['KHR_lights_punctual']['lights'][li],'status':'inactive fixture witness; receiving physical light calibration pending'})
  if not ext:node.pop('extensions',None)
assert len(lights)==36
for key in ['extensionsUsed','extensionsRequired']:
 if key in out:
  out[key]=[e for e in out[key] if e!='KHR_lights_punctual']
  if not out[key]:out.pop(key)
if 'extensions' in out:
 out['extensions'].pop('KHR_lights_punctual',None)
 if not out['extensions']:out.pop('extensions')
for key in ['meshes','materials','textures','images','accessors','bufferViews','buffers','samplers']:assert out.get(key)==j.get(key)
for a,c in zip(j['nodes'],out['nodes']):
 for key in ['matrix','translation','rotation','scale','mesh','children','extras']:assert a.get(key)==c.get(key)
assert len({m['runtime_name']for m in mapping})==len(mapping)
data=json.dumps(out,separators=(',',':'),allow_nan=False).encode();data+=b' '*((-len(data))%4);result=struct.pack('<4sII',b'glTF',2,20+len(data)+len(tail))+struct.pack('<II',len(data),0x4e4f534a)+data+tail
p=D/'WP10_moss_receiving_inert001.glb';assert not p.exists();p.write_bytes(result)
receipt={'source_sha256':sha(b),'derivative_sha256':sha(result),'binary_tail_sha256':sha(tail),'source_geometry_material_image_accessor_transform_unchanged':True,'mapping':mapping,'inactive_lights':lights,'scope':'Unbatched receiving candidate, no live adoption, no performance or lighting acceptance'}
(D/'SOURCE_RUNTIME_MAPPING.json').write_text(json.dumps(receipt,indent=2)+'\n');print({k:v for k,v in receipt.items()if k not in ['mapping','inactive_lights']})
