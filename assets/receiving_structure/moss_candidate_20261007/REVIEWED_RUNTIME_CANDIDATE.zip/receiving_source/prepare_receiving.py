from pathlib import Path
import json,hashlib,shutil,importlib.util
D=Path(__file__).resolve().parent; C=D/'runtime_candidate'; S=D/'source_intake/WP10_D06_directory_03'; G=Path('/workspace/shared/Astraea_recovery_20261007_AXWr5x/Game')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(rel,s):
 p=C/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
def dump(rel,d):put(rel,json.dumps(d,indent=2)+'\n')
m=json.loads((C/'data/architecture/moss_sanctuary/runtime_manifest.json').read_text())
for f in (D/'runtime_derivative001').glob('*.glb'):
 target=C/'assets/models'/Path(m['derivative_file']).name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,target)
 assert sha(target)==m['derivative_sha256']
materials=json.loads((S/'assets/materials/material_manifest.json').read_text())['materials'];m['finish_textures']=[]
for role in ['warm_stone','ivory_enamel']:
 src=S/'assets/materials'/materials[role]['base_color_file'];rel='assets/models/WP10_receiving_'+role+'.png';p=C/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,p)
 m['finish_textures'].append({'role':role,'file':'res://'+rel,'sha256':sha(p),'meters_per_tile_uv':materials[role]['meters_per_tile_uv'],'roughness':materials[role]['roughness']})
sp=importlib.util.spec_from_file_location('preview',S/'source/preview_floor.py');mod=importlib.util.module_from_spec(sp);sp.loader.exec_module(mod)
v,f,mat=mod.floor_mesh_data();proof=mod.verify_partition(v,f)
m['floor_owner']='D06_moss_sanctuary_receiving_floor';m['floor_shader']='res://shaders/moss_sanctuary_receiving_finish.gdshader';m['source_floor_partition']={'paths_uv':mod.PATHS,'source_sha256':sha(S/'source/preview_floor.py'),'proof':proof,'uv_mapping':'u=-8-x; v=z+250; original source texture UV=(x,-z)'}
geom=json.loads((G/'data/architecture/packages/botanical_court/BOTANICAL_GUARD_EXPORT_GEOMETRY.json').read_text());mapping=json.loads((G/'data/architecture/packages/botanical_court/BOTANICAL_IMPORT_NAME_MAP.json').read_text());names={r['source_name']:r['imported_name'] for r in mapping['pairs']}
m['opened_guard_names']=[names.get(n,n)for n in geom['objects']if n.startswith('BOTCOURT_port_PORTAL_CLOSURE_')];assert len(m['opened_guard_names'])==14
m['portal_state']='Only the exact supported Moss port portal is open; Nursery and other guards remain closed'
m['scope']='Source-faithful receiving candidate; actual import/contact/input/render acceptance pending'
dump('data/architecture/moss_sanctuary/runtime_manifest.json',m)
shader='''shader_type spatial;
render_mode diffuse_burley, specular_schlick_ggx;
uniform sampler2D warm_stone : source_color, filter_nearest_mipmap, repeat_enable;
uniform sampler2D ivory_enamel : source_color, filter_nearest_mipmap, repeat_enable;
varying vec2 ship_xz;
void vertex() { ship_xz = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xz; }
bool inside(vec2 p, vec4 r) { return p.x > r.x && p.x < r.y && p.y > r.z && p.y < r.w; }
void fragment() {
 vec2 p=vec2(-8.0-ship_xz.x,ship_xz.y+250.0);
 bool path=false;
'''
for u,v,du,dv in mod.PATHS: shader+=f' path = path || inside(p,vec4({u-du/2:.6f},{u+du/2:.6f},{v-dv/2:.6f},{v+dv/2:.6f}));\n'
shader+=' vec2 uv=vec2(ship_xz.x,-ship_xz.y);\n'
for i,role in enumerate(['warm_stone','ivory_enamel']):
 r=materials[role];shader+=(' if (path) {' if i else ' {')+f' ALBEDO=texture({role},uv/vec2({r["meters_per_tile_uv"][0]:.6f},{r["meters_per_tile_uv"][1]:.6f})).rgb; ROUGHNESS={r["roughness"]:.6f}; }}\n'
shader+=' METALLIC=0.0;\n}\n';put('shaders/moss_sanctuary_receiving_finish.gdshader',shader)
p=C/'scripts/moss_sanctuary_receiving.gd';s=p.read_text();s=s.replace('# Isolated receiving candidate. Source geometry preserved; live floor/portal gates pending.','# Source-preserved whole receiving candidate. No new capacity or gameplay authority.')
s=s.replace(' return root\n',' _finish_floor(space,data)\n _open_supported_portal(space,data)\n return root\n')
s+='''
static func _finish_floor(space: Node3D, data: Dictionary) -> void:
 var floor: Node3D=space.get_node("CompiledStructuralFloors_NotFinishedRooms/"+str(data.floor_owner))
 assert(floor.get_meta("floor_y",27.0)==27.0)
 var material:=ShaderMaterial.new()
 material.shader=load(str(data.floor_shader))
 for record in data.finish_textures:
  assert(FileAccess.get_sha256(str(record.file))==str(record.sha256))
  material.set_shader_parameter(str(record.role),load(str(record.file)))
 var count:=0
 for child in floor.get_children():
  if child is MeshInstance3D and str(child.name).begins_with("cell_"):
   assert(child.mesh.get_surface_count()==1)
   child.set_surface_override_material(0,material)
   count+=1
 assert(count==data.finish_top_chunks.size())

static func _open_supported_portal(space: Node3D, data: Dictionary) -> void:
 # Authenticate a connected floor owner before changing only the named portal.
 var floors: Node3D=space.get_node("CompiledStructuralFloors_NotFinishedRooms")
 var compiled: Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://data/generated/structural_meshes.json"))
 var matches:=0
 for row in compiled.regions:
  if str(row.id)!=str(data.floor_owner): continue
  assert(row.deck=="D06" and row.floor_y==27 and row.thickness==.24 and row.structural_area_m2==3128)
  assert(row.rings==[[[-54,-250],[-8,-250],[-8,-182],[-54,-182]]])
  matches+=1
 assert(matches==1 and floors.has_node(NodePath(str(data.floor_owner))))
 var guard: Node3D=space.get_node("BotanicalCourtReceivingClosedInterim")
 var changed:=0
 for mesh in guard.find_children("*","MeshInstance3D",true,false):
  if str(mesh.name) not in data.opened_guard_names: continue
  assert(mesh.visible)
  var shapes: Array=mesh.find_children("*","CollisionShape3D",true,false)
  assert(shapes.size()==1 and not shapes[0].disabled)
  mesh.visible=false
  shapes[0].disabled=true
  mesh.set_meta("moss_supported_portal_open",true)
  changed+=1
 assert(changed==14)
'''
p.write_text(s)
print('Prepared runtime assets, exact14 portal states and material-only floor finish')
