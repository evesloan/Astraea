from pathlib import Path
import json,hashlib
D=Path(__file__).resolve().parent;C=D/'successor002/Game';L=Path('/workspace/shared/Astraea_recovery_20261007_AXWr5x/Game');M=D.parent/'movement_receiving_20261007/successor001';T=D.parent/'team_lounge_receiving_20261007/runtime_implementation001/proof_work'
sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(p.read_text())
ctx=load(C/'data/architecture/packages/moss_sanctuary/BUILD_CONTEXT.json');pre=ctx['predecessors'];g='tests/medical_triage_successor_guard.gd';s=(C/pre[g]['retained_path']).read_text();ed=[]
def edit(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a));ed.insert(0,{'before':a,'after':b,'count':1});s=s.replace(a,b)
edit('or value==movement_current_compiled)','or value==movement_current_compiled or value==moss_current_compiled)')
edit('\tif value==movement_current_compiled: value=team_lounge_current_compiled','\tif value==moss_current_compiled: value=movement_current_compiled\n\tif value==movement_current_compiled: value=team_lounge_current_compiled')
edit('\tif movement_checked: return','\tif movement_checked: return\n\t_moss_ensure()')
edit('FileAccess.get_sha256("res://"+str(path))==str(movement_proof.current_sha256[path])','_moss_current_sha256("res://"+str(path))==str(movement_proof.current_sha256[path])')
# Only the latest layer reads current raw inputs. Project its exact predecessor.
for a in ['FileAccess.get_file_as_string("res://tests/medical_triage_successor_guard.gd")','FileAccess.get_file_as_string("res://"+str(path))','FileAccess.get_file_as_string("res://data/spatial_layout.json")','FileAccess.get_file_as_string("res://data/generated/structural_meshes.json")','FileAccess.get_file_as_string("res://docs/LAYOUT_COMPILE_CHECKS.json")']:
 edit(a,a.replace('FileAccess.get_file_as_string','_moss_current_text'))
a='\tassert(floors!=null and floors.get_child_count()==279,"Complete actual 279-owner roster required before predecessor projection")';edit(a,'\tvar moss_predecessor_children: Array=_moss_floor_children(floors)\n'+a.replace('floors.get_child_count()','moss_predecessor_children.size()'))
edit('\tvar children: Array=floors.get_children()','\tvar children: Array=moss_predecessor_children')
# Preserve every geometric and identity check on all136 guards. Only exact14 states change.
start=s.index('static func _botanical_validate_guards(');end=s.index('static func _botanical_floor_children(',start)
old_guard=s[start:end];new_guard=old_guard.replace('assert(mesh.visible and mesh.material_override==null and mesh.mesh!=null)','assert(mesh.visible==(not _moss_guard_is_open(name_key)) and mesh.material_override==null and mesh.mesh!=null)').replace('assert(contacts.size()==1 and not contacts[0].disabled and contacts[0].shape is ConcavePolygonShape3D)','assert(contacts.size()==1 and contacts[0].disabled==_moss_guard_is_open(name_key) and contacts[0].shape is ConcavePolygonShape3D)')
assert new_guard!=old_guard
edit(old_guard,new_guard)
section=(T/'lounge_section.gd.in').read_text().replace('TEAM_LOUNGE','MOSS').replace('team_lounge','moss').replace('275-to-277','279-to-280').replace('D07_directory_08','D06_directory_03').replace('packages/moss/','packages/moss_sanctuary/').replace('["D07_moss_receiving_floor","D07_moss_axial_connector"]','["D06_moss_sanctuary_receiving_floor"]').replace('==277','==280').replace('==275','==279').replace('actual 277-owner','actual 280-owner').replace('2477.7225461174385','3128.0').replace('\tassert(float(moss_proof.added_compiled_records[1].structural_area_m2)==16.0)\n','').replace('summary.moss_additive','summary.moss_sanctuary_additive').replace('row.deck=="D07" and float(row.floor_y)==35.5','row.deck=="D06" and float(row.floor_y)==27')
section=section.replace('@RUNTIME_VALIDATOR@',(D/'moss_runtime_validator.gd.in').read_text().rstrip())
paths=ctx['newpaths']+['data/spatial_layout.json','data/generated/structural_meshes.json','docs/LAYOUT_COMPILE_CHECKS.json','tools/compile_layout.py','scripts/ship.gd','tools/moss_sanctuary_incremental_preservation.py',ctx['compiler_proof'],'tests/validate_botanical_receiving_access.gd','tests/fixtures/botanical_moss_receiving_acceptance011.json']
current={r:sha((C/r).read_bytes())for r in paths}
for rel in ['scripts/player.gd','scripts/lighting_budget.gd','scripts/static_contact_cache.gd','project.godot','tests/medical_test_scene.gd']:current[rel]=sha((L/rel).read_bytes())
proof={'schema':1,'programme_key':'D06_directory_03','projected_paths':list(pre),'current_sha256':current,'predecessors':pre,'added_owner_ids':[r['id']for r in ctx['added']],'added_layout_records':ctx['added'],'added_compiled_records':ctx['expected'],'compile_summary':load(C/'docs/LAYOUT_COMPILE_CHECKS.json'),'consumer_inverse_edits':ed,'integration_block_normalized_sha256':sha(section.encode()),'exact_inverse_edits':ctx['exact_inverse_edits'],'runtime_manifest':'data/architecture/moss_sanctuary/runtime_manifest.json','scope':'Exact source/guard-state/floor successor; engine acceptance unrun'}
rp='data/architecture/packages/moss_sanctuary/MOSS_RUNTIME_PROOF.json';p=C/rp;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(proof,indent=2)+'\n');(C/g).write_text(s+section.replace('<PROOF_SHA>',sha(p.read_bytes()),1))
paths+=list(r['retained_path']for r in pre.values())+[rp,g]
mm=load(M/'UNION_APPLY_MANIFEST.json');prior={r['path']:r for r in mm['files']}
def oldhash(rel):return sha((L/rel).read_bytes())if (L/rel).is_file()else None
manifest={'scope':'Apply only after exact verified Movement279 predecessor. No engines, imports or live changes made by worker.','predecessor_count':279,'successor_count':280,'movement_manifest_sha256':ctx['movement_manifest_sha256'],'files':[{'path':r,'sha256':sha((C/r).read_bytes()),'existing_Game_sha256':oldhash(r),'bytes':(C/r).stat().st_size}for r in sorted(set(paths))],'open_gates':['Actual fresh import and strict runtime guard','Actual unchanged-player entry, full public/care route and return with information RMB/E','Loaded cart and species fit','Normal in-engine visual review and water motion','Full current regression and primary bearing/target hardware acceptance']}
(D/'successor002/UNION_APPLY_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n');print('Moss exact runtime and portal successor ready',len(manifest['files']),'files')
