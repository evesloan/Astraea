from pathlib import Path
import json,hashlib
D=Path(__file__).resolve().parent;C=D/'successor001/Game';G=Path('/workspace/shared/Astraea_recovery_20261007_AXWr5x/Game')
p=G/'tests/validate_botanical_receiving_access.gd';s=p.read_text();old=s;ed=[]
def edit(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a));ed.insert(0,{'before':a,'after':b,'count':1});s=s.replace(a,b)
fixture=json.loads((G/'tests/fixtures/botanical_receiving_acceptance010.json').read_text());fixture['future_portals'][0]['state']='OPEN';fixture['scope']='Exact closed botanical predecessor plus only the supported Moss doorway, interior and return'
fixture['unchanged_input_sha256']['data/generated/structural_meshes.json']=hashlib.sha256((C/'data/generated/structural_meshes.json').read_bytes()).hexdigest()
fp=C/'tests/fixtures/botanical_moss_receiving_acceptance011.json';fp.parent.mkdir(parents=True,exist_ok=True);fp.write_text(json.dumps(fixture,indent=2)+'\n')
edit('botanical_receiving_acceptance010.json','botanical_moss_receiving_acceptance011.json');edit('8b2f830ac96fc565bde7f17528471b45997e5c5cd18a1ae1c2e67f792e36d682',hashlib.sha256(fp.read_bytes()).hexdigest())
edit('var footprint_support_queries: int=0','var footprint_support_queries: int=0\nvar moss_portal_crossings: int=0\nvar moss_route_completed: bool=false')
edit('"scope":"Bounded installed D06 receiving floor/closed-guard player check. No room entry, cart/controller tuning, species acceptance, final art or all-ship claim."','"moss_portal_crossings":moss_portal_crossings,"moss_route_completed":moss_route_completed,"scope":"Bounded actual unchanged-player Botanical receiving and Moss interior/return; cart/species, visuals and full ship acceptance remain separate."')
edit('\t\tvar was_x: float=before.x','\t\tif (before.x>-8 and actor.global_position.x<=-8) or (before.x<-8 and actor.global_position.x>=-8): moss_portal_crossings+=1\n\t\tvar was_x: float=before.x')
edit('\t\t\t\tif not guard_contact(Vector3(float(side)*7.4,float(y),z),Vector3(float(side)*8.2,float(y),z),"closed outer edge"): return false','\t\t\t\tif side==-1 and z> -218.1 and z< -213.9:\n\t\t\t\t\tif not require(ray(Vector3(-7.4,float(y),z),Vector3(-8.2,float(y),z),exclusions()).is_empty(),"Moss portal must now be clear"): return false\n\t\t\t\telse:\n\t\t\t\t\tif not guard_contact(Vector3(float(side)*7.4,float(y),z),Vector3(float(side)*8.2,float(y),z),"closed outer edge"): return false')
a='\t\tif not require(portal.state=="CLOSED" and portal.floor_y==27 and portal.center_z==-216,"Future portal identity/datum changed"): return false';edit(a,'\t\tif portal.programme_id=="D06_directory_03":\n\t\t\tif not require(portal.state=="OPEN" and portal.floor_y==27 and portal.center_z==-216 and portal.edge_x==-8 and portal.clear_width_m==4.2,"Exact Moss portal identity/datum required"): return false\n\t\t\tfor x in [-7.98,-8.02,-8.5,-9.0,-10.0]:\n\t\t\t\tif not support_at(Vector3(float(x),27,-216)): return false\n\t\t\tcontinue\n'+a)
edit('\t\tif not await bump_guard(label+" closed future portal",Vector2(float(side),0)): return false','\t\tif side==-1:\n\t\t\tif not await moss_interior(): return false\n\t\telse:\n\t\t\tif not await bump_guard(label+" closed future portal",Vector2(float(side),0)): return false')
edit('completed_bumps.size()==6 and','completed_bumps.size()==5 and moss_portal_crossings>=2 and moss_route_completed and')
edit('Both seams must be crossed out/back and all six actual barriers contacted','Both seams and Moss doorway must be crossed out/back and all five retained actual barriers contacted')
edit('real player barrier contacts. No room entry or species acceptance.','real retained barrier contacts plus Moss interior/return. No cart/species acceptance.')
section='''
# MOSS_ACCESS_EXACT_SECTION_BEGIN
func moss_interior() -> bool:
 # Source public route centre-lines, explicit original entry datum and dry garden loop.
 if not await route([[-6,-216],[-10,-216],[-18,-216],[-18,-238],[-44,-238],[-44,-216],[-44,-188],[-18,-188],[-18,-216]]): return false
 # The care route is source-authored, reached through its existing cross-path.
 if not await route([[-44,-216],[-51,-216],[-51,-245],[-42.2,-245],[-42.2,-246.6]]): return false
 if not await read_moss_information("WP10_info_care_01"): return false
 if not await route([[-42.2,-245],[-51,-245],[-51,-216],[-44,-216],[-18,-216],[-18,-222.2],[-19.8,-222.2]]): return false
 if not await read_moss_information("WP10_info_stream_01"): return false
 if not await route([[-18,-222.2],[-18,-216],[-10,-216],[-6,-216]]): return false
 moss_route_completed=true
 return true

func read_moss_information(identity: String) -> bool:
 var target: Node3D=ship.get_node("ShipSpace/D06_MossSanctuary_Receiving_WIP/"+identity)
 var delta: Vector3=target.global_position-actor.camera.global_position
 actor.rotation.y=atan2(-delta.x,-delta.z)
 var pitch: float=atan2(delta.y,Vector2(delta.x,delta.z).length())
 actor.set("pitch",pitch);actor.camera.rotation.x=pitch
 right_mouse(true)
 if not await advance(10,true): return false
 if not require(not target.expanded,"Information starts closed"): return false
 key(KEY_E,true)
 if not await advance(1,true): return false
 key(KEY_E,false)
 if not await advance(5,true): return false
 if not require(target.expanded,"Original RMB/E did not open "+identity): return false
 key(KEY_E,true)
 if not await advance(1,true): return false
 key(KEY_E,false)
 if not await advance(5,true): return false
 if not require(not target.expanded,"Original RMB/E did not close "+identity): return false
 right_mouse(false)
 return true
# MOSS_ACCESS_EXACT_SECTION_END
'''
# Helper name from retained medical harness.
section=section.replace('right_mouse(', 'focus(')
(C/'tests/validate_botanical_receiving_access.gd').write_text(s+section)
(D/'successor001/ACCESS_EXACT_INVERSE.json').write_text(json.dumps({'predecessor_sha256':hashlib.sha256(old.encode()).hexdigest(),'inverse_edits':ed,'appended_section':section},indent=2)+'\n')
print('Bounded botanical access successor prepared')
