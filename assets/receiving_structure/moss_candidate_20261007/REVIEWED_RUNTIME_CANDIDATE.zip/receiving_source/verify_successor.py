from pathlib import Path
import json,hashlib,copy,subprocess,sys,importlib.util
from shapely.geometry import Polygon,box
from shapely.ops import unary_union
from gdtoolkit.parser import parser
D=Path(__file__).resolve().parent;W=D/'successor001';C=W/'Game';L=Path('/workspace/shared/Astraea_recovery_20261007_AXWr5x/Game');M=D.parent/'movement_receiving_20261007/successor001'
sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(p.read_text())
manifest=load(W/'UNION_APPLY_MANIFEST.json');mm=load(M/'UNION_APPLY_MANIFEST.json');mp={r['path']:r for r in mm['files']};p=load(C/'data/architecture/packages/moss_sanctuary/MOSS_RUNTIME_PROOF.json');checks=[];negative=[]
def yes(v,why='Mismatch'):assert v,why
def prior(rel):return M/'Game'/rel if rel in mp else L/rel
def resolve(rel):return C/rel if (C/rel).exists()else prior(rel)
def undo(s,ed):
 for e in ed:yes(s.count(e['after'])==e['count']);s=s.replace(e['after'],e['before'])
 return s
for r in manifest['files']:
 yes(sha((C/r['path']).read_bytes())==r['sha256'],r['path']);old=prior(r['path']);yes((sha(old.read_bytes())if old.exists()else None)==r['existing_Game_sha256'],r['path'])
for rel,digest in p['current_sha256'].items():yes(sha(resolve(rel).read_bytes())==digest,rel)
for rel,r in p['predecessors'].items():yes((C/r['retained_path']).read_bytes()==prior(rel).read_bytes());yes(sha((C/r['retained_path']).read_bytes())==r['sha256'])
g='tests/medical_triage_successor_guard.gd';guard=(C/g).read_text()
def recover(s):
 a='# MOSS_EXACT_SECTION_BEGIN\n';z='# MOSS_EXACT_SECTION_END\n';yes(s.count(a)==s.count(z)==1);i=s.index(a);j=s.index(z)+len(z);block=s[i:j];digest=sha((C/'data/architecture/packages/moss_sanctuary/MOSS_RUNTIME_PROOF.json').read_bytes());yes(block.count(digest)==1);yes(sha(block.replace(digest,'<PROOF_SHA>').encode())==p['integration_block_normalized_sha256']);return undo(s[:i]+s[j:],p['consumer_inverse_edits'])
yes(recover(guard)==prior(g).read_text())
for rel,ed in p['exact_inverse_edits'].items():yes(undo((C/rel).read_text(),ed)==prior(rel).read_text())
access=load(W/'ACCESS_EXACT_INVERSE.json');text=(C/'tests/validate_botanical_receiving_access.gd').read_text();yes(text.endswith(access['appended_section']));yes(undo(text[:-len(access['appended_section'])],access['inverse_edits'])==prior('tests/validate_botanical_receiving_access.gd').read_text())
checks.append('All hashes/preimages, exact guard/compiler/ship inverses and exact Botanical access predecessor recovered')
movement=load(M/'Game/data/architecture/packages/movement_studio/MOVEMENT_RUNTIME_PROOF.json')
for rel,digest in movement['current_sha256'].items():yes(sha((prior(rel)if rel in p['projected_paths']else resolve(rel)).read_bytes())==digest,rel)
checks.append('Complete Movement279 runtime proof preserved by exact latest-layer projection')
oldl=load(prior('data/spatial_layout.json'));oldc=load(prior('data/generated/structural_meshes.json'));layout=load(C/'data/spatial_layout.json');compiled=load(C/'data/generated/structural_meshes.json');summary=load(C/'docs/LAYOUT_COMPILE_CHECKS.json')
def structures(l,c,s):
 yes(l['regions']==oldl['regions']+p['added_layout_records']);yes(c['regions']==oldc['regions']+p['added_compiled_records']);yes(len(c['regions'])==280)
 for x in [l,c]:yes(len({r['id']for r in x['regions']})==len(x['regions']))
 yes({k:v for k,v in l.items()if k!='regions'}=={k:v for k,v in oldl.items()if k!='regions'});yes(c['source_checks']==s==p['compile_summary']);yes(s['moss_sanctuary_additive_preservation']['complete_old_records_preserved'])
structures(layout,compiled,summary)
shape=box(-54,-250,-8,-182);row=p['added_compiled_records'][0];yes(row['floor_y']==27 and row['thickness']==.24 and row['structural_area_m2']==3128)
for triangles in [row['triangles'],[t for chunk in row['render_chunks']for t in chunk['triangles']]]:
 ts=[Polygon(t)for t in triangles];yes(unary_union(ts).equals(shape)and sum(t.area for t in ts)==3128)
for old in oldc['regions']:
 sh=unary_union([Polygon(t)for t in old['triangles']]);overlap=shape.intersection(sh).area
 if overlap>1e-8:yes(min(27,old['floor_y'])-max(26.76,old['floor_y']-old['thickness'])<1e-7)
checks.append('Independent3128m² complete floor/chunk coverage, all279 predecessor slabs separated, globals/voids/records unchanged')
m=load(C/'data/architecture/moss_sanctuary/runtime_manifest.json');geom=load(L/'data/architecture/packages/botanical_court/BOTANICAL_GUARD_EXPORT_GEOMETRY.json');names=load(L/'data/architecture/packages/botanical_court/BOTANICAL_IMPORT_NAME_MAP.json');mapping={r['source_name']:r['imported_name']for r in names['pairs']};expected=[mapping.get(n,n)for n in geom['objects']if n.startswith('BOTCOURT_port_PORTAL_CLOSURE_')];yes(m['opened_guard_names']==expected and len(expected)==14 and len(geom['objects'])-len(expected)==122)
checks.append('Exactly14 named Moss closure states change; all136 geometry checks and122 active guard checks survive including Nursery')
S=D/'source_intake/WP10_D06_directory_03';sp=importlib.util.spec_from_file_location('source_preview',S/'source/preview_floor.py');mod=importlib.util.module_from_spec(sp);sp.loader.exec_module(mod);v,f,mats=mod.floor_mesh_data();yes(abs(mod.verify_partition(v,f)['covered_area_m2']-3128)<1e-6)
for role in m['finish_textures']:yes(sha((C/role['file'][6:]).read_bytes())==role['sha256'])
for r in load(D/'SOURCE_GEOMETRY_INVENTORY.json')['ground_contact_meshes']:
 yes(shape.buffer(.00002).covers(box(*[r['xz_min'][0],r['xz_min'][1],r['xz_max'][0],r['xz_max'][1]])))
checks.append('Original preview partition and exact texture bytes reused on compiler top only; all inventoried source ground-contact bounds supported')
def reject(name,f):
 try:f()
 except AssertionError:negative.append(name);return
 raise AssertionError('Mutation escaped: '+name)
for name,kind,mut in [('old owner edit','c',lambda x:x['regions'][0].update(floor_y=-1)),('extra owner','c',lambda x:x['regions'].append(x['regions'][0])),('missing owner','c',lambda x:x['regions'].pop()),('new triangle edit','c',lambda x:x['regions'][-1]['triangles'][0][0].__setitem__(0,100)),('global edit','l',lambda x:x.update(rogue=True)),('reordered owners','c',lambda x:x['regions'].reverse()),('summary edit','s',lambda x:x.update(regions=279))]:
 d={'l':copy.deepcopy(layout),'c':copy.deepcopy(compiled),'s':copy.deepcopy(summary)};mut(d[kind]);reject(name,lambda d=d:structures(**d))
reject('runtime assertion weakened',lambda:recover(guard.replace('opened==14 and closed==122','opened>=14 and closed>=122')))
reject('retained guard tolerance changed',lambda:yes(recover(guard.replace('var distance: float=0.0001','var distance: float=0.001'))==prior(g).read_text()))
reject('Nursery wrongly opened',lambda:yes(expected+['BOTCOURT_starboard_PORTAL_CLOSURE_Label']==m['opened_guard_names']))
for r in manifest['files']:
 if r['path'].endswith('.gd'):parser.parse((C/r['path']).read_text())
checks.append('Grammar of every delivered and archived GDScript parsed; not Godot type checking')
r=subprocess.run([sys.executable,str(C/'tools/compile_layout.py')],capture_output=True,text=True);yes(r.returncode==0,r.stderr)
for row in manifest['files']:yes(sha((C/row['path']).read_bytes())==row['sha256'],'Recompile changed '+row['path'])
checks.append('Second compiler execution deterministic for every manifest output')
result={'status':'PASS_SOURCE_ONLY','positive_checks':checks,'negative_mutations_rejected':negative,'engine_run':False,'live_project_modified':False,'manifest_sha256':sha((W/'UNION_APPLY_MANIFEST.json').read_bytes()),'limits':manifest['open_gates']};(W/'SOURCE_VALIDATION.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
