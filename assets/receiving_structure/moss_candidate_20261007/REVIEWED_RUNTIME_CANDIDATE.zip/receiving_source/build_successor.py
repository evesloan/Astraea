from pathlib import Path
import json,hashlib,shutil,math,subprocess,sys
import shapely
from shapely.geometry import Polygon,box
from shapely.geometry.polygon import orient
D=Path(__file__).resolve().parent;L=Path('/workspace/shared/Astraea_recovery_20261007_AXWr5x/Game');M=D.parent/'movement_receiving_20261007/successor001';W=D/'successor001';C=W/'Game';T=D.parent/'team_lounge_receiving_20261007/runtime_implementation001/proof_work'
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_text())
mm=load(M/'UNION_APPLY_MANIFEST.json');overlay={r['path']:r for r in mm['files']}
def read(rel):
 p=M/'Game'/rel if rel in overlay else L/rel
 b=p.read_bytes()
 if rel in overlay: assert sha(b)==overlay[rel]['sha256']
 return b
def put(rel,data):
 p=C/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data if isinstance(data,bytes)else data.encode())
def dump(rel,d):put(rel,json.dumps(d,indent=2)+'\n')
assert not W.exists(),'Preserve prior attempt'
W.mkdir();shutil.copytree(L/'data',C/'data');shutil.copytree(L/'tools',C/'tools');(C/'docs').mkdir();(C/'assets/models').mkdir(parents=True)
shutil.copy2(L/'assets/models/AST-CUL-005_static_003.glb',C/'assets/models/AST-CUL-005_static_003.glb')
for rel in overlay:put(rel,read(rel))
newpaths=[]
for p in (D/'runtime_candidate').rglob('*'):
 if p.is_file():
  rel=p.relative_to(D/'runtime_candidate').as_posix();assert rel not in overlay and not (L/rel).exists();put(rel,p.read_bytes());newpaths.append(rel)
pre={};ret='data/architecture/packages/moss_sanctuary/retained_279/'
for rel in ['data/spatial_layout.json','data/generated/structural_meshes.json','docs/LAYOUT_COMPILE_CHECKS.json','tools/compile_layout.py','scripts/ship.gd','tests/medical_triage_successor_guard.gd','tests/validate_botanical_receiving_access.gd']:
 b=read(rel);put(ret+rel,b);pre[rel]={'sha256':sha(b),'retained_path':ret+rel}
added=[{'id':'D06_moss_sanctuary_receiving_floor','deck':'D06','kind':'amenity_receiving_floor','boundary':[[-54,-250],[-8,-250],[-8,-182],[-54,-182]],'thickness':.24,'render_cell_m':8,'priority':0,'material_role':'guest_floor','status':'Source-faithful whole Moss Sanctuary receiving candidate; runtime and final quality gates pending'}]
layout=json.loads(read('data/spatial_layout.json'));layout['regions']+=added;dump('data/spatial_layout.json',layout)
sys.path.insert(0,str(C/'tools'))
from theater_incremental_preservation import effective_shapes
elevations={r['deck_id']:r['floor_elevation_m'] for r in json.loads(read('data/design_contract.json'))['deck_datums']}
effective=effective_shapes(layout,elevations)
expected=[]
for item in added:
 shape=effective[item['id']];chunks=[];cell=8;x0,z0,x1,z1=shape.bounds
 for cx in range(math.floor(x0/cell),math.ceil(x1/cell)):
  for cz in range(math.floor(z0/cell),math.ceil(z1/cell)):
   part=shape.intersection(box(cx*cell,cz*cell,(cx+1)*cell,(cz+1)*cell))
   if part.area<1e-8:continue
   chunks.append({'id':f'cell_{cx}_{cz}','triangles':[[list(c)for c in t.exterior.coords[:3]]for t in shapely.constrained_delaunay_triangles(part).geoms]})
 expected.append({'id':item['id'],'deck':'D06','floor_y':27,'thickness':.24,'triangles':[[list(c)for c in t.exterior.coords[:3]]for t in shapely.constrained_delaunay_triangles(shape).geoms],'rings':[[list(c)for c in orient(shape,sign=1.0).exterior.coords[:-1]]],'structural_area_m2':3128.,'render_chunks':chunks,'status':item['status'],'material_role':'guest_floor'})
m=load(C/'data/architecture/moss_sanctuary/runtime_manifest.json');m['finish_top_chunks']=[r['id']for r in chunks];m['floor_record']=expected[0];dump('data/architecture/moss_sanctuary/runtime_manifest.json',m)
cp='data/architecture/packages/moss_sanctuary/MOSS_COMPILER_PROOF.json';dump(cp,{'schema':1,'programme_key':'D06_directory_03','predecessors':{k:pre[k]for k in list(pre)[:3]},'new_layout_records':added,'new_expected_compiled_records':expected,'contract_sha256':sha(read('data/design_contract.json'))})
module=read('tools/movement_studio_incremental_preservation.py').decode()
module=module.replace('preserve_movement_studio_successor','preserve_moss_sanctuary_successor').replace('packages/movement_studio/MOVEMENT_COMPILER_PROOF','packages/moss_sanctuary/MOSS_COMPILER_PROOF')
import re
module=re.sub(r"PROOF_SHA='[a-f0-9]+'",'PROOF_SHA='+repr(sha((C/cp).read_bytes())),module)
module=module.replace("{'D07_movement_studio_floor','D07_movement_studio_entry'}","{'D06_moss_sanctuary_receiving_floor'}").replace('len(new_outputs)==2','len(new_outputs)==1').replace('len(preserved)+2','len(preserved)+1').replace("row['deck']=='D07' and row['floor_y']==35.5","row['deck']=='D06' and row['floor_y']==27").replace('min(35.5,','min(27,').replace('max(35.26,','max(26.76,')
module=module.replace('outputs,preserve_lounge,preserve_botanical,preserve_triage,preserve_welcome):','outputs,preserve_movement,preserve_lounge,preserve_botanical,preserve_triage,preserve_welcome):').replace('preserved,welcome,triage,botanical,lounge=preserve_lounge(root,projected,elevations,prior_owned,old_outputs,preserve_botanical,preserve_triage,preserve_welcome)','preserved,welcome,triage,botanical,lounge,movement=preserve_movement(root,projected,elevations,prior_owned,old_outputs,preserve_lounge,preserve_botanical,preserve_triage,preserve_welcome)').replace('return preserved+new_outputs,welcome,triage,botanical,lounge,receipt','return preserved+new_outputs,welcome,triage,botanical,lounge,movement,receipt')
put('tools/moss_sanctuary_incremental_preservation.py',module)
def edit(s,a,b,ed):
 assert s.count(a)==1,(a,s.count(a));ed.insert(0,{'before':a,'after':b,'count':1});return s.replace(a,b)
inverse={};s=read('tools/compile_layout.py').decode();ed=[]
a='from movement_studio_incremental_preservation import preserve_movement_studio_successor';s=edit(s,a,a+'\nfrom moss_sanctuary_incremental_preservation import preserve_moss_sanctuary_successor',ed)
a='outputs,medical_preservation,triage_preservation,botanical_preservation,team_lounge_preservation,movement_preservation=preserve_movement_studio_successor(root,layout,elevations,owned,outputs,preserve_team_lounge_successor,preserve_botanical_court_successor,preserve_medical_triage_successor,preserve_medical_predecessor)';s=edit(s,a,a.replace('movement_preservation=preserve_movement_studio_successor','movement_preservation,moss_preservation=preserve_moss_sanctuary_successor').replace('outputs,preserve_team','outputs,preserve_movement_studio_successor,preserve_team'),ed)
a="checks['movement_studio_additive_preservation']=movement_preservation";s=edit(s,a,a+"\nchecks['moss_sanctuary_additive_preservation']=moss_preservation",ed);put('tools/compile_layout.py',s);inverse['tools/compile_layout.py']=ed
s=read('scripts/ship.gd').decode();ed=[];a='\tlighting_budget.configure(self,player)';s=edit(s,a,'\tload("res://scripts/moss_sanctuary_receiving.gd").build(self)\n'+a,ed);put('scripts/ship.gd',s);inverse['scripts/ship.gd']=ed
r=subprocess.run([sys.executable,str(C/'tools/compile_layout.py')],capture_output=True,text=True);(W/'compiler_run.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
# Runtime successor is built in the companion script, against these exact outputs.
dump('data/architecture/packages/moss_sanctuary/BUILD_CONTEXT.json',{'predecessors':pre,'added':added,'expected':expected,'exact_inverse_edits':inverse,'newpaths':newpaths,'compiler_proof':cp,'movement_manifest_sha256':sha((M/'UNION_APPLY_MANIFEST.json').read_bytes())})
print('Exact 279→280 floor compiler candidate prepared')
