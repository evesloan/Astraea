# Rebased against runtime-proven Movement279

This successor002 replaces successor001 for adoption. It retains the root’s one-call pristine-import census correction, whose complete nested actual medical_structure002 run passed with zero errors. See REBASE_RECEIPT.json. Successor001 remains untouched.

# Moss Sanctuary exact receiving successor

Whole candidate, ready for root-controlled engine gates after Movement's exact279 stage. Apply only the27 paths listed in UNION_APPLY_MANIFEST.json from this directory's Game overlay, after checking every candidate hash and expected preimage. Unlisted compiler staging files are dependencies, not deliverables. This worker made no live Game/Catalogue changes, engine/import runs, backup operations or commits.

## Implemented

- One exact3,128m² D06 floor owner, Y27/underside26.76, producing280 owners with all279 full predecessor records/order and all globals/voids unchanged. Exact current Movement compiler/runtime proof is nested rather than bypassed.
- Original WP10 revision02 geometry/materials/poses remain in the name-only inert-emitter derivative:976 mesh instances,760,942 source triangles,975 exact imported trimesh contacts. Decorative water has no contact; it uses the unchanged flowing-water shader at source-adapter speed0.12.
- Original preview_floor.py stone/ivory partition is applied only as a shader to authenticated compiler top chunks. Exact original textures, world-metre UVs, roughness and source path rectangles are retained. No duplicate floor mesh or decorative slab.
-36 source-positioned, source-oriented, fixture-bound SpotLights join the existing sole lighting manager. Initial explicit energy/range values remain unaccepted calibration, with original current8 shadow/32 visibility budget untouched.
- Two fitted information adapters use original RMB/E interaction. No invented gameplay, capacity, access rules or stock behavior.
- Exactly14 BOTCOURT_port_PORTAL_CLOSURE_ meshes are hidden and their one collision shape disabled after floor-record authentication. They are retained in hierarchy; all136 original render/contact geometry checks remain. Other122 meshes remain visible and colliding, including closed Nursery.
- The existing botanical walking check has an explicit reversible successor. All nonportal checks survive. Only Moss's portal barrier is replaced with clear opening, support, actual crossing, source-authored full public loop/care route, both real RMB/E interactions and return; five remaining actual guard bumps stay required. No player/collision/input settings are altered.

## Source validation

SOURCE_VALIDATION.json: seven positive groups and ten rejected negative mutations. Includes complete inverse recovery, pinned Movement projection, independent slab overlap/triangle/chunk conservation, original preview partition, all inventoried source-ground-contact bounds, grammar parsing and deterministic second compiler run. GDScript parsing is grammar only, not engine type checking.

The original source has420 exactly degenerate triangles. The raw-source/import comparison deliberately retains their multiplicity; there is no permissive exception if Godot drops or modifies them. First fresh-import diagnostics must establish actual fidelity.

I read AGENTS/current status/backup/master application and complete master chapter blocks4,5,21,28,32. Reopened actual source arrival pixels and REF-098 pixels; source contract and reference study govern the receiving adaptation. Existing inboard source roof/enclosure is preserved. No exterior window, skylight, neighbour aperture or internal redesign was introduced. Ground support here proves authored slab coverage, not primary structural bearing certification. Root owns current independent retention checks and source adoption.

## Engine handoff

1. Apply/verify Movement279 first, retain its unmodified evidence, then verify all Moss expected preimages before overlay. Preserve surviving edits and rebase if any differ.
2. Import the new WP10 GLB once, retain importer-generated identity/default serialization, then set only source-fidelity semantics: nodes/root_type Node3D; nodes/use_name_suffixes false; nodes/use_node_type_suffixes false; meshes/force_disable_compression true; meshes/generate_lods false; meshes/create_shadow_meshes false; meshes/ensure_tangents false; animation/import false. Do not copy another asset's UID. Refresh import. No .import files are supplied or raw-serialization-pinned; strict runtime checks verify critical settings and actual positions/UVs/winding.
3. Run existing tools/validate.py --only medical_structure first. This invokes the complete280-owner nested runtime proof including Moss/Movement/Lounge and original Botanical/Medical/Pool preservation.
4. Run tools/validate.py --only botanical_receiving_access for unchanged player support, preserved guard contacts, Moss loop/care/entry/return and information. Existing wrapper frame budget is12000; expected route total is roughly11,100 walking frames plus settle/turn overhead. If the wrapper terminates early, retain that failure and run the identical test with a30,000 frame invocation, without changing assertions or controller.
5. Run unchanged affected lighting_budget and grand_pool_access. Use current full tools/validate.py later for the aggregate gate; focused results are not aggregate acceptance.
6. Capture ordinary eye-height entry(-6,28.65,-216), source threshold(-12,28.65,-216), fore loop(-18,28.65,-234), source stream approach(-19.8,28.65,-222.2), aft loop(-18,28.65,-196), care(-42.2,28.65,-246.6), and return. Inspect default/effects-off material, roof, neighbour, portal continuity and actual water motion. Source Blender images are not runtime evidence.

Loaded-cart travel/turns, all-species fit, primary bearing, full-ship final art and target-hardware performance remain explicit gates. This package does not claim them.
