from pathlib import Path
import json,hashlib,shutil,subprocess,sys
D=Path(__file__).resolve().parent;L=Path('/workspace/shared/Astraea_recovery_20261007_AXWr5x/Game');old=D/'successor001';W=D/'successor002';C=W/'Game'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert not W.exists(),'Never overwrite a surviving candidate'
fix=json.loads((D.parent/'movement_receiving_20261007/root_apply001/raw_import_scope_fix001/RECEIPT.json').read_text());result=json.loads((D.parent/'movement_receiving_20261007/root_apply001/medical_structure002.json').read_text());assert result['passed'] and result['exit_code']==0 and not result['errors']
g='tests/medical_triage_successor_guard.gd';mp='data/architecture/packages/movement_studio/MOVEMENT_RUNTIME_PROOF.json'
assert sha((L/g).read_bytes())==fix['guard_sha256'];assert sha((L/mp).read_bytes())==fix['new_proof_sha256']
shutil.copytree(old,W)
# The already verified compiled279 predecessor is unchanged. Only its strictly bounded runtime guard/proof successor changed.
ctxpath=C/'data/architecture/packages/moss_sanctuary/BUILD_CONTEXT.json';ctx=json.loads(ctxpath.read_text());changes=[]
for rel,spec in ctx['predecessors'].items():
 data=(L/rel).read_bytes();digest=sha(data)
 if digest!=spec['sha256']:
  assert rel==g,(rel,'Unexpected predecessor change')
  changes.append({'path':rel,'old_sha256':spec['sha256'],'new_sha256':digest});(C/spec['retained_path']).write_bytes(data);spec['sha256']=digest
assert len(changes)==1
(C/mp).write_bytes((L/mp).read_bytes());ctxpath.write_text(json.dumps(ctx,indent=2)+'\n')
helper=(D/'build_runtime_proof.py').read_text().replace("C=D/'successor001/Game'","C=D/'successor002/Game'").replace("D/'successor001/UNION_APPLY_MANIFEST.json'","D/'successor002/UNION_APPLY_MANIFEST.json'")
helper=helper.replace("def oldhash(rel):return prior[rel]['sha256']if rel in prior else sha((L/rel).read_bytes())if (L/rel).is_file()else None","def oldhash(rel):return sha((L/rel).read_bytes())if (L/rel).is_file()else None")
hp=D/'build_runtime_proof002.py';hp.write_text(helper);r=subprocess.run([sys.executable,str(hp)],capture_output=True,text=True);assert r.returncode==0,r.stdout+r.stderr
receipt={'status':'REBASED_SOURCE_ONLY','source_stage_preserved':'successor001','target_stage':'successor002','predecessor_engine_result':result,'root_fix_receipt':fix,'predecessor_changes':changes,'floor_layout_compiled_unchanged':True,'live_writes':False,'engine_jobs':False,'manifest_sha256':sha((W/'UNION_APPLY_MANIFEST.json').read_bytes())};(W/'REBASE_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
