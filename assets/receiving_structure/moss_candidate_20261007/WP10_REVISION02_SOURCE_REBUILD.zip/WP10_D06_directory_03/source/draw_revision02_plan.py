"""Dimensioned source proposal diagram; does not assert actual mesh acceptance."""
from pathlib import Path
import json,ast,hashlib
P=Path(__file__).resolve().parents[1]
module=ast.parse((P/'source/revision02_landscape.py').read_text())
stream=next(ast.literal_eval(n.value) for n in module.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='STREAM' for t in n.targets))
p=P/'docs/plan_contract.json';c=json.loads(p.read_text());c['revision02_landscape']={'status':'source proposal; final native/visual gates separately required','water_mesh':'WP10_R02_STREAM_WATER_01','stream_centreline_local_uv':stream,'water_h':.28,'bed_top_h':.14,'bank_top_h':.42,'main_growing_medium_top_h':.115,'tree_root_planters_uv_top':[[29.3,18,1.0],[17.5,20.6,.72],[18.4,44,1.05],[26.4,51.8,.95]],'seated_contemplation_eye_uvh':[38.56,21.8,1.15],'no_occupied_level_change':True,'water_latest_human_authority':'correction_cycle_20261007/OWNER_DIRECTIVE.md','exterior':'real frontage opportunity remains receiving-held; directory edge is inboard'}
c['child_spaces'][1]['purpose']='Contained winding stream, moss/rock/root tiers, branching canopy and dry resting/viewing loop'
p.write_text(json.dumps(c,indent=2)+'\n')
q=[]
def add(s):q.append(s)
def text(x,y,t,size=15):add(f'<text x="{x}" y="{y}" font-size="{size}">{t}</text>')
def rect(u,v,w,h,col):add(f'<rect x="{60+u*9}" y="{100+v*9}" width="{w*9}" height="{h*9}" fill="{col}" stroke="#526153"/>')
def poly(points,col):add('<polygon points="'+' '.join(f'{60+u*9},{100+v*9}' for u,v in points)+f'" fill="{col}" stroke="#526153"/>')
add('<svg xmlns="http://www.w3.org/2000/svg" width="1250" height="880" viewBox="0 0 1250 880"><rect width="1250" height="880" fill="#f6f2e9"/><style>text{font-family:Arial;fill:#24372d}</style>')
text(35,35,'WP10 MOSS SANCTUARY — REVISION02 PLAN / SECTION',23)
text(35,62,'Prepared source geometry proposal • actual native, route, bearing and pixel gates remain separate',14)
rect(0,0,46,68,'#e9e2d3');rect(.5,.5,45,9,'#bdc8c9');rect(40.5,10,4.5,54,'#bdc8c9')
for u,v,w,h in [(7.9,10,4.2,54),(33.9,10,4.2,54),(8,9.9,30,4.2),(8,59.9,30,4.2),(0,30.8,45,6.4)]:rect(u,v,w,h,'#fffcf2')
poly([(15,14.7),(29.8,14.7),(32,20),(29.7,29.5),(16.5,29.5),(13.8,23)],'#657e45')
poly([(17,39.2),(29,40),(32,47),(29.4,57.5),(16,57.5),(13.5,49)],'#637c44')
add('<polyline points="'+' '.join(f'{60+u*9},{100+v*9}' for u,v in stream)+'" fill="none" stroke="#64715f" stroke-width="20" stroke-linejoin="round"/>')
add('<polyline points="'+' '.join(f'{60+u*9},{100+v*9}' for u,v in stream)+'" fill="none" stroke="#3f979b" stroke-width="13.5" stroke-linejoin="round"/>')
for u,v,r in [(29.3,18,1.25),(17.5,20.6,1.1),(18.4,44,2.1),(26.4,51.8,2.1)]:
 add(f'<ellipse cx="{60+u*9}" cy="{100+v*9}" rx="{r*9}" ry="{r*8}" fill="#385638" stroke="#b9a889" stroke-width="3"/>')
for u,v in [(15.3,24.1),(23,20.4),(28.9,28.4),(17,27.4),(25,43),(18.5,52.4),(27.1,56)]:add(f'<ellipse cx="{60+u*9}" cy="{100+v*9}" rx="10" ry="7" fill="#65735d" stroke="#b5bd94"/>')
for u,v in [(8,17),(8,26),(8,48),(8,58),(38.8,23),(38.8,51)]:rect(u-1,v-.4,2,.8,'#9b7757')
text(60,90,'u0 axial side → u46 outboard (inboard of hull)',13);text(60,730,'46m allocation width;68m fore-to-aft extent',14)
text(66,135,'COOL CARE / STOCK',13);text(105,402,'LEVEL ENTRY / DRY CROSS ROUTE',12);text(220,610,'QUIET GROVE',13)
text(525,115,'WORLD INTERFACE',17)
for j,t in enumerate(['X−54..−8 / Z−250..−182','FloorY27; next occupied datumY35.5','Portal[−8,27,−216]; external4m link UNBUILT','Local(u,v,h) → (−8−u,27+h,−250+v)','Blue: contained1.5m stream; UV.y downstream','Green: continuous rooted low growth with tiered trees','White: level guest/custodial routes','Seats retained; east fore rests now face landscape','Exact west seated-eye view(38.56,21.8,1.15)','Care route and growing beds remain separate']):text(525,143+j*25,t,14)
text(525,430,'LANDSCAPE SECTION — DIMENSIONS IN METRES',17)
add('<line x1="540" y1="680" x2="1180" y2="680" stroke="#354234" stroke-width="3"/>')
text(545,705,'Y27 receiving floor; source preview only',13)
def sr(x,width,bottom,top,col):add(f'<rect x="{x}" y="{680-top*170}" width="{width}" height="{(top-bottom)*170}" fill="{col}" stroke="#485943"/>')
sr(550,120,0,.115,'#657e45');sr(680,170,.025,.14,'#686f60');sr(675,20,.025,.42,'#65715d');sr(835,20,.025,.42,'#65715d');sr(900,140,0,.9,'#baa989')
add('<line x1="695" y1="632.4" x2="835" y2="632.4" stroke="#39939a" stroke-width="5"/>')
text(550,630,'soil.115',12);text(713,612,'water.28',12);text(704,667,'bed.14',12);text(853,600,'bank.42',12);text(900,510,'root tier.90',12)
text(525,756,'Trees root into actual soil; rock toes and moss roots intersect growing medium.',13)
text(525,780,'No crossing slab cut, occupied step, false skylight or invented exterior window.',13)
text(35,830,'Schematic derived from current constructor coordinates; not a substitute for evaluated mesh/support/pixel evidence.',14)
add('</svg>');(P/'docs/plan_section.svg').write_text('\n'.join(q),encoding='utf8')
print('WP10 revision02 source-plan and landscape section written')
