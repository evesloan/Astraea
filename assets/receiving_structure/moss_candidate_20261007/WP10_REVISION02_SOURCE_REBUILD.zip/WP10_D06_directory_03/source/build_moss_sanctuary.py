"""Portable WP10 source-only moss sanctuary builder. Blender 4.3.2, bundled inputs only.
Native editable asset collections retained; evaluated exchange proxies share meshes.
No main-game imports/adoption. Heavy job: coordinator must schedule execution.
"""
import bpy, bmesh, json, math, hashlib, random
from pathlib import Path
from mathutils import Vector, Matrix

P=Path(__file__).resolve().parents[1]
ID='WP10_D06_directory_03'; PROGRAMME='D06_directory_03'
for record in json.loads((P/'assets/dependencies.json').read_text()):
    assert hashlib.sha256((P/record['file']).read_bytes()).hexdigest()==record['sha256'],record
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
s=bpy.context.scene;s.unit_settings.system='METRIC';s.unit_settings.scale_length=1
s.render.threads_mode='FIXED';s.render.threads=12;s.cycles.device='CPU'
s.render.engine='CYCLES';s.cycles.samples=24;s.cycles.use_denoising=True
s.render.resolution_x=1280;s.render.resolution_y=800;s.render.resolution_percentage=100
s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs[0].default_value=(.11,.15,.18,1)
s.world.node_tree.nodes['Background'].inputs[1].default_value=.06;s.view_settings.view_transform='AgX'
M={};material_records=json.loads((P/'assets/materials/material_manifest.json').read_text())['materials']
for role,r in material_records.items():
    m=bpy.data.materials.new('WP10_'+role);m.use_nodes=True;m['astraea_material_role']=role;m['meters_per_tile_uv']=r['meters_per_tile_uv']
    bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Roughness'].default_value=r['roughness'];bs.inputs['Metallic'].default_value=r['metallic']
    image=bpy.data.images.load(str(P/'assets/materials'/r['base_color_file']),check_existing=True);image.pack()
    tex=m.node_tree.nodes.new('ShaderNodeTexImage');tex.image=image;tex.interpolation='Closest';m.node_tree.links.new(tex.outputs['Color'],bs.inputs['Base Color']);M[role]=m
def simple(name,color,emission=0):
    m=bpy.data.materials.new(name);m.use_nodes=True;bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*color,1);bs.inputs['Roughness'].default_value=.72
    if emission:bs.inputs['Emission Color'].default_value=(*color,1);bs.inputs['Emission Strength'].default_value=emission
    M[name]=m;return m
simple('soil',(.12,.095,.062));simple('opal',(1,.86,.62),2);simple('daylight',(.78,.88,1),2)
# Original restrained mulch texture: packed pixels, stable metre scale, visible growing medium.
soil_image=bpy.data.images.new('WP10_original_dark_mulch',width=64,height=64)
soil_rng=random.Random(60321);pixels=[]
for i in range(64*64):
    grain=soil_rng.choice([.68,.84,1.0,1.15,1.30]);pixels.extend((.115*grain,.076*grain,.043*grain,1))
soil_image.pixels=pixels;soil_image.pack()
soil_tex=M['soil'].node_tree.nodes.new('ShaderNodeTexImage');soil_tex.image=soil_image;soil_tex.interpolation='Closest'
M['soil'].node_tree.links.new(soil_tex.outputs['Color'],M['soil'].node_tree.nodes['Principled BSDF'].inputs['Base Color'])
M['soil']['meters_per_tile_uv']=[.35,.35]
W=lambda u,v,h:Vector((-8-u,250-v,27+h))
records=[];fixtures=[];markers=[];instances=[];templates={}
def uv_mesh(me,role):
    uv=me.uv_layers.active or me.uv_layers.new(name='metric_material_uv');scale=material_records.get(role,{}).get('meters_per_tile_uv',[.35,.35] if role=='soil' else [1,1])
    for face in me.polygons:
        ax=max(range(3),key=lambda k:abs(face.normal[k]));axes=[i for i in range(3) if i!=ax]
        for li in face.loop_indices:
            co=me.vertices[me.loops[li].vertex_index].co;uv.data[li].uv=(co[axes[0]]/scale[0],co[axes[1]]/scale[1])
def finish(o,name,role,bevel=0):
    o.name='WP10_'+name;o['programme_key']=PROGRAMME;o['package_id']=ID;o['role']=role;o.data.materials.append(M[role])
    if o.type=='MESH':
        uv_mesh(o.data,role)
        if bevel:
            mod=o.modifiers.new('Editable edge easing','BEVEL');mod.width=bevel;mod.segments=2
            o.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
    return o
def box(name,u,v,h,du,dv,dh,role,bevel=.03):
    bpy.ops.mesh.primitive_cube_add(size=1,location=W(u,v,h));o=bpy.context.object;o.dimensions=(du,dv,dh);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,name,role,bevel)
def cylinder(name,u,v,h,r,depth,role,n=20):
    bpy.ops.mesh.primitive_cylinder_add(vertices=n,radius=r,depth=depth,location=W(u,v,h));return finish(bpy.context.object,name,role,.02)
def beam(name,a,b,width,depth,role):
    a,b=W(*a),W(*b);mid=(a+b)/2
    bpy.ops.mesh.primitive_cube_add(size=1,location=mid);o=bpy.context.object;o.dimensions=(width,depth,(b-a).length);o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,name,role,.025)
def marker(name,u,v,h,kind,**extra):
    o=bpy.data.objects.new('WP10_MARK_'+name,None);s.collection.objects.link(o);o.location=W(u,v,h);o['kind']=kind;o['programme_key']=PROGRAMME
    markers.append({'id':o.name,'kind':kind,'world_godot':[-8-u,27+h,-250+v],**extra});return o
def area(name,u,v,h,power,size=3,color=(.82,.90,1)):
    d=bpy.data.lights.new(name,'SPOT');d.energy=power;d.spot_size=math.radians(115);d.spot_blend=.65;d.shadow_soft_size=size*.2;d.color=color
    o=bpy.data.objects.new('WP10_LIGHT_'+name,d);s.collection.objects.link(o);o.location=W(u,v,h)
    fixtures.append({'id':o.name,'world_godot':[-8-u,27+h,-250+v],'watts':power,'source':'Visible physically mounted luminaire; exported KHR_lights_punctual spot. Higgins applies current runtime light budget.'})
    return o
def pendant(name,u,v,mount,bottom=3.7,power=190):
    if name in {'care_route','stock_general'}:
        for du in [-.65,.65]:
            box(name+'_mount',u+du,v,mount-.04,.22,.22,.08,'ivory_enamel')
            beam(name+'_drop',(u+du,v,mount-.07),(u+du,v,bottom+.08),.05,.05,'champagne_metal')
        box(name+'_housing',u,v,bottom+.06,1.8,.45,.18,'ivory_enamel')
        box(name+'_diffuser',u,v,bottom-.04,1.6,.33,.025,'daylight',.006)
        area(name,u,v,bottom-.07,power,1.2,(.76,.88,1));marker(name+'_mount',u,v,mount,'fixture_contact')
        return
    cylinder(name+'_mount',u,v,mount-.06,.15,.12,'champagne_metal')
    cylinder(name+'_stem',u,v,(mount+bottom)/2,.035,mount-bottom,'champagne_metal',12)
    cylinder(name+'_shade',u,v,bottom+.10,.40,.2,'champagne_metal')
    cylinder(name+'_diffuser',u,v,bottom-.012,.345,.035,'opal')
    area(name,u,v,bottom-.06,power,.7,(1,.78,.48));marker(name+'_mount',u,v,mount,'fixture_contact')
def text(name,body,u,v,h,size=.25,facing='south'):
    cu=bpy.data.curves.new(name,'FONT');cu.body=body;cu.size=size;cu.align_x='CENTER';cu.extrude=.003
    # Local text Y must remain vertical +Z. North-facing signs use local X=-world X.
    # The old negative-X rotation inverted the glyphs when seen from the public approach.
    o=bpy.data.objects.new('WP10_'+name,cu);s.collection.objects.link(o);o.location=W(u,v,h);o.rotation_euler=(math.pi/2,0,math.pi) if facing=='south' else (math.pi/2,0,-math.pi/2)
    o.data.materials.append(M['champagne_metal']);o['programme_key']=PROGRAMME;return o
def ellipsoid_plinth(name,u,v,ru,rv,top):
    # Closed polygonal island with substantial coping, actual soil and stepped beds.
    for suffix,h,depth,scale,mat in [('base',top/2,top,1,'warm_stone'),('soil',top+.005,.03,.94,'soil')]:
        o=cylinder(name+'_'+suffix,u,v,h,1,depth,mat,24);o.scale.x=ru*scale;o.scale.y=rv*scale;bpy.context.view_layer.objects.active=o;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
        uv_mesh(o.data,mat)
        if suffix=='base':o['collision_proposal']='solid planter; foliage separate'
    # Real annular coping; a full disc would bury the soil and root support surface.
    n=32;verts=[];faces=[]
    for h in [top-.03,top+.08]:
        for scale in [.93,1.035]:
            for i in range(n):
                a=2*math.pi*i/n;verts.append(tuple(W(u+ru*scale*math.cos(a),v+rv*scale*math.sin(a),h)))
    for i in range(n):
        j=(i+1)%n
        faces.extend([(i,j,n+j,n+i),(2*n+i,3*n+i,3*n+j,2*n+j),(i,2*n+i,2*n+j,j),(n+i,n+j,3*n+j,3*n+i)])
    me=bpy.data.meshes.new(name+'_open_coping');me.from_pydata(verts,[],faces);me.update()
    bm=bmesh.new();bm.from_mesh(me);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(me);bm.free();me.update()
    o=bpy.data.objects.new('WP10_'+name+'_open_coping',me);s.collection.objects.link(o);finish(o,name+'_open_coping','ivory_enamel',.018)
    marker(name+'_soil',u,v,top+.02,'soil_support')
def template(asset):
    if asset in templates:return templates[asset]
    with bpy.data.libraries.load(str(P/'assets/native'/f'{asset}.blend'),link=False) as (available,dst):dst.objects=available.objects
    loaded=[o for o in dst.objects if o]
    temp=bpy.data.collections.new('TEMP_EVALUATE_'+asset);s.collection.children.link(temp)
    for ob in loaded:temp.objects.link(ob)
    bpy.context.view_layer.update()
    obs=[o for o in loaded if o.type in {'MESH','CURVE','FONT'}]
    cached={o.name:o.matrix_world.copy() for o in obs}
    assert obs,asset
    col=bpy.data.collections.new('EDITABLE_RETAINED_'+asset)
    for ob in obs:
        world=cached[ob.name];ob.parent=None;ob.matrix_world=world;col.objects.link(ob)
    s.collection.children.unlink(temp);bpy.data.collections.remove(temp)
    templates[asset]=col;return col
def reuse(asset,name,u,v,h=0,angle=0):
    o=bpy.data.objects.new('WP10_'+name,None);s.collection.objects.link(o);o.instance_type='COLLECTION';o.instance_collection=template(asset);o.location=W(u,v,h);o.rotation_euler.z=math.radians(angle)
    o['retained_catalogue_id']=asset;o['programme_key']=PROGRAMME;o['package_id']=ID;instances.append((o,asset));return o

# New WP10 architecture. Infrastructure above retains immutable native components only.
def prism(name,poly,bottom,top,role):
    n=len(poly);verts=[tuple(W(u,v,h)) for h in [bottom,top] for u,v in poly]
    faces=[tuple(reversed(range(n))),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update()
    bm=bmesh.new();bm.from_mesh(me);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(me);bm.free();me.update()
    o=bpy.data.objects.new(name,me);s.collection.objects.link(o);return finish(o,name,role,.02)

def garden(name,poly,top):
    cu=sum(a for a,b in poly)/len(poly);cv=sum(b for a,b in poly)/len(poly)
    inside=[(cu+(u-cu)*.955,cv+(v-cv)*.955) for u,v in poly]
    prism(name+'_contained_base',poly,0,top-.04,'warm_stone')
    prism(name+'_visible_growing_medium',inside,top-.055,top,'soil')
    # Closed four-sided rim strips leave actual visible soil, never a filled coping disc.
    for i in range(len(poly)):
        j=(i+1)%len(poly);prism(name+'_rim', [poly[i],poly[j],inside[j],inside[i]],top-.07,top+.06,'ivory_enamel')
    marker(name+'_soil',cu,cv,top,'soil_support',contained=True)
    return inside

def within(u,v,poly):
    hit=False;j=len(poly)-1
    for i in range(len(poly)):
        a,b=poly[i];c,d=poly[j]
        if ((b>v)!=(d>v)) and u<(c-a)*(v-b)/(d-b)+a:hit=not hit
        j=i
    return hit

def planted(name,poly,top,seed,spacing=.78):
    inner=garden(name,poly,top);rng=random.Random(seed);index=0
    cu=sum(a for a,b in inner)/len(inner);cv=sum(b for a,b in inner)/len(inner)
    # Density belongs to low growth; tall fans occur as restrained grouped accents.
    xmin=min(a for a,b in inner);xmax=max(a for a,b in inner);ymin=min(b for a,b in inner);ymax=max(b for a,b in inner)
    row=0;v=ymin+.45
    while v<ymax-.3:
        u=xmin+.45+(row%2)*spacing*.5
        while u<xmax-.3:
            uu=u+rng.uniform(-.1,.1);vv=v+rng.uniform(-.1,.1)
            if name=='aft_court' and any(math.hypot(uu-tu,vv-tv)<2.8 for tu,tv in [(18.4,44),(26.4,51.8),(25,43),(18.5,52.4),(27.1,56)]):
                u+=spacing;continue
            if all(within(uu+dx,vv+dy,inner) for dx,dy in [(0,0),(.5,0),(-.5,0),(0,.5),(0,-.5)]):
                asset='AST-BOT-003' if rng.random()<.62 else ('AST-BOT-002' if rng.random()<.82 else 'AST-BOT-009')
                reuse(asset,name+'_low_'+str(index),uu,vv,top+.005,rng.randrange(360));index+=1
            u+=spacing
        v+=spacing;row+=1
    return index

# One continuous material-indexed preview surface: no coincident inlay geometry.
# All vertices lie at the proposed floor datum Y27, excluded from exchange export.
import sys
sys.path.insert(0,str(P/'source'))
from preview_floor import floor_mesh_data, verify_partition
floor_uv,floor_faces,floor_materials=floor_mesh_data()
floor_proof=verify_partition(floor_uv,floor_faces)
floor_mesh=bpy.data.meshes.new('WP10_preview_floor_partition')
floor_mesh.from_pydata([tuple(W(u,v,0)) for u,v in floor_uv],[],floor_faces);floor_mesh.update()
floor=bpy.data.objects.new('WP10_SOURCE_PREVIEW_ONLY_floor',floor_mesh);s.collection.objects.link(floor)
finish(floor,'SOURCE_PREVIEW_ONLY_floor','warm_stone')
floor_mesh.materials.append(M['ivory_enamel'])
for face,material_index in zip(floor_mesh.polygons,floor_materials):face.material_index=material_index
floor['SOURCE_PREVIEW_ONLY']=True
floor['preview_floor_partition']='single shared-vertex surface; stone/ivory per-face; no overlapping inlays'
floor_proof.update({'surface_world_y':27,'SOURCE_PREVIEW_ONLY':True,'exported':False})
(P/'qa/preview_floor_build_check.json').write_text(json.dumps(floor_proof,indent=2)+'\n')
# Opaque protected allocation; only the agreed axial aperture is omitted.
box('outer_port_wall',45.75,34,4,.5,68,8,'ivory_enamel')
for v in [.25,67.75]:box('end_enclosure',23,v,4,45,.5,8,'ivory_enamel')
box('axial_fore_return',.25,15.85,4,.5,31.7,8,'ivory_enamel')
box('axial_aft_return',.25,52.15,4,.5,31.7,8,'ivory_enamel')
box('portal_header',.25,34,5.8,.5,4.6,4.4,'ivory_enamel')
box('protected_opaque_roof',23,34,8.06,45.5,67.5,.28,'ivory_enamel')
marker('public_portal',0,34,0,'uninstalled_boundary_aperture',width=4.2,height=3.6,external_link='X-8..-4 UNBUILT PARENT OWNED')
# Entry is a thick supported shallow vault, not unsupported decoration.
for v in [31.65,36.35]:
    box('entry_jamb',2.8,v,1.8,5.1,.5,3.6,'warm_walnut',.07)
    box('entry_foot',2.8,v,.14,5.2,.62,.28,'warm_stone')
box('entry_lintel',2.8,34,3.85,5.1,5.2,.5,'warm_walnut',.07)
box('entry_luminaire_housing',3.3,34,3.62,3.6,.65,.18,'champagne_metal')
box('entry_luminaire_diffuser',3.3,34,3.515,3.3,.52,.025,'opal')
area('entry',3.3,34,3.49,500,2,(1,.84,.65))
# Entry-side identity stands clear of the perpendicular quiet screen at u4.6..8.4.
# Face normal is +sourceX toward the axial arrival; native text stays editable.
box('identity_backboard',3.8,39.3,2.3,.16,4.7,.85,'warm_walnut')
for v in [37.15,41.45]:box('identity_post',3.8,v,1.2,.14,.14,2.4,'champagne_metal')
o=text('identity','MOSS SANCTUARY',3.705,39.3,2.12,.28,'east');o.rotation_euler=(math.pi/2,0,math.pi/2)
o.data.materials.clear();o.data.materials.append(M['ivory_enamel'])
# Real picture-light assembly bears into the sign face, clear of the public dry loop.
for v in [38,40.6]:
    box('identity_light_mount_plate',3.7,v,2.56,.07,.18,.24,'champagne_metal',.008)
    beam('identity_light_riser',(3.685,v,2.56),(3.685,v,3.02),.035,.045,'champagne_metal')
    beam('identity_light_projecting_arm',(3.685,v,3.02),(3.22,v,3.02),.035,.045,'champagne_metal')
    marker('identity_light_mount',3.72,v,2.56,'fixture_contact',bearing='Sign backboard front face, u3.72')
box('identity_light_housing',3.22,39.3,2.975,.22,4.3,.13,'champagne_metal',.018)
box('identity_light_diffuser',3.22,39.3,2.902,.17,4.15,.016,'opal',.006)
for v in [38,39.3,40.6]:
    lamp=area('identity_picture_light',3.22,v,2.88,55,.45,(1,.90,.73))
    lamp.data.spot_size=math.radians(60)
    lamp.rotation_euler=(W(3.705,v,2.29)-lamp.location).to_track_quat('-Z','Y').to_euler()
# Opaque artificial daylight ceilings sit in complete supported frames.
for court,cv,span_v,mount in [('fore',22,24,6.7),('aft',49,24,6.2)]:
    supports_v=[15,30] if court=='fore' else [38,59]
    for u in [13.2,32.8]:
        for v in supports_v:
            box(court+'_stone_plinth',u,v,.18,.9,.95,.36,'warm_stone',.06)
            box(court+'_bearing_pier',u,v,(mount-.5)/2,.62,.7,mount-.5,'ivory_enamel',.07)
            box(court+'_capital',u,v,mount-.45,1.0,1.0,.25,'champagne_metal')
        beam(court+'_longitudinal_rail',(u,cv-span_v/2,mount-.28),(u,cv+span_v/2,mount-.28),.52,.52,'warm_walnut')
    for v in supports_v:
        beam(court+'_cross_rail',(13.2,v,mount-.25),(32.8,v,mount-.25),.6,.48,'ivory_enamel')
        for u,sgn in [(13.2,1),(32.8,-1)]:beam(court+'_visible_haunch',(u,v,mount-1.25),(u+sgn*2.5,v,mount-.25),.24,.38,'champagne_metal')
    for u in [13.2,32.8]:
        for base,end in [(supports_v[0],cv-span_v/2),(supports_v[1],cv+span_v/2)]:beam(court+'_long_haunch',(u,base,mount-1.1),(u,end,mount-.28),.24,.30,'champagne_metal')
    box(court+'_opaque_canopy',23,cv,mount+.12,24,span_v+.6,.24,'ivory_enamel')
    # 12x24m original coffer, datum localZ0 hanging down, physically on canopy underside.
    reuse('AST-ATR-002',court+'_retained_artificial_daylight',23,cv,mount)
    for u in [17,29]:
        for v in [cv-10,cv+10]:box(court+'_coffer_socket',u,v,mount-.05,.4,.5,.3,'champagne_metal')
    for v in [cv-7,cv,cv+7]:area(court+'_daylight',23,v,mount-.70,2200,4.5,(.83,.92,1))
    # Exposed timber borders are supported by primary rails, never a floating ceiling curl.
    for u in [13.5,32.5]:box(court+'_timber_border',u,cv,mount-.1,2.6,span_v,.22,'warm_walnut')
# Lower quiet-edge canopy is carried on paired piers; its end surfaces are visible.
for cv in [20,51]:
    box('quiet_edge_soffit',5.2,cv,4.3,8.5,18,.24,'warm_walnut')
    for u in [1.2,6.8]:
        for v in [cv-8.6,cv+8.6]:
            box('quiet_edge_pier',u,v,2.08,.45,.45,4.16,'ivory_enamel')
            box('quiet_edge_capital',u,v,4.13,.7,.7,.17,'champagne_metal')
    for v in [cv-5,cv+4]:pendant('quiet_seat_task',6.5,v,4.18,3.1,420)
# Screened care band, its open internal doorways avoid the public seated pockets.
for lo,hi in [(10,32.2),(35.8,57.2),(60.8,64)]:
    box('care_screen',40.2,(lo+hi)/2,1.65,.32,hi-lo,3.3,'warm_walnut')
for v in [34,59]:
    box('care_opening_head',40.2,v,3.5,.5,4,.4,'ivory_enamel')
    marker('internal_care_opening',40.2,v,0,'internal_care_aperture',width=3.6,height=3.3)
box('care_screen_bearing_rail',40.2,37,3.45,.5,54,.3,'champagne_metal')
box('care_band_soffit',42.8,37,3.75,5.3,54,.3,'ivory_enamel')
for v in [16,28,42,55,62]:pendant('care_route',43,v,3.6,2.95,300)
# Workroom at fore end; solid screen with two entrances from dry route.
for lo,hi in [(.5,8.2),(11.8,41.2)]:box('workroom_screen',(lo+hi)/2,9.9,1.7,hi-lo,.3,3.4,'ivory_enamel')
box('workroom_screen_head_rail',23,9.9,3.49,45,.5,.35,'ivory_enamel')
box('workroom_soffit',23,5,3.7,45,9.4,.25,'ivory_enamel')
for u in [10,43]:marker('workroom_opening',u,9.9,0,'internal_care_aperture',width=3.6,height=3.4)
for u in [8,20,32,42]:pendant('stock_general',u,5,3.575,2.95,360)
for u in [18,21,24]:reuse('AST-STF-007','supply_cabinet',u,2.1,0,180)
box('care_worktop',29,4.5,1.02,5.8,1.4,.14,'warm_stone')
for u in [26.6,31.4]:box('care_worktop_support',u,4.5,.475,.44,1.1,.95,'warm_walnut')
for u in [27,31]:
    beam('care_lamp_drop',(u,4.5,3.575),(u,4.5,2.65),.035,.035,'champagne_metal')
    cylinder('care_lamp_mount',u,4.5,3.54,.14,.07,'champagne_metal')
box('care_task_housing',29,4.5,2.65,4.5,.35,.18,'champagne_metal')
box('care_task_diffuser',29,4.5,2.548,4.3,.27,.024,'daylight')
for u in [27.6,30.4]:area('care_worktop',u,4.5,2.525,300,1.8)
for u in [8,13,36]:
    for h in [.35,1.1,1.85,2.6]:box('stock_shelf',u,1.35,h,3.8,.75,.09,'warm_walnut')
    for uu in [u-1.75,u+1.75]:box('stock_shelf_post',uu,1.35,1.35,.10,.75,2.7,'champagne_metal')
    for i in range(4):
        for h in [1.325,2.075]:box('sealed_supply_bin',u-1.35+i*.9,1.35,h,.65,.5,.36,'ivory_enamel')
for u in [27,28,30]:
    box('care_tray',u,4.5,1.13,.7,.6,.08,'champagne_metal')
    box('care_tray_medium',u,4.5,1.178,.58,.48,.018,'soil')
marker('care_work_stance',29,6.1,0,'work_stance');marker('cart_park',37.8,6,0,'parking_target',footprint=[2,3])
# Large irregular groundcover beds with differentiated long and short edges.
import revision02_landscape as r02
r02.forecourt(globals())
planted('aft_court',[(17,39.2),(29,40),(32,47),(29.4,57.5),(16,57.5),(13.5,49)],.42,1011,.73)
planted('quiet_fore_edge',[(1.6,12),(3.8,12),(4.4,17),(3.8,27),(1.6,27)],.42,1012,.66)
planted('quiet_aft_edge',[(1.6,41),(3.3,41),(3.5,56),(2.7,61),(1.6,61)],.42,1013,.66)
for i,(u,v) in enumerate([(21,41),(29,46),(23,55)]):
    reuse('AST-BOT-007','grouped_fan_accent',u,v,.425,i*47)
# Retained joined seat roots are planted only inside their documented soil opening.
def bench_group(name,u,v,corner=False,angle=0):
    # Original native positiveX/positiveY converted through actual retained rotation.
    a=math.radians(angle)
    def local(x,y):return u-(x*math.cos(a)-y*math.sin(a)),v-(x*math.sin(a)+y*math.cos(a))
    reuse('AST-BOT-004',name+'_straight',u,v,0,angle)
    for off in [.42,1.2,1.98]:
        pu,pv=local(off,.515);reuse('AST-BOT-003',name+'_soil_rosette',pu,pv,.39,angle)
    if corner:
        pu,pv=local(2.4,0);reuse('AST-BOT-005',name+'_quarter',pu,pv,0,angle)
        for aa in [-65,-30]:
            aa=math.radians(aa);pu,pv=local(2.4+.85*math.cos(aa),1.4+.85*math.sin(aa));reuse('AST-BOT-003',name+'_corner_rosette',pu,pv,.39,angle)
        pu,pv=local(3.8,1.4);reuse('AST-BOT-006',name+'_terminal',pu,pv,0,angle+90)
    else:
        pu,pv=local(2.4,0);reuse('AST-BOT-006',name+'_terminal',pu,pv,0,angle)
    pu,pv=local(-.035,.265)
    o=box(name+'_start_closure',pu,pv,.235,.07,1.03,.47,'ivory_enamel',.008);o.rotation_euler.z=a
    pu,pv=local(1.2,-.24);marker(name+'_seat_contact',pu,pv,.47,'seat_top')
    pu,pv=local(-.8,-.4);marker(name+'_companion_space',pu,pv,0,'clear_rest_space',footprint=[1.5,1.5])
for i,(u,v,corner,angle) in enumerate([(8,17,False,-90),(8,26,False,-90),(8,48,True,0),(8,58,False,0),(38.8,23,False,90),(38.8,51,False,90)]):bench_group('rest_'+str(i),u,v,corner,angle)
# Native garden lanterns have ground feet; exported spot originates just below actual hood.
for i,(u,v) in enumerate([(12.8,14),(33,29),(12.7,41),(33.5,58),(38.5,36)]):
    reuse('AST-GAR-002','path_lantern',u,v,0)
    area('path_lantern',u-.42,v,2.94,260,.8,(1,.80,.52))
    marker('path_lantern_foot',u,v,0,'fixture_contact')
# Mounted wall lanterns on tangible quiet screens, each backed rather than floating.
for u,v in [(6.5,11.2),(6.5,40.2),(37.8,64.5)]:
    box('quiet_lantern_backing',u,v,1.55,3.8,.22,3.1,'warm_walnut')
    reuse('AST-LGT-001','quiet_wall_lantern',u,v+.13,1.5,0)
    lamp=area('wall_lantern',u,v+.44,1.95,90,.35,(1,.80,.56))
    lamp.rotation_euler=(W(u,v+2,1.0)-lamp.location).to_track_quat('-Z','Y').to_euler()
# Local upper-edge lights illuminate the outer seat pockets as well as main courts.
for u,v in [(37.8,21),(37.8,49)]:
    box('seat_light_pier',39.3,v,1.7,.35,.4,3.4,'warm_walnut')
    beam('seat_light_bracket',(39.3,v,3.35),(u,v,3.35),.16,.18,'champagne_metal')
    pendant('outer_seat_task',u,v,3.35,2.8,300)

r02.final_details(globals())

camera_specs={'arrival':((4.7,34,1.68),(23,23,2.6)), 'court':((10,29,1.68),(24,20,2.4)), 'sheltered':((35.5,57,1.68),(22,47,2.4)), 'quiet':((8,44,1.68),(5.8,48.5,1.15)), 'care':((34,7.2,1.68),(25.5,3.6,1.25)), 'mounts':((10,34,1.68),(22,23,6.5)), 'loop':((36,35.7,1.68),(35,58,2.1)), 'section':((65,75,42),(23,34,2))}
camera_specs.update({'stream':((11.4,25.5,1.68),(23,22.7,1.25)), 'contemplation':((38.56,21.8,1.15),(23.0,22.7,.5)), 'joinery':((5.8,28,1.68),(.7,24,1.9)), 'care_detail':((34.2,3.8,1.68),(34.2,1.9,1.55))})
for key,(pos,target) in camera_specs.items():
    d=bpy.data.cameras.new('WP10_'+key);d.lens=23 if key!='mounts' else 28
    o=bpy.data.objects.new('WP10_'+key,d);s.collection.objects.link(o);o.location=W(*pos);o.rotation_euler=(W(*target)-o.location).to_track_quat('-Z','Y').to_euler()
s.camera=bpy.data.objects['WP10_arrival'];s['acceptance']='SOURCE ONLY: isolated preview floor; no live connection/runtime acceptance'
for image in bpy.data.images:
    if image.source=='FILE' and image.users and not image.packed_file:image.pack()
native=P/'source/WP10_moss_sanctuary.blend';bpy.ops.wm.save_as_mainfile(filepath=str(native),compress=True)

# Native source remains editable. Exchange builds one evaluated mesh per retained family.
def compact_asset(asset,col):
    s.collection.children.link(col);bpy.context.view_layer.update();deps=bpy.context.evaluated_depsgraph_get()
    vertices=[];faces=[];mat_indices=[];uv_faces=[];materials=[]
    for ob in list(col.objects):
        me=bpy.data.meshes.new_from_object(ob.evaluated_get(deps),depsgraph=deps);transform=ob.matrix_world;offset=len(vertices)
        vertices.extend(tuple(transform@v.co) for v in me.vertices)
        source_uv=me.uv_layers.active
        for f in me.polygons:
            faces.append(tuple(offset+j for j in f.vertices))
            material=me.materials[f.material_index] if me.materials else M['ivory_enamel']
            if material not in materials:materials.append(material)
            mat_indices.append(materials.index(material))
            uv_faces.append([tuple(source_uv.data[li].uv) if source_uv else (me.vertices[me.loops[li].vertex_index].co.x,me.vertices[me.loops[li].vertex_index].co.z) for li in f.loop_indices])
        bpy.data.meshes.remove(me)
    me=bpy.data.meshes.new('EXCHANGE_SHARED_'+asset);me.from_pydata(vertices,[],faces);me.update()
    for material in materials:me.materials.append(material)
    uv=me.uv_layers.new(name='retained_metric_uv')
    for i,f in enumerate(me.polygons):
        f.material_index=mat_indices[i]
        for li,co in zip(f.loop_indices,uv_faces[i]):uv.data[li].uv=co
    s.collection.children.unlink(col);return me
meshes={asset:compact_asset(asset,col) for asset,col in templates.items()}
for old,asset in instances:
    ob=bpy.data.objects.new(old.name,meshes[asset]);s.collection.objects.link(ob);ob.matrix_world=old.matrix_world.copy()
    for key,value in old.items():ob[key]=value
    bpy.data.objects.remove(old,do_unlink=True)
# Convert original text/curves so export includes visible signage and valid UVs.
for ob in list(s.objects):
    if ob.type in {'FONT','CURVE'}:
        bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob;bpy.ops.object.convert(target='MESH');uv_mesh(bpy.context.object.data,'champagne_metal')
bpy.ops.object.select_all(action='DESELECT')
for ob in s.objects:
    if ob.type in {'MESH','LIGHT','EMPTY'} and not ob.get('SOURCE_PREVIEW_ONLY'):ob.select_set(True)
bpy.ops.export_scene.gltf(filepath=str(P/'exports/WP10_moss_sanctuary.glb'),export_format='GLB',use_selection=True,export_yup=True,export_apply=True,export_extras=True,export_lights=True,export_cameras=False)
report={'status':'SOURCE ONLY built; independent export/source/visual review pending','programme_key':PROGRAMME,'world_coordinates':True,'glb_world_placement':[0,0,0],'blender_to_glb':'(x,y,z)->(x,z,-y)','allocation':{'x':[-54,-8],'z':[-250,-182],'y':[27,35.5]},'native_sha256':hashlib.sha256(native.read_bytes()).hexdigest(),'glb_sha256':hashlib.sha256((P/'exports/WP10_moss_sanctuary.glb').read_bytes()).hexdigest(),'retained_instances':len(instances),'retained_families':sorted(templates),'fixtures':fixtures,'markers':markers,'review_cameras':camera_specs,'preview_floor_exported':False,'integration_held':True,'floor_proposal':{'boundary_xz':[[-54,-250],[-8,-250],[-8,-182],[-54,-182]],'surface_y':27,'owner':'Higgins must allocate compiler ownership','receiving_link':'X-8..-4 UNBUILT and excluded'},'limits':['No live ship traversal or controls','External service routes sealed/planned','No atmosphere/fluid/NPC/care gameplay claim','Candidate supports not structural certification','Actual source appearance must be reviewed']}
(P/'qa/build_manifest.json').write_text(json.dumps(report,indent=2)+'\n')
print('WP10_BUILD_SOURCE_ONLY_COMPLETE',len(instances),'retained instances',len(fixtures),'mounted light sources')
