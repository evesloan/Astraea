"""Original revision02 landscape and craft, kept local to the source candidate.
No live interaction binding, fluid simulation, pressure-hull or floor authority.
"""
import bpy, json, math, random
from mathutils import Vector

STREAM=[(17.1,16.5),(20.0,17.0),(23.7,17.7),(26.6,19.1),(27.0,21.2),
        (24.8,22.7),(21.9,23.4),(19.1,24.6),(19.0,26.1),(22.1,27.0),(26.8,27.7)]

def install(g):
    globals().update({k:g[k] for k in ['P','s','M','W','box','beam','cylinder','finish','prism','reuse','marker','text','area','ellipsoid_plinth','within','instances']})
    # Original low-resolution material artwork, no third-party texture pixels.
    for name,color,rough in [('r02_bark',(.23,.17,.105),.92),('r02_leaf',(.16,.32,.13),.9),
        ('r02_moss',(.25,.37,.12),1),('r02_rock',(.31,.34,.30),.95),
        ('r02_cool_panel',(.40,.49,.51),.7),('r02_cool_metal',(.33,.41,.43),.5),
        ('r02_water',(.11,.30,.29),.22)]:
        m=bpy.data.materials.new('WP10_'+name);m.use_nodes=True
        bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Roughness'].default_value=rough
        if name=='r02_cool_metal':bs.inputs['Metallic'].default_value=.55
        image=bpy.data.images.new('WP10_original_'+name,width=64,height=64)
        rng=random.Random(name);pix=[]
        for y in range(64):
            for x in range(64):
                grain=rng.uniform(.8,1.17)
                if name=='r02_bark':grain*=.84 if x%9 in [0,1] else 1
                pix.extend([min(.99,c*grain) for c in color]+[1])
        image.pixels=pix;image.pack()
        node=m.node_tree.nodes.new('ShaderNodeTexImage');node.image=image;node.interpolation='Closest'
        m.node_tree.links.new(node.outputs['Color'],bs.inputs['Base Color']);M[name]=m

def blob(name,u,v,h,rx,ry,rz,role,seed):
    bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=2,radius=1,location=W(u,v,h))
    ob=bpy.context.object;rng=random.Random(seed)
    for ve in ob.data.vertices:
        ve.co*=rng.uniform(.88,1.12)
        ve.co.x*=rx;ve.co.y*=ry;ve.co.z*=rz
    return finish(ob,name,role)

def trunk_segment(name,a,b,r0,r1):
    aa,bb=W(*a),W(*b)
    bpy.ops.mesh.primitive_cone_add(vertices=9,radius1=r0,radius2=r1,depth=(bb-aa).length,location=(aa+bb)/2)
    ob=bpy.context.object;ob.rotation_euler=(bb-aa).to_track_quat('Z','Y').to_euler();finish(ob,name,'r02_bark')

def tree(name,u,v,soil,top,spread=1.7):
    # Readable trunk, bough hierarchy and separate asymmetric branch clusters.
    trunk_segment(name+'_rooted_trunk',(u,v,soil-.1),(u+.12,v,top-1.1),.23,.12)
    for j in range(5):
        a=j*2.399+.4;dx=math.cos(a)*spread;dy=math.sin(a)*spread
        start=(u+.08,v,soil+1.2+j*.24);end=(u+dx*.68,v+dy*.68,top-.7+(j%2)*.28)
        trunk_segment(name+'_bough_'+str(j),start,end,.11,.036)
        for k in [-1,1]:
            tip=(u+dx+k*.3,v+dy,top-.42+(j%2)*.3)
            trunk_segment(name+'_twig_'+str(j)+'_'+str(k),end,tip,.04,.012)
            blob(name+'_canopy_'+str(j)+'_'+str(k),*tip,.85,.75,.48,'r02_leaf',name+str(j)+str(k))
    marker(name+'_root',u,v,soil,'tree_soil_contact',top=top,source='Original branch hierarchy; master21:370')

def rock(name,u,v,soil,scale=1):
    rng=random.Random(name)
    rx,ry,rz=1.2*rng.uniform(.85,1.3),.9*rng.uniform(.8,1.2),.65*rng.uniform(.75,1.3)
    ob=blob(name,u,v,soil+.9*scale,rx*scale,ry*scale,rz*scale,'r02_rock',name)
    # Squared shoulders and tilted strata produce varied outcrops instead of uniform balls.
    for vertex in ob.data.vertices:
        vertex.co.x+=vertex.co.z*.24
        vertex.co.z+=.08*scale*math.sin(vertex.co.x*3+vertex.co.y*2)
    minimum=min(v.co.z for v in ob.data.vertices)
    ob.location.z=27+soil+.006-minimum
    ob.data.update();ob.data.materials.append(M['r02_moss'])
    for f in ob.data.polygons:
        c=f.center;z=c.z/(rz*scale)
        # Connected crown-to-shaded-side moss, broken naturally around exposed stone ridges.
        if z>.24 or (c.x<.3*scale and z>-.6 and math.sin(c.y*4/scale)+math.cos(z*5)>-.6):f.material_index=1
    return ob

def moss_swathe(name,poly,base,stream_exclusion=False,step=.48):
    """Continuous shared-vertex irregular low moss relief rooted on actual growing medium."""
    lo=[min(p[k] for p in poly) for k in range(2)];hi=[max(p[k] for p in poly) for k in range(2)]
    nx=math.ceil((hi[0]-lo[0])/step);ny=math.ceil((hi[1]-lo[1])/step)
    verts=[];faces=[];lookup={}
    def vertex(i,j):
        if (i,j) not in lookup:
            u,v=lo[0]+i*step,lo[1]+j*step
            relief=.020+.042*(.5+.5*math.sin(u*1.9+v*.6))+.024*(.5+.5*math.cos(v*3.1-u*.8))
            lookup[i,j]=len(verts);verts.append(tuple(W(u,v,base+relief)))
        return lookup[i,j]
    for j in range(ny):
        for i in range(nx):
            coords=[(lo[0]+ii*step,lo[1]+jj*step) for ii,jj in [(i,j),(i+1,j),(i+1,j+1),(i,j+1)]]
            if not all(within(u,v,poly) for u,v in coords):continue
            if stream_exclusion and any(nearest_stream(u,v)<1.10 for u,v in coords):continue
            a,b,c,d=[vertex(ii,jj) for ii,jj in [(i,j),(i+1,j),(i+1,j+1),(i,j+1)]]
            faces.extend([(a,b,c),(a,c,d)])
    # A constant buried underside provides real root contact. A normal-offset
    # Solidify edge would shift the root outside the inset soil at steep rims.
    n=len(verts);top_faces=list(faces);edges={}
    for f in top_faces:
        for a,b in zip(f,f[1:]+f[:1]):
            key=tuple(sorted((a,b)));edges.setdefault(key,[]).append((a,b))
    verts.extend((x,y,27+base-.018) for x,y,z in list(verts))
    faces.extend(tuple(i+n for i in reversed(f)) for f in top_faces)
    for uses in edges.values():
        if len(uses)==1:
            a,b=uses[0];faces.append((b,a,a+n,b+n))
    me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update()
    ob=bpy.data.objects.new(name,me);s.collection.objects.link(ob);finish(ob,name,'r02_moss')
    ob['support']='Continuous low growth rooted on contained growing medium; no walkable surface'
    return ob

def nearest_stream(u,v):
    p=Vector((u,v));best=1000
    for a,b in zip(STREAM,STREAM[1:]):
        a,b=Vector(a),Vector(b);t=max(0,min(1,(p-a).dot(b-a)/(b-a).length_squared))
        best=min(best,(p-(a+(b-a)*t)).length)
    return best

def horticultural_stock(u,index):
    """Open supported storage with visibly different, truthful care contents."""
    n=20;verts=[]
    for r,h in [(.16,.395),(.16,.54),(.14,.54),(.14,.415)]:
        verts.extend(tuple(W(u+r*math.cos(i*math.tau/n),1.38+r*math.sin(i*math.tau/n),h)) for i in range(n))
    faces=[]
    for k in range(3):
        for i in range(n):j=(i+1)%n;faces.append((k*n+i,k*n+j,(k+1)*n+j,(k+1)*n+i))
    faces.extend([tuple(reversed(range(n))),tuple(range(3*n,4*n))])
    name='R02_care_product_'+str(index);me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update()
    o=bpy.data.objects.new(name,me);s.collection.objects.link(o);finish(o,name,'ivory_enamel')
    # Thin badges have two actual standoffs into the container side.
    box('R02_horticultural_badge_'+str(index),u,1.551,.465,.27,.012,.10,'r02_cool_panel',.007)
    for du in [-.07,.07]:beam('R02_horticultural_badge_fixing',(u+du,1.51,.465),(u+du,1.552,.465),.012,.012,'r02_cool_metal')
    label=text('R02_horticultural_label_'+str(index),['PLANT TIES','POT LABELS','CLEAN CLOTHS','BRUSHES'][index],u,1.562,.454,.028)
    label.rotation_euler=(math.pi/2,0,0);label.data.extrude=.0008;label.data.materials.clear();label.data.materials.append(M['ivory_enamel'])
    if index==0:
        for j in range(4):box('R02_horti_tie_bundle_'+str(j),u,1.38,.424+j*.018,.13,.22,.018,'teal_weave',.002)
    elif index==1:
        for j in range(5):box('R02_horti_pot_label_'+str(j),u-.08+j*.04,1.38,.645,.027,.018,.46,'warm_walnut',.002)
    elif index==2:
        for j in range(4):box('R02_horti_cloth_'+str(j),u,1.38,.435+j*.040,.19,.19,.04,'ivory_enamel',.006)
    else:
        for j in range(3):
            uu=u-.065+j*.065
            cylinder('R02_horti_brush_handle_'+str(j),uu,1.38,.595,.016,.36,'warm_walnut',10)
            box('R02_horti_brush_head_'+str(j),uu,1.38,.7975,.046,.052,.045,'r02_cool_metal',.006)
            box('R02_horti_brush_bristles_'+str(j),uu,1.38,.85,.042,.048,.06,'ivory_enamel',.004)

def forecourt(g):
    install(g)
    # Low continuous contained growing island; its soil stays below the stream tray.
    outline=[(15,14.7),(29.8,14.7),(32,20),(29.7,29.5),(16.5,29.5),(13.8,23)]
    inner=g['garden']('R02_fore_growing_island',outline,.115)
    moss_swathe('R02_fore_continuous_moss_swathe',inner,.118,True)
    rng=random.Random(2710);ix=0
    for ui in range(14,32):
        for vi in range(15,30):
            u,v=ui+.45,vi+.35
            if nearest_stream(u,v)<1.7:continue
            if any(math.hypot(u-a,v-b)<rr for a,b,rr in [(29.3,18.0,2.0),(17.5,20.6,3),(23,20.4,1.7),(15.3,24.1,1.5),(28.9,28.4,1.3),(17,27.4,1.3)]):continue
            if 22<u<29.5 and 24<v<26.3:continue
            if all(within(u+du,v+dv,inner) for du,dv in [(.5,0),(-.5,0),(0,.5),(0,-.5)]):
                reuse('AST-BOT-003','R02_fore_moss_groundcover_'+str(ix),u,v,.12,rng.randrange(360));ix+=1
    # Stream bed top is above the growing island, and water has no coplanar base.
    n=len(STREAM);left=[];right=[];dist=[0]
    for i,(u,v) in enumerate(STREAM):
        a=Vector(STREAM[max(0,i-1)]);b=Vector(STREAM[min(n-1,i+1)])
        tangent=(b-a).normalized();normal=Vector((-tangent.y,tangent.x))
        left.append((u+normal.x*.75,v+normal.y*.75));right.append((u-normal.x*.75,v-normal.y*.75))
        if i:dist.append(dist[-1]+(Vector(STREAM[i])-Vector(STREAM[i-1])).length)
    # Closed watertight tray above the compiler floor, visible lower bed and raised banks.
    prism('R02_stream_closed_tray',left+list(reversed(right)),.025,.14,'r02_rock')
    verts=[tuple(W(u,v,.28)) for pair in zip(left,right) for u,v in pair]
    faces=[(2*i,2*i+1,2*i+3,2*i+2) for i in range(n-1)]
    me=bpy.data.meshes.new('WP10_R02_STREAM_WATER_01');me.from_pydata(verts,[],faces);me.update()
    ob=bpy.data.objects.new('WP10_R02_STREAM_WATER_01',me);s.collection.objects.link(ob);finish(ob,'R02_STREAM_WATER_01','r02_water')
    # Viewed from above Blender vertices are wound downward: fix normals explicitly.
    for f in me.polygons:
        if f.normal.z<0:f.flip()
    uv=me.uv_layers.active
    for f in me.polygons:
        for li in f.loop_indices:
            ix=me.loops[li].vertex_index;uv.data[li].uv=(ix%2,dist[ix//2])
    ob['flow_direction']='UV.y increasing downstream';ob['collision_policy']='decorative water; never walkable'
    for side,line,sgn in [('left',left,1),('right',right,-1)]:
        outer=[]
        for i,(u,v) in enumerate(line):
            c=Vector(STREAM[i]);delta=Vector((u,v))-c;outer.append(tuple(c+delta*1.46))
        for i in range(n-1):
            prism('R02_stream_'+side+'_bank_'+str(i),[line[i],line[i+1],outer[i+1],outer[i]],.025,.42,'r02_rock')
    # End closures and contained inlet/return heads do not require slab penetration.
    for name,i in [('inlet',0),('return',n-1)]:
        u,v=STREAM[i];cylinder('R02_'+name+'_housing',u,v,.35,.78,.65,'r02_rock',16)
        cylinder('R02_'+name+'_grille',u,v,.683,.57,.026,'r02_cool_metal',16)
        for du in [-.3,0,.3]:box('R02_'+name+'_grille_bar',u+du,v,.701,.08,.85,.016,'dark_rubber',0)
    # Shaped side beds establish tiering and roots while keeping the water visible.
    beds=[('fore_root_north',[(15.4,19.5),(18.3,19.2),(21.4,20.2),(21.0,21.6),(17.9,22.3),(15.5,22.3)],.72),
          ('fore_root_south',[(22.1,24.9),(25.1,24.3),(28.7,24.0),(29.0,26.0),(27.8,26.2),(24,25.8)],.90)]
    for name,poly,top in beds:
        g['planted'](name,poly,top,602,.80)
        cu=sum(a for a,b in poly)/len(poly);cv=sum(b for a,b in poly)/len(poly)
        soil_poly=[(cu+(u-cu)*.955,cv+(v-cv)*.955) for u,v in poly]
        moss_swathe(name+'_moss',soil_poly,top+.003,False,.28)
    ellipsoid_plinth('R02_fore_tree_planter',29.3,18.0,1.25,1.3,1.0)
    tree('R02_fore_tree',29.3,18.0,1.02,5.25,1.65)
    root_poly=[(29.3+1.1*math.cos(i*math.tau/24),18+1.15*math.sin(i*math.tau/24)) for i in range(24)]
    moss_swathe('R02_fore_tree_root_moss',root_poly,1.025,False,.20)
    tree('R02_fore_small_tree',17.5,20.6,.74,4.5,1.15)
    for i,(u,v,h,sc) in enumerate([(15.3,24.1,.03,.85),(23.0,20.4,.03,.95),(28.9,28.4,.03,.72),(17,27.4,.03,.8)]):rock('R02_fore_rock_'+str(i),u,v,h,sc)
    for i,(u,v) in enumerate([(16,18.7),(15.2,21),(15.9,25.9),(18.8,28.2),(21,28.6),(24.5,28.9),(29.9,24.1),(30.6,22.8)]):
        # Connected shrub drifts root directly into the main bed, with low moss between them.
        for j,(du,dv) in enumerate([(-.18,-.2),(.22,.18),(.10,-.25)]):
            reuse('AST-BOT-002','R02_rooted_shrub_drift_'+str(i)+'_'+str(j),u+du,v+dv,.12,i*37+j*70)
    contract={'mesh_prefix':'WP10_R02_STREAM_WATER_','meshes':[ob.name], 'local_axes':'u west, v aft, h up; world=(-8-u,27+h,-250+v)',
        'centreline_local_uv':STREAM,'length_m':dist[-1],'water_local_h':.28,'bed_top_local_h':.14,'bank_top_local_h':.42,
        'flow':'UV.y increases downstream, continuous metres; UV.x 0..1 across bed','collision':'nonwalkable decorative surface',
        'status':'contained architectural proposal; visual flow adapter pending; no fluid, audio or operating pump claim'}
    (P/'runtime/water_binding.json').write_text(json.dumps(contract,indent=2)+'\n')

def final_details(g):
    # Aft quiet grove uses the same hierarchy without pretending a stream crosses dry floor.
    aft_poly=[(17,39.2),(29,40),(32,47),(29.4,57.5),(16,57.5),(13.5,49)]
    cu=sum(a for a,b in aft_poly)/len(aft_poly);cv=sum(b for a,b in aft_poly)/len(aft_poly)
    aft_soil=[(cu+(u-cu)*.955,cv+(v-cv)*.955) for u,v in aft_poly]
    moss_swathe('R02_aft_continuous_moss_swathe',aft_soil,.423,False)
    for i,(u,v,top,spread) in enumerate([(18.4,44,1.05,1.7),(26.4,51.8,.95,1.8)]):
        ellipsoid_plinth('R02_aft_tree_tier_'+str(i),u,v,2.1,1.85,top)
        tree('R02_aft_tree_'+str(i),u,v,top+.02,4.9,spread)
    for i,(u,v,sc) in enumerate([(25,43,.95),(18.5,52.4,1.15),(27.1,56,.8)]):rock('R02_aft_rock_'+str(i),u,v,.42,sc)
    # Quiet axial wall receives deep framed fields, weighted ledge and closed returns.
    for i,(lo,hi) in enumerate([(12.0,18.5),(19.3,26.7),(42,48),(49.2,55.5),(56.2,60.5)]):
        mid=(lo+hi)/2;span=hi-lo
        box('R02_quiet_recess_'+str(i),.59,mid,2.08,.12,span,2.5,'teal_weave',.02)
        for vv in [lo-.1,hi+.1]:box('R02_quiet_field_return',.72,vv,2.08,.4,.2,2.75,'warm_walnut',.035)
        box('R02_quiet_field_head',.72,mid,3.45,.4,span+.4,.2,'warm_walnut')
        box('R02_quiet_ledge',.77,mid,.75,.52,span+.4,.15,'warm_stone',.05)
        box('R02_quiet_ledge_plinth',.73,mid,.35,.46,span+.2,.65,'warm_walnut')
    # Institutional service side: real cool panels over public timber screen, practical fixtures.
    for lo,hi in [(10,32.2),(35.8,57.2),(60.8,64)]:
        box('R02_staff_screen_face',40.375,(lo+hi)/2,1.64,.028,hi-lo-.05,3.18,'r02_cool_panel',.01)
    targets=('care_worktop_support','care_lamp','care_task_housing','stock_shelf','stock_general','care_route','care_tray')
    for o in list(s.objects):
        if any(o.name.startswith('WP10_'+x) for x in targets) and o.type=='MESH':
            role='daylight' if 'diffuser' in o.name else 'r02_cool_metal'
            o.data.materials.clear();o.data.materials.append(M[role]);o['role']=role
        if o.type=='LIGHT' and any(x in o.name for x in ['stock_general','care_route','care_worktop']):o.data.color=(.76,.88,1)
    # Reachable stock on shelf, a clean work area and a separate supported info board.
    for i,u in enumerate([7.1,7.7,8.3,8.9]):horticultural_stock(u,i)
    # Retained closed bins remain explicitly sealed storage; no unseen contents
    # are invented. Identifiers distinguish locations from the open care items.
    for i,u in enumerate([6.65,7.55,8.45,9.35],1):
        for h,row in [(1.325,'A'),(2.075,'B')]:
            badge=box('R02_sealed_bin_badge_'+row+str(i),u,1.607,h,.45,.014,.11,'r02_cool_panel',.003)
            label=text('R02_sealed_bin_label_'+row+str(i),'SEALED '+row+str(i),u,1.619,h-.015,.034)
            label.rotation_euler=(math.pi/2,0,0);label.data.extrude=.0008;label.data.materials.clear();label.data.materials.append(M['ivory_enamel'])
    # Small practical strip is directly borne by the existing shelf underside.
    box('R02_care_stock_lamp_housing',8,1.64,1.025,3.20,.14,.060,'r02_cool_metal',.008)
    box('R02_care_stock_lamp_lens',8,1.64,.988,3.05,.10,.014,'daylight',.003)
    area('R02_care_stock_shelf_task',8,1.68,.971,85,1.8,(.76,.88,1))
    box('R02_care_notice_backboard',34.2,1.86,1.55,1.9,.10,.9,'r02_cool_panel')
    for u in [33.5,34.9]:box('R02_care_notice_standoff',u,1.58,1.55,.08,.5,.6,'r02_cool_metal',.01)
    # Standoffs terminate on a real wall supported by the end enclosure.
    box('R02_care_notice_support',34.2,.93,1.3,2.1,1.0,2.6,'r02_cool_panel')
    note=text('R02_care_notice_text','GARDEN CARE\nKEEP THE DRY LOOP CLEAR',34.2,1.93,1.61,.14,'south')
    note.rotation_euler=(math.pi/2,0,0);note.data.materials.clear();note.data.materials.append(M['ivory_enamel'])
    # Public low information plaque carried by weighted post, away from the dry-loop swept band.
    cylinder('R02_stream_info_foot',13.3,27.5,.05,.32,.10,'warm_stone')
    cylinder('R02_stream_info_post',13.3,27.5,.65,.05,1.25,'champagne_metal',12)
    board=box('R02_stream_info_backboard',13.2,27.5,1.28,.10,1.2,.50,'warm_walnut')
    note=text('R02_stream_info_text','MOSS SANCTUARY\nSUNCORP',13.14,27.5,1.33,.095,'east');note.rotation_euler=(math.pi/2,0,math.pi/2)
    note.data.materials.clear();note.data.materials.append(M['ivory_enamel'])
    candidates=[{'id':'WP10_info_stream_01','visual_node':board.name,'action':'read_information','label':'Read garden information',
        'information':'Moss Sanctuary. Rest beside the contained stream; keep the dry garden loop clear.',
        'focus_world_m':[-21.14,28.28,-222.2],'approach_feet_world_m':[-19.8,27,-222.2],
        'target_size_m':[.08,.36,.5],'access':'public','status':'proposed; receiving ray binding pending'},
        {'id':'WP10_info_care_01','visual_node':'WP10_R02_care_notice_backboard','action':'read_information','label':'Read garden care notice',
        'information':'Plant ties, pot labels, clean cloths and brushes are on the lower stock shelf. Keep the dry loop and cart parking clear.',
        'focus_world_m':[-42.2,28.28,-248.07],'approach_feet_world_m':[-42.2,27,-246.6],
        'target_size_m':[.50,.30,.06],'access':'staff','status':'proposed; receiving access and ray binding pending'}]
    (P/'runtime/interaction_candidates.json').write_text(json.dumps({'schema':1,'coordinate_space':'Godot world metres; identity placement','candidates':candidates},indent=2)+'\n')

