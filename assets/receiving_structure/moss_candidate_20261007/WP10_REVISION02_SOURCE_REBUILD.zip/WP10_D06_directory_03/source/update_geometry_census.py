"""Refresh final actual-GLB census, preserving the frozen predecessor census."""
from pathlib import Path
import json, struct, hashlib
P = Path(__file__).resolve().parents[1]
receipt = P / 'qa/revision02_geometry_delta.json'
r = json.loads(receipt.read_text())
path = P / 'exports/WP10_moss_sanctuary.glb'
raw = path.read_bytes()
d = json.loads(raw[20:20 + struct.unpack_from('<I', raw, 12)[0]])
groups = {}
for node in d['nodes']:
    if 'mesh' not in node:
        continue
    family = node.get('extras', {}).get('retained_catalogue_id', 'authored_architecture')
    group = groups.setdefault(family, {'nodes': 0, 'triangles': 0})
    group['nodes'] += 1
    for primitive in d['meshes'][node['mesh']]['primitives']:
        assert primitive.get('mode', 4) == 4
        group['triangles'] += d['accessors'][primitive['indices']]['count'] // 3
current = {'file': str(path), 'sha256': hashlib.sha256(raw).hexdigest(),
           'groups': groups, 'total_triangles': sum(g['triangles'] for g in groups.values()),
           'images': len(d.get('images', []))}
r['exports'] = [r['exports'][0], current]
assert current['total_triangles'] == json.loads((P/'qa/export_check.json').read_text())['triangles']
receipt.write_text(json.dumps(r, indent=2) + '\n')
print(current['sha256'], current['total_triangles'], groups)
