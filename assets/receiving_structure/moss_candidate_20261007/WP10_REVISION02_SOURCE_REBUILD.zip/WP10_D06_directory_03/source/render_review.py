"""Scheduled source-only ordinary-eye review. Does not modify native source."""
import bpy,sys,json,hashlib,datetime
from pathlib import Path
from mathutils import Vector
P=Path(__file__).resolve().parents[1]
native=P/'source/WP10_moss_sanctuary.blend';native_before=hashlib.sha256(native.read_bytes()).hexdigest()
receipt_path=P/'qa/final_view_receipts.json';receipts=json.loads(receipt_path.read_text()).get('views',{}) if receipt_path.exists() else {}
bpy.ops.wm.open_mainfile(filepath=str(P/'source/WP10_moss_sanctuary.blend'))
s=bpy.context.scene
s.render.threads_mode='FIXED';s.render.threads=12;s.cycles.device='CPU'
keys=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else ['arrival','court','sheltered','quiet','care','mounts','loop']
if 'care_stock' in keys:
    # Supplemental working-face camera only; geometry/light/native stay unchanged.
    W=lambda u,v,h:Vector((-8-u,250-v,27+h))
    data=bpy.data.cameras.new('WP10_care_stock_review');data.lens=30
    stock_camera=bpy.data.objects.new('WP10_care_stock',data);s.collection.objects.link(stock_camera)
    stock_camera.location=W(9,4,1.68)
    stock_camera.rotation_euler=(W(8,1.35,1.0)-stock_camera.location).to_track_quat('-Z','Y').to_euler()
if 'identity' in keys:
    # Review-session camera only: no native save or architectural/light modification.
    W=lambda u,v,h:Vector((-8-u,250-v,27+h))
    camera_data=bpy.data.cameras.new('WP10_identity_review_camera')
    camera_data.lens=18  # Includes the sign backing and full supporting posts at ordinary eye.
    # WP10_identity is the existing FONT sign, so camera lookup must not use that name.
    camera=bpy.data.objects.new('WP10_REVIEW_identity_camera',camera_data)
    s.collection.objects.link(camera)
    camera.location=W(.9,39.3,1.68)
    camera.rotation_euler=(W(3.8,39.3,1.65)-camera.location).to_track_quat('-Z','Y').to_euler()
baseline={o.name:o.hide_render for o in s.objects}
for key in keys:
    for o in s.objects:o.hide_render=baseline[o.name]
    s.camera=camera if key=='identity' else bpy.data.objects['WP10_'+key]
    assert s.camera.type=='CAMERA',f'Review key {key} resolved to {s.camera.type}, not a camera'
    if key=='section':
        for o in s.objects:
            if any(n in o.name for n in ['protected_opaque_roof','outer_port_wall','end_enclosure','soffit','opaque_canopy']):o.hide_render=True
    s.render.filepath=str(P/'qa'/f'SOURCE_ONLY_{key}.png');bpy.ops.render.render(write_still=True)
    f=Path(s.render.filepath)
    receipts[key]={'file':str(f.relative_to(P)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'source_sha256':native_before,'rendered_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'camera_type':s.camera.type,'camera_source_xyz':list(s.camera.location),'eye_above_floor_m':s.camera.location.z-27,'exposure':s.view_settings.exposure,'geometry_hidden':key=='section','camera_scope':'review-session supplemental camera' if key in ['identity','care_stock'] else 'saved native camera','status':'rendered, owner/root pixel review separate'}
    assert hashlib.sha256(native.read_bytes()).hexdigest()==native_before
    receipt_path.write_text(json.dumps({'native_sha256':native_before,'views':receipts,'all_views_current_native':all(r['source_sha256']==native_before for r in receipts.values()),'source_only':True},indent=2)+'\n')
print('WP10_SOURCE_ONLY_RENDER_DONE')
