"""Bind final source checks and ordinary-eye images; does not grant root acceptance."""
from pathlib import Path
import json,hashlib,struct,datetime
P=Path(__file__).resolve().parents[1]
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
native=P/'source/WP10_moss_sanctuary.blend';glb=P/'exports/WP10_moss_sanctuary.glb';ns,gs=sha(native),sha(glb)
reports={name:json.loads((P/'qa'/name).read_text()) for name in ['native_check.json','revision02_native_gates.json','revision02_supports.json','export_check.json']}
assert all(r['pass'] for r in reports.values())
for name in ['native_check.json','revision02_native_gates.json','revision02_supports.json']:assert reports[name]['native_sha256']==ns,name
assert reports['export_check.json']['sha256']==gs
views=json.loads((P/'qa/final_view_receipts.json').read_text())['views']
required=['arrival','stream','contemplation','care','court','sheltered','quiet','mounts','loop','joinery','care_detail','identity','care_stock']
for key in required:
    r=views[key];assert r['source_sha256']==ns and sha(P/r['file'])==r['sha256'] and not r['geometry_hidden'],key
def files(names):return [{'file':n,'sha256':sha(P/n)} for n in names]
dispositions=[
 {'id':'WP10-FR-01','disposition':'Corrected in source; root final verification pending','change':'Staff-facing cool practical panels/metal and supported rectangular task fixtures; real identified lower-shelf horticultural supplies with distinct bearings and no mutual bin overlap. Working surface retained clear.','evidence':['qa/SOURCE_ONLY_care.png','qa/SOURCE_ONLY_care_stock.png','qa/SOURCE_ONLY_care_detail.png','qa/revision02_supports.json']},
 {'id':'WP10-FR-02','disposition':'Corrected in source; root final verification pending','change':'Recessed quiet-edge fields, thick closed returns/heads and weighted ledges; retained connected dry routes. Historical no-water restriction superseded by explicit current human stream instruction.','evidence':['qa/SOURCE_ONLY_quiet.png','qa/SOURCE_ONLY_joinery.png','qa/SOURCE_ONLY_loop.png','qa/revision02_native_gates.json']},
 {'id':'WP10-FR-03','disposition':'Corrected evidence binding; root final verification pending','change':'All13 current ordinary-eye views bind to one unchanged final native. No prior6 views are passed off as current; all earlier native/images/reports remain historical.','evidence':['qa/final_view_receipts.json','qa/REVISION02_CORRECTION_RECEIPT.json','history/PREDECESSOR.json']},
 {'id':'EXPERIENCE','disposition':'Source correction complete; final independent pixels pending','change':'Contained winding stream with coherent downstream UVs, continuous moss relief rooted into soil, varied moss-wrapped rock bodies, supported tiered branching trees and actual seated waterward view.','evidence':['qa/SOURCE_ONLY_stream.png','qa/SOURCE_ONLY_contemplation.png','qa/SOURCE_ONLY_sheltered.png','qa/revision02_supports.json','docs/plan_section.svg']},
 {'id':'EXTERIOR_VIEW','disposition':'Retained receiving hold','change':'No direct hull exposure verified. About66m is a historical maximum-outline plan gap, not an adopted upper-deck hull location. Real connected port frontage needs separate allocation and hull/structure reconciliation.','evidence':['EXPERIENCE_BRIEF.md','docs/source_evidence/EXTERIOR_OPPORTUNITY_SCREEN.json']},
 {'id':'INTERACTION_AND_FLOW','disposition':'Final receiving tests/lighting adaptation hold','change':'Actual source notice rays and small fitted targets pass. Root earlier isolated actual-player read/close and water shader binding passed, but raw imported-light visual probe clipped and gave no valid visible-flow proof. Final info test and receiving lighting conversion remain separate.','evidence':['runtime/interaction_candidates.json','runtime/water_binding.json','qa/revision02_native_gates.json']}]
r={'package':'WP10_D06_directory_03','status':'Final source gates and native-bound images complete; owner pixel review complete; root approval and final runtime receipts separate','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'native':{'file':str(native.relative_to(P)),'sha256':ns},'glb':{'file':str(glb.relative_to(P)),'sha256':gs,'placement':[0,0,0]},'dispositions':dispositions,'source_tests':files(['qa/'+n for n in reports]),'ordinary_eye_views':{k:views[k] for k in required},'references':files(['docs/reference_library/full_catalog_manifest.json','docs/reference_library/inspection_receipt.json','docs/reference_library/REFERENCE_STUDY.md']),'receiving_holds':['Fresh273-region cloud exclusivity/conflicts and current access','Receiving floor and outside4m links','Real controller/cart/six-species fit','Runtime lighting conversion and default-effects/CRT/hardware appearance','Valid rendered flowing-water proof; no fluid simulation, pump/audio/gameplay operation claimed'],'historical_evidence':'history/revision01 and revision02_attempt02 through revision02_attempt05; no historical job is a required rebuild step','root_verified':False}
root_path=P/'root_review.json'
if root_path.exists():
    review=json.loads(root_path.read_text())
    verified=(review.get('status')=='coordinator_source_candidate_review_passed'
              and review.get('artifacts',{}).get(str(native.relative_to(P)).replace('\\','/'))==ns
              and review.get('artifacts',{}).get(str(glb.relative_to(P)).replace('\\','/'))==gs
              and all(review.get('reviewed_views',{}).get(views[k]['file'].replace('\\','/'))==views[k]['sha256'] for k in required))
    if verified:
        r['root_verified']=True
        r['root_review']={'file':'root_review.json','sha256':sha(root_path),'scope':'Independent source candidate review only'}
        r['status']='Final source gates and all13 native-bound views passed owner and independent coordinator source review; final06 isolated engine check and receiving holds remain pending'
        for item in r['dispositions']:
            if item['id'] in ['WP10-FR-01','WP10-FR-02','WP10-FR-03','EXPERIENCE']:
                item['disposition']='Source correction independently reviewed and accepted; receiving holds remain separate'
                item['evidence'].append('root_review.json')
engine_path=P/'runtime/isolated_verification.json'
if engine_path.exists():
    engine=json.loads(engine_path.read_text())
    bound=engine.get('water_binding',{})
    isolated_ok=(engine.get('pass') is True and engine.get('glb_sha256')==gs
                 and engine.get('candidates_sha256')==sha(P/'runtime/interaction_candidates.json')
                 and bound.get('manifest_sha256')==sha(P/'runtime/water_binding.json')
                 and bound.get('bound')==['WP10_R02_STREAM_WATER_01'] and not bound.get('missing')
                 and len(engine.get('results',[]))==2
                 and all(x.get('pass') and x.get('ray_target') and x.get('read_and_close') for x in engine['results']))
    if isolated_ok:
        r['isolated_runtime_verification']={'file':'runtime/isolated_verification.json','sha256':sha(engine_path),'pass':True,'scope':'Actual final GLB fitted information ray/read/close and exact water shader binding only; receiving lighting and rendered motion remain held'}
        if r['root_verified']:
            r['status']='Final source and all13 views independently accepted; final06 isolated information and water shader-binding checks pass. Receiving installation, lighting and rendered-motion holds remain.'
        item=next(x for x in r['dispositions'] if x['id']=='INTERACTION_AND_FLOW')
        item['disposition']='Final isolated information and shader binding pass; receiving lighting and rendered-motion hold'
        item['change']='Both fitted notices pass actual final Godot player-ray/read/close checks. Exact stream mesh binds the pinned existing shader. Raw imported-light visual probe remains invalid for visible-motion proof; no installed-engine visual or flow acceptance is claimed.'
        item['evidence'].append('runtime/isolated_verification.json')
(P/'qa/REVISION02_CORRECTION_RECEIPT.json').write_text(json.dumps(r,indent=2)+'\n')
print('FINAL_SOURCE_RECEIPT_READY',ns,gs,len(required),'views; coordinator source review',r['root_verified'],'receiving holds separate')
