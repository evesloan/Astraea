"""One continuous source-preview surface; standard library only, no scene side effects."""
from math import isclose

ALLOCATION = (0.0, 46.0, 0.0, 68.0)
PATHS = [(10,37,4.2,54),(36,37,4.2,54),(23,12,30,4.2),
         (23,62,30,4.2),(19,34,38,4.2),(43,35,4,60)]

def floor_mesh_data():
    rectangles = [(u-du/2,u+du/2,v-dv/2,v+dv/2) for u,v,du,dv in PATHS]
    xs = sorted({0.0,46.0} | {x for a,b,c,d in rectangles for x in (a,b)})
    ys = sorted({0.0,68.0} | {y for a,b,c,d in rectangles for y in (c,d)})
    vertices = [(x,y) for y in ys for x in xs]
    faces, materials = [], []
    nx = len(xs)
    for j in range(len(ys)-1):
        for i in range(nx-1):
            faces.append((j*nx+i,j*nx+i+1,(j+1)*nx+i+1,(j+1)*nx+i))
            x,y=(xs[i]+xs[i+1])/2,(ys[j]+ys[j+1])/2
            materials.append(int(any(a<x<b and c<y<d for a,b,c,d in rectangles)))
    return vertices,faces,materials

def verify_partition(vertices, faces, tolerance=1e-6):
    """Check actual supplied faces, independently of how the partition was generated."""
    assert len(vertices)==len(set(tuple(v) for v in vertices)), 'Duplicate unshared vertices'
    bounds=[];total_area=0.0
    for face in faces:
        assert len(face)==4 and len(set(face))==4
        points=[vertices[k] for k in face]
        a,b=min(p[0] for p in points),max(p[0] for p in points)
        c,d=min(p[1] for p in points),max(p[1] for p in points)
        assert set(points)=={(a,c),(b,c),(b,d),(a,d)}, 'Non-rectangular face'
        signed=sum(points[i][0]*points[(i+1)%4][1]-points[(i+1)%4][0]*points[i][1] for i in range(4))/2
        assert signed>0 and isclose(signed,(b-a)*(d-c),abs_tol=tolerance)
        assert a>=-tolerance and b<=46+tolerance and c>=-tolerance and d<=68+tolerance
        bounds.append((a,b,c,d));total_area+=signed
    positive_overlaps=[]
    for i,(a,b,c,d) in enumerate(bounds):
        for j in range(i):
            e,f,g,h=bounds[j]
            area=max(0,min(b,f)-max(a,e))*max(0,min(d,h)-max(c,g))
            if area>tolerance:positive_overlaps.append((j,i,area))
    assert not positive_overlaps, positive_overlaps[:5]
    assert isclose(total_area,46*68,abs_tol=tolerance),total_area
    return {'pass':True,'shared_vertices':len(vertices),'faces':len(faces),
            'positive_area_overlap_pairs':len(positive_overlaps),
            'covered_area_m2':total_area,'required_area_m2':46*68,
            'proof':'Every positive-area face lies within allocation, no pair overlaps with positive area, summed area equals complete allocation.'}
