# Revision02 reference application and limits



Contained stream, continuous irregular moss/low growth, varied mossy rocks, rooted tiered trees, seated water view and cool stocked care.



All12 immutable catalog sheets were reopened during this revision intake. Exact sheet/original hashes and source paths are in inspection_receipt.json; full_catalog_manifest.json is byte-identical to the central136-original/189-alias manifest. Complete original bytes remain centrally preserved. Relevant originals are retained locally. The overview is not a claim of136 full-resolution individual inspections.



## Selected original application



- REF-021: Readable small stock groups on supported reachable shelves; retain clear worktops. Limit: No speculative product formulation or functioning inventory claim.

- REF-022: Cool practical staff fittings, local work illumination and protected services. Limit: Do not apply guest walnut/brass indiscriminately to staff work surfaces.

- REF-081: Deep reveals, recessed fields and authored closed end conditions. Limit: Do not treat modular pictures as allocation, floor or ownership authority.

- REF-085: Modeled returns/end caps and visible fixture attachment instead of superficial strip decoration. Limit: Preserve current programme, clear routes and protected ceiling.

- REF-097: Weighted portal depth and framed changes in spatial hierarchy. Limit: No copied game branding, scale or fabricated exterior exposure.

- REF-098: Continuous canopy/shrub/groundcover hierarchy, water and dry circulation composed together. Limit: No oversized void or skylight through occupied deck. Water authority is latest explicit human instruction and only WP10 uses it.

- REF-099: Supported visible stock, shaped containers and local light explaining shelf depth. Limit: No copied labels, ingredients or blanket clutter across worktops.

- REF-113: Real broad framed exterior sightlines appreciated from sitting and walking edges. Limit: Current inboard allocation does not establish facade; connected frontage and adopted hull remain receiving-held.

- REF-116: Institutional practical finishes, clipped services, real fittings and cool task pools. Limit: Reference screenshot is not proof of runtime light budget or current staff access classification.

- REF-127: Sweeping framed views with substantial architectural supports and resting edges. Limit: No window through neighbours or occupied deck; proposed upper hull is unadopted.

- REF-136: Primary architectural mass, deep portals, readable material depth and useful local source lighting. Limit: Quality benchmark does not authorize oversized height, photorealistic finish or invented capacity.



## Complete overview coverage



REF001–024: arrivals, comfortable inhabited edges and care/service detail. Apply the current arrival/activity/quiet/support hierarchy and useful supported stock. Historical room names, people and exterior scenes grant no capacity or space rights.

REF025–048: asset families, material samples, small props, plans and atlas interfaces. Retain approved native family geometry and explicit source dimensions; historical labels/counts are not current control.

REF049–072: joined threshold, cove, support and circulation studies. Build real wall/ceiling/planter contacts and protect the floor, roof and neighbouring systems. No tram/core/upper-hull remapping is implied.

REF073–096: authored frames, repeated modules, garden and public-room compositions. Finish chosen edge conditions with modeled depth and useful tiering; do not replace primary forms with decoration or copy unrelated retail/residential programme.

REF097–120: close game/environment images demonstrate readable material scale, bracketed light and supplied workplaces. Use distinct public/staff finishes and purposeful small stock groups. Do not copy brands or claim runtime performance/operation from reference imagery.

REF121–136: layered quiet volumes, panoramic views and quality benchmarks. Preserve inward views and supported shaped edges; maintain a specific receiving opportunity for a real exterior frontage. Current directory bounds are inboard, not adopted facade authority. No fabricated screen, skylight, mezzanine or neighbour cut.



The complete master/current application and latest owner directive govern over image labels. EXPERIENCE_BRIEF.md provides this section’s exact functional application, interfaces and exterior hold. Historical source review and rejected build evidence remain preserved; current native/GLB and final pixels are separately verified.