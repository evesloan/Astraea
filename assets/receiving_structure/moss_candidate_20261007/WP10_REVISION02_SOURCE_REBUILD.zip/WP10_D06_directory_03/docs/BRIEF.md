HISTORICAL REVISION01 DOCUMENT. Current source proposal, experience and gate status are in ../../EXPERIENCE_BRIEF.md. Its prior holds and acceptance references are dated history, not current status.

# WP10 Moss Sanctuary — isolated source candidate

D06_directory_03 remains the Moss Sanctuary. Confirmed allocation is X -54..-8, Z -250..-182, floor Y27, next datum Y35.5. Portal [-8,27,-216] is retained. This is a source package, not an installed ship section.

Two quiet courts use broad irregular planted beds, a continuous 4.2m dry loop, low edge gardens and integrated planted seating. The entry compresses to a supported 3.6m threshold before the taller garden canopy. The second court has a lower canopy and sheltered rest pockets. Four substantial planting masses use approved low rosettes, broad-leaf understory, fan crowns and flowering banks rooted in visible contained growing medium. No new botanical species, moisture parameter or capacity is claimed.

Seating faces into the gardens with companion spaces beside the dry loop. Screens interrupt direct axial views into quiet pockets and the horticultural room. A 3.6m dry care route reaches two garden openings and a stocked workroom with supply cabinets, worktop, soil trays and cart parking. Public and care circulation meet at the entry cross-route intentionally; no separate external service penetration is invented.

Cream structural piers rise from stone plinths into capitals, primary rails and short haunches. Walnut canopy infill bears on those rails. Opaque artificial daylight coffers have modeled support sockets below the protected opaque roof. Local pendant and retained lantern sources have real mount surfaces and effective exported punctual lights. The quiet seat and worktop receive dedicated task lighting.

The atlas page8 identifies this as the port-side Moss Sanctuary with Botanical Nursery opposite. Master chapters4,5,7,21,30,32 were read in full, including the full chapter21 after the first tool output truncation. The current application overrides were read in full. The latest exact117-file preflight is PASS. Approved native sources are individually hashed before bundling and every rebuild rechecks bundled dependencies.

Actual pixels inspected: page8 of Astraea-current-layout-atlas.pdf rendered at130dpi (docs/references/atlas_page08.png); botanical atrium_reference.png; retro_atrium_quality_benchmark.png. Adopted evidence: planted hierarchy, layered edges, real supports, warm material articulation and legible circulation. Giant central trees, multilevel atria, roof glazing and broad staircases in references are not applicable to this one-deck quiet section.

Parent retains the unbuilt4m receiver, floor/slabs and final collision/runtime adoption. WP01 above, WP04 across and D05 medical below are protected. No neighbour, roof or exterior aperture is created. Preview floor is source context and excluded from GLB. Source render/native/export checks do not certify runtime traversal, lighting budget, care gameplay, environmental systems or structural engineering.

## Preview-floor revision

First source renders exposed pure-black shapes at intersecting dry-loop preview boxes. The near overlap projected to image corner (416,622) and the far overlap to the rear care threshold, matching the defects. These were coincident coplanar inlay faces, not intentional mats or missing architecture.

The preview now uses one shared-vertex planar mesh at world Y27. Its non-overlapping rectangular faces carry stone or ivory material indices; intersecting routes are a single material region. The floor remains SOURCE_PREVIEW_ONLY and is excluded from GLB. The architecture, lights, cameras and retained assets are unchanged. The standard-library partition proof verifies in-bounds positive faces, zero positive-area face overlap and complete3128m² coverage. Native QA independently repeats this proof on the saved mesh, checks one preview object and the Y27 datum. Coordinator rebuild and all seven fresh renders remain required.

## Identity correction

Actual identity pixels revealed the perpendicular quiet-lantern screen intersecting the sign and insufficient letter illumination. The sign is relocated from localu5.8 to3.8, retaining v39.3, with0.72m separation from that screen and0.85m from the public dry-route edge. Editable FONT lettering now uses physical ivory enamel on walnut. A real linear picture-light housing is carried by two board-mounted plates, risers and projecting arms; three angled55W punctual sources illuminate the sign face. No exposure adjustment is used. The isolated eye-level identity review camera is retargeted to show the full sign and supporting posts.

The floor, planted courts, existing lights and original seven cameras are unchanged. Rebuild, native/export/sign parity checks and fresh arrival/identity pixels are required. Previously reviewed other court images precede this local identity relocation, finish change and added local illumination; they must not be described as all captured from the final revision.
