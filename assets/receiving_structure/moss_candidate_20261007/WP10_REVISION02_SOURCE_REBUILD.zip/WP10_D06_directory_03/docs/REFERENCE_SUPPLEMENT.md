# WP10 reference supplement

All12 contact sheets reopened in this fresh review; only listed originals individually opened at full resolution.

Central catalog: `C:\Users\cered\Dolphin\AstraeaShip\local_delivery\higgins_parallel_20261006\reference_catalog`. Manifest SHA256 `8d913337814f39962df95b9e5554972bfc1607851c116b22050b766c5f6d7208`. Exact selected originals and manifest are retained here; full136-image catalog remains centrally preserved.

Compare the shaped garden courts, supported opaque coffers and planted rest edges positively; use cool staff references for the isolated workroom and deep module/ledge lessons for selected quiet-edge ends without taking route width.

## REF-021
Exact SHA256: `ddc572d2654171ada4d4e642e362d2948c6a384b0feed05fdd67e75c14f66df7`. Retained: `supplements\WP10\reference_library\REF-021.png`.

Stocked care shelves combine visible bottle/container silhouettes, folded cloths, shelf depth and a nearby bulb.

Compare the shaped garden courts, supported opaque coffers and planted rest edges positively; use cool staff references for the isolated workroom and deep module/ledge lessons for selected quiet-edge ends without taking route width.

Limit: Historical runtime care image; local craft benchmark only. Its warm guest-edge palette does not override a staff workroom designation.

## REF-022
Exact SHA256: `8de04004ec4c726247436c75d713d3beed13fdd9b57d9c18f3f8284710e6a8f6`. Retained: `supplements\WP10\reference_library\REF-022.png`.

Cool linear fixtures, practical ceiling/panels and modest used furniture distinguish a staffed institutional setting.

Compare the shaped garden courts, supported opaque coffers and planted rest edges positively; use cool staff references for the isolated workroom and deep module/ledge lessons for selected quiet-edge ends without taking route width.

Limit: Historical runtime image and legacy bodies are not current access, species or room approval.

## REF-081
Exact SHA256: `419e1ed876dae76d34828b9683b6c8299a3196b157e8d56d5053faf1cff9c4eb`. Retained: `supplements\WP10\reference_library\REF-081.png`.

Shaped handles, layered furniture supports, deep shelving recesses and closed wall/cove ends create useful touch-scale construction.

Compare the shaped garden courts, supported opaque coffers and planted rest edges positively; use cool staff references for the isolated workroom and deep module/ledge lessons for selected quiet-edge ends without taking route width.

Limit: Original design translation only; no suite programme, exterior window, brand or photoreal finish is imported.

## REF-085
Exact SHA256: `1a21aaa8f3726b843881ae9378a415ad96b517fc2ea839ad2cfc4b2eefaadb3a`. Retained: `supplements\WP10\reference_library\REF-085.png`.

Module corner returns, end caps, deep doorway pieces and populated shelf alcoves resolve transitions as real form.

Compare the shaped garden courts, supported opaque coffers and planted rest edges positively; use cool staff references for the isolated workroom and deep module/ledge lessons for selected quiet-edge ends without taking route width.

Limit: Kit inspiration is not an approved asset family or permission to copy branded geometry.

## REF-097
Exact SHA256: `0ba2e575c0fc9531e81c5faab487edda83f471b3d781df38df7faffd40fefd44`. Retained: `supplements\WP10\reference_library\REF-097.png`.

Deep portals, vertical fins, substantial bases and nearby source light organize arrival and background destinations.

Compare the shaped garden courts, supported opaque coffers and planted rest edges positively; use cool staff references for the isolated workroom and deep module/ledge lessons for selected quiet-edge ends without taking route width.

Limit: No copied lions, signs, logos or staging; not an instruction to add stairs or an atrium.

## REF-098
Exact SHA256: `f84205f20a3d757f1d63e3e4dbfb7d13a4cfb91fc62f2d71c8343122f679510d`. Retained: `supplements\WP10\reference_library\REF-098.png`.

Grounded planting hierarchy and occupied edges make focal garden volumes legible with dry routes and pauses.

Compare the shaped garden courts, supported opaque coffers and planted rest edges positively; use cool staff references for the isolated workroom and deep module/ledge lessons for selected quiet-edge ends without taking route width.

Limit: No giant tree, watercourse, multilevel void, roof glass or lift is authorized inside WP10.

## REF-099
Exact SHA256: `cc653fbc181a5df910eda1ccbb39eac1a023b4815913a864553ce3c6aa652140`. Retained: `supplements\WP10\reference_library\REF-099.webp`.

A visible bulb lights shaped labeled containers on deep patterned shelves, with useful readable local contrast.

Compare the shaped garden courts, supported opaque coffers and planted rest edges positively; use cool staff references for the isolated workroom and deep module/ledge lessons for selected quiet-edge ends without taking route width.

Limit: Appearance/material lesson only; no food programme, borrowed labels or uniform ambient wash.

## REF-116
Exact SHA256: `35f53a078f3a620c83385278c0a6e8a83f3b8e43d48e1603f3ced363b4dc3a1c`. Retained: `supplements\WP10\reference_library\REF-116.png`.

Cool guarded task fixture, end plates, brackets and clipped services have real physical mounts and readable maintenance organization.

Compare the shaped garden courts, supported opaque coffers and planted rest edges positively; use cool staff references for the isolated workroom and deep module/ledge lessons for selected quiet-edge ends without taking route width.

Limit: Translate to original low-poly staff fixtures; photo is not a dimension or engineering certificate.

## REF-136
Exact SHA256: `c9a0df0a78dcaf68fd379c35d2cbd1bcaf2a58057966603ab4765e9febbeaabe`. Retained: `supplements\WP10\reference_library\REF-136.png`.

Weighted supports, layered edges, local light and inhabited focal places carry composition at different distances.

Compare the shaped garden courts, supported opaque coffers and planted rest edges positively; use cool staff references for the isolated workroom and deep module/ledge lessons for selected quiet-edge ends without taking route width.

Limit: Quality/hierarchy comparison only; gold luxury treatment is inappropriate in staff-only workrooms, and extra levels/windows/capacity are not inferred.

## Catalog-wide application limits

- REF-001–008: Arrival hierarchy, crafted stock/personal scale, seating/ceiling coherence and allocation orientation. Relevant originals selected below. Limit: No unrelated cabin, dining, outside view, atrium level or brand becomes room programme.
- REF-009–043: Historical runtime examples distinguish shaped thresholds, source lighting, inhabited edges, care and staff/public character. REF021/022 reopened at full resolution. Limit: Legacy controls, species and prior local approval do not certify this revision; sheet view is not individual full-resolution inspection.
- REF-044–066: Atlas and planning diagrams reinforce separate allocations, interfaces and evidence limits. D01 atlas reopened for WP08/09. Limit: Hotel/lift/restaurant planning is outside these four rooms; no new cores, rooms or ownership inferred.
- REF-067–096: Blueprint hierarchy, functional programme rows and modular ends/returns inform distinct work and public rooms; relevant kit and blueprint originals reopened. Limit: Historical counts, labels, brands, technical claims and exterior openings remain subordinate to current master/allocation.
- REF-097–114: Deep threshold, stocked local bulb, garden hierarchy and close material lessons; relevant originals reopened. Limit: No film staging, soundtrack, restaurant, extra volume or photoreal finish copied. Cyberpunk density is not random clutter.
- REF-115–132: Practical staff service mounting and personal-scale organization contrast with guest luxury and inhabited circulation. REF116 reopened. Limit: Corridor dimensions, berths, exterior windows, hotel/tram structures and branded objects not imported.
- REF-133–136: Manufactured staff interfaces and layered public support/light are useful contrasting craft benchmarks. REF136 reopened. Limit: No lift or atrium programme in these rooms; no reference or prototype serves as blanket approval.

All12 sheet paths and hashes are in REFERENCE_SUPPLEMENT.json. These are review references, not licensed production textures.
