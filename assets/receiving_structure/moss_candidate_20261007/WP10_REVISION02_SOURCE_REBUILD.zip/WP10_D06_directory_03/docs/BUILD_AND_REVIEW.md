HISTORICAL REVISION01 DOCUMENT. Current source proposal, experience and gate status are in ../../EXPERIENCE_BRIEF.md. Its prior holds and acceptance references are dated history, not current status.

# WP10 build and review

Run only in the coordinator-assigned heavy slot. Portable Blender4.3.2, CPU12 threads. All builder inputs are bundled. The package root is discovered from __file__; no native Catalogue or Game writes occur.

```powershell
$blender = 'C:/Users/cered/Dolphin/AstraeaTools/blender-4.3.2-windows-x64/blender.exe'
$packet = 'C:/Users/cered/Dolphin/AstraeaShip/external_packages/windows/WP10_D06_directory_03'
& $blender --background --factory-startup --threads 12 --python "$packet/source/build_moss_sanctuary.py"
& $blender --background --factory-startup --threads 12 --python "$packet/tests/check_native.py"
python "$packet/tests/check_export.py"
& $blender --background --factory-startup --threads 12 --python "$packet/source/render_review.py" -- arrival court sheltered quiet care mounts loop
```

The native .blend retains editable approved native instances and packed textures. The GLB shares evaluated family meshes, excludes SOURCE_PREVIEW_ONLY floor/inlays and exports punctual spots. Piers, soffits, mount shoes and stock/care contents remain in all ordinary-eye images. Section camera is separate diagnostic only.

Review actual eye-level pixels for: correct readable backed entrance identity; substantial low layered gardens and exposed growing medium; root/seat separation; unobstructed loop and screened care doors; supported canopy/coffer and fixture contacts; legible quiet seat and task-lit worktop; plausible material/texture scale; no neighbour/exterior opening. Native and actual GLB bounds checks must pass before source visual approval. These do not certify live traversal, collision, full atmospheric systems, operation of doors or final runtime light budget.

Parent owns floor/slab/interface adoption and the unbuilt4m receiver. No upload, global Catalogue registration or Game edits are part of this package. Heavy build and visual review were not run by the section owner.
