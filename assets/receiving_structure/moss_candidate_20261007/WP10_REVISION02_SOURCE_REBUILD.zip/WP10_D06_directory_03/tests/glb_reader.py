import json,struct
def glb(path):
    b=path.read_bytes();n=struct.unpack_from('<I',b,12)[0];d=json.loads(b[20:20+n]);off=20+n;binary=b[off+8:]
    def acc(i):
        a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];fmt={5126:'f',5125:'I',5123:'H',5121:'B'}[a['componentType']];w={'SCALAR':1,'VEC3':3}[a['type']];stride=v.get('byteStride',struct.calcsize(fmt)*w);start=v.get('byteOffset',0)+a.get('byteOffset',0)
        return [struct.unpack_from('<'+fmt*w,binary,start+j*stride) for j in range(a['count'])]
    parent={c:i for i,n in enumerate(d['nodes']) for c in n.get('children',[])}
    def point(p,i):
        n=d['nodes'][i]
        if 'matrix' in n:
            m=n['matrix'];p=[sum(m[k+4*j]*p[j] for j in range(3))+m[k+12] for k in range(3)]
        else:
            p=[a*s for a,s in zip(p,n.get('scale',[1,1,1]))];x,y,z,w=n.get('rotation',[0,0,0,1]);u=[x,y,z];cross=lambda a,b:[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];t=[2*q for q in cross(u,p)];c=cross(u,t);p=[p[k]+w*t[k]+c[k]+n.get('translation',[0,0,0])[k] for k in range(3)]
        return point(p,parent[i]) if i in parent else p
    rows=[]
    for i,node in enumerate(d['nodes']):
        if 'mesh' not in node:continue
        for primitive in d['meshes'][node['mesh']]['primitives']:
            vs=[point(p,i) for p in acc(primitive['attributes']['POSITION'])];idx=[v[0] for v in acc(primitive['indices'])] if 'indices' in primitive else list(range(len(vs)))
            rows.extend((node.get('name','')+'@'+d['nodes'][parent[i]].get('name','') if i in parent else node.get('name',''),[vs[idx[k+j]] for j in range(3)]) for k in range(0,len(idx),3))
    return rows

