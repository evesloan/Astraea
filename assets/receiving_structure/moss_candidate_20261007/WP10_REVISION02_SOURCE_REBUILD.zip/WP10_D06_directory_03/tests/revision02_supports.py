"""Actual evaluated root/rock/stock bearings, including collection instances."""
import bpy,json,hashlib,math
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
P=Path(__file__).resolve().parents[1];src=P/'source/WP10_moss_sanctuary.blend'
bpy.ops.wm.open_mainfile(filepath=str(src));dg=bpy.context.evaluated_depsgraph_get()
def evaluated(ob,matrix=None):
    ev=ob.evaluated_get(dg);me=ev.to_mesh();m=matrix if matrix is not None else ev.matrix_world
    pts=[m@q.co for q in me.vertices];faces=[list(f.vertices) for f in me.polygons];ev.to_mesh_clear();return pts,faces
supports=[]
for ob in bpy.context.scene.objects:
    if ob.type!='MESH':continue
    if ob.get('SOURCE_PREVIEW_ONLY') or 'visible_growing_medium' in ob.name or ob.name.endswith('_soil') or ob.name.startswith('WP10_stock_shelf') and 'post' not in ob.name:
        pts,faces=evaluated(ob);supports.append((ob.name,BVHTree.FromPolygons(pts,faces)))
def support_below(point,kind,tested_name):
    hitlist=[]
    for name,tree in supports:
        if name==tested_name:continue
        if kind=='planter' and 'SOURCE_PREVIEW_ONLY_floor' not in name:continue
        if kind!='planter' and 'SOURCE_PREVIEW_ONLY' in name:continue
        if kind=='stock' and not name.startswith('WP10_stock_shelf'):continue
        if kind!='stock' and name.startswith('WP10_stock_shelf'):continue
        loc,normal,idx,d=tree.ray_cast(Vector((point.x,point.y,point.z+.30)),Vector((0,0,-1)),.62)
        if loc is not None:hitlist.append((abs(loc.z-point.z),name,loc.z))
    return min(hitlist) if hitlist else None
checks=[]
def check(name,pts,kind,faces=None):
    lo=min(p.z for p in pts)
    if kind=='moss':
        # Evaluated solidified bottom faces, not an intended growth datum.
        probes=[]
        for face in faces:
            a,b,c=(pts[face[i]] for i in range(3));n=(b-a).cross(c-a)
            if n.z<0:probes.append(sum((pts[i] for i in face),Vector())/len(face))
    else:
        bottom=[p for p in pts if p.z<=lo+.008]
        probes=[sum(bottom,Vector())/len(bottom)]
    failures=[];receipts=[]
    for p in probes:
        bearing=support_below(p,kind,name);gap=p.z-bearing[2] if bearing else None
        # Embedded plant roots/rock toes are legitimate; a hovering base is not.
        ok=bearing is not None and -.24<=gap<=.012
        r={'point':list(p),'bearing':bearing[1] if bearing else None,'actual_support_z':bearing[2] if bearing else None,'gap_m':gap,'pass':ok}
        if not ok:failures.append(r)
        if len(receipts)<6:receipts.append(r)
    checks.append({'node':name,'kind':kind,'evaluated_bottom_z':lo,'probe_count':len(probes),'failures':failures,'sample_evidence':receipts,'pass':bool(probes) and not failures})
for ob in bpy.context.scene.objects:
    if ob.type!='MESH':continue
    name=ob.name
    kind='planter' if name.startswith(('WP10_R02_fore_tree_planter_base','WP10_R02_aft_tree_tier_')) and name.endswith('_base') or name.endswith('_contained_base') else 'moss' if 'continuous_moss_swathe' in name or name.endswith('_root_moss') or name.endswith('_root_north_moss') or name.endswith('_root_south_moss') else 'root' if '_rooted_trunk' in name else 'rock' if name.startswith(('WP10_R02_fore_rock_','WP10_R02_aft_rock_')) else 'stock' if (name.startswith('WP10_R02_care_product_') and '_cap_' not in name or name.startswith('WP10_sealed_supply_bin')) else None
    if kind:
        pts,faces=evaluated(ob);check(name,pts,kind,faces)
for ob in bpy.context.scene.objects:
    if ob.type!='EMPTY' or not ob.instance_collection or not ob.name.startswith(('WP10_R02_fore_moss_groundcover_','WP10_R02_rooted_shrub_drift_')):continue
    pts=[]
    for child in ob.instance_collection.objects:
        if child.type=='MESH':points,_=evaluated(child,ob.matrix_world@child.matrix_world);pts.extend(points)
    check(ob.name,pts,'plant')
# Care stock mutual intersections are independently checked with actual bounds.
stock_bounds=[]
for ob in bpy.context.scene.objects:
    if ob.type!='MESH' or not (ob.name.startswith('WP10_R02_care_product_') or ob.name.startswith('WP10_sealed_supply_bin')):continue
    pts,faces=evaluated(ob);stock_bounds.append((ob.name,[min(p[k] for p in pts) for k in range(3)],[max(p[k] for p in pts) for k in range(3)]))
overlap=[]
for i,(name,lo,hi) in enumerate(stock_bounds):
    for other,lo2,hi2 in stock_bounds[i+1:]:
        # Own cap touches its vessel intentionally; each is smaller than the body.
        if name.replace('_cap_','_')==other or other.replace('_cap_','_')==name:continue
        depth=[min(hi[k],hi2[k])-max(lo[k],lo2[k]) for k in range(3)]
        if all(d>.003 for d in depth):overlap.append({'a':name,'b':other,'overlap_m':depth})
contents=[]
for ob in bpy.context.scene.objects:
    if ob.type!='MESH' or not ob.name.startswith('WP10_R02_horti_'):continue
    name=ob.name;pts,faces=evaluated(ob);bottom=min(p.z for p in pts);low=[p for p in pts if p.z<bottom+.002];point=sum(low,Vector())/len(low)
    if '_tie_bundle_' in name:index=0;previous=int(name.rsplit('_',1)[1]);bearing='WP10_R02_care_product_0' if previous==0 else name.rsplit('_',1)[0]+'_'+str(previous-1)
    elif '_pot_label_' in name:index=1;bearing='WP10_R02_care_product_1'
    elif '_cloth_' in name:index=2;previous=int(name.rsplit('_',1)[1]);bearing='WP10_R02_care_product_2' if previous==0 else name.rsplit('_',1)[0]+'_'+str(previous-1)
    elif '_brush_handle_' in name:index=3;bearing='WP10_R02_care_product_3'
    elif '_brush_head_' in name:index=3;bearing=name.replace('_brush_head_','_brush_handle_')
    elif '_brush_bristles_' in name:index=3;bearing=name.replace('_brush_bristles_','_brush_head_')
    else:continue
    support=bpy.context.scene.objects[bearing];assert support.name!=ob.name,('Self support excluded',ob.name);sp,sf=evaluated(support);tree=BVHTree.FromPolygons(sp,sf)
    loc,normal,face,d=tree.ray_cast(point+Vector((0,0,.002)),Vector((0,0,-1)),.08);gap=point.z-loc.z if loc is not None else None
    cx=-8-[7.1,7.7,8.3,8.9][index];cy=250-1.38
    footprint=max(math.hypot(p.x-cx,p.y-cy) for p in low)<=.14+.003
    contents.append({'node':name,'actual_bottom':bottom,'bearing':bearing,'actual_bearing_z':loc.z if loc is not None else None,'gap_m':gap,'root_footprint_inside_container':footprint,'pass':gap is not None and -.003<=gap<=.01 and footprint})
r={'pass':not overlap and bool(checks) and all(c['pass'] for c in checks) and contents and all(c['pass'] for c in contents),'native_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'scope':'Actual evaluated geometry and vertical bearing rays; embedded garden roots distinguished from floating objects; no structural rating','checks':checks,'actual_care_stock_overlaps':overlap,'horticultural_content_bearings':contents}
(P/'qa/revision02_supports.json').write_text(json.dumps(r,indent=2)+'\n');print('SUPPORTS',r['pass'],'checks',len(checks),'failed',[c['node'] for c in checks if not c['pass']],'overlaps',overlap,'content_failures',[c for c in contents if not c['pass']]);assert r['pass']
