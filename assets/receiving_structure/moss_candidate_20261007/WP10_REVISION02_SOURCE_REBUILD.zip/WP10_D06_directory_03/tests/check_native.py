"""Independent native reload, bounds and source dependency verification; scheduled Blender job."""
import bpy,json,hashlib,struct
from pathlib import Path
P=Path(__file__).resolve().parents[1]
for r in json.loads((P/'assets/dependencies.json').read_text()):assert hashlib.sha256((P/r['file']).read_bytes()).hexdigest()==r['sha256']
bpy.ops.wm.open_mainfile(filepath=str(P/'source/WP10_moss_sanctuary.blend'))
s=bpy.context.scene
assert any(o.get('SOURCE_PREVIEW_ONLY') for o in s.objects)
# Verify actual saved source geometry, including one surface, shared vertices and coverage.
import sys
sys.path.insert(0,str(P/'source'))
from preview_floor import verify_partition
preview_objects=[o for o in s.objects if o.get('SOURCE_PREVIEW_ONLY')]
assert len(preview_objects)==1 and preview_objects[0].type=='MESH'
preview=preview_objects[0];points=[preview.matrix_world@v.co for v in preview.data.vertices]
assert all(abs(v.z-27)<1e-6 for v in points)
proof=verify_partition([(-8-v.x,250-v.y) for v in points],
                       [tuple(face.vertices) for face in preview.data.polygons],tolerance=.001)
assert {face.material_index for face in preview.data.polygons}=={0,1}
proof.update({'scope':'Actual reloaded native mesh','surface_world_y':27,'SOURCE_PREVIEW_ONLY':True})
(P/'qa/preview_floor_native_check.json').write_text(json.dumps(proof,indent=2)+'\n')
assert len([o for o in s.objects if o.instance_type=='COLLECTION'])>60
assert len([o for o in s.objects if o.type=='LIGHT'])>15
assert all(im.packed_file for im in bpy.data.images if im.source=='FILE' and im.users>0)
deps=bpy.context.evaluated_depsgraph_get();bounds=[[1e9]*3,[-1e9]*3];violations=[];meshes=0
for inst in deps.object_instances:
    ob=inst.object
    if ob.type not in {'MESH','CURVE','FONT'} or ob.original.get('SOURCE_PREVIEW_ONLY'):continue
    mesh=bpy.data.meshes.new_from_object(ob,depsgraph=deps);meshes+=1
    for vert in mesh.vertices:
        co=inst.matrix_world@vert.co;p=[co.x,co.z,-co.y]
        for k in range(3):bounds[0][k]=min(bounds[0][k],p[k]);bounds[1][k]=max(bounds[1][k],p[k])
        if not(-54.0002<=p[0]<=-7.9998 and 26.9998<=p[1]<=35.5002 and -250.0002<=p[2]<=-181.9998):
            if len(violations)<25:violations.append({'name':ob.name,'point':p})
    bpy.data.meshes.remove(mesh)
raw=(P/'exports/WP10_moss_sanctuary.glb').read_bytes();doc=json.loads(raw[20:20+struct.unpack_from('<I',raw,12)[0]])
nodes={n.get('name'):n for n in doc['nodes']};labels=[]
for ob in s.objects:
    if ob.type!='FONT':continue
    node=nodes.get(ob.name,{});primitives=doc['meshes'][node['mesh']]['primitives'] if 'mesh' in node else []
    count=sum(doc['accessors'][p['attributes']['POSITION']]['count'] for p in primitives)
    labels.append({'native_FONT':ob.name,'body':ob.data.body,'actual_export_positions':count,'all_UV':bool(primitives) and all('TEXCOORD_0' in p['attributes'] for p in primitives),'pass':count>0 and bool(primitives) and all('TEXCOORD_0' in p['attributes'] for p in primitives)})
report={'pass':not violations and labels and all(r['pass'] for r in labels),'scope':'native editable reload,packed images,retained dependencies,evaluated source bounds and actual FONT-to-GLB mesh parity; not runtime/visual acceptance','evaluated_objects':meshes,'bounds_world_godot':bounds,'violations':violations,'font_mesh_parity':labels,'native_sha256':hashlib.sha256((P/'source/WP10_moss_sanctuary.blend').read_bytes()).hexdigest(),'glb_sha256':hashlib.sha256(raw).hexdigest()}
(P/'qa/native_check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));assert not violations
assert report['pass']
