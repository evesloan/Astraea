"""Independent actual native ray, fitted target, UV and conservative route gates."""
import bpy, json, math, hashlib
from pathlib import Path
from mathutils import Vector
P=Path(__file__).resolve().parents[1]
bpy.ops.wm.open_mainfile(filepath=str(P/'source/WP10_moss_sanctuary.blend'))
s=bpy.context.scene;dg=bpy.context.evaluated_depsgraph_get()
# World-space AABBs from actual evaluated mesh vertices, including retained instances.
solids=[]
for inst in dg.object_instances:
    ob=inst.object
    if ob.type not in {'MESH','CURVE','FONT'} or ob.original.get('SOURCE_PREVIEW_ONLY'):continue
    coords=[inst.matrix_world@Vector(c) for c in ob.bound_box]
    lo=[min(c[k] for c in coords) for k in range(3)];hi=[max(c[k] for c in coords) for k in range(3)]
    if hi[2]>27.08 and lo[2]<29.1:solids.append((ob.name,lo,hi))

def obstacles(u,v,r):
    x,y=-8-u,250-v;result=[]
    for name,lo,hi in solids:
        dx=max(lo[0]-x,0,x-hi[0]);dy=max(lo[1]-y,0,y-hi[1])
        if dx*dx+dy*dy<r*r-1e-8:result.append(name)
    return result

routes=[('public_east',(10,12),(10,62)),('public_west',(36,12),(36,62)),
        ('public_fore',(10,12),(36,12)),('public_aft',(10,62),(36,62)),
        ('arrival',(0,34),(43,34)),('staff_spine',(43,7.5),(43,62)),
        ('staff_workroom',(10,7.5),(43,7.5)),('staff_entry',(10,7.5),(10,12)),
        ('staff_aft_entry',(36,59),(43,59))]
fail=[];samples=0
for name,a,b in routes:
    length=math.dist(a,b);n=math.ceil(length/.25)
    for i in range(n+1):
        u=a[0]+(b[0]-a[0])*i/n;v=a[1]+(b[1]-a[1])*i/n;samples+=1
        for r in [.3,.65]:
            obs=obstacles(u,v,r)
            if obs:fail.append({'route':name,'local_uv':[u,v],'radius':r,'obstructions':obs})

interaction=[]
for c in json.loads((P/'runtime/interaction_candidates.json').read_text())['candidates']:
    ob=bpy.data.objects[c['visual_node']];focus=Vector((c['focus_world_m'][0],-c['focus_world_m'][2],c['focus_world_m'][1]))
    feet=c['approach_feet_world_m'];eye=Vector((feet[0],-feet[2],feet[1]+1.68));direction=focus-eye
    hit,location,normal,face,hitob,matrix=s.ray_cast(dg,eye,direction.normalized(),distance=direction.length+.08)
    diagonal=math.sqrt(sum(q*q for q in c['target_size_m']))
    approach=obstacles(-8-feet[0],feet[2]+250,.65)
    interaction.append({'id':c['id'],'range':direction.length,'hit':hitob.name if hit else None,
       'expected':ob.name,'target_diagonal_m':diagonal,'approach_obstructions':approach,'pass':bool(hit and hitob.name==ob.name and direction.length<=2.5 and diagonal<=1.2 and not approach)})

water=bpy.data.objects['WP10_R02_STREAM_WATER_01'];assert water.type=='MESH'
uv=water.data.uv_layers.active;water_y=[water.matrix_world@v.co for v in water.data.vertices]
water_pass=bool(uv and all(abs(v.z-27.28)<.0001 for v in water_y) and min(p.normal.z for p in water.data.polygons)>.9)
report={'pass':not fail and all(c['pass'] for c in interaction) and water_pass,
 'native_sha256':hashlib.sha256((P/'source/WP10_moss_sanctuary.blend').read_bytes()).hexdigest(),
 'scope':'Conservative actual native AABB swept route samples, real scene interaction rays, stream UV/level; not runtime or pixel acceptance',
 'routes':routes,'samples_per_radius':samples,'radii':[.3,.65],'route_failures':fail,'interactions':interaction,'stream_level_uv_upward_normals':water_pass}
(P/'qa/revision02_native_gates.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='route_failures'}));print('route failures',len(fail));assert report['pass']
