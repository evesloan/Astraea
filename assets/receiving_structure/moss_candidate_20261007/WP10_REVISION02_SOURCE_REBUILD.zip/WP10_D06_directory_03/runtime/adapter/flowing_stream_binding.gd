extends RefCounted
## Reuses the existing game's water shader. Surface animation, not fluid simulation.
static func bind(root: Node3D, exact_mesh_names: PackedStringArray, shader: Shader, speed: float = 0.12) -> Dictionary:
	var bound: Array[String] = []
	var missing: Array[String] = []
	for mesh_name in exact_mesh_names:
		var mesh := root.find_child(mesh_name, true, false) as MeshInstance3D
		if mesh == null:
			missing.append(mesh_name)
			continue
		var material := ShaderMaterial.new()
		material.shader = shader
		material.set_shader_parameter("flow_speed", speed)
		mesh.material_override = material
		mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		bound.append(mesh_name)
	return {"bound": bound, "missing": missing, "scope": "UV.y surface travel only; no audio, fluid, contact or gameplay simulation"}

