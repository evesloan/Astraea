# Whole Team Lounge runtime candidate

This is an isolated overlay, not a standalone complete project. Nothing was applied to live Game. `FINAL_APPLY_MANIFEST.json` unions `Game/` and `proof_work/Game/`, with exact staged paths and live predecessor hashes. Apply only this allowlist after independent retention; do not copy the earlier compiler dependency tree wholesale.

## Implemented

- The selected source-faithful 241-surface derivative is instantiated once at (31,35.5,216), retaining 4,676 source semantic identities. Original GLB bytes are archived as `.glb.archive` to prevent a second 4,263-mesh import.
- Exactly 101 physics groups consume deterministic little-endian float32 source faces. Four root-local groups and 97 original-local singletons preserve every face, including the explicitly ledgered 832 zero-area faces. Independent byte comparison and corruption controls passed.
- Ninety physical spotlight adaptations begin invisible and request shadows before the sole existing `lighting_budget.configure` scan. Shared budgets, manager, renderer and controllers stay unchanged. Source inner-cone metadata is preserved; Godot angular falloff remains a stated bounded calibration rather than an exact Blender/glTF light model.
- Ninety-six inert proposed rest markers create no admission capacity or interactions.
- A region-local shader replaces only the 52 existing top-chunk materials. It reproduces the source material predicates and world UVs, using the exact 192-sided nominal lobe construction for stone bearing-pad fringes. No overlay mesh or duplicate floor/collision is added.
- The nine previously validated compiler changes add the shaped receiving slab and four-metre connector. Strict runtime proof composes the complete current botanical predecessor with exact inverse edits, full 277-owner roster, source import geometry, collision, light and semantic checks.

## Source checks

Run from this directory:

`PYTHONDONTWRITEBYTECODE=1 python verify_source_stage.py`

`PYTHONDONTWRITEBYTECODE=1 python collision_work/verify_collision_faces.py`

The existing GDScript grammar parser is available under `botanical_receiving_court_build_20261007/proof_integration003/parser_deps`. Its default HOME is read-only; use this directory's `parser_cache` as HOME. Two setup failures are preserved in the session evidence; the subsequent grammar checks passed. Grammar validation is not Godot semantic validation.

## Root engine sequence after retained bounded application

Use the existing isolated HOME/XDG environment and source-freeze receipts from the project's current validation workflow. Do not run engines concurrently.

1. `godot --headless --path /workspace/shared/Astraea_recovery_20261007_AXWr5x/Game --editor --quit`
2. `godot --headless --path /workspace/shared/Astraea_recovery_20261007_AXWr5x/Game --fixed-fps 60 --quit-after 30000 --script res://tests/validate_team_lounge_access.gd`

The access test calls the complete structural/runtime successor proof before one normal D07-spine arrival and ordinary W-input traversal through the threshold, both source cleaning circuits, refreshment/return approaches and back to the spine. It is not registered in `tools/validate.py`, to avoid an unrelated pinned runner change. A PASS marker and an error-free zero exit are both required; retained attempted receipts go to `Game/artifacts/`.

Godot may canonicalize the newly authored `.import`; preserve that first result and make a measured exact successor to its pin rather than accepting arbitrary changes. Imported winding, exact UV/material spellings and all 832 degenerate faces are deliberately checked strictly. Any native failure is a real unfinished gate, not a reason to relax old tolerances.

After the first whole-destination gate, run affected predecessor checks using the normal `tools/validate.py --only ...` workflow, then an actual loaded-cart entry/turn/cleaning/service-return exercise and normal 1.65m-eye CRT-on/off views. Primary hull/deck bearing, all-species use, audio, autonomous population, target hardware and final art remain unaccepted. No engine was launched by this worker.
