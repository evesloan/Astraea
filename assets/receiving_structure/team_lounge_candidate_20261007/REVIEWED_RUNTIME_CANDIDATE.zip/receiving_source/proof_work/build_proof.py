#!/usr/bin/env python3
"""Build only the isolated lounge proof overlay. Never mutates production Game."""
import argparse,hashlib,json,shutil
from pathlib import Path
HERE=Path(__file__).resolve().parent
STAGE=HERE.parent.parent
BASE=Path('/workspace/shared/Astraea_recovery_20261007_AXWr5x/Game')
CANDIDATE=STAGE/'candidate/Game'
RUNTIME=HERE.parent/'Game'
OUT=HERE/'Game'
GUARD='tests/medical_triage_successor_guard.gd'
PROOF='data/architecture/packages/team_lounge/TEAM_LOUNGE_RUNTIME_PROOF.json'
RETAIN='data/architecture/packages/team_lounge/retained_275'
def sha(data):return hashlib.sha256(data).hexdigest()
def read(p):return p.read_text()
def write(rel,data):
 p=OUT/rel;p.parent.mkdir(parents=True,exist_ok=True)
 p.write_bytes(data if isinstance(data,bytes) else data.encode())
def build():
 original=read(BASE/GUARD); source=original; edits=[]
 def change(before,after):
  nonlocal source
  assert source.count(before)==1,(before,source.count(before))
  source=source.replace(before,after)
  edits.insert(0,{'before':before,'after':after,'count':1})
 change('return checked and (value==current_compiled or value==botanical_current_compiled)',
  'return checked and (value==current_compiled or value==botanical_current_compiled or value==team_lounge_current_compiled)')
 change('\tif value==botanical_current_compiled: value=current_compiled',
  '\tif value==team_lounge_current_compiled: value=botanical_current_compiled\n\tif value==botanical_current_compiled: value=current_compiled')
 change('static func _botanical_ensure() -> void:\n\tif botanical_checked: return',
  'static func _botanical_ensure() -> void:\n\tif botanical_checked: return\n\t_team_lounge_ensure()')
 change('FileAccess.get_sha256("res://"+str(path))==str(botanical_proof.current_sha256[path])',
  '_team_lounge_current_sha256("res://"+str(path))==str(botanical_proof.current_sha256[path])')
 change('var own_source := FileAccess.get_file_as_string("res://tests/medical_triage_successor_guard.gd")',
  'var own_source := _team_lounge_current_text("res://tests/medical_triage_successor_guard.gd")')
 change('var restored := FileAccess.get_file_as_string("res://"+str(path))',
  'var restored := _team_lounge_current_text("res://"+str(path))')
 for path in ['data/spatial_layout.json','data/generated/structural_meshes.json','docs/LAYOUT_COMPILE_CHECKS.json']:
  change('FileAccess.get_file_as_string("res://'+path+'")','_team_lounge_current_text("res://'+path+'")')
 change('\tassert(floors!=null and floors.get_child_count()==botanical_current_compiled.regions.size(),"Complete 275-owner current floor roster required")',
  '\tvar actual_owners: Array=_team_lounge_floor_children(floors)\n\tassert(floors!=null and actual_owners.size()==botanical_current_compiled.regions.size(),"Complete 275-owner current floor roster required")')
 change('\tfor value in floors.get_children():','\tfor value in actual_owners:')
 runtime_validator=read(HERE/'runtime_validator.gd.in')
 section=read(HERE/'lounge_section.gd.in').replace('@RUNTIME_VALIDATOR@',runtime_validator.rstrip())
 assert '<PROOF_SHA>' in section and '@RUNTIME_VALIDATOR@' not in section
 block_hash=sha(section.encode())
 compiler=json.loads(read(CANDIDATE/'data/architecture/packages/team_lounge/TEAM_LOUNGE_COMPILER_PROOF.json'))
 manifest=json.loads(read(STAGE/'BOUNDED_COMPILER_APPLY_MANIFEST.json'))
 current={row['path']:row['candidate_sha256'] for row in manifest['files']}
 predecessors=dict(compiler['predecessors'])
 projected=list(predecessors)+['tools/compile_layout.py','scripts/ship.gd',GUARD]
 for path in ['tools/compile_layout.py','scripts/ship.gd',GUARD]:
  data=(BASE/path).read_bytes(); retained=RETAIN+'/'+path
  predecessors[path]={'retained_path':retained,'sha256':sha(data)}; write(retained,data)
 runtime_files=[p for p in RUNTIME.rglob('*') if p.is_file() and '.godot' not in p.parts]
 assert runtime_files,'Runtime builder has not produced its isolated Game overlay'
 for p in runtime_files:
  rel=p.relative_to(RUNTIME).as_posix()
  assert rel not in current or current[rel]==sha(p.read_bytes()),('Runtime/compiler conflict',rel)
  assert rel!=GUARD and rel!=PROOF,'Builder may not replace proof-owned source'
  current[rel]=sha(p.read_bytes())
 ship_anchor='\tlighting_budget.configure(self,player)'
 ship_add='\tpreload("res://scripts/team_lounge_receiving.gd").build(self)\n'+ship_anchor
 ship_before=read(BASE/'scripts/ship.gd'); assert ship_before.count(ship_anchor)==1
 ship_after=ship_before.replace(ship_anchor,ship_add)
 assert read(RUNTIME/'scripts/ship.gd')==ship_after,'Ship source must be exact one-call successor'
 inverse=json.loads(read(STAGE/'compiler_exact_inverse_edits.json'))
 inverse['scripts/ship.gd']=[{'before':ship_anchor,'after':ship_add,'count':1}]
 p={'schema':1,'scope':'Strict whole Team Lounge runtime addition; every 275-owner predecessor assertion retained',
 'programme_key':'D07_directory_08','projected_paths':projected,'current_sha256':dict(sorted(current.items())),
 'predecessors':predecessors,'added_owner_ids':['D07_team_lounge_receiving_floor','D07_team_lounge_axial_connector'],
 'added_layout_records':compiler['new_layout_records'],'added_compiled_records':json.loads(read(STAGE/'receiving_compiled_records.json')),
 'compile_summary':json.loads(read(CANDIDATE/'docs/LAYOUT_COMPILE_CHECKS.json')),
 'consumer_inverse_edits':edits,'integration_block_normalized_sha256':block_hash,'exact_inverse_edits':inverse,
 'runtime_manifest':'data/architecture/team_lounge/runtime_manifest.json',
 'acceptance_limits':['Source-only candidate; engine import, actual runtime geometry, contacts, traversal, cart, lighting and views remain unexecuted.','No capacity, all-species, primary-bearing-path or final-art acceptance.']}
 raw=(json.dumps(p,indent=2)+'\n').encode(); proof_sha=sha(raw)
 write(PROOF,raw);write(GUARD,source+section.replace('<PROOF_SHA>',proof_sha,1))
 rows=[]
 for f in sorted(OUT.rglob('*')):
  if f.is_file():
   rel=f.relative_to(OUT).as_posix()
   rows.append({'path':rel,'sha256':sha(f.read_bytes()),'bytes':f.stat().st_size,'existing_Game_sha256':sha((BASE/rel).read_bytes()) if (BASE/rel).exists() else None})
 (HERE/'PROOF_APPLY_MANIFEST.json').write_text(json.dumps({'scope':'Only these proof files; compiler and runtime overlays are separate bounded manifests.','files':rows},indent=2)+'\n')
 print(json.dumps({'proof_sha256':proof_sha,'files':len(rows),'pinned_current_inputs':len(current),'predecessor_source_sha256':sha(original.encode())},indent=2))
if __name__=='__main__':build()
