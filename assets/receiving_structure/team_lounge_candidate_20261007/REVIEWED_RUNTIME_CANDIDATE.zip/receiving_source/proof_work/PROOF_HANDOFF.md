# Team Lounge exact runtime proof candidate

Only the five files in `PROOF_APPLY_MANIFEST.json` are this worker's apply outputs. Combine them with the separately reviewed nine compiler files and parent runtime overlay. Do not copy this whole working directory into Game.

`PROOF_SOURCE_VALIDATION.json` records five positive source checks and sixteen negative mutation controls. All pass. The full generated GDScript consumer parses with the retained gdtoolkit grammar. These checks did not run Godot or Blender, and do not establish Godot type checking, successful import, physics, lighting, traversal, art, species/capacity, performance, or structural bearing acceptance.

The proof consumer extends the existing botanical consumer in one normalized, hashed section. Its exact inverse restores every byte of the immediate predecessor (SHA-256 `600d0e7ed3bfa1f803b0b6eecd09e567c84e6910cbc0b35ced7ef6c41fb5632f`). The existing botanical section then authenticates its own original normalized logic and predecessors. No old source pins, tolerance, guards, or assertions were broadened. The one ship loader call precedes the original `lighting_budget.configure(self,player)` call; reversing it restores the whole previous ship source exactly.

The current proof pins123 inputs and requires all277 floor owners, order, complete source records and all live slab triangles before projecting275 into the existing botanical proof. The existing botanical guards and earlier medical/pool predecessor validations remain in the call path.

Whole-lounge checks include exact root placement, every imported hierarchy path/class/local transform,4676 source identities,241 surfaces,101 contact groups and complete face arrays,96 inert rest markers,90 physical lights with exact float32 scalar expectations and the existing manager's requested-shadow membership, eight-source global cap, and52 source-derived finish chunk bindings. All expected final paths are enumerated; added repeated child names are resolved by exact parent paths, not by broad name filtering.

A read-only GLB decoder independently requires every imported local position/UV triangle, material assignment, triangle multiplicity and Godot-reversed winding to match the pinned derivative. All494470 triangles, including832 precisely retained degenerate faces, are required. No blanket omission is accepted. Native imported normal arrays are compared with a fresh pinned import; source-to-derivative normal correspondence remains in the separate binary source receipt.

`tests/validate_team_lounge_access.gd` already calls `validate_current(floors)` before its walk, so no extra runner is needed. Root should invoke the existing fixed60 validation wrapper with that script after fresh import. Any importer rewriting of the new `.import` sidecar, different material spelling, UV/winding change, type error or degenerate omission must be inspected as an actual failure before revision. Do not call the source-only receipt runtime acceptance.

Rebuild after an explicitly reviewed runtime-overlay change with `python proof_work/build_proof.py`, then repeat `verify_proof_source.py` using the retained parser dependency path and a writable parser HOME. These tools write only inside proof_work. A rerun does not authorize changing the runtime overlay or old acceptance.
