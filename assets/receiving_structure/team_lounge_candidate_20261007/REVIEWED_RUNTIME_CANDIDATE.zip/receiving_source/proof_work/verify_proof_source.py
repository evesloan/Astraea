#!/usr/bin/env python3
"""Source-only verification; this does not execute Godot, contact or rendering tests."""
import copy, hashlib, json
from pathlib import Path
import build_proof as b
HERE=b.HERE
proof_bytes=(b.OUT/b.PROOF).read_bytes()
p=json.loads(proof_bytes)
guard=(b.OUT/b.GUARD).read_text()
compiler_paths={x['path'] for x in json.loads((b.STAGE/'BOUNDED_COMPILER_APPLY_MANIFEST.json').read_text())['files']}
checks=[]
def sha(x):return hashlib.sha256(x).hexdigest()
def resolve(rel):
 if (b.OUT/rel).is_file():return b.OUT/rel
 if (b.RUNTIME/rel).is_file():return b.RUNTIME/rel
 if rel in compiler_paths:return b.CANDIDATE/rel
 return b.BASE/rel
def checked(label,call):call();checks.append({'name':label,'status':'PASS'})
def ensure(condition,detail='Mismatch'):assert condition,detail
def undo(text,edits):
 for edit in edits:
  ensure(text.count(edit['after'])==edit['count'],'Inverse cardinality')
  text=text.replace(edit['after'],edit['before'])
 return text
def recovered_consumer(text):
 begin='# TEAM_LOUNGE_EXACT_SECTION_BEGIN\n';end='# TEAM_LOUNGE_EXACT_SECTION_END\n'
 ensure(text.count(begin)==text.count(end)==1)
 start=text.index(begin);finish=text.index(end)+len(end);block=text[start:finish]
 ensure(block.count(sha(proof_bytes))==1)
 ensure(sha(block.replace(sha(proof_bytes),'<PROOF_SHA>').encode())==p['integration_block_normalized_sha256'])
 return undo(text[:start]+text[finish:],p['consumer_inverse_edits'])
def assert_sources():
 for path,digest in p['current_sha256'].items():ensure(sha(resolve(path).read_bytes())==digest,path)
 for path,spec in p['predecessors'].items():
  data=resolve(spec['retained_path']).read_bytes()
  ensure(sha(data)==spec['sha256'],path)
  ensure(data==(b.BASE/path).read_bytes(),'Predecessor must equal surviving production input: '+path)
 ensure(recovered_consumer(guard)==(b.BASE/b.GUARD).read_text())
 for path,edits in p['exact_inverse_edits'].items():ensure(undo(resolve(path).read_text(),edits)==(b.BASE/path).read_text(),path)
 ensure(sha(proof_bytes) in guard)
 old=recovered_consumer(guard)
 botanical=json.loads((b.BASE/'data/architecture/packages/botanical_court/BOTANICAL_RUNTIME_PROOF.json').read_text())
 for path,digest in botanical['current_sha256'].items():
  now=(b.BASE/path).read_bytes() if path in p['projected_paths'] else resolve(path).read_bytes()
  ensure(sha(now)==digest,'Botanical acceptance is preserved: '+path)
 start=old.index('# BOTANICAL_EXACT_SECTION_BEGIN\n');finish=old.index('# BOTANICAL_EXACT_SECTION_END\n')+len('# BOTANICAL_EXACT_SECTION_END\n')
 proof_sha=sha((b.BASE/'data/architecture/packages/botanical_court/BOTANICAL_RUNTIME_PROOF.json').read_bytes())
 ensure(sha(old[start:finish].replace(proof_sha,'<PROOF_SHA>').encode())==botanical['integration_block_normalized_sha256'])
 ensure(undo(old[:start]+old[finish:],botanical['consumer_inverse_edits'])==(b.BASE/botanical['predecessors'][b.GUARD]['retained_path']).read_text())

def structures(layout,compiled,summary):
 old_layout=json.loads((b.BASE/'data/spatial_layout.json').read_text());old_compiled=json.loads((b.BASE/'data/generated/structural_meshes.json').read_text())
 for now,old,added in [(layout,old_layout,p['added_layout_records']),(compiled,old_compiled,p['added_compiled_records'])]:
  ensure(now['regions']==old['regions']+added,'Exact retained and added records/order')
  ensure(len({r['id']for r in now['regions']})==len(now['regions']))
 ensure({k:v for k,v in layout.items() if k!='regions'}=={k:v for k,v in old_layout.items() if k!='regions'})
 ensure({k:v for k,v in compiled.items() if k not in ['regions','source_checks']}=={k:v for k,v in old_compiled.items() if k not in ['regions','source_checks']})
 ensure(summary==compiled['source_checks']==p['compile_summary'])
 ensure(summary['team_lounge_additive_preservation']['complete_old_records_preserved'])
 ensure(len(compiled['regions'])==277 and len(old_compiled['regions'])==275)
 ensure([r['id']for r in p['added_compiled_records']]==p['added_owner_ids'])
 for r in p['added_compiled_records']:ensure(r['deck']=='D07' and r['floor_y']==35.5 and r['thickness']==.24)
 ensure([r['structural_area_m2']for r in p['added_compiled_records']]==[2477.7225461174385,16])
layout=json.loads(resolve('data/spatial_layout.json').read_text());compiled=json.loads(resolve('data/generated/structural_meshes.json').read_text());summary=json.loads(resolve('docs/LAYOUT_COMPILE_CHECKS.json').read_text())
checked('All123 current pins, six exact predecessors, complete botanical and preceding consumer bytes',assert_sources)
checked('Exact current277 records, predecessor275, global records and summaries',lambda: structures(layout,compiled,summary))
checked('Ship preserves all prior bytes with exactly one loader before manager configure',lambda:ensure(resolve('scripts/ship.gd').read_text().replace('\tpreload("res://scripts/team_lounge_receiving.gd").build(self)\n','')==(b.BASE/'scripts/ship.gd').read_text()))
negative=[]
def rejected(label,call):
 try:call()
 except AssertionError:negative.append({'name':label,'status':'REJECTED_AS_REQUIRED'});return
 raise AssertionError('Mutation escaped: '+label)
for label,target,mutate in [
 ('old floor complete record changed','compiled',lambda x:x['regions'][0].update({'floor_y':-10})),
 ('new receiving slab triangle changed','compiled',lambda x:x['regions'][-2]['triangles'][0][0].__setitem__(0,100)),
 ('new connector missing','compiled',lambda x:x['regions'].pop()),
 ('unrelated extra owner','compiled',lambda x:x['regions'].append(dict(x['regions'][0],id='rogue'))),
 ('duplicate owner','compiled',lambda x:x['regions'].append(x['regions'][0])),
 ('predecessor record order changed','compiled',lambda x:x['regions'].reverse()),
 ('global layout metadata changed','layout',lambda x:x.update({'rogue':True})),
 ('old source region changed','layout',lambda x:x['regions'][0].update({'status':'changed'})),
 ('summary changed','summary',lambda x:x.update({'regions':275})),
]:
 values={'layout':copy.deepcopy(layout),'compiled':copy.deepcopy(compiled),'summary':copy.deepcopy(summary)}
 mutate(values[target]);rejected(label,lambda values=values:structures(**values))
rejected('old botanical tolerance change rejected by complete inverse',lambda:ensure(recovered_consumer(guard.replace('var distance: float=0.0001','var distance: float=0.001'))==(b.BASE/b.GUARD).read_text()))
rejected('extra loader call rejected by exact inverse',lambda:ensure(undo(resolve('scripts/ship.gd').read_text()+'\tpreload("res://scripts/team_lounge_receiving.gd").build(self)\n',p['exact_inverse_edits']['scripts/ship.gd'])==(b.BASE/'scripts/ship.gd').read_text()))
rejected('current proof logic alteration rejected',lambda:recovered_consumer(guard.replace('assert(seen.size()==277 and retained.size()==275)','assert(seen.size()>=277 and retained.size()>=275)')))
# Model only the strict roster logic. This is not a live-node/collision assertion.
ids=[r['id']for r in compiled['regions']]
def roster(names):
 ensure(len(names)==277 and len(set(names))==277 and names==ids)
 ensure(len([n for n in names if n not in p['added_owner_ids']])==275)
checked('Source model of exact277-owner runtime roster',lambda:roster(ids))
for label,names in [('unknown runtime owner',ids[:-1]+['rogue']),('missing runtime owner',ids[:-1]),('duplicate runtime owner',ids[:-1]+[ids[0]]),('runtime order changed',list(reversed(ids)))]:rejected(label,lambda names=names:roster(names))
# Parse both changed proof and existing source using the already-retained parser.
from gdtoolkit.parser import parser
checked('Generated whole GDScript consumer grammar',lambda:parser.parse(guard))
result={'scope':'SOURCE_ONLY_NO_GODOT_OR_BLENDER_EXECUTION','proof_sha256':sha(proof_bytes),'consumer_sha256':sha(guard.encode()),'positive_checks':checks,'negative_mutation_checks':negative,'limits':['GDScript grammar is not Godot type checking.','The raw-GLB runtime decoder,101 actual contacts,277 slabs,96 markers,90 lights and actual walking have not run.','Every832 degenerate triangle remains required; no omission is approved.','Current old guard and source hashes remain unchanged.']}
(HERE/'PROOF_SOURCE_VALIDATION.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
