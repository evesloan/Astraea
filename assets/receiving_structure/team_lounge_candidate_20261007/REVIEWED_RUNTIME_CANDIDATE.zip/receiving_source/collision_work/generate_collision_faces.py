#!/usr/bin/env python3
"""Build exact WP15 collision face sidecars, without importing or running Godot.

Each file is a headerless stream of little-endian XYZ binary32 coordinates,
three vertices per face (36 bytes per triangle), in source triangle order with
corners [0, 2, 1] for Godot clockwise contacts. Nothing is simplified or dropped.
The four static groups are baked once into WP15 placement-local coordinates.
The 97 singletons retain the original mesh-local float32 coordinates verbatim.

Default output is this isolated implementation's Game/ tree and collision_work/.
--output-root creates another isolated tree for byte-for-byte rerun comparison.
Existing files are accepted only if already byte-identical; never overwritten.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
BASE = HERE.parent.parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(BASE / "runtime_audit"))
from glb_decoder import GLB  # noqa: E402

PINS = {
    "unchanged_source/exports/WP15_team_lounge.glb": "b2afb9a77e892c813123924f9e3b62ebcef230896e95846b6c29cd488a917ae0",
    "runtime_derivative/FINAL_COLLISION_MEMBERSHIP.json": "c3cbd51307f8a9f25cd9a9ae5124c569ba0be6217e63bd0564ec9f1a914fc4b2",
    "runtime_derivative/FINAL_COLLISION_DEGENERATE_LEDGER.json": "287ef1c617d1aa69ace53c2fa69eb084a840a2a9b1a05564a04fb19da564d7cb",
    "runtime_derivative/source_runtime_bijection.json": "55fafe1ab5d896a31fb2ad15078b67486b8ae00b03a12d46f50b14c69221cbf9",
    "runtime_audit/glb_decoder.py": "53bf54c9813bd62e5fb97cda465642292a263d3f08e991c6629aa6ab81ecf5c3",
}
PLACEMENT = np.array([31.0, 35.5, 216.0], dtype=np.float64)
STATIC = "exact_static_compartment_bvh"
EXPECTED_POLICIES = {
    STATIC: 4,
    "original_local_articulation_singleton": 62,
    "original_local_precision_singleton": 3,
    "original_local_lens_precision_singleton": 32,
}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def check_inputs() -> dict[str, str]:
    actual = {name: digest((BASE / name).read_bytes()) for name in PINS}
    assert actual == PINS, "Pinned source or collision-plan input changed"
    return actual


def encode_json(value: object) -> bytes:
    return (json.dumps(value, indent=2, allow_nan=False) + "\n").encode("utf-8")


def write_preserving(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == data, f"Refusing to overwrite differing work: {path}"
    else:
        with path.open("xb") as output:
            output.write(data)


def build(output_root: Path) -> dict:
    input_hashes = check_inputs()
    plan = json.loads((BASE / "runtime_derivative/FINAL_COLLISION_MEMBERSHIP.json").read_text())
    ledger = json.loads((BASE / "runtime_derivative/FINAL_COLLISION_DEGENERATE_LEDGER.json").read_text())
    mapping = json.loads((BASE / "runtime_derivative/source_runtime_bijection.json").read_text())
    source = GLB(BASE / "unchanged_source/exports/WP15_team_lounge.glb")
    doc = source.document
    assert digest(source.bytes) == plan["source_glb_sha256"] == ledger["source_glb_sha256"]
    assert plan["derived_glb_sha256"] == ledger["derived_glb_sha256"]
    assert len(plan["groups"]) == plan["collision_group_count"] == 101
    assert Counter(group["policy"] for group in plan["groups"]) == EXPECTED_POLICIES
    assert len({group["group_id"] for group in plan["groups"]}) == 101

    expected_members = {
        (ni, pi)
        for ni, node in source.mesh_nodes()
        for pi in range(len(doc["meshes"][node["mesh"]]["primitives"]))
    }
    assert len(expected_members) == 4263
    expected_degenerate = {
        (row["source_node_index"], row["source_primitive_index"], row["source_triangle_index"]): row
        for row in ledger["entries"]
    }
    assert len(expected_degenerate) == ledger["count"] == 832

    manifest = []
    provenance_groups = []
    observed_members = set()
    observed_degenerates = set()
    faces_total = nondegenerate_total = degenerate_total = 0
    collapsed = unintended_reversals = 0
    max_quantization_error = 0.0
    files: dict[Path, bytes] = {}

    for group in plan["groups"]:
        group_id = group["group_id"]
        assert re.fullmatch(r"WP15_CONTACT_FINAL_[A-Za-z0-9_]+", group_id)
        static = group["policy"] == STATIC
        if static:
            assert group["source_node_index"] is None
            assert group["runtime_parent_name"] is None
            assert group["face_coordinate_frame"] == "WP15_LOCAL_FLOAT32_BAKED_ONCE"
        else:
            assert group["face_coordinate_frame"] == "ORIGINAL_SOURCE_MESH_LOCAL_FLOAT32_NO_BAKING"
            ni = group["source_node_index"]
            assert group["runtime_parent_node_index"] == ni
            assert mapping["nodes"][ni]["kind"] == "retained_mesh"
            assert group["runtime_parent_name"] == mapping["nodes"][ni]["runtime_name"]
            assert {member["source_node_index"] for member in group["members"]} == {ni}

        blocks = []
        provenance_members = []
        cursor = group_nonzero = group_zero = 0
        for member in group["members"]:
            ni, pi = member["source_node_index"], member["source_primitive_index"]
            key = (ni, pi)
            assert key in expected_members and key not in observed_members
            observed_members.add(key)
            node = doc["nodes"][ni]
            assert member["source_mesh_index"] == node["mesh"]
            assert member["source_name"] == node.get("name")
            assert member["runtime_semantic_node_name"] == mapping["nodes"][ni]["runtime_name"]
            primitive = doc["meshes"][node["mesh"]]["primitives"][pi]
            assert primitive.get("mode", 4) == 4
            position_accessor = doc["accessors"][primitive["attributes"]["POSITION"]]
            assert position_accessor["componentType"] == 5126 and position_accessor["type"] == "VEC3"
            raw32 = source.accessor(primitive["attributes"]["POSITION"])
            assert raw32.dtype == np.dtype("<f4") and np.isfinite(raw32).all()
            raw64 = raw32.astype(np.float64)
            indices = source.accessor(primitive["indices"]).ravel().astype(np.int64).reshape(-1, 3)
            assert np.all(indices >= 0) and np.all(indices < len(raw32))
            count = len(indices)
            assert member["source_triangle_count"] == count
            assert member["collision_triangle_start"] == cursor
            assert member["collision_triangle_end_exclusive"] == cursor + count

            raw_triangles = raw64[indices]
            raw_cross = np.cross(raw_triangles[:, 1] - raw_triangles[:, 0], raw_triangles[:, 2] - raw_triangles[:, 0])
            nonzero = np.any(raw_cross != 0.0, axis=1)
            zero_indices = np.flatnonzero(~nonzero)
            for ti in zero_indices.tolist():
                face_key = (ni, pi, ti)
                assert face_key in expected_degenerate
                row = expected_degenerate[face_key]
                assert row["source_vertex_indices"] == indices[ti].tolist()
                assert row["proposed_collision_group_id"] == group_id
                assert row["proposed_collision_triangle_index"] == cursor + ti
                observed_degenerates.add(face_key)

            if static:
                transform = source.world_matrix(ni).copy()
                transform[:3, 3] -= PLACEMENT
                reference = raw64 @ transform[:3, :3].T + transform[:3, 3]
                output_positions = reference.astype("<f4")
                max_quantization_error = max(max_quantization_error, float(np.abs(reference - output_positions.astype(np.float64)).max()))
            else:
                reference = raw64
                output_positions = raw32

            clockwise_indices = indices[:, [0, 2, 1]]
            face_array = np.ascontiguousarray(output_positions[clockwise_indices], dtype="<f4")
            assert face_array.shape == (count, 3, 3) and np.isfinite(face_array).all()
            expected_clockwise = reference[clockwise_indices]
            actual64 = face_array.astype(np.float64)
            before_cross = np.cross(expected_clockwise[:, 1] - expected_clockwise[:, 0], expected_clockwise[:, 2] - expected_clockwise[:, 0])
            after_cross = np.cross(actual64[:, 1] - actual64[:, 0], actual64[:, 2] - actual64[:, 0])
            current_collapsed = int(np.sum(nonzero & ~np.any(after_cross != 0.0, axis=1)))
            current_reversed = int(np.sum(nonzero & (np.einsum("ij,ij->i", before_cross, after_cross) <= 0.0)))
            assert current_collapsed == current_reversed == 0, f"Precision loss in {group_id}, {key}"
            assert int(np.sum(~np.any(after_cross != 0.0, axis=1))) == len(zero_indices)
            collapsed += current_collapsed
            unintended_reversals += current_reversed

            block = face_array.tobytes(order="C")
            assert len(block) == count * 36
            if not static:
                assert block == np.ascontiguousarray(raw32[clockwise_indices], dtype="<f4").tobytes()
            blocks.append(block)
            provenance_member = {k: v for k, v in member.items() if k != "render_mappings"}
            provenance_member.update({
                "source_position_accessor": primitive["attributes"]["POSITION"],
                "source_indices_accessor": primitive["indices"],
                "output_byte_offset": cursor * 36,
                "output_byte_length": len(block),
                "output_sha256": digest(block),
                "retained_degenerate_source_triangle_indices": zero_indices.tolist(),
            })
            provenance_members.append(provenance_member)
            cursor += count
            group_nonzero += int(np.sum(nonzero))
            group_zero += len(zero_indices)

        assert cursor == group["triangles"]
        payload = b"".join(blocks)
        assert len(payload) == cursor * 36
        relative = Path("data/architecture/team_lounge/contacts") / f"{group_id}.faces"
        files[output_root / "Game" / relative] = payload
        row = {
            "id": group_id,
            "runtime_parent_name": group["runtime_parent_name"],
            "triangles": cursor,
            "faces_file": "res://" + relative.as_posix(),
            "sha256": digest(payload),
            "policy": group["policy"],
            "source_node_index": group["source_node_index"],
            "compartment": group["compartment"],
            "face_coordinate_frame": group["face_coordinate_frame"],
            "contact_local_transform": group["contact_local_transform"],
            "byte_length": len(payload),
            "nondegenerate_faces": group_nonzero,
            "retained_zero_area_faces": group_zero,
        }
        manifest.append(row)
        provenance_groups.append({"id": group_id, "members": provenance_members})
        faces_total += cursor
        nondegenerate_total += group_nonzero
        degenerate_total += group_zero

    assert observed_members == expected_members
    assert observed_degenerates == set(expected_degenerate)
    assert (faces_total, nondegenerate_total, degenerate_total) == (494470, 493638, 832)
    assert check_inputs() == input_hashes

    provenance = {
        "schema": "astraea.wp15.collision_face_source_provenance.v1",
        "status": "GENERATED_ISOLATED_SOURCE_SIDECARS_NO_ENGINE_ACCEPTANCE",
        "input_sha256": input_hashes,
        "derived_glb_sha256": plan["derived_glb_sha256"],
        "placement_m": PLACEMENT.tolist(),
        "format": "headerless little-endian float32 XYZ; 3 vertices per triangle; 36 bytes per triangle",
        "source_triangle_corner_order": [0, 2, 1],
        "source_triangle_order_and_membership": "PRESERVED_EXACTLY_INCLUDING_ZERO_AREA_FACES",
        "runtime_static_parent": "WP15 placement root at (31, 35.5, 216), identity rotation and unit scale",
        "runtime_singleton_parent": "Exact retained original named mesh node, identity contact local transform",
        "groups": provenance_groups,
    }
    manifest_bytes = encode_json(manifest)
    provenance_bytes = encode_json(provenance)
    summary = {
        "schema": "astraea.wp15.collision_face_generation.v1",
        "status": "PASS_SOURCE_ONLY_ENGINE_INGESTION_AND_CONTACT_ACCEPTANCE_PENDING",
        "input_sha256_before": input_hashes,
        "input_sha256_after": check_inputs(),
        "source_glb_preserved": True,
        "group_count": len(manifest),
        "policy_counts": dict(sorted(Counter(row["policy"] for row in manifest).items())),
        "primitive_memberships_exactly_once": len(observed_members),
        "triangles_including_retained_degenerates": faces_total,
        "nondegenerate_faces": nondegenerate_total,
        "retained_zero_area_faces": degenerate_total,
        "source_degenerate_ledger_coverage_exact": True,
        "nondegenerate_collapses": collapsed,
        "unintended_winding_reversals_after_required_corner_swap": unintended_reversals,
        "max_static_coordinate_quantization_error_m": max_quantization_error,
        "singleton_mesh_local_float32_bytes_preserved": True,
        "source_triangle_corner_order": [0, 2, 1],
        "binary_faces_total_bytes": sum(len(value) for value in files.values()),
        "collision_groups_json_sha256": digest(manifest_bytes),
        "collision_provenance_json_sha256": digest(provenance_bytes),
        "godot_run": False,
        "live_game_edited": False,
        "engine_acceptance_claimed": False,
        "limitations": [
            "Engine zero-area ingestion, face retention and contact behavior require a separate native check.",
            "These contacts add no source floor, receiving apron, bearing pad or route.",
            "Singleton contact bodies remain static until articulation is separately implemented.",
        ],
    }
    work = output_root / "collision_work"
    files[work / "collision_groups.json"] = manifest_bytes
    files[work / "collision_provenance.json"] = provenance_bytes
    files[work / "GENERATION_RECEIPT.json"] = encode_json(summary)

    # Validate every collision before writing any generated artifact.
    for path, data in files.items():
        if path.exists():
            assert path.read_bytes() == data, f"Refusing to overwrite differing work: {path}"
    for path, data in files.items():
        write_preserving(path, data)
    assert check_inputs() == input_hashes
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", type=Path, default=HERE.parent)
    args = parser.parse_args()
    print(json.dumps(build(args.output_root.resolve()), indent=2))


if __name__ == "__main__":
    main()
