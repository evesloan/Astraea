# WP15 exact contact sidecars

These are isolated source-derived contact inputs. They are not native-engine
acceptance or installation in the live Game project.

## Format and placement contract

- `collision_groups.json` is the runtime manifest array. Its 101 entries preserve
  final-plan order and point to `Game/data/architecture/team_lounge/contacts/`.
- Each `.faces` file is headerless, little-endian IEEE-754 float32 XYZ data:
  three vertices per triangle, nine floats or 36 bytes per triangle.
- Every original triangle is retained, including all 832 recorded zero-area
  faces. No deduplication, simplification, face dropping or renumbering occurs.
- Source triangle corners are emitted in order `[0, 2, 1]`, the intended Godot
  clockwise order. Triangle sequence within each original primitive is unchanged.
- The four `exact_static_compartment_bvh` groups have a null runtime parent name.
  Attach each at identity beneath the WP15 placement root at `(31, 35.5, 216)`
  with zero rotation and unit scale. Source world transforms minus that placement
  are evaluated in float64 and quantized once into these float32 coordinates.
- The other 97 groups have an exact retained mesh-node name in the manifest.
  Attach each at identity beneath that named mesh node, whose original transform
  must survive. Their original mesh-local float32 position bytes are unchanged
  apart from the required triangle corner order. Never rebake these coordinates.
- Keep all groups static until articulation is separately implemented. Do not add
  generic ship static contacts on top of these dedicated shapes.
- This geometry supplies no source floor, receiving apron, bearing pad or route.

## Generation and checks

From the receiving-tree root:

```sh
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 python runtime_implementation001/collision_work/generate_collision_faces.py
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 python runtime_implementation001/collision_work/verify_deterministic_rerun.py
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 python runtime_implementation001/collision_work/verify_collision_faces.py
```

The generator pins original GLB, final membership, original-to-runtime bijection,
degenerate ledger and source decoder hashes. It refuses to overwrite a differing
existing output. `--output-root` can target a fresh isolated comparison directory.

`collision_provenance.json` records every source node/mesh/primitive membership,
face range, output byte range and hash, and original degenerate triangle indices.
`GENERATION_RECEIPT.json` records source integrity and complete coordinate and
winding checks. `DETERMINISTIC_RERUN_RECEIPT.json` attests a fresh-process rerun
whose 104 generated artifacts all match byte for byte.

`verify_collision_faces.py` is a separately implemented verifier that reads the
original GLB directly, without importing the generator or its decoder. Its result
must be read separately; generation success does not stand in for that check.

Native Godot ingestion, zero-area retention/filtering behavior and real contact
tests remain explicit gates. Source-only passes do not establish in-engine
contacts, articulation, route access, visual quality or performance acceptance.
