#!/usr/bin/env python3
"""Rebuild every sidecar and demand byte-identical contents without replacement."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
BASE = ROOT.parent


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory() -> dict:
    rows = json.loads((HERE / "collision_groups.json").read_text())
    paths = [ROOT / "Game" / row["faces_file"].removeprefix("res://") for row in rows]
    paths += [HERE / name for name in ("collision_groups.json", "collision_provenance.json", "GENERATION_RECEIPT.json")]
    assert len(paths) == len(set(paths)) == 104
    return {
        path.relative_to(ROOT).as_posix(): {"sha256": sha256(path), "bytes": path.stat().st_size}
        for path in sorted(paths)
    }


def main() -> None:
    before = inventory()
    source = BASE / "unchanged_source/exports/WP15_team_lounge.glb"
    source_before = sha256(source)
    generator = HERE / "generate_collision_faces.py"
    result = subprocess.run(
        [sys.executable, str(generator)],
        env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1", "OPENBLAS_NUM_THREADS": "1"},
        capture_output=True,
        text=True,
        check=True,
    )
    generated = json.loads(result.stdout)
    assert result.stderr == ""
    after = inventory()
    assert before == after
    assert sha256(source) == source_before == "b2afb9a77e892c813123924f9e3b62ebcef230896e95846b6c29cd488a917ae0"
    assert generated == json.loads((HERE / "GENERATION_RECEIPT.json").read_text())
    receipt = {
        "schema": "astraea.wp15.collision_face_deterministic_rerun.v1",
        "status": "PASS",
        "method": "Fresh generator process recomputed every output; existing bytes were required to match before any write. Full 104-file inventories also match before/after.",
        "generator_sha256": sha256(generator),
        "generator_exit_code": result.returncode,
        "generator_stderr_empty": True,
        "source_sha256_before": source_before,
        "source_sha256_after": sha256(source),
        "generated_artifact_count": len(before),
        "binary_face_file_count": 101,
        "byte_identical_rerun": True,
        "artifacts": after,
        "godot_run": False,
        "live_game_edited": False,
    }
    encoded = (json.dumps(receipt, indent=2) + "\n").encode()
    output = HERE / "DETERMINISTIC_RERUN_RECEIPT.json"
    if output.exists():
        assert output.read_bytes() == encoded, "Refusing to overwrite differing prior receipt"
    else:
        output.write_bytes(encoded)
    print(json.dumps({key: value for key, value in receipt.items() if key != "artifacts"}, indent=2))


if __name__ == "__main__":
    main()
