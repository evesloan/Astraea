#!/usr/bin/env python3
"""Independently verify WP15 collision sidecars against immutable glTF bytes.

No generator or existing decoder is imported. No engine is launched. The only
write is this verifier's JSON receipt. Coordinates are XYZ little-endian float32,
with source triangle corners 0, 2, 1 for clockwise physics winding.
"""

from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import struct
import sys
import traceback
from unittest.mock import patch

import numpy as np


SOURCE_SHA256 = "b2afb9a77e892c813123924f9e3b62ebcef230896e95846b6c29cd488a917ae0"
DERIVATIVE_SHA256 = "292eeb623ca272882ea051aa37abecd5cdce80802c272234edcdf331ee1e3e6e"
PLACEMENT = np.array([31.0, 35.5, 216.0], dtype=np.float64)
CORNER_ORDER = [0, 2, 1]
EXPECTED_POLICIES = {
    "exact_static_compartment_bvh": 4,
    "original_local_articulation_singleton": 62,
    "original_local_precision_singleton": 3,
    "original_local_lens_precision_singleton": 32,
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


class IndependentGLB:
    """Strict GLB reader using struct row decoding, with independent TRS math."""

    COMPONENTS = {
        5120: ("b", "<i1"), 5121: ("B", "<u1"),
        5122: ("h", "<i2"), 5123: ("H", "<u2"),
        5125: ("I", "<u4"), 5126: ("f", "<f4"),
    }
    WIDTHS = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4}

    def __init__(self, path):
        self.path = Path(path)
        self.raw = self.path.read_bytes()
        require(len(self.raw) >= 20, "Truncated GLB header")
        magic, version, byte_length = struct.unpack_from("<4sII", self.raw)
        require((magic, version, byte_length) == (b"glTF", 2, len(self.raw)),
                "GLB header/version/length mismatch")
        chunks = []
        offset = 12
        while offset < len(self.raw):
            require(offset + 8 <= len(self.raw), "Truncated GLB chunk header")
            length, kind = struct.unpack_from("<II", self.raw, offset)
            offset += 8
            require(length % 4 == 0 and offset + length <= len(self.raw),
                    "Invalid GLB chunk boundary")
            chunks.append((kind, self.raw[offset:offset + length]))
            offset += length
        require(len(chunks) == 2 and chunks[0][0] == 0x4E4F534A
                and chunks[1][0] == 0x004E4942, "Expected JSON then BIN chunks")
        self.doc = json.loads(chunks[0][1])
        self.binary = chunks[1][1]
        buffers = self.doc.get("buffers", [])
        require(len(buffers) == 1 and "uri" not in buffers[0],
                "Expected single embedded GLB buffer")
        require(0 <= len(self.binary) - buffers[0]["byteLength"] <= 3,
                "Embedded buffer length mismatch")
        self.parents = {}
        for parent, node in enumerate(self.doc["nodes"]):
            for child in node.get("children", []):
                require(0 <= child < len(self.doc["nodes"]), "Invalid child node")
                require(child not in self.parents, "Multiple node parents")
                self.parents[child] = parent
        self._arrays = {}
        self._worlds = {}

    def accessor(self, index):
        if index in self._arrays:
            return self._arrays[index]
        item = self.doc["accessors"][index]
        require("sparse" not in item, "Sparse accessor is outside pinned source format")
        require(not item.get("normalized", False), "Unexpected normalized geometry")
        require(item["type"] in self.WIDTHS, "Unexpected matrix accessor")
        width = self.WIDTHS[item["type"]]
        fmt, dtype = self.COMPONENTS[item["componentType"]]
        row = struct.Struct("<" + fmt * width)
        count = item["count"]
        require(count >= 0, "Negative accessor count")
        if "bufferView" not in item:
            result = np.zeros((count, width), dtype=dtype)
        else:
            view = self.doc["bufferViews"][item["bufferView"]]
            require(view["buffer"] == 0, "External buffer access")
            view_start = view.get("byteOffset", 0)
            view_end = view_start + view["byteLength"]
            stride = view.get("byteStride", row.size)
            start = view_start + item.get("byteOffset", 0)
            end = start + (count - 1) * stride + row.size if count else start
            require(stride >= row.size and start >= view_start and end <= view_end
                    and view_end <= len(self.binary), "Accessor exceeds buffer view")
            result = np.array([row.unpack_from(self.binary, start + i * stride)
                               for i in range(count)], dtype=dtype).reshape(count, width)
        result.setflags(write=False)
        self._arrays[index] = result
        return result

    def local_transform(self, node_index):
        node = self.doc["nodes"][node_index]
        if "matrix" in node:
            require(not any(key in node for key in ("rotation", "translation", "scale")),
                    "Matrix and TRS coexist")
            return np.asarray(node["matrix"], dtype=np.float64).reshape(4, 4).T.copy()
        quaternion = np.asarray(node.get("rotation", [0, 0, 0, 1]), dtype=np.float64)
        norm = np.linalg.norm(quaternion)
        require(norm > 0, "Zero quaternion")
        x, y, z, w = quaternion / norm
        rotation = np.array([
            [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
            [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
            [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
        ], dtype=np.float64)
        transform = np.eye(4, dtype=np.float64)
        transform[:3, :3] = rotation * np.asarray(node.get("scale", [1, 1, 1]))[None, :]
        transform[:3, 3] = node.get("translation", [0, 0, 0])
        return transform

    def placed_transform(self, node_index, ancestry=()):
        require(node_index not in ancestry, "Cycle in node hierarchy")
        if node_index not in self._worlds:
            if node_index in self.parents:
                parent = self.placed_transform(self.parents[node_index], ancestry + (node_index,))
            else:
                parent = np.eye(4, dtype=np.float64)
                parent[:3, 3] = PLACEMENT
            self._worlds[node_index] = parent @ self.local_transform(node_index)
        return self._worlds[node_index]

    def geometry(self, node_index, primitive_index):
        node = self.doc["nodes"][node_index]
        primitive = self.doc["meshes"][node["mesh"]]["primitives"][primitive_index]
        require(primitive.get("mode", 4) == 4, "Non-triangle primitive")
        position_accessor = primitive["attributes"]["POSITION"]
        position_item = self.doc["accessors"][position_accessor]
        require(position_item["type"] == "VEC3" and position_item["componentType"] == 5126,
                "POSITION must be original float32 VEC3")
        positions = self.accessor(position_accessor)
        require(np.isfinite(positions).all(), "Non-finite source geometry")
        if "indices" in primitive:
            indices_item = self.doc["accessors"][primitive["indices"]]
            require(indices_item["type"] == "SCALAR"
                    and indices_item["componentType"] in (5121, 5123, 5125),
                    "Invalid index accessor")
            indices = self.accessor(primitive["indices"]).reshape(-1).astype(np.int64)
        else:
            indices = np.arange(len(positions), dtype=np.int64)
        require(len(indices) % 3 == 0 and (indices >= 0).all()
                and (indices < len(positions)).all(), "Invalid triangle indices")
        return positions, indices.reshape(-1, 3)

    def primitive_instances(self):
        roots = self.doc["scenes"][self.doc.get("scene", 0)]["nodes"]
        reached = set()

        def visit(index):
            require(index not in reached, "Node instantiated multiple times in scene")
            reached.add(index)
            for child in self.doc["nodes"][index].get("children", []):
                visit(child)

        for root in roots:
            visit(root)
        all_mesh_nodes = {i for i, node in enumerate(self.doc["nodes"]) if "mesh" in node}
        require(all_mesh_nodes <= reached, "Mesh node outside active source scene")
        return {(i, node["mesh"], j)
                for i, node in enumerate(self.doc["nodes"]) if i in all_mesh_nodes
                for j in range(len(self.doc["meshes"][node["mesh"]]["primitives"]))}


def face_normals(faces):
    f = faces.astype(np.float64)
    return np.cross(f[:, 1] - f[:, 0], f[:, 2] - f[:, 0])


def verify(root, game, manifest_path, receipt):
    source_path = root / "unchanged_source/exports/WP15_team_lounge.glb"
    derivative_path = root / "runtime_derivative/WP15_team_lounge_runtime_compartment_material_v1.glb"
    plan_path = root / "runtime_derivative/FINAL_COLLISION_MEMBERSHIP.json"
    ledger_path = root / "runtime_derivative/FINAL_COLLISION_DEGENERATE_LEDGER.json"
    source = IndependentGLB(source_path)
    require(sha256(source.raw) == SOURCE_SHA256, "Immutable source hash mismatch")
    derived = IndependentGLB(derivative_path)
    require(sha256(derived.raw) == DERIVATIVE_SHA256, "Pinned derivative hash mismatch")
    plan_bytes = plan_path.read_bytes()
    plan = json.loads(plan_bytes)
    ledger_bytes = ledger_path.read_bytes()
    ledger = json.loads(ledger_bytes)
    for document in (plan, ledger):
        require(document["source_glb_sha256"] == SOURCE_SHA256, "Input source pin mismatch")
        require(document["derived_glb_sha256"] == DERIVATIVE_SHA256, "Input derivative pin mismatch")
    groups = plan["groups"]
    require(len(groups) == 101, "Expected 101 collision groups")
    require(Counter(g["policy"] for g in groups) == Counter(EXPECTED_POLICIES),
            "Collision group policies differ from approved final split")
    manifest_bytes = manifest_path.read_bytes()
    manifest = json.loads(manifest_bytes)
    require(isinstance(manifest, list), "Manifest must be a group array")
    manifest_by_id = {item["id"]: item for item in manifest}
    require(len(manifest) == len(manifest_by_id) == 101, "Missing or duplicate manifest groups")
    require(set(manifest_by_id) == {g["group_id"] for g in groups}, "Manifest group ID mismatch")
    source_members = source.primitive_instances()
    require(len(source_members) == 4263, "Pinned source primitive count mismatch")
    covered = set()
    observed_degenerates = {}
    group_receipts = []
    max_rounding = 0.0
    triangles_total = 0
    degenerate_total = 0
    retained_local_triangles = 0
    corners_bytes_total = 0
    expected_contacts = set()

    for group in groups:
        group_id = group["group_id"]
        entry = manifest_by_id[group_id]
        static = group["policy"] == "exact_static_compartment_bvh"
        for key in ("policy", "source_node_index", "runtime_parent_name", "triangles"):
            require(entry[key] == group[key], f"{group_id}: manifest {key} mismatch")
        resource = entry["faces_file"]
        expected_resource = "res://data/architecture/team_lounge/contacts/" + group_id + ".faces"
        require(resource == expected_resource, f"{group_id}: unexpected face path")
        face_path = game / resource.removeprefix("res://")
        expected_contacts.add(face_path.resolve())
        raw_faces = face_path.read_bytes()
        require(len(raw_faces) == group["triangles"] * 36, f"{group_id}: face byte count mismatch")
        require(sha256(raw_faces) == entry["sha256"], f"{group_id}: manifest checksum mismatch")
        actual_faces = np.frombuffer(raw_faces, dtype="<f4").reshape(-1, 3, 3)
        require(np.isfinite(actual_faces).all(), f"{group_id}: non-finite emitted position")
        expected_chunks = []
        cursor = 0
        group_degenerate_indices = []
        if static:
            require(group["source_node_index"] is None and group["runtime_parent_name"] is None,
                    f"{group_id}: static parent metadata is wrong")
            require(group["face_coordinate_frame"] == "WP15_LOCAL_FLOAT32_BAKED_ONCE",
                    f"{group_id}: static coordinate frame is wrong")
        else:
            node_index = group["source_node_index"]
            runtime_index = group["runtime_parent_node_index"]
            runtime_node = derived.doc["nodes"][runtime_index]
            require(runtime_node["name"] == group["runtime_parent_name"] and "mesh" in runtime_node,
                    f"{group_id}: retained named mesh missing from derivative")
            require(runtime_node.get("extras", {}).get("source_node_index") == node_index,
                    f"{group_id}: retained mesh source identity mismatch")
            require(np.array_equal(source.placed_transform(node_index), derived.placed_transform(runtime_index)),
                    f"{group_id}: retained named mesh transform changed")
            require(group["face_coordinate_frame"] == "ORIGINAL_SOURCE_MESH_LOCAL_FLOAT32_NO_BAKING",
                    f"{group_id}: retained local coordinate frame is wrong")

        for member in group["members"]:
            node_index = member["source_node_index"]
            primitive_index = member["source_primitive_index"]
            source_node = source.doc["nodes"][node_index]
            identity = (node_index, member["source_mesh_index"], primitive_index)
            require(identity in source_members and identity not in covered,
                    f"{group_id}: missing or repeated primitive {identity}")
            require(source_node["mesh"] == member["source_mesh_index"]
                    and source_node["name"] == member["source_name"],
                    f"{group_id}: source member identity mismatch")
            covered.add(identity)
            local_positions, source_indices = source.geometry(node_index, primitive_index)
            count = len(source_indices)
            require(count == member["source_triangle_count"], f"{group_id}: primitive face count changed")
            require(member["collision_triangle_start"] == cursor
                    and member["collision_triangle_end_exclusive"] == cursor + count,
                    f"{group_id}: discontinuous member face interval")
            original_triangles = local_positions[source_indices]
            source_degenerate = np.all(face_normals(original_triangles) == 0, axis=1)
            world_matrix = source.placed_transform(node_index)
            if static:
                # Remove the placement from matrix translation BEFORE applying it
                # to vertices. Adding and subtracting it per vertex loses tiny
                # source features even in float64 and is a different operation.
                contact_translation = world_matrix[:3, 3] - PLACEMENT
                contact_positions = local_positions @ world_matrix[:3, :3].T + contact_translation
                unrounded = contact_positions[source_indices[:, CORNER_ORDER]]
                expected = unrounded.astype("<f4")
                if count:
                    max_rounding = max(max_rounding, float(np.max(np.abs(expected.astype(np.float64) - unrounded))))
            else:
                require(node_index == group["source_node_index"], f"{group_id}: non-singleton source node")
                unrounded = original_triangles[:, CORNER_ORDER].astype(np.float64)
                expected = original_triangles[:, CORNER_ORDER]
                retained_local_triangles += count
                for mapping in member["render_mappings"]:
                    require(mapping["runtime_node_index"] == runtime_index,
                            f"{group_id}: render mapping attached elsewhere")
                    derivative_positions, derivative_indices = derived.geometry(runtime_index, mapping["runtime_primitive_index"])
                    offset = mapping["runtime_triangle_start"]
                    derivative_faces = derivative_positions[derivative_indices[offset:offset + count]][:, CORNER_ORDER]
                    require(derivative_faces.tobytes() == expected.tobytes(),
                            f"{group_id}: retained derivative mesh-local bytes changed")
            expected_bytes = expected.tobytes(order="C")
            emitted_bytes = raw_faces[cursor * 36:(cursor + count) * 36]
            require(expected_bytes == emitted_bytes,
                    f"{group_id}: source face bytes differ at primitive {identity}, group face {cursor}")
            expected_chunks.append(expected_bytes)
            emitted = actual_faces[cursor:cursor + count]
            emitted_normals = face_normals(emitted)
            emitted_degenerate = np.all(emitted_normals == 0, axis=1)
            require(np.array_equal(source_degenerate, emitted_degenerate),
                    f"{group_id}: face collapse or degenerate expansion at {identity}")
            normal_dot = np.einsum("ij,ij->i", face_normals(unrounded), emitted_normals)
            require(np.all(normal_dot[~source_degenerate] > 0),
                    f"{group_id}: unintended winding reversal at {identity}")
            for local_index in np.flatnonzero(source_degenerate):
                source_triangle = int(local_index)
                group_triangle = cursor + source_triangle
                key = identity + (source_triangle,)
                observed_degenerates[key] = {
                    "group_id": group_id, "group_triangle_index": group_triangle,
                    "source_vertex_indices": source_indices[source_triangle].tolist(),
                    "source_local_positions": original_triangles[source_triangle],
                }
                group_degenerate_indices.append(group_triangle)
            cursor += count
        require(cursor == group["triangles"], f"{group_id}: incomplete face membership")
        require(b"".join(expected_chunks) == raw_faces, f"{group_id}: assembled byte mismatch")
        triangles_total += cursor
        degenerate_total += len(group_degenerate_indices)
        corners_bytes_total += len(raw_faces)
        group_receipts.append({
            "id": group_id, "policy": group["policy"], "triangles": cursor,
            "primitive_memberships": len(group["members"]), "sha256": sha256(raw_faces),
            "exact_source_face_bytes": True, "zero_area_faces": len(group_degenerate_indices),
            "zero_area_triangle_indices": group_degenerate_indices,
            "nondegenerate_collapses": 0, "unintended_winding_reversals": 0,
            "original_mesh_local_bytes_preserved": not static,
        })

    require(covered == source_members, "Incomplete original primitive membership coverage")
    require(triangles_total == 494470 and degenerate_total == 832,
            "Final triangle or zero-area count mismatch")
    require(triangles_total - degenerate_total == 493638, "Nondegenerate count mismatch")
    ledger_by_identity = {}
    for entry in ledger["entries"]:
        key = tuple(entry[field] for field in (
            "source_node_index", "source_mesh_index", "source_primitive_index", "source_triangle_index"))
        require(key not in ledger_by_identity, "Duplicate final-degenerate-ledger entry")
        ledger_by_identity[key] = entry
    require(set(ledger_by_identity) == set(observed_degenerates), "Degenerate ledger membership mismatch")
    for key, observed in observed_degenerates.items():
        entry = ledger_by_identity[key]
        require(entry["proposed_collision_group_id"] == observed["group_id"]
                and entry["proposed_collision_triangle_index"] == observed["group_triangle_index"],
                f"Degenerate ledger group face index changed: {key}")
        require(entry["source_vertex_indices"] == observed["source_vertex_indices"],
                f"Degenerate ledger source indices changed: {key}")
        ledger_positions = np.asarray(entry["source_local_positions"], dtype="<f4")
        require(ledger_positions.tobytes() == observed["source_local_positions"].tobytes(),
                f"Degenerate ledger original position bytes changed: {key}")
    contacts_dir = game / "data/architecture/team_lounge/contacts"
    actual_contacts = {p.resolve() for p in contacts_dir.glob("*.faces")}
    require(actual_contacts == expected_contacts, "Extra or missing collision sidecar files")
    require(sha256(source_path.read_bytes()) == SOURCE_SHA256, "Source changed during verification")
    require(sha256(derivative_path.read_bytes()) == DERIVATIVE_SHA256, "Derivative changed during verification")
    receipt.update({
        "status": "PASS_SOURCE_BINARY_CORRESPONDENCE_ONLY",
        "source_glb_sha256": SOURCE_SHA256, "source_hash_preserved": True,
        "derived_glb_sha256": DERIVATIVE_SHA256,
        "membership_sha256": sha256(plan_bytes), "degenerate_ledger_sha256": sha256(ledger_bytes),
        "collision_manifest_sha256": sha256(manifest_bytes),
        "collision_group_count": len(groups), "policy_counts": dict(EXPECTED_POLICIES),
        "primitive_memberships": len(covered), "triangle_faces": triangles_total,
        "nondegenerate_faces": triangles_total - degenerate_total, "zero_area_faces": degenerate_total,
        "face_bytes": corners_bytes_total, "retained_local_triangles": retained_local_triangles,
        "exact_source_face_correspondence": True, "complete_primitive_coverage": True,
        "degenerate_ledger_indices_preserved": True, "retained_local_bytes_preserved": True,
        "retained_named_mesh_parent_transforms_preserved": True,
        "static_max_absolute_float32_rounding_error_m": max_rounding,
        "nondegenerate_collapses": 0, "unintended_winding_reversals": 0,
        "source_corner_order_in_emitted_physics_faces": CORNER_ORDER,
        "intentional_winding_conversion": "glTF source corners 0,2,1; no other winding reversal",
        "static_reference_operation_order": "Compose source world matrix in float64; subtract (31,35.5,216) from its translation before transforming positions; quantize once to little-endian float32.",
        "groups": group_receipts,
    })


def negative_controls(root, game, manifest_path):
    """Reject adversarial inputs entirely in memory; never alter source artifacts."""
    original_read = Path.read_bytes
    manifest = json.loads(original_read(manifest_path))
    first = manifest[0]
    face_path = game / first["faces_file"].removeprefix("res://")
    face_bytes = original_read(face_path)
    bitflip = bytearray(face_bytes)
    bitflip[0] ^= 1
    winding = face_bytes[:12] + face_bytes[24:36] + face_bytes[12:24] + face_bytes[36:]
    tests = [
        ("coordinate_bit_changed_with_matching_manifest_hash", bytes(bitflip), None,
         "source face bytes differ"),
        ("triangle_corner_winding_swapped_with_matching_manifest_hash", winding, None,
         "source face bytes differ"),
        ("triangle_deleted_with_matching_manifest_hash", face_bytes[:-36], None,
         "face byte count mismatch"),
        ("runtime_parent_name_changed", None, "UNAUTHORIZED_PARENT", "manifest runtime_parent_name mismatch"),
    ]
    results = []
    for name, altered_faces, parent_override, expected_error in tests:
        alternate_manifest = json.loads(json.dumps(manifest))
        overrides = {}
        if altered_faces is not None:
            alternate_manifest[0]["sha256"] = sha256(altered_faces)
            overrides[face_path.resolve()] = altered_faces
        if parent_override is not None:
            alternate_manifest[0]["runtime_parent_name"] = parent_override
        overrides[manifest_path.resolve()] = json.dumps(alternate_manifest).encode()

        def intercepted_read(path):
            resolved = path.resolve()
            return overrides[resolved] if resolved in overrides else original_read(path)

        rejected = None
        with patch.object(Path, "read_bytes", intercepted_read):
            try:
                verify(root, game, manifest_path, {})
            except ValueError as error:
                rejected = str(error)
        require(rejected is not None and expected_error in rejected,
                f"Negative control was not rejected at intended boundary: {name}: {rejected}")
        results.append({"name": name, "status": "PASS_REJECTED", "rejection": rejected})
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    work = Path(__file__).resolve().parent
    parser.add_argument("--root", type=Path, default=work.parent.parent)
    parser.add_argument("--game", type=Path, default=work.parent / "Game")
    parser.add_argument("--manifest", type=Path, default=work / "collision_groups.json")
    parser.add_argument("--receipt", type=Path, default=work / "independent_collision_faces_receipt.json")
    args = parser.parse_args()
    require(args.receipt.resolve().parent == work,
            "Receipt must remain inside this isolated collision_work directory")
    receipt = {
        "schema": "astraea.wp15.independent_collision_faces_verification.v1",
        "status": "FAIL", "engine_run": False, "production_files_modified": False,
        "generator_or_shared_decoder_imported": False,
        "verifier_sha256": sha256(Path(__file__).read_bytes()),
        "limits": ["This verifies sidecar bytes and declared attachment metadata, not runtime body installation.",
                   "Godot shape ingestion, zero-area filtering, contact behavior and visual acceptance remain untested.",
                   "Generator deterministic-rerun proof is owned by the generation receipt."],
    }
    code = 0
    try:
        verify(args.root, args.game, args.manifest, receipt)
        receipt["in_memory_negative_controls"] = negative_controls(args.root, args.game, args.manifest)
        attempt = work / "independent_collision_faces_attempt001.json"
        if attempt.exists():
            receipt["preserved_prior_attempt"] = {
                "file": attempt.name,
                "sha256": sha256(attempt.read_bytes()),
                "diagnosis": "Attempt001 used a verifier reference with world placement added and subtracted per vertex. That removed source X values near 1e-16 at node440. The prescribed contract subtracts placement from matrix translation BEFORE applying it to vertices; correcting only the verifier to this contract restored exact byte agreement. No output sidecars were modified and no byte tolerance was introduced.",
            }
    except Exception as error:
        receipt["status"] = "FAIL"
        receipt["error"] = str(error)
        receipt["traceback"] = traceback.format_exc()
        code = 1
    args.receipt.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    print(json.dumps({k: v for k, v in receipt.items() if k not in ("groups", "traceback")}, indent=2))
    return code


if __name__ == "__main__":
    sys.exit(main())
