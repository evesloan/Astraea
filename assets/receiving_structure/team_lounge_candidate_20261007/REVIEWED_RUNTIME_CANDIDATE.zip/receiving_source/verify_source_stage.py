"""Read-only runtime source verification; not a Godot acceptance substitute."""
from pathlib import Path
import hashlib, json, math, sys
import numpy as np
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
GAME=ROOT/'Game'
LIVE=Path('/workspace/shared/Astraea_recovery_20261007_AXWr5x/Game')
def read(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def resource(p):
    assert p.startswith('res://') and '..' not in p
    return GAME/p[6:]
d=read(GAME/'data/architecture/team_lounge/runtime_manifest.json')
assert sha(resource(d['source_file']))==d['source_sha256']==sha(BASE/'unchanged_source/exports/WP15_team_lounge.glb')
assert sha(resource(d['derivative_file']))==d['derivative_sha256']==sha(BASE/'runtime_derivative/WP15_team_lounge_runtime_compartment_material_v1.glb')
assert len(d['semantic_nodes'])==4676 and len({x['runtime_name'] for x in d['semantic_nodes']})==4676
assert len(d['collision_groups'])==101 and sum(x['triangles'] for x in d['collision_groups'])==494470
assert sum(x['runtime_parent_name'] is None for x in d['collision_groups'])==4
for row in d['collision_groups']:
    p=resource(row['faces_file'])
    assert sha(p)==row['sha256'] and p.stat().st_size==row['triangles']*36
    assert np.isfinite(np.frombuffer(p.read_bytes(),dtype='<f4')).all()
assert len(d['rest_contacts'])==96 and len({r['id'] for r in d['rest_contacts']})==96
for row in d['rest_contacts']:
    assert np.array_equal(np.array(row['local_position'])+d['placement'],row['world_contact_xyz'])
    assert abs(np.linalg.norm(row['forward'])-1)<1e-9
assert len(d['lights'])==90 and len({r['runtime_parent_name'] for r in d['lights']})==90
plan=read(BASE/'runtime_audit/light_inventory_and_adaptation.json')['lights']
for row,p in zip(d['lights'],plan):
    assert row['source_index']==p['node_index']
    assert row['color']==p['original_light']['color']
    assert row['world_transform_column_major']==p['world_transform_column_major']
    assert row['light_energy']==p['runtime_proposal']['light_energy']
    assert row['spot_range']==p['runtime_proposal']['spot_range_m']
    assert row['spot_angle']==p['runtime_proposal']['spot_angle_degrees']
    assert row['illumination_anchor']==p['runtime_proposal']['illumination_anchor_world_xyz']
assert len(d['finish_top_chunks'])==52 and len(set(d['finish_top_chunks']))==52
for row in d['finish_textures']: assert sha(resource(row['file']))==row['sha256']
for row in read(BASE/'BOUNDED_COMPILER_APPLY_MANIFEST.json')['files']:
    assert sha(GAME/row['path'])==row['candidate_sha256']
    p=LIVE/row['path']
    assert (sha(p) if p.exists() else None)==row['existing_Game_sha256']
ship=(GAME/'scripts/ship.gd').read_bytes()
addition=b'\tpreload("res://scripts/team_lounge_receiving.gd").build(self)\n'
assert ship.count(addition)==1 and ship.replace(addition,b'')==(LIVE/'scripts/ship.gd').read_bytes()
assert ship.index(addition)<ship.index(b'\tlighting_budget.configure(self,player)')
builder=(GAME/'scripts/team_lounge_receiving.gd').read_text()
assert 'create_trimesh_collision' not in builder and 'light_energy' in builder
assert builder.count('space.add_child(root)')==1
assert builder.index('light.visible = false')<builder.index('light.shadow_enabled = true')<builder.index('space.add_child(root)')
assert builder.count('set_surface_override_material')==1 and 'create_trimesh' not in builder
assert not (GAME/'scripts/lighting_budget.gd').exists()
assert not (GAME/'scripts/structural_floor_builder.gd').exists()
assert not (GAME/'project.godot').exists()
assert not (GAME/'data/programme_ledger.json').exists()
assert (GAME/'tests/fixtures/team_lounge_access001.json').exists()
print(json.dumps({'status':'PASS_SOURCE_ONLY_RUNTIME_STAGE','semantic_nodes':4676,'render_meshes_selected':241,'collision_groups':101,'faces_including_832_degenerate':494470,'rest_contacts':96,'physical_fixture_lights':90,'finished_existing_top_chunks':52,'single_loader_addition':True,'nine_compiler_candidates_match':True,'shared_builders_managers_controllers_unmodified':True,'Godot_launched':False,'runtime_physics_visual_acceptance':False},indent=2))
