"""Deterministic isolated WP15 intake. Never modifies Game or retained WP15 inputs."""
from pathlib import Path
import hashlib, json, shutil, sys
ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
GAME = ROOT / 'Game'
LIVE = Path('/workspace/shared/Astraea_recovery_20261007_AXWr5x/Game')
sys.path.insert(0, str(BASE / 'runtime_audit'))
from glb_decoder import GLB
def read(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p, data):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')
def copy(source, rel):
    target = GAME / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    assert sha(target) == sha(source)
    return 'res://' + rel
receipt = read(BASE / 'runtime_derivative/FINAL_RECEIPT.json')
source_path = BASE / 'unchanged_source/exports/WP15_team_lounge.glb'
derivative_path = BASE / 'runtime_derivative/WP15_team_lounge_runtime_compartment_material_v1.glb'
assert sha(source_path) == receipt['source_glb_sha256']
assert sha(derivative_path) == receipt['derived_glb_sha256']
derivative_rel = 'assets/models/WP15_team_lounge_runtime_compartment_material_v1.glb'
source_rel = 'data/architecture/team_lounge/source/WP15_team_lounge_source.glb'
# Archive extension is intentionally not .glb: prevent a second source import,
# while preserving exact original bytes for correspondence and recovery.
source_rel += '.archive'
for rel in [source_rel, derivative_rel]:
    assert not (LIVE / rel).exists(), 'Reserved destination already occupied'
source_file = copy(source_path, source_rel)
derivative_file = copy(derivative_path, derivative_rel)
policy = read(BASE / 'runtime_derivative/PROPOSED_IMPORT_POLICY.json')['params']
imported = 'res://.godot/imported/' + Path(derivative_rel).name + '-' + hashlib.md5(derivative_file.encode()).hexdigest() + '.scn'
lines = ['[remap]', '', 'importer="scene"', 'importer_version=1', 'type="PackedScene"', 'path=' + json.dumps(imported), '', '[deps]', '', 'source_file=' + json.dumps(derivative_file), 'dest_files=[' + json.dumps(imported) + ']', '', '[params]', '']
for key, val in policy.items(): lines.append(key + '=' + json.dumps(val))
lines += ['nodes/root_type="Node3D"', 'nodes/root_name="WP15RuntimeSource"', 'materials/extract=0', 'gltf/embedded_image_handling=1', '_subresources={}', '']
(GAME / (derivative_rel + '.import')).write_text('\n'.join(lines))
mapping = read(BASE / 'runtime_derivative/source_runtime_bijection.json')
g = GLB(derivative_path, placement=(0, 0, 0))
semantic = []
for row in mapping['nodes']:
    idx = row['runtime_node_index']
    semantic.append({'source_index':row['source_node_index'], 'source_name':row['source_name'], 'runtime_name':row['runtime_name'], 'kind':row['kind'], 'runtime_index':idx, 'runtime_parent_index':g.parents.get(idx), 'local_transform_column_major':g.local_matrix(idx).flatten(order='F').tolist()})
rests = []
for row in read(BASE / 'all_96_rest_contact_mapping.json')['contacts']:
    rests.append({'id':row['id'], 'local_position':[a-b for a,b in zip(row['world_contact_xyz'], [31,35.5,216])], 'world_contact_xyz':row['world_contact_xyz'], 'forward':row['world_forward_xyz'], 'furniture_instance':row['furniture_instance'], 'source_support_index':row['actual_glb_support_node_index']})
lights = []
for row in read(BASE / 'runtime_audit/light_inventory_and_adaptation.json')['lights']:
    p = row['runtime_proposal']
    lights.append({'source_index':row['node_index'], 'source_name':row['node_name'], 'runtime_parent_name':mapping['nodes'][row['node_index']]['runtime_name'], 'world_transform_column_major':row['world_transform_column_major'], 'color':row['original_light']['color'], 'light_energy':p['light_energy'], 'spot_range':p['spot_range_m'], 'spot_angle':p['spot_angle_degrees'], 'spot_attenuation':1.0, 'spot_angle_attenuation':1.0, 'source_inner_cone_degrees':row['inner_cone_degrees'], 'fixture_members':[m['node_index'] for m in row['physical_fixture_members']], 'illumination_anchor':p['illumination_anchor_world_xyz'], 'receiver_evidence':row.get('source_axis_first_hit_up_to_12m'), 'calibration_status':'Initial source-derived Godot range/energy; Godot angular falloff is not glTF inner-cone equivalence. Runtime light/receiver review remains required.'})
textures = []
for row in read(BASE / 'receiving_finish_materials.json')['materials']:
    assert sha(BASE / row['path']) == row['sha256']
    file = copy(BASE / row['path'], 'assets/textures/team_lounge/' + row['role'] + '.png')
    textures.append({'role':row['role'], 'file':file, 'sha256':row['sha256']})
floor = read(BASE / 'receiving_compiled_records.json')[0]
data = {'schema':'astraea.wp15.runtime.v1', 'program_key':'D07_directory_08', 'root_name':'D07_TeamLounge_Receiving_WIP', 'placement':[31,35.5,216], 'source_file':source_file, 'source_sha256':receipt['source_glb_sha256'], 'derivative_file':derivative_file, 'derivative_sha256':receipt['derived_glb_sha256'], 'semantic_nodes':semantic, 'collision_groups':read(ROOT / 'collision_work/collision_groups.json'), 'rest_contacts':rests, 'lights':lights, 'finish_textures':textures, 'finish_top_chunks':[r['id'] for r in floor['render_chunks']], 'counts':{'semantic_nodes':4676,'render_meshes':241,'collision_groups':101,'faces_including_degenerates':494470,'rest_contacts':96,'lights':90,'finish_top_chunks':52}, 'limits':['No admission capacity or interaction created','Primary deck/hull bearing unverified','No Godot import, physics, traversal or visual acceptance yet','Godot angular falloff remains a bounded calibration, not exact Blender photometry']}
write(GAME / 'data/architecture/team_lounge/runtime_manifest.json', data)
for row in read(BASE / 'BOUNDED_COMPILER_APPLY_MANIFEST.json')['files']:
    current = LIVE / row['path']
    assert (sha(current) if current.exists() else None) == row['existing_Game_sha256']
    assert sha(BASE / 'candidate/Game' / row['path']) == row['candidate_sha256']
    copy(BASE / 'candidate/Game' / row['path'], row['path'])
ship = (LIVE / 'scripts/ship.gd').read_bytes()
anchor = b'\tlighting_budget.configure(self,player)\n'
addition = b'\tpreload("res://scripts/team_lounge_receiving.gd").build(self)\n'
assert ship.count(anchor) == 1 and addition not in ship
(GAME / 'scripts/ship.gd').write_bytes(ship.replace(anchor, addition + anchor))
assert (GAME / 'scripts/ship.gd').read_bytes().replace(addition,b'') == ship
print('Staged exact compiler candidate, single loader addition, source archive, selected derivative, textures and complete runtime manifest.')
