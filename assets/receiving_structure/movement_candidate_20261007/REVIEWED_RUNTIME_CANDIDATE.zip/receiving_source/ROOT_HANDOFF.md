# Movement Studio exact receiving successor

Ready for root-controlled adoption against the current Team Lounge predecessor, subject to root's physical/import/runtime gates. This is isolated source work, not an installed or accepted room.

## Apply

Use only `UNION_APPLY_MANIFEST.json`'s 28 files from this directory's `Game/` overlay. The overlay also contains compiler staging dependencies copied from the predecessor; those unlisted files are NOT apply outputs. Verify every candidate digest and every `existing_Game_sha256` immediately before copy. Null preimages must still be absent. Preserve any later surviving changes and rebase rather than force-copy.

Manifest SHA256: `01c13eabf4fd2621cfdd58e9ebcf090b5b0a4d6b4aae39c31d46c596c2896280`.
Runtime proof SHA256: `6e0084719decdbbe0d442949732628dac3920c43027af7dc6728ea190efeb394`.

- All 13 original `game_apply/` deliverables are byte-identical.
- Adds exactly `D07_movement_studio_floor` (3128 m²) and `D07_movement_studio_entry` (32 m²), at Y35.5/depth0.24. Complete compiled predecessor277 records and order survive, producing279; every old layout/global/void record survives.
- Adds `tools/movement_studio_incremental_preservation.py`, nesting the existing Team Lounge → Botanical → Medical preservation chain. It authenticates its proof, exact predecessor bytes, unchanged effective footprints, exact two compiled records, area and non-overlap.
- Changes compiler only by its exact recorded import/call/receipt additions.
- Inserts exactly one `load("res://scripts/movement_studio_receiving.gd").build($ShipSpace/Districts,self)` immediately before the existing sole lighting configure. Every preceding ship byte and Team Lounge call survives.
- Runtime guard authenticates complete new pins, exact guard/ship/compiler inverses, full279 runtime roster and slab geometry before exposing277 to the unchanged prior Team Lounge proof. It validates retained source hierarchy against fresh imported templates, complete collision faces, raw pinned GLB position/UV/winding/multiplicity using unchanged exact decoder helpers, nine marker poses,31 fixture lights, two information target geometries, floor finish textures and sole shared light budget. It preserves all existing tolerances, including the old Botanical0.0001 guard tolerance. The room loader's tighter0.00001 seat checks remain.
- No imports/settings files supplied. Follow original `IMPORT_POLICY.json` before engine import; preserve importer-generated UIDs and defaults and verify semantic settings/fresh cache. Current proof pins model sources and import semantics rather than arbitrary pre-import serialization.

## Independent source evidence

`SOURCE_VALIDATION.json`: PASS_SOURCE_ONLY,7 positive groups and16 negative mutations rejected. It checks live preimages and union hashes, complete previous proof pins, exact predecessor record/global preservation, independently recomputed new rectangle/triangle/render cell support and old slab separation, source archive and original13 file pins, grammar of every delivered GDScript, and a deterministic second compiler run.

Run with the already retained dependencies:

HOME=/workspace/scratch/375c2e438292/movement_receiving_20261007/parser_cache PYTHONPATH=/workspace/scratch/375c2e438292/botanical_receiving_court_build_20261007/python_deps:/workspace/scratch/375c2e438292/botanical_receiving_court_build_20261007/proof_integration003/parser_deps python /workspace/scratch/375c2e438292/movement_receiving_20261007/verify_successor.py

`build_successor.py` refuses to overwrite a stage. Failed first and second compiler preparation attempts remain in `successor001_attempt001` and `successor001_attempt002`: independently staged expectations initially had equivalent rectangle triangle/ring ordering differing from the actual compiler's priority-difference operations. Fixed by deriving expected shapes through the existing exact effective-shape pipeline, without weakening any equality or tolerance. The final independent geometric verifier separately proves rectangle coverage and areas. `successor001_pre_raw_import` preserves the intermediate stage before adding raw GLB runtime validation. All these are isolated evidence only.

The first source-verifier negative test incorrectly checked inverse cardinality without comparing its result to the predecessor; this test was strengthened to require the complete predecessor and now rejects duplicate loaders. Parser cache attempts initially hit read-only default HOME; final run uses the isolated HOME above. No engine was involved.

## Remaining gates and coordination

Root supplied `ROOT_WP03_ROOF_CLEARANCE.json`: current retained Cloud Conservatory source roof35.199999243 versus proposed underside35.26, about6 cm positive separation. The earlier plan's35.0 value is historical, not the measured current roof. This does not establish primary bearing capacity or authorize future unpublished source changes.

No Game/Catalogue edits, engine/import run, backup changes, commits or source archive changes were made by this task. GDScript grammar is not engine type checking. The new raw-source/import validators are executable fail-closed gates, not executed success claims; import differences must be diagnosed, never hidden by relaxed tolerances or degenerate exclusions. Actual room/capsule/cart/four-products/RMB-E/lighting/art/GPU/audio/primary structure gates remain open as documented in the original receiving plan. Root owns the qualified directory ledger update and aggregate/focused regressions.

Moss worker has been told to compose after this strict279-owner successor rather than overwrite it. It must nest Movement's compiler proof and project the Movement runtime proof before exposing the prior279-owner world.
