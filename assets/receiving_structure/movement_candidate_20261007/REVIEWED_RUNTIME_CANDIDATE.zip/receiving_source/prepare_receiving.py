"""Isolated binary/source receiving preparation. No engine or project compiler invoked."""
import json,struct,hashlib,copy,math,re
from pathlib import Path
import numpy as np
from shapely.geometry import Polygon,box
from shapely.ops import unary_union
R=Path(__file__).resolve().parent; S=R/'source_frozen/WP11_D07_directory_02'; G=Path('/workspace/shared/Astraea_recovery_20261007_AXWr5x/Game'); A=R/'game_apply'
for p in ['assets/models','data/architecture/packages/movement_studio','scripts','shaders','tests']: (A/p).mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n')
def glb(p):
 b=p.read_bytes();assert b[:4]==b'glTF';jlen,jkind=struct.unpack_from('<II',b,12);assert jkind==0x4e4f534a;d=json.loads(b[20:20+jlen]);off=20+jlen;blen,bkind=struct.unpack_from('<II',b,off);assert bkind==0x004e4942;return d,b[off+8:off+8+blen]
def save(p,d,b):
 j=json.dumps(d,separators=(',',':'),ensure_ascii=True).encode();j+=b' '*((-len(j))%4);b+=b'\0'*((-len(b))%4);p.write_bytes(struct.pack('<III',0x46546c67,2,28+len(j)+len(b))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(b),0x004e4942)+b)
def acc(d,b,i):
 a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];n={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']];t={5120:'i1',5121:'u1',5122:'<i2',5123:'<u2',5125:'<u4',5126:'<f4'}[a['componentType']];dt=np.dtype(t);stride=v.get('byteStride',n*dt.itemsize);return np.ndarray((a['count'],n),dt,buffer=b,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(stride,dt.itemsize)).copy()
def mat(n):
 if 'matrix'in n:return np.array(n['matrix']).reshape(4,4).T
 t=np.eye(4);t[:3,3]=n.get('translation',[0,0,0]);x,y,z,w=n.get('rotation',[0,0,0,1]);rot=np.array([[1-2*y*y-2*z*z,2*x*y-2*z*w,2*x*z+2*y*w],[2*x*y+2*z*w,1-2*x*x-2*z*z,2*y*z-2*x*w],[2*x*z-2*y*w,2*y*z+2*x*w,1-2*x*x-2*y*y]])
 t[:3,:3]=rot@np.diag(n.get('scale',[1,1,1]));return t
def nodes(d,b,placement=[0,0,0]):
 out=[]
 def walk(i,m):
  n=d['nodes'][i];m=m@mat(n)
  if 'mesh'in n:
   allv=[];nf=0;dg=0
   for pr in d['meshes'][n['mesh']]['primitives']:
    assert pr.get('mode',4)==4
    v=acc(d,b,pr['attributes']['POSITION']).astype(float);v=(np.c_[v,np.ones(len(v))]@m.T)[:,:3]+placement;allv.append(v)
    ix=acc(d,b,pr['indices']).reshape(-1) if 'indices'in pr else np.arange(len(v));f=v[ix.reshape(-1,3)];area=np.linalg.norm(np.cross(f[:,1]-f[:,0],f[:,2]-f[:,0]),axis=1);nf+=len(f);dg+=int((area==0).sum())
   v=np.concatenate(allv);out.append({'index':i,'name':n['name'],'world_min':v.min(0).tolist(),'world_max':v.max(0).tolist(),'vertices':len(v),'triangles':nf,'exact_degenerate_triangles':dg})
  for c in n.get('children',[]):walk(c,m)
 for i in d['scenes'][d.get('scene',0)]['nodes']:walk(i,np.eye(4))
 return out
source=S/'exports/WP11_movement_studio.glb';d,b=glb(source);assert sha(source)=='e2607aee0a51ee4ec019b265c2fae28b8f8217cb17b8150c7661005a9e02c95e'
nd=copy.deepcopy(d);mapping=[]
for i,n in enumerate(nd['nodes']):
 old=n['name'];safe=f'WP11N_{i:04d}';n['name']=safe;n.setdefault('extras',{}).update({'source_name':old,'source_node_index':i});mapping.append({'source_index':i,'source_name':old,'runtime_name':safe})
model=A/'assets/models/WP11_movement_studio_runtime_names001.glb';save(model,nd,b)
check,bb=glb(model);assert bb==b
for i,n in enumerate(check['nodes']):
 n['name']=d['nodes'][i]['name'];n['extras'].pop('source_name');n['extras'].pop('source_node_index');
 if not n['extras'] and 'extras'not in d['nodes'][i]:del n['extras']
assert check==d
nb=nodes(d,b,np.array([8,35.5,-456]));mins=np.min([n['world_min'] for n in nb],axis=0);maxs=np.max([n['world_max']for n in nb],axis=0);assert maxs[1]<43.35001 and mins[1]>35.49999
lookup={m['source_name']:m['runtime_name']for m in mapping};seats=[n for n in d['nodes']if n['name'].startswith('Seat_')];assert len(seats)==9
lights=[];bounds={n['name']:n for n in nb}
for k,l in enumerate(json.load(open(S/'docs/lights.json'))):
 n=l['id']+'_emitter';bo=bounds[n];p=np.array(l['world']);assert abs(p[0]-(bo['world_min'][0]+bo['world_max'][0])/2)<3e-6 and abs(p[2]-(bo['world_min'][2]+bo['world_max'][2])/2)<3e-6
 assert .02<bo['world_min'][1]-p[1]<.03
 staff=l['id'].startswith('Service_');practice=l['id'].startswith('Practice_')
 lights.append({'id':f'WP11_source_{k:02d}','source_id':l['id'],'fixture_node':lookup[n],'world':l['world'],'direction':[0,-1,0],'color':[.83,.92,1]if staff else[1,.8,.56],'source_area_power_w':l['power_w'],'spot_energy':1.6 if practice else(1.15 if staff else 1.2),'spot_range':10.0 if practice else 7.0,'spot_angle_degrees':68,'shadow_requested':True,'visible_initially':False,'calibration':'Initial area-to-spot receiving mapping, requires actual appearance/fixture exit and budget verification; not source render equivalence.'})
# Exact retained authored four-metre guard segment, rigidly relocated twice; no source vertex edit.
gp=G/'assets/models/AST-ATR-001_botanical_receiving_closed002.glb';gd,gb=glb(gp);gn=copy.deepcopy(gd);selected=[copy.deepcopy(n)for n in gd['nodes']if n.get('name','').startswith('BOTCOURT_starboard_EDGE_0_')];assert len(selected)==10 and all('children'not in n for n in selected)
gn['nodes']=[]
for label,t,rot in [('Fore',[12,8.5,-668],[0,1,0,0]),('Aft',[0,8.5,-244],[0,0,0,1])]:
 child=[]
 for n in selected:
  n=copy.deepcopy(n);n.setdefault('extras',{})['retained_source_name']=n['name'];n['name']='WP11Guard_'+label+'_'+n['name'].split('EDGE_0_')[1];child.append(len(gn['nodes']));gn['nodes'].append(n)
 gn['nodes'].append({'name':'WP11Guard_'+label,'children':child,'translation':t,'rotation':rot})
gn['scenes']=[{'name':'MovementReceivingGuards','nodes':[10,21]}];gn['scene']=0
# Reused unused resources stay byte-identical, and are not instantiated by the two selected scene roots.
guard=A/'assets/models/WP11_movement_receiving_guards001.glb';save(guard,gn,gb);gbounds=nodes(gn,gb);gm=np.min([n['world_min']for n in gbounds],axis=0);gx=np.max([n['world_max']for n in gbounds],axis=0)
# Tiny end-post pads are measured rather than assumed entirely inside the32m² connector.
footprints=[]
for n in gbounds:
 if n['world_min'][1]<35.50001:
  a=n['world_min'];q=n['world_max'];footprints.append(box(a[0],a[2],q[0],q[2]))
layout=json.load(open(G/'data/spatial_layout.json'));compiled=json.load(open(G/'data/generated/structural_meshes.json'));room=box(8,-466,54,-398);branch=box(4,-460,8,-452)
# Existing axial floor and source room support endpoint slivers; no unsupported pad is accepted.
oldfloor=unary_union([Polygon(t)for r in compiled['regions']if abs(r['floor_y']-35.5)<1e-8 for t in r['triangles']]);support=unary_union([oldfloor,room,branch]);unsupported=[]
for f in footprints:
 if f.difference(support.buffer(1e-5)).area>1e-8:unsupported.append(f.bounds)
assert not unsupported,unsupported
regions=[]
for ident,poly,kind in [('D07_movement_studio_floor',room,'authored_programme_receiving'),('D07_movement_studio_entry',branch,'authored_programme_connector')]:
 hits=[]
 for r in compiled['regions']:
  if max(35.26,r['floor_y']-r['thickness'])<min(35.5,r['floor_y'])-1e-8:
   area=poly.intersection(unary_union([Polygon(t)for t in r['triangles']])).area
   if area>1e-7:hits.append([r['id'],area])
 assert not hits,hits
 regions.append({'id':ident,'deck':'D07','boundary':[list(q)for q in poly.exterior.coords[:-1]],'thickness':.24,'render_cell_m':4,'material_role':'guest_floor','kind':kind,'programme_key':'D07_directory_02','status':'Whole Movement Studio receiving WIP; source room installed only when loader called; runtime and final quality not accepted'})
contract={'schema':1,'programme_key':'D07_directory_02','root_name':'D07_MovementStudio_Receiving_WIP','persistent_id':'D07_movement_studio_receiving_001','placement':[8,35.5,-456],'model_file':model.name,'model_sha256':sha(model),'source_model_sha256':sha(source),'guard_file':guard.name,'guard_sha256':sha(guard),'mesh_instances':1290,'guard_mesh_instances':20,'source_node_count':1337,'floor_owners':[r['id']for r in regions],'existing_axis_owner':'D07_fore_route','seats':[{'source_name':n['name'],'runtime_name':lookup[n['name']],'world':next(c['world']for c in json.load(open(S/'docs/contacts.json'))if c['name']==n['name'])}for n in seats],'lights':lights,'lighting_budget_unchanged':{'shadow_sources':8,'visibility_candidates':32,'update_s':.2},'roof_max_y':43.35,'adoption_state':'candidate; parent apply and engine import validation required','first_pass_quality_accepted':False,'capacity_accepted':False,'source_floor_excluded':True,'node_bijection_file':'res://data/architecture/packages/movement_studio/NODE_BIJECTION.json','floor_shader':'res://shaders/movement_studio_floor.gdshader'}
C=A/'data/architecture';dump(C/'D07_MOVEMENT_STUDIO_RECEIVING.json',contract);dump(C/'packages/movement_studio/NODE_BIJECTION.json',mapping);dump(R/'SPATIAL_ADDITIONS.json',{'append_only_regions':regions,'old_regions_preserved':True,'priority_replacements':[],'void_exemptions':[],'compiled_count_before':len(compiled['regions']),'source_sha256':sha(G/'data/spatial_layout.json'),'compiled_sha256':sha(G/'data/generated/structural_meshes.json')})
dump(R/'BINARY_RECEIVING_AUDIT.json',{'source_sha256':sha(source),'derived_sha256':sha(model),'source_native_sha256':sha(S/'source/WP11_movement_studio.blend'),'source_json_equal_after_name_metadata_inverse':True,'source_binary_chunk_identical':True,'source_mesh_instances':len(nb),'mesh_resources':len(d['meshes']),'materials':len(d['materials']),'images':len(d['images']),'embedded_punctual_lights':0,'mesh_world_min':mins.tolist(),'mesh_world_max':maxs.tolist(),'triangles':sum(n['triangles']for n in nb),'exact_degenerate_triangles':sum(n['exact_degenerate_triangles']for n in nb),'nine_seat_markers':True,'fixture_lights':len(lights),'node_bounds':nb,'guard_derivative':{'source_sha256':sha(gp),'binary_chunk_identical':glb(guard)[1]==gb,'selected_source_prefix':'BOTCOURT_starboard_EDGE_0_','selected_meshes_per_instance':10,'instances':2,'world_min':gm.tolist(),'world_max':gx.tolist(),'bounds':gbounds,'support_failures':unsupported},'source_preview_floor_exported':False,'floor_additive_overlap_checks_passed':True,'engine_or_compiler_run':False})
# Retain source route witnesses without promoting them to actual-runtime proof.
dump(C/'packages/movement_studio/SOURCE_ROUTE_WITNESSES.json',json.load(open(S/'tests/revision02_routes_support.json')))
for src,name in [('warm_stone.png','WP11_receiving_warm_stone.png'),('warm_walnut.png','WP11_receiving_warm_walnut.png')]: (A/'assets/models'/name).write_bytes((S/'assets/materials'/src).read_bytes())
# No live write; only capture hashes required for a conflict-aware parent apply.
pins={str(p.relative_to(G)):sha(p)for p in [G/'scripts/ship.gd',G/'scripts/player.gd',G/'scripts/lighting_budget.gd',G/'scripts/static_contact_cache.gd',G/'data/spatial_layout.json',G/'data/generated/structural_meshes.json',G/'data/programme_ledger.json',G/'data/architecture/FORWARD_PUBLIC_CORE.json',G/'tools/compile_layout.py',G/'tools/validate.py']};dump(R/'LIVE_READ_PINS.json',pins)
print(json.dumps({'mesh_bounds':[mins.tolist(),maxs.tolist()],'guard_bounds':[gm.tolist(),gx.tolist()],'triangles':sum(n['triangles']for n in nb),'source_nodes':len(d['nodes']),'source_preserved':True,'additive_floor_area':room.area+branch.area,'lights':len(lights)}))
