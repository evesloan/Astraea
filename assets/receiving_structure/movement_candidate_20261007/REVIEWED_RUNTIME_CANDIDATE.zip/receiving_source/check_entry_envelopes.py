"""Conservative source-bounds compound route screen. Not driven-cart/physics acceptance."""
import json,math,hashlib
from pathlib import Path
from shapely.geometry import Polygon,box,Point,MultiPoint
from shapely.affinity import rotate,translate
from shapely.ops import unary_union
R=Path(__file__).resolve().parent;G=Path('/workspace/shared/Astraea_recovery_20261007_AXWr5x/Game')
b=json.load(open(R/'BINARY_RECEIVING_AUDIT.json'));compiled=json.load(open(G/'data/generated/structural_meshes.json'));extra=json.load(open(R/'SPATIAL_ADDITIONS.json'))['append_only_regions']
floor=unary_union([Polygon(t)for r in compiled['regions']if abs(r['floor_y']-35.5)<1e-8 for t in r['triangles']]+[Polygon(r['boundary'])for r in extra])
obs=[]
for n in b['node_bounds']+b['guard_derivative']['bounds']:
 lo=n['world_min'];hi=n['world_max']
 if hi[1]>35.51 and lo[1]<37.3 and hi[0]>-4 and lo[0]<25 and hi[2]>-464 and lo[2]<-450:
  obs.append((n['name'],box(lo[0],lo[2],hi[0],hi[2]),lo[1],hi[1]))
cart=json.load(open(G/'data/architecture/cleaning_cart_contacts.json'));parts=[]
for i,c in enumerate(cart['boxes']):
 x,y,z=c['center'];w,h,l=c['size'];parts.append((str(i)+'_'+c['name'],box(x-w/2,z-l/2,x+w/2,z+l/2),y-h/2,y+h/2))
for i,c in enumerate(cart['wheel_contacts']):
 x,y,z=c['center'];r=c['radius'];parts.append((f'wheel{i}',Point(x,z).buffer(r,resolution=32),y-r,y+r))
for i in range(4):parts.append((f'product{i}',Point(-.16+.32*(i%2),-.20+.4*(i//2)).buffer(.057,resolution=32),.96,1.21))
# Conservative rectangle contains every1.8m/0.3m production capsule cross-section.
parts.append(('operator',box(-.3,1.1,.3,1.7),0,1.8))
# +Z is rear/handle. In x/z plane, yaw90 sends the cart nose toward +X.
poses=[]
def straight(a,c,angle):
 dist=math.dist(a,c);n=math.ceil(dist/.05)
 for i in range(n+1):poses.append((a[0]+(c[0]-a[0])*i/n,a[1]+(c[1]-a[1])*i/n,angle))
def turn(p,a,c):
 n=math.ceil(abs(c-a)/1.0)
 for i in range(n+1):poses.append((*p,a+(c-a)*i/n))
straight((2,-458),(13,-458),90);turn((13,-458),90,180);straight((13,-458),(13,-456),180);turn((13,-456),180,90);straight((13,-456),(22,-456),90)
# Safe complete return with supported orientation change inside the room.
turn((22,-456),90,-90);straight((22,-456),(13,-456),-90);turn((13,-456),-90,0);straight((13,-456),(13,-458),0);turn((13,-458),0,-90);straight((13,-458),(2,-458),-90)
fail=[];clear=float('inf');support_clear=float('inf');supports=0
for j,(x,z,yaw)in enumerate(poses):
 for name,poly,low,high in parts:
  env=translate(rotate(poly,yaw,origin=(0,0),use_radians=False),xoff=x,yoff=z)
  if name.startswith('wheel') or name=='operator':
   supports+=1
   support_clear=min(support_clear,env.distance(floor.boundary))
   if not floor.buffer(1e-6).covers(env):fail.append({'pose':j,'kind':'unsupported','part':name})
  for nn,ob,yl,yh in obs:
   if min(35.5+high,yh)-max(35.5+low,yl)<=1e-5:continue
   gap=env.distance(ob);clear=min(clear,gap)
   if env.intersection(ob).area>1e-9:fail.append({'pose':j,'part':name,'obstacle':nn,'kind':'collision'})
# Walk-only centerline radius0.3, all ordinary entrance/turn points and reverse.
walkline=[(2,-458),(6,-458),(9,-458),(13,-458),(13,-456),(22,-456)];walkfail=[];ws=0
for a,c in zip(walkline,walkline[1:]):
 n=math.ceil(math.dist(a,c)/.05)
 for i in range(n+1):
  x=a[0]+(c[0]-a[0])*i/n;z=a[1]+(c[1]-a[1])*i/n;env=box(x-.3,z-.3,x+.3,z+.3);ws+=1
  if not floor.buffer(1e-6).covers(env):walkfail.append([x,z,'support'])
  for nn,ob,yl,yh in obs:
   if min(37.3,yh)>max(35.51,yl)and env.intersection(ob).area>1e-9:walkfail.append([x,z,nn])
out={'scope':'Conservative actual source mesh-AABB obstruction and full compound box/wheel/four-product/operator envelopes, spatially sampled50mm/yaw1degree; no engines, no dynamic force-driven result or freehand/species acceptance. Conservative maximum point movement between poses is bounded by translation plus rotational chord; positive clearance beyond this bound proves the declared geometric path between samples. Dynamic loaded-cart and grip behavior remain untested.','passed':not fail and not walkfail,'declared_portal_datum':[8,35.5,-456],'actual_clear_entry_center':[8,35.5,-458],'actual_inward_wall_aperture_z':[-460.2000000476837,-455.79999923706055],'source_deep_return_intrudes_clear_to_z':-459.9999998062849,'conservative_clear_entry_z':[-459.9999998062849,-455.79999923706055],'branch_boundary_xz':[[4,-460],[8,-460],[8,-452],[4,-452]],'forward_path_cart_centers':[[2,-458],[13,-458],[13,-456],[22,-456]],'cart_pose_count':len(poses),'compound_parts':len(parts),'wheel_operator_support_samples':supports,'walk_samples':ws,'minimum_sampled_obstacle_clearance_m':clear,'minimum_support_boundary_clearance_m':support_clear,'maximum_between_pose_point_displacement_bound_m':.05+2*1.73*math.sin(math.radians(1)/2),'continuous_conservative_envelope_clearance_proved':min(clear,support_clear)>.05+2*1.73*math.sin(math.radians(1)/2),'cart_failures':fail[:20],'walk_failures':walkfail[:20],'source_geometry_and_datum_changed':False,'no_core_aperture_change':True,'operator_local_rear_offset_m':1.4,'input_hashes':{str(p.relative_to(G)):hashlib.sha256(p.read_bytes()).hexdigest()for p in [G/'data/architecture/cleaning_cart_contacts.json',G/'scripts/cleaning_cart.gd',G/'scripts/cleaning_bottle.gd',G/'scripts/player.gd']}}
(R/'ENTRY_ENVELOPE_SCREEN.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in ['scope','input_hashes']}));assert out['passed']
