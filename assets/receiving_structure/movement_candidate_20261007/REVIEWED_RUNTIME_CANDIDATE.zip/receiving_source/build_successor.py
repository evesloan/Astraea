from pathlib import Path
import json,hashlib,shutil,math,subprocess,sys
import shapely
from shapely.geometry import Polygon,box
from shapely.geometry.polygon import orient
D=Path(__file__).resolve().parent; B=Path('/workspace/shared/Astraea_recovery_20261007_AXWr5x/Game'); W=D/'successor001'; C=W/'Game'; T=Path('/workspace/scratch/375c2e438292/team_lounge_receiving_20261007/runtime_implementation001/proof_work')
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_text())
def put(rel,data):
 p=C/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data if isinstance(data,bytes) else data.encode())
def dump(rel,data):put(rel,json.dumps(data,indent=2)+'\n')
assert not W.exists(),'Preserve earlier stage'
assert len(load(B/'data/generated/structural_meshes.json')['regions'])==277
W.mkdir();shutil.copytree(B/'data',C/'data');shutil.copytree(B/'tools',C/'tools');(C/'docs').mkdir()
(C/'assets/models').mkdir(parents=True);shutil.copy2(B/'assets/models/AST-CUL-005_static_003.glb',C/'assets/models/AST-CUL-005_static_003.glb')
newpaths=[]
for p in (D/'game_apply').rglob('*'):
 if p.is_file():
  rel=p.relative_to(D/'game_apply').as_posix();assert not (B/rel).exists();put(rel,p.read_bytes());newpaths.append(rel)
pre={};ret='data/architecture/packages/movement_studio/retained_277/'
for rel in ['data/spatial_layout.json','data/generated/structural_meshes.json','docs/LAYOUT_COMPILE_CHECKS.json','tools/compile_layout.py','scripts/ship.gd','tests/medical_triage_successor_guard.gd']:
 data=(B/rel).read_bytes();put(ret+rel,data);pre[rel]={'sha256':sha(data),'retained_path':ret+rel}
added=load(D/'SPATIAL_ADDITIONS.json')['append_only_regions'];layout=load(B/'data/spatial_layout.json');layout['regions']+=added;dump('data/spatial_layout.json',layout)
sys.path.insert(0,str(B/"tools"))
from theater_incremental_preservation import effective_shapes
elevations={x["deck_id"]:x["floor_elevation_m"] for x in load(B/"data/design_contract.json")["deck_datums"]}
effective=effective_shapes(layout,elevations)
expected=[]
for item in added:
 shape=effective[item['id']]
 tri=shapely.constrained_delaunay_triangles(shape);p=orient(shape,sign=1.0);chunks=[];cell=item['render_cell_m'];x0,z0,x1,z1=shape.bounds
 for cx in range(math.floor(x0/cell),math.ceil(x1/cell)):
  for cz in range(math.floor(z0/cell),math.ceil(z1/cell)):
   part=shape.intersection(box(cx*cell,cz*cell,(cx+1)*cell,(cz+1)*cell))
   if part.area<1e-8:continue
   chunks.append({'id':f'cell_{cx}_{cz}','triangles':[[list(c) for c in t.exterior.coords[:3]] for t in shapely.constrained_delaunay_triangles(part).geoms]})
 expected.append({'id':item['id'],'deck':item['deck'],'floor_y':35.5,'thickness':.24,'triangles':[[list(c) for c in t.exterior.coords[:3]]for t in tri.geoms],'rings':[[list(c)for c in p.exterior.coords[:-1]]],'structural_area_m2':shape.area,'render_chunks':chunks,'status':item['status'],'material_role':item['material_role']})
cp='data/architecture/packages/movement_studio/MOVEMENT_COMPILER_PROOF.json'
dump(cp,{'schema':1,'programme_key':'D07_directory_02','predecessors':{k:pre[k]for k in list(pre)[:3]},'new_layout_records':added,'new_expected_compiled_records':expected,'contract_sha256':sha((B/'data/design_contract.json').read_bytes()),'scope':'Exact two-owner addition; runtime and primary bearing acceptance open'})
module=(B/'tools/team_lounge_incremental_preservation.py').read_text()
module=module.replace('275','277').replace('team_lounge','movement_studio').replace('TEAM_LOUNGE_COMPILER_PROOF','MOVEMENT_COMPILER_PROOF').replace('D07_movement_studio_receiving_floor','D07_movement_studio_floor').replace('D07_movement_studio_axial_connector','D07_movement_studio_entry')
module=module.replace("PROOF_SHA='5d1aaf3c888822728b80de77b83e5ad30598b7aed23163d260b5e807b0016db0'",'PROOF_SHA='+repr(sha((C/cp).read_bytes())))
module=module.replace('outputs,preserve_botanical,preserve_triage,preserve_welcome):','outputs,preserve_lounge,preserve_botanical,preserve_triage,preserve_welcome):').replace('preserved,welcome,triage,botanical=preserve_botanical(root,projected,elevations,prior_owned,old_outputs,preserve_triage,preserve_welcome)','preserved,welcome,triage,botanical,lounge=preserve_lounge(root,projected,elevations,prior_owned,old_outputs,preserve_botanical,preserve_triage,preserve_welcome)').replace('return preserved+new_outputs,welcome,triage,botanical,receipt','return preserved+new_outputs,welcome,triage,botanical,lounge,receipt')
put('tools/movement_studio_incremental_preservation.py',module)
inverse={};s=(B/'tools/compile_layout.py').read_text();ed=[]
def edit(s,a,b,ed):
 assert s.count(a)==1,(a,s.count(a));ed.insert(0,{'before':a,'after':b,'count':1});return s.replace(a,b)
a='from team_lounge_incremental_preservation import preserve_team_lounge_successor';s=edit(s,a,a+'\nfrom movement_studio_incremental_preservation import preserve_movement_studio_successor',ed)
a='outputs,medical_preservation,triage_preservation,botanical_preservation,team_lounge_preservation=preserve_team_lounge_successor(root,layout,elevations,owned,outputs,preserve_botanical_court_successor,preserve_medical_triage_successor,preserve_medical_predecessor)';s=edit(s,a,a.replace('team_lounge_preservation=preserve_team_lounge_successor','team_lounge_preservation,movement_preservation=preserve_movement_studio_successor').replace('outputs,preserve_botanical','outputs,preserve_team_lounge_successor,preserve_botanical'),ed)
a="checks['team_lounge_additive_preservation']=team_lounge_preservation";s=edit(s,a,a+"\nchecks['movement_studio_additive_preservation']=movement_preservation",ed);put('tools/compile_layout.py',s);inverse['tools/compile_layout.py']=ed
s=(B/'scripts/ship.gd').read_text();ed=[];a='\tlighting_budget.configure(self,player)';s=edit(s,a,'\tload("res://scripts/movement_studio_receiving.gd").build($ShipSpace/Districts,self)\n'+a,ed);put('scripts/ship.gd',s);inverse['scripts/ship.gd']=ed
r=subprocess.run(['python',str(C/'tools/compile_layout.py')],capture_output=True,text=True);(W/'compiler_run.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
# Extend the current guard, retaining every lounge, botanical, medical and pool byte through exact inversion.
g='tests/medical_triage_successor_guard.gd';s=(B/g).read_text();ed=[]
s=edit(s,'or value==team_lounge_current_compiled)','or value==team_lounge_current_compiled or value==movement_current_compiled)',ed)
s=edit(s,'\tif value==team_lounge_current_compiled: value=botanical_current_compiled','\tif value==movement_current_compiled: value=team_lounge_current_compiled\n\tif value==team_lounge_current_compiled: value=botanical_current_compiled',ed)
s=edit(s,'\tif team_lounge_checked: return','\tif team_lounge_checked: return\n\t_movement_ensure()',ed)
s=edit(s,'FileAccess.get_sha256("res://"+str(path))==str(team_lounge_proof.current_sha256[path])','_movement_current_sha256("res://"+str(path))==str(team_lounge_proof.current_sha256[path])',ed)
for a in ['FileAccess.get_file_as_string("res://tests/medical_triage_successor_guard.gd")','FileAccess.get_file_as_string("res://"+str(path))','FileAccess.get_file_as_string("res://data/spatial_layout.json")','FileAccess.get_file_as_string("res://data/generated/structural_meshes.json")','FileAccess.get_file_as_string("res://docs/LAYOUT_COMPILE_CHECKS.json")']:
 s=edit(s,a,a.replace('FileAccess.get_file_as_string','_movement_current_text'),ed)
a='\tassert(floors!=null and floors.get_child_count()==277,"Complete actual 277-owner roster required before predecessor projection")';s=edit(s,a,'\tvar movement_predecessor_children: Array=_movement_floor_children(floors)\n'+a.replace('floors.get_child_count()','movement_predecessor_children.size()'),ed)
s=edit(s,'\tvar children: Array=floors.get_children()','\tvar children: Array=movement_predecessor_children',ed)
section=(T/'lounge_section.gd.in').read_text().replace('TEAM_LOUNGE','MOVEMENT').replace('team_lounge','movement').replace('275-to-277','277-to-279').replace('D07_directory_08','D07_directory_02').replace('packages/movement/','packages/movement_studio/').replace('D07_movement_receiving_floor','D07_movement_studio_floor').replace('D07_movement_axial_connector','D07_movement_studio_entry').replace('==277','==279').replace('==275','==277').replace('actual 277-owner','actual 279-owner').replace('2477.7225461174385','3128.0').replace('==16.0','==32.0').replace('summary.movement_additive','summary.movement_studio_additive')
section=section.replace('@RUNTIME_VALIDATOR@',(D/'movement_runtime_validator.gd.in').read_text().rstrip())
current={}
paths=newpaths+['data/spatial_layout.json','data/generated/structural_meshes.json','docs/LAYOUT_COMPILE_CHECKS.json','tools/compile_layout.py','scripts/ship.gd','tools/movement_studio_incremental_preservation.py',cp]
for rel in paths:current[rel]=sha((C/rel).read_bytes())
for rel in ['scripts/player.gd','scripts/lighting_budget.gd','scripts/static_contact_cache.gd','project.godot']:
 current[rel]=sha((B/rel).read_bytes())
proof={'schema':1,'programme_key':'D07_directory_02','projected_paths':list(pre),'current_sha256':current,'predecessors':pre,'added_owner_ids':[r['id']for r in added],'added_layout_records':added,'added_compiled_records':expected,'compile_summary':load(C/'docs/LAYOUT_COMPILE_CHECKS.json'),'consumer_inverse_edits':ed,'integration_block_normalized_sha256':sha(section.encode()),'exact_inverse_edits':inverse,'runtime_manifest':'data/architecture/D07_MOVEMENT_STUDIO_RECEIVING.json','scope':'Source-preserved successor; engine/runtime and imported geometry acceptance pending'}
rp='data/architecture/packages/movement_studio/MOVEMENT_RUNTIME_PROOF.json';dump(rp,proof);put(g,s+section.replace('<PROOF_SHA>',sha((C/rp).read_bytes()),1))
paths+=list(x['retained_path']for x in pre.values())+[rp,g]
manifest={'scope':'Union overlay only; compiler and runtime proof against exact current277. No imports/engine/live edits.','live_game':str(B),'source_manifest_sha256':sha((D/'APPLY_MANIFEST.json').read_bytes()),'predecessor_count':277,'successor_count':279,'files':[{'path':rel,'sha256':sha((C/rel).read_bytes()),'existing_Game_sha256':sha((B/rel).read_bytes())if (B/rel).is_file()else None,'bytes':(C/rel).stat().st_size}for rel in sorted(set(paths))],'open_gates':load(D/'APPLY_MANIFEST.json')['open_gates']}
(W/'UNION_APPLY_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Built',W,len(manifest['files']),'union files')
