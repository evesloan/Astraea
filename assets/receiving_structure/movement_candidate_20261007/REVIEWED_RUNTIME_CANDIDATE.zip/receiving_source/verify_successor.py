"""Independent read-only source verifier; never executes Godot or changes live Game."""
import json,hashlib,copy,subprocess,os
from pathlib import Path
from shapely.geometry import Polygon
from shapely.ops import unary_union
D=Path(__file__).resolve().parent;W=D/'successor001';C=W/'Game';B=Path('/workspace/shared/Astraea_recovery_20261007_AXWr5x/Game')
sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(p.read_text())
manifest=load(W/'UNION_APPLY_MANIFEST.json');rp='data/architecture/packages/movement_studio/MOVEMENT_RUNTIME_PROOF.json';p=load(C/rp);g='tests/medical_triage_successor_guard.gd';guard=(C/g).read_text();checks=[];negative=[]
def yes(v,why='Mismatch'):assert v,why
def resolve(rel):return C/rel if (C/rel).exists() else B/rel
def undo(s,edits):
 for e in edits:yes(s.count(e['after'])==e['count']);s=s.replace(e['after'],e['before'])
 return s
def recovered(s):
 a='# MOVEMENT_EXACT_SECTION_BEGIN\n';z='# MOVEMENT_EXACT_SECTION_END\n';yes(s.count(a)==s.count(z)==1);i=s.index(a);j=s.index(z)+len(z);block=s[i:j];digest=sha((C/rp).read_bytes());yes(block.count(digest)==1);yes(sha(block.replace(digest,'<PROOF_SHA>').encode())==p['integration_block_normalized_sha256']);return undo(s[:i]+s[j:],p['consumer_inverse_edits'])
for row in manifest['files']:
 yes(sha((C/row['path']).read_bytes())==row['sha256'],row['path'])
 prior=B/row['path'];yes((sha(prior.read_bytes())if prior.exists()else None)==row['existing_Game_sha256'],'Live preimage moved: '+row['path'])
for rel,digest in p['current_sha256'].items():yes(sha(resolve(rel).read_bytes())==digest,rel)
for rel,spec in p['predecessors'].items():yes((C/spec['retained_path']).read_bytes()==(B/rel).read_bytes());yes(sha((C/spec['retained_path']).read_bytes())==spec['sha256'])
yes(recovered(guard)==(B/g).read_text())
for rel,ed in p['exact_inverse_edits'].items():yes(undo((C/rel).read_text(),ed)==(B/rel).read_text())
checks.append('All union hashes, live preimages, current source pins and every exact predecessor byte authenticated')
# Evaluate preservation of the already accepted lounge proof under new projection.
lounge=load(B/'data/architecture/packages/team_lounge/TEAM_LOUNGE_RUNTIME_PROOF.json')
for rel,digest in lounge['current_sha256'].items():
 data=(B/rel).read_bytes() if rel in p['projected_paths'] else resolve(rel).read_bytes();yes(sha(data)==digest,'Lounge postimage lost: '+rel)
checks.append('All Team Lounge current pins preserved by bounded projection; complete original guard recovered byte-for-byte')
old_l=load(B/'data/spatial_layout.json');old_c=load(B/'data/generated/structural_meshes.json');layout=load(C/'data/spatial_layout.json');compiled=load(C/'data/generated/structural_meshes.json');summary=load(C/'docs/LAYOUT_COMPILE_CHECKS.json')
def structures(l,c,s):
 yes(l['regions']==old_l['regions']+p['added_layout_records']);yes(c['regions']==old_c['regions']+p['added_compiled_records']);yes(len(c['regions'])==279)
 for obj in [l,c]:yes(len({r['id']for r in obj['regions']})==len(obj['regions']))
 yes({k:v for k,v in l.items()if k!='regions'}=={k:v for k,v in old_l.items()if k!='regions'})
 yes({k:v for k,v in c.items()if k not in ['regions','source_checks']}=={k:v for k,v in old_c.items()if k not in ['regions','source_checks']})
 yes(c['source_checks']==s==p['compile_summary']);yes(s['movement_studio_additive_preservation']['complete_old_records_preserved'])
structures(layout,compiled,summary);checks.append('279 complete compiled records equal all277 predecessors plus exactly2 pinned additions; global and void records unchanged')
for spec,row,area in zip(p['added_layout_records'],p['added_compiled_records'],[3128,32]):
 shape=Polygon(spec['boundary']);yes(shape.area==area==row['structural_area_m2']);yes(row['floor_y']==35.5 and row['thickness']==.24)
 ts=[Polygon(t)for t in row['triangles']];yes(unary_union(ts).equals(shape));yes(sum(x.area for x in ts)==area)
 chunks=[Polygon(t)for chunk in row['render_chunks']for t in chunk['triangles']];yes(unary_union(chunks).equals(shape));yes(sum(x.area for x in chunks)==area)
 for old in old_c['regions']:
  oldshape=unary_union([Polygon(t)for t in old['triangles']]);overlap=shape.intersection(oldshape).area
  if overlap>1e-8:yes(min(35.5,old['floor_y'])-max(35.26,old['floor_y']-old['thickness'])<1e-7)
checks.append('Independent new rectangle/triangles/render cells area and all277 predecessor slab-volume checks')
for row in load(D/'APPLY_MANIFEST.json')['new_game_files']:yes((C/row['path']).read_bytes()==(D/'game_apply'/row['path']).read_bytes());yes(sha((C/row['path']).read_bytes())==row['sha256'])
checks.append('All13 original receiving files unchanged; original archive pin remains authentic')
yes(sha(Path(load(D/'APPLY_MANIFEST.json')['source_archive']).read_bytes())==load(D/'APPLY_MANIFEST.json')['source_archive_sha256'])
def reject(name,f):
 try:f()
 except AssertionError:negative.append(name);return
 raise AssertionError('Mutation escaped: '+name)
for name,kind,mutate in [
 ('predecessor geometry modified','c',lambda x:x['regions'][0].update(floor_y=-1)),
 ('new triangle modified','c',lambda x:x['regions'][-1]['triangles'][0][0].__setitem__(0,100)),
 ('extra owner','c',lambda x:x['regions'].append(dict(x['regions'][0],id='rogue'))),
 ('missing owner','c',lambda x:x['regions'].pop()),
 ('duplicate owner','c',lambda x:x['regions'].append(x['regions'][0])),
 ('reordered predecessor','c',lambda x:x['regions'].reverse()),
 ('old source record edited','l',lambda x:x['regions'][0].update(status='rogue')),
 ('global metadata changed','l',lambda x:x.update(rogue=True)),
 ('summary modified','s',lambda x:x.update(regions=277))]:
 d={'l':copy.deepcopy(layout),'c':copy.deepcopy(compiled),'s':copy.deepcopy(summary)};mutate(d[kind]);reject(name,lambda d=d:structures(**d))
reject('prior tolerance weakened',lambda:yes(recovered(guard.replace('var distance: float=0.0001','var distance: float=0.001'))==(B/g).read_text()))
reject('new assertion weakened',lambda:recovered(guard.replace('seen.size()==279 and retained.size()==277','seen.size()>=279 and retained.size()>=277')))
reject('duplicate loader',lambda:yes(undo((C/'scripts/ship.gd').read_text().replace('\tlighting_budget.configure(self,player)','\tload("res://scripts/movement_studio_receiving.gd").build($ShipSpace/Districts,self)\n\tlighting_budget.configure(self,player)'),p['exact_inverse_edits']['scripts/ship.gd'])==(B/'scripts/ship.gd').read_text()))
ids=[r['id']for r in compiled['regions']]
def roster(names):yes(names==ids and len(names)==279 and len(set(names))==279);yes(len([x for x in names if x not in p['added_owner_ids']])==277)
roster(ids)
for name,names in [('unknown runtime owner',ids[:-1]+['rogue']),('missing runtime owner',ids[:-1]),('duplicate runtime owner',ids[:-1]+ids[:1]),('runtime order changed',ids[::-1])]:reject(name,lambda names=names:roster(names))
from gdtoolkit.parser import parser
for row in manifest['files']:
 if row['path'].endswith('.gd'):parser.parse((C/row['path']).read_text())
checks.append('All delivered GDScript grammar parsed, including whole chained successor; not Godot type checking')
# Deterministic recompile and all predecessor/manifest pins still hold.
before={(x['path']):x['sha256'] for x in manifest['files']};r=subprocess.run(['python',str(C/'tools/compile_layout.py')],capture_output=True,text=True);yes(r.returncode==0,r.stderr)
for rel,digest in before.items():yes(sha((C/rel).read_bytes())==digest,'Recompile changed '+rel)
checks.append('Second exact isolated compiler run is deterministic across all union output hashes')
result={'status':'PASS_SOURCE_ONLY','positive_checks':checks,'negative_mutations_rejected':negative,'source_check_count':len(checks),'negative_check_count':len(negative),'engine_run':False,'live_project_modified':False,'limits':['GDScript grammar is not engine type checking.','Fresh import and raw-source/import exact geometry parity are authored fail-closed runtime gates, not executed receipts.','Actual ordinary walking, loaded cart, controls, lighting, visuals and structural bearing acceptance remain pending.'],'proof_sha256':sha((C/rp).read_bytes()),'union_manifest_sha256':sha((W/'UNION_APPLY_MANIFEST.json').read_bytes())}
(W/'SOURCE_VALIDATION.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
