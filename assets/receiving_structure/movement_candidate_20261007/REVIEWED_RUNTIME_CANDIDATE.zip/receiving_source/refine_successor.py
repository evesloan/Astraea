from pathlib import Path
D=Path(__file__).resolve().parent;B=Path('/workspace/shared/Astraea_recovery_20261007_AXWr5x/Game');p=D/'movement_runtime_validator.gd.in';s=p.read_text()
s=s.replace('\tassert(meshes==count and actual.find_children', '\t_movement_validate_import(actual,filename,count)\n\tassert(meshes==count and actual.find_children')
s=s.replace('\t\tassert(lamp.spot_range==float(spec.spot_range) and lamp.spot_angle==float(spec.spot_angle_degrees) and lamp.light_energy==float(spec.spot_energy))','\t\tvar expected_lamp:=SpotLight3D.new()\n\t\texpected_lamp.spot_range=float(spec.spot_range);expected_lamp.spot_angle=float(spec.spot_angle_degrees);expected_lamp.light_energy=float(spec.spot_energy)\n\t\tassert(lamp.spot_range==expected_lamp.spot_range and lamp.spot_angle==expected_lamp.spot_angle and lamp.light_energy==expected_lamp.light_energy)\n\t\texpected_lamp.free()')
old=(B/'tests/medical_triage_successor_guard.gd').read_text();raw=old[old.index('static func _team_lounge_validate_import('):old.index('# TEAM_LOUNGE_EXACT_SECTION_END')]
raw=raw.replace('static func _team_lounge_validate_import(source: Node3D, data: Dictionary, actual: Dictionary) -> void:','static func _movement_validate_import(source: Node3D, filename: String, mesh_count: int) -> void:\n\tvar actual: Dictionary={}\n\tfor node in source.find_children("*","Node3D",true,false):\n\t\tassert(not actual.has(str(node.name)));actual[str(node.name)]=node')
raw=raw.replace('str(data.derivative_file)','"res://assets/models/"+filename').replace('\tassert(document.nodes.size()==4766 and document.meshes.size()==241)','\tassert(document.nodes.size()==actual.size())')
raw=raw.replace('\tassert(source_meshes==241 and source_triangles==494470)','\tassert(source_meshes==mesh_count)\n\tif mesh_count==1290: assert(source_triangles==191456)')
s+='\n'+raw;p.write_text(s)
p=D/'build_successor.py';s=p.read_text();s=s.replace("for rel in paths:current[rel]=sha((C/rel).read_bytes())","for rel in paths:current[rel]=sha((C/rel).read_bytes())\nfor rel in ['scripts/player.gd','scripts/lighting_budget.gd','scripts/static_contact_cache.gd','project.godot']:\n current[rel]=sha((B/rel).read_bytes())")
p.write_text(s)
