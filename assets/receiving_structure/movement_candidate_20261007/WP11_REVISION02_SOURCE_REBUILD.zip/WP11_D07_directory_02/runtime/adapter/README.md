# Portable receiving adapter

After placing the imported section at its declared world placement, call
`load(adapter_folder.path_join("bind_information.gd")).bind(section, manifest)`
with this package's `interaction_candidates.json`. Inspect the returned bound
and rejected IDs. This preserves the existing RMB focus and E information
interaction contract. It implements no cleaning, restocking, inventory,
privilege checks, doors or playback. Staff access remains a receiving gate.

Where included, `flowing_stream_binding.gd` binds only the explicit mesh names
from `water_binding.json` using the adjacent existing-game shader. UV.y travels
downstream at proposed speed0.12. The receiving collision assembly must exclude
decorative water. This is surface animation, not audio or fluid simulation.

The adjacent verification receipt proves isolated final-GLB target/ray and
triangle-occlusion checks. It is not receiving installation, actual input/HUD,
capsule/cart travel, species fit, floor adoption or GPU-performance acceptance.
