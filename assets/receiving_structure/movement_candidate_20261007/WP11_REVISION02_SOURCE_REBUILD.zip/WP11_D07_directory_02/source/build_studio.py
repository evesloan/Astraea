"""Portable Blender4.3.2 source candidate. Heavy execution scheduled by coordinator."""
from pathlib import Path
import bpy,json,math,hashlib
from mathutils import Vector,Matrix
P=Path(__file__).resolve().parents[1]
assert bpy.app.version[:2]==(4,3)
for r in json.loads((P/'assets/intake_manifest.json').read_text(encoding='utf8')):
    if r['file'].startswith('assets/'):assert hashlib.sha256((P/r['file']).read_bytes()).hexdigest()==r['sha256']
for d in ['exports','tests/views']:(P/d).mkdir(parents=True,exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True);S=bpy.context.scene
S.unit_settings.system='METRIC';S.render.engine='CYCLES';S.cycles.samples=24;S.cycles.use_denoising=True
S.render.resolution_x=1280;S.render.resolution_y=720;S.render.resolution_percentage=100
S.world=bpy.data.worlds.new('Bounded ambient');S.world.use_nodes=True;S.world.node_tree.nodes['Background'].inputs['Color'].default_value=(.035,.043,.055,1);S.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.15
S.view_settings.view_transform='AgX';S.view_settings.exposure=-.3
OUT=[];MARKERS=[];LIGHTS=[];INSTANCES=[];CACHE={};TEMPLATES=[];M={};PLACEMENT_AUDIT=[]
def v(x,z,h):return Vector((x-8,-(z+456),h))
def tag(o,role='architecture'):
    o['package']='WP11_D07_directory_02';o['role']=role;OUT.append(o);return o
spec=json.loads((P/'assets/materials/material_manifest.json').read_text())['materials']
for role,r in spec.items():
    m=bpy.data.materials.new('WP11_'+role);m.use_nodes=True;b=m.node_tree.nodes['Principled BSDF'];b.inputs['Roughness'].default_value=r['roughness'];b.inputs['Metallic'].default_value=r['metallic']
    n=m.node_tree.nodes.new('ShaderNodeTexImage');n.image=bpy.data.images.load(str(P/'assets/materials'/r['base_color_file']),check_existing=True);n.image.pack();n.interpolation='Closest';m.node_tree.links.new(n.outputs['Color'],b.inputs['Base Color']);M[role]=m
def tint(new,base,rgb):
    m=M[base].copy();m.name='WP11_'+new;b=m.node_tree.nodes['Principled BSDF'];src=b.inputs['Base Color'].links[0].from_socket;n=m.node_tree.nodes.new('ShaderNodeMixRGB');n.blend_type='MULTIPLY';n.inputs[0].default_value=1;n.inputs[2].default_value=(*rgb,1);m.node_tree.links.new(src,n.inputs[1]);m.node_tree.links.new(n.outputs[0],b.inputs['Base Color']);M[new]=m
tint('sage','ivory_enamel',(.39,.58,.50));tint('deep_teal','ivory_enamel',(.11,.25,.24));tint('quiet_stone','warm_stone',(.55,.58,.53));tint('walnut','warm_walnut',(.65,.66,.62))
for name,c,em in [('warm_glow',(1,.73,.40),3),('task_glow',(.8,.9,1),3),('letter',(.88,.82,.63),0)]:
    m=bpy.data.materials.new('WP11_'+name);m.use_nodes=True;b=m.node_tree.nodes['Principled BSDF'];b.inputs['Base Color'].default_value=(*c,1);b.inputs['Emission Color'].default_value=(*c,1);b.inputs['Emission Strength'].default_value=em;M[name]=m
def uv(o):
    layer=o.data.uv_layers.new(name='UVMap')
    for f in o.data.polygons:
        axes=sorted(range(3),key=lambda i:abs(f.normal[i]))[:2]
        for j in f.loop_indices:
            q=o.data.vertices[o.data.loops[j].vertex_index].co;layer.data[j].uv=(q[axes[0]],q[axes[1]])
def box(name,x,z,h,w,d,t,mat='ivory_enamel',role='architecture',bevel=.025):
    verts=[(a*w/2,b*d/2,c*t/2) for a,b,c in [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),(-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]]
    me=bpy.data.meshes.new(name);me.from_pydata(verts,[],[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]);me.update()
    o=bpy.data.objects.new(name,me);S.collection.objects.link(o);o.location=v(x,z,h);me.materials.append(M[mat]);uv(o)
    if bevel:
        b=o.modifiers.new('Eased join','BEVEL');b.width=min(bevel,min(w,d,t)/4);b.segments=2;o.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
    return tag(o,role)
def rod(name,a,b,r,mat='champagne_metal'):
    a,b=Vector(a),Vector(b);delta=b-a;n=12
    pts=[(r*math.cos(2*math.pi*i/n),r*math.sin(2*math.pi*i/n),h) for h in [-delta.length/2,delta.length/2] for i in range(n)]
    faces=[tuple(reversed(range(n))),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    me=bpy.data.meshes.new(name);me.from_pydata(pts,[],faces);me.update();o=bpy.data.objects.new(name,me);S.collection.objects.link(o);o.location=(a+b)/2;o.rotation_euler=delta.to_track_quat('Z','Y').to_euler();me.materials.append(M[mat]);uv(o);return tag(o,'supported_detail')

def mark(name,x,z,h,kind):
    o=bpy.data.objects.new(name,None);S.collection.objects.link(o);o.location=v(x,z,h);o['meaning']=kind;tag(o,'marker');MARKERS.append({'name':name,'world':[x,35.5+h,z],'kind':kind})
def sign(name,text,x,z,h,width=3,size=.22):
    box(name+'_board',x,z,h,.14,width,.7,'deep_teal')
    c=bpy.data.curves.new(name,'FONT');c.body=text;c.size=size;c.align_x='CENTER';c.extrude=.005;o=bpy.data.objects.new(name,c);S.collection.objects.link(o);o.location=v(x-.08,z,h-.08);o.rotation_euler=(math.pi/2,0,-math.pi/2);o.data.materials.append(M['letter']);tag(o,'mounted_sign')
    for zz in [z-width/2+.12,z+width/2-.12]:rod(name+'_fastener',v(x-.09,zz,h+.2),v(x+.15,zz,h+.2),.03)
def cache(ident):
    if ident in CACHE:return CACHE[ident]
    with bpy.data.libraries.load(str(P/'assets/native'/f'{ident}.blend'),link=False) as (a,b):b.objects=a.objects
    allobs=[o for o in b.objects if o]
    for o in allobs:S.collection.objects.link(o)
    bpy.context.view_layer.update();chosen=[o for o in allobs if o.type in ['MESH','EMPTY'] and not o.name.startswith('EXPORT_')]
    deps=bpy.context.evaluated_depsgraph_get()
    matrices={o:o.evaluated_get(deps).matrix_world.copy() for o in chosen}
    assert not any(o.constraints for o in chosen),('Native constraint target remapping requires review',ident)
    CACHE[ident]=(chosen,matrices);TEMPLATES.extend(allobs)
    for o in allobs:o.hide_render=True;o.hide_set(True)
    return CACHE[ident]
def reuse(ident,name,x,z,h=0,yaw=0):
    originals,mats=cache(ident);copies={};trans=Matrix.Translation(v(x,z,h))@Matrix.Rotation(yaw,4,'Z')
    for src in originals:
        o=src.copy();o.data=src.data;S.collection.objects.link(o);o.name=name+'__'+src.name;o.hide_render=False;o.hide_set(False);copies[src]=o
    # Assign explicit parent-relative transforms. Setting world matrices while the
    # copied parents are still stale adds placement again at each hierarchy level.
    for src,o in copies.items():
        o.parent=copies.get(src.parent);o.matrix_parent_inverse=Matrix.Identity(4)
        o.delta_location=(0,0,0);o.delta_rotation_euler=(0,0,0)
        o.delta_rotation_quaternion=(1,0,0,0);o.delta_scale=(1,1,1)
        o.matrix_basis=(mats[src.parent].inverted()@mats[src]) if src.parent in copies else trans@mats[src]
        o['parent_catalogue_id']=ident;tag(o,'reused_component')
    bpy.context.view_layer.update();deps=bpy.context.evaluated_depsgraph_get();failures=[];max_error=0.0
    for src,o in copies.items():
        expected=trans@mats[src];actual=o.evaluated_get(deps).matrix_world
        error=max(abs(actual[i][j]-expected[i][j]) for i in range(4) for j in range(4));max_error=max(max_error,error)
        if error>0.0001:failures.append({'name':o.name,'matrix_max_error':error})
    PLACEMENT_AUDIT.append({'instance':name,'source_id':ident,'object_count':len(copies),'maximum_matrix_error':max_error,'failures':failures})
    (P/'tests/native_placement_parity.json').write_text(json.dumps(PLACEMENT_AUDIT,indent=2))
    assert not failures,('Native hierarchy placement parity failed',name,'count',len(failures),'first10',failures[:10])
    INSTANCES.append({'name':name,'source_id':ident,'world_datum':[x,35.5+h,z],'cached_once':True,'shared_mesh_data':True,'placement_matrix_max_error':max_error})
    return copies
def light(name,x,z,mount,low,warm=True,power=800):
    box(name+'_plate',x,z,mount-.04,.42,.42,.08,'champagne_metal');rod(name+'_stem',v(x,z,mount),v(x,z,low+.12),.04)
    box(name+'_housing',x,z,low+.08,1.75,.38,.16,'champagne_metal');box(name+'_emitter',x,z,low-.01,1.6,.29,.02,'warm_glow' if warm else 'task_glow',role='emitter')
    d=bpy.data.lights.new(name,'AREA');d.energy=power;d.shape='RECTANGLE';d.size=1.6;d.size_y=.25;d.color=(1,.8,.56) if warm else (.83,.92,1)
    o=bpy.data.objects.new(name,d);S.collection.objects.link(o);o.location=v(x,z,low-.045);LIGHTS.append({'id':name,'world':[x,35.5+low-.045,z],'mount_y':35.5+mount,'power_w':power,'type':'AREA','runtime_adaptation_required':True})

# Exact package floor remains receiving-owned; these surfaces exist only in source previews.
preview=box('SOURCE_PREVIEW_ONLY_floor',31,-432,-.12,46,68,.24,'quiet_stone','SOURCE_PREVIEW_ONLY');OUT.remove(preview)
practice=box('SOURCE_PREVIEW_ONLY_practice_finish',33,-427.5,.004,20,43,.004,'warm_walnut','SOURCE_PREVIEW_ONLY',0);OUT.remove(practice)
mark('floor_datum',8,-456,0,'receiving-owned finished floor');mark('public_portal',8,-456,0,'proposed aperture; exterior4m link excluded')
for z in [-465.8,-398.2]:box('Opaque_end_'+str(z),31,z,3.87,46,.4,7.74,'sage')
box('Opaque_starboard',53.8,-432,3.87,.4,67.2,7.74,'ivory_enamel')
for z,d in [(-463,5.6),(-427,57.6)]:box('Inward_boundary_'+str(z),8.2,z,3.87,.4,d,7.74,'ivory_enamel')
box('Opaque_roof_cap',31,-432,7.79,46,68,.12,'ivory_enamel')
box('Entry_header',8.45,-456,5.6,.9,8.4,4,'ivory_enamel');sign('Entry_title','SUNCORP / MOVEMENT STUDIO',8.5,-456,4.5,7,.30)
for z in [-460.2,-451.8]:box('Deep_entry_return_'+str(z),10,z,2.25,4,.4,4.5,'quiet_stone')
box('Entry_coffer',15.3,-456,4.6,13.6,8.4,.3,'walnut')
for x in [10,21]:
    for z in [-460.1,-451.9]:box('Entry_bearing',x,z,2.22,.55,.55,4.44,'ivory_enamel')
reuse('AST-SAL-001','Niche_threshold_return',18.7,-442.5,0,math.pi/2)

# Folded, materially lined main roof; ribs are full-depth structural members at perimeter piers.
def roof(name,z0,z1,thick=.20,mat='walnut'):
    profile=[(23.3,6.25),(27,7.0),(33,7.55),(39,7.0),(43.3,6.25)];verts=[]
    for z in [z0,z1]:
        for x,h in profile:verts.extend([tuple(v(x,z,h)),tuple(v(x,z,h+thick))])
    faces=[];n=10
    for i in range(4):
        a=2*i;b=a+2;faces.extend([(a,b,b+n,a+n),(a+1,a+n+1,b+n+1,b+1),(a,a+1,b+1,b),(a+n,b+n,b+n+1,a+n+1)])
    faces.extend([(0,10,11,1),(8,9,19,18)]);me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new(name,me);S.collection.objects.link(o);me.materials.append(M[mat]);uv(o);tag(o,'supported_ceiling')
roof('Main_folded_soffit',-451,-403)
for z in [-450,-442,-434,-426,-418,-410,-403.5]:
    roof('Visible_roof_rib_'+str(z),z-.2,z+.2,.29,'ivory_enamel')
    for x in [23.5,43.1]:
        box('Practice_edge_pier_'+str((x,z)),x,z,3.15,.48,.64,6.3,'ivory_enamel')
        box('Pier_foot_'+str((x,z)),x,z,.16,.64,.8,.32,'champagne_metal')
for x,h in [(28,7.07),(38,7.06)]:
    box('Main_light_bearing_'+str(x),x,-427, h,.24,47,.2,'champagne_metal')
    for z in [-446,-438,-430,-422,-414,-406]:light('Practice_lamp_'+str((x,z)),x,z,h,5.72,True,1000)

# Sheltered side niches have supported lower roofs, return walls, mounted practice bars and mats.
for i,zc in enumerate([-442.5,-427.5,-412.5],1):
    box('Niche_roof_'+str(i),13.7,zc,4.32,10.6,9.4,.32,'walnut')
    for z in [zc-4.5,zc+4.5]:
        box('Niche_return_'+str((i,z)),12,z,2,7.2,.3,4,'sage')
        box('Niche_front_post_'+str((i,z)),18.6,z,2.13,.46,.6,4.26,'ivory_enamel')
        box('Niche_front_beam_'+str((i,z)),13.65,z,4.05,10.35,.42,.25,'champagne_metal')
    for h in [.88,1.16]:
        rod('Practice_bar_'+str((i,h)),v(9.13,zc-3.3,h),v(9.13,zc+3.3,h),.055,'warm_walnut')
        for z in [zc-3,zc,zc+3]:rod('Bar_wall_bracket_'+str((i,h,z)),v(8.4,z,h),v(9.13,z,h),.035)
    for z in [zc-2,zc+2]:box('Niche_mat_'+str((i,z)),14.2,z,.025,2.6,1.4,.05,'teal_weave','practice_mat',.08)
    box('Niche_sign_mount_'+str(i),18.6,zc-4.4,2.8,.65,.3,1.0,'ivory_enamel')
    sign('Niche_sign_'+str(i),'PRACTICE '+str(i),18.3,zc-4.4,2.8,2,.20)
    light('Niche_lamp_'+str(i),14,zc,4.15,3.45,True,650)

# Principal free practice area: a composed mat group at its aft end leaves a large open movement zone.
for x in [27,32,37]:
    for z in [-424,-418,-412]:box('Practice_mat_'+str((x,z)),x,z,.025,2.8,1.5,.05,'clay_weave','practice_mat',.08)
for z in [-448,-407]:
    box('Practice_identity_wall_'+str(z),40.8,z,2.0,.25,3.8,2.8,'deep_teal')
    sign('Practice_identity_'+str(z),'MOVE / REST / RETURN',40.6,z,2.25,3.5,.21)
    box('Identity_wall_foot',40.8,z,.12,.7,4,.24,'quiet_stone')

# Rest furniture is the verified native family, placed with real mesh transforms and separate approaches.
for name,x,z,yaw in [('arrivalA',13,-462.5,0),('arrivalB',18,-462.5,0),('orientationA',28,-462.5,0),('orientationB',35,-462.5,0),('orientationC',42,-462.5,0),('aftA',13,-400.5,0),('aftB',18,-400.5,0),('aftC',29,-400.5,0),('aftD',35,-400.5,0)]:
    aft=name.startswith('aft');yaw=math.pi if aft else yaw
    reuse('AST-FUR-001','Rest_bench_'+name,x,z,0,yaw);reuse('AST-FUR-003','Rest_table_'+name,x+(1.85 if aft else 0),z+(-.15 if aft else 1.4),0,yaw);mark('Seat_'+name,x,z,.5,'seat region; actual actor fit pending')
box('Orientation_coffer',37,-458.5,4.8,30,13,.3,'walnut')
for x in [23,43,51.8]:
    for z in [-464.7,-452.4]:box('Orientation_pier_'+str((x,z)),x,z,2.34,.55,.55,4.68,'ivory_enamel')
for x in [28,38,49]:light('Orientation_lamp_'+str(x),x,-458,4.63,3.7,True,700)
reuse('AST-STF-007','Equipment_checkin_cabinet',50.2,-459,0,-math.pi/2)
box('Checkin_backboard_support',52.9,-459,1.8,.3,4.8,3.6,'sage')
sign('Checkin_board','EQUIPMENT / RETURN',52.66,-459,2.7,4.5,.25)
box('Aft_shelter_roof',25,-400.4,4.35,33,3.5,.3,'walnut')
for x in [10,21,32,40]:box('Aft_shelter_pier_'+str(x),x,-399.2,2.14,.5,.5,4.28,'ivory_enamel')
for x in [14,25,36]:light('Rest_light_'+str(x),x,-400.5,4.19,3.45,True,650)

# Separate screened equipment/care side. Internal service links stay inside X43.5..47.
box('Service_ceiling',48.5,-426,4.75,10.2,53,.3,'ivory_enamel')
for z in [-450,-438,-426,-414,-400]:
    box('Service_bearing_beam_'+str(z),48.4,z,4.52,10.5,.3,.32,'champagne_metal')
    for x in [43.2,53.0]:box('Service_bearing_post_'+str((x,z)),x,z,2.2,.35,.4,4.4,'ivory_enamel')
for za,zb in [(-452,-443),(-439,-425),(-421,-408),(-404,-398.4)]:box('Screened_support_wall_'+str(za),47.25,(za+zb)/2,2.1,.3,zb-za,4.2,'sage')
for z in [-434,-418]:box('Support_room_divider_'+str(z),50.4,z,2.1,6.4,.25,4.2,'ivory_enamel')
for z,title in [(-441,'EQUIPMENT'),(-423,'CARE / STOCK'),(-406,'RETURNS')]:
    box('Service_portal_lintel_'+title,47.25,z,3.5,.4,4.1,1.4,'ivory_enamel');sign('Support_sign_'+title,title,46.98,z,3.1,3.8,.23)
for z in [-429,-426,-423]:reuse('AST-STF-007','Care_cabinet_'+str(z),51.8,z,0,-math.pi/2)
for z in [-447,-440,-413,-409]:
    for h in [.2,1.05,1.9]:box('Equipment_shelf_'+str((z,h)),51.8,z,h,2.4,3.3,.12,'walnut')
    for zz in [z-1.5,z+1.5]:box('Shelf_standard_'+str((z,zz)),52.8,zz,1.25,.14,.14,2.5,'champagne_metal')
    for i in range(5):
        zz=z-1.2+i*.6
        rod('Rolled_mat_'+str((z,i)),v(51,zz,1.30),v(52.4,zz,1.30),.19,'teal_weave')
        box('Equipment_block_'+str((z,i)),51.6,zz,.51,.6,.43,.5,'clay_weave',role='equipment')
for x in [45.3,50.6]:
    box('Service_light_bearing_'+str(x),x,-426,4.58,.2,52,.16,'champagne_metal')
    for z in [-448,-436,-424,-412,-402]:light('Service_lamp_'+str((x,z)),x,z,4.5,3.7,False,650)
mark('Sealed_external_service',53.5,-406,1.5,'sealed future service link; no opening')

exec(compile((P/'source/revision02_details.py').read_text(),str(P/'source/revision02_details.py'),'exec'))

CAMERAS={'entry':([12,-456,1.65],[30,-435,2.4]),'practice':([25,-446,1.65],[36,-415,2.8]),'niche':([21,-441,1.65],[12,-442,1.2]),'rest':([30,-407,1.65],[28,-400.5,1.7]),'care':([45.3,-423,1.65],[51.8,-426,1.2]),'ceiling':([25,-439,1.65],[33,-429,7]),'section':([4,-475,18],[31,-432,2])}
CAMERAS.update({'bar_detail':([11.5,-441,1.65],[9.0,-442,1.1]),'care_detail':([50.0,-426.3,1.65],[51.8,-425.6,.7]),'rest_detail':([14.5,-403.5,1.65],[14.2,-400.3,1.4])})
for name,(a,b) in CAMERAS.items():
    c=bpy.data.cameras.new('SOURCE_ONLY_'+name);o=bpy.data.objects.new(c.name,c);S.collection.objects.link(o);o.location=v(*a);o.rotation_euler=(v(*b)-o.location).to_track_quat('-Z','Y').to_euler();c.lens=24;c.clip_end=250
    if name=='section':c.type='ORTHO';c.ortho_scale=86
S.camera=bpy.data.objects['SOURCE_ONLY_entry']
for o in TEMPLATES:bpy.data.objects.remove(o,do_unlink=True)
root=bpy.data.objects.new('WP11_PLACEMENT_ROOT',None);S.collection.objects.link(root)
for o in list(OUT):
    if o.parent is None:o.parent=root
tag(root,'placement_root')
bpy.context.view_layer.update();deps=bpy.context.evaluated_depsgraph_get();bounds=[];errors=[]
for o in OUT:
    if o.type not in ['MESH','FONT','CURVE']:continue
    ev=o.evaluated_get(deps);me=ev.to_mesh();points=[ev.matrix_world@p.co for p in me.vertices]
    if points:
        lo=[min(q[i] for q in points) for i in range(3)];hi=[max(q[i] for q in points) for i in range(3)];bounds.append({'name':o.name,'min':lo,'max':hi,'role':o.get('role'),'vertices':len(points)})
        if lo[0]<-.005 or hi[0]>46.005 or lo[1]<-58.005 or hi[1]>10.005 or lo[2]<-.005 or hi[2]>7.855:errors.append(o.name)
    ev.to_mesh_clear()
(P/'tests/source_geometry.json').write_text(json.dumps({'source_only':True,'mesh_count':len(bounds),'out_of_bounds':errors,'bounds':bounds},indent=2))
assert not errors,('Evaluated bounds failed','count',len(errors),'first10',errors[:10],'full_receipt','tests/source_geometry.json')
for im in bpy.data.images:
    if im.source=='FILE' and im.has_data:im.pack()
# Keep authored FONT/CURVE editable in native. Convert exchange copies only after saving.
bpy.ops.wm.save_as_mainfile(filepath=str(P/'source/WP11_movement_studio.blend'),compress=True)
export_names=[o.name for o in OUT];font_names=[o.name for o in OUT if o.type=='FONT']
for name in export_names:
    o=bpy.data.objects[name]
    if o.type in ['FONT','CURVE']:
        bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o;bpy.ops.object.convert(target='MESH');uv(bpy.context.object)
bpy.ops.object.select_all(action='DESELECT')
for name in export_names:bpy.data.objects[name].select_set(True)
bpy.ops.export_scene.gltf(filepath=str(P/'exports/WP11_movement_studio.glb'),export_format='GLB',use_selection=True,export_apply=True,export_yup=True,export_extras=True,export_cameras=False,export_lights=False)
# Independent binary node census: every native FONT name must resolve to a nonempty exported mesh.
import struct
raw=(P/'exports/WP11_movement_studio.glb').read_bytes();length,kind=struct.unpack_from('<II',raw,12);g=json.loads(raw[20:20+length]);found={n.get('name'):n for n in g['nodes']}
missing=[]
for name in font_names:
    n=found.get(name)
    if not n or 'mesh' not in n or not any(g['accessors'][p['attributes']['POSITION']]['count']>0 for p in g['meshes'][n['mesh']]['primitives']):missing.append(name)
assert not missing,('GLB omitted authored text',missing)
(P/'tests/sign_export_parity.json').write_text(json.dumps({'native_font_names':font_names,'missing_or_empty_glb_meshes':missing,'status':'pass','source_saved_before_conversion':True},indent=2))
for name,obj in [('lights',LIGHTS),('contacts',MARKERS),('instances',INSTANCES)]: (P/'docs'/f'{name}.json').write_text(json.dumps(obj,indent=2))
manifest={'package':'WP11_D07_directory_02','programme':'D07_directory_02','status':'source candidate, unreviewed','units':'m','origin_world':[8,35.5,-456],'source_to_glb':'x,y,z -> x,z,-y','placement_translation':[8,35.5,-456],'rotation':'identity','floor':{'included_in_glb':False,'top_y':35.5,'polygon_xz':[[8,-466],[54,-466],[54,-398],[8,-398]],'owner':'receiving parent','preview_finish_roles':['quiet_stone','warm_walnut']},'external_4m_link':'excluded unbuilt parent-owned','light_delivery':'physical mounted fixtures exported; effective AREA source emitters provided separately for receiving adaptation','source_sha256':hashlib.sha256((P/'source/WP11_movement_studio.blend').read_bytes()).hexdigest(),'glb_sha256':hashlib.sha256((P/'exports/WP11_movement_studio.glb').read_bytes()).hexdigest(),'cached_native_families':list(CACHE),'mesh_count':len(bounds)}
(P/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print('WP11_SOURCE_BUILT',len(bounds))
