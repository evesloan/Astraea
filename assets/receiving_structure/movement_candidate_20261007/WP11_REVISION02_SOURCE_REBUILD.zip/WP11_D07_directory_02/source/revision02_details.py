"""Purposeful occupied edges; main practice floor and all deck interfaces unchanged."""
def prism(name,points,lo,hi,mat):
    n=len(points);verts=[tuple(v(x,z,h)) for h in [lo,hi] for x,z in points]
    faces=[tuple(reversed(range(n))),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update();import bmesh;bm=bmesh.new();bm.from_mesh(me);bmesh.ops.recalc_face_normals(bm,faces=bm.faces);bm.to_mesh(me);bm.free();o=bpy.data.objects.new(name,me);S.collection.objects.link(o);me.materials.append(M[mat]);uv(o);return tag(o,'authored_supported_edge')

def label(name,body,x,z,h,size=.07):
    c=bpy.data.curves.new(name,'FONT');c.body=body;c.size=size;c.align_x='CENTER';c.extrude=.001
    o=bpy.data.objects.new(name,c);S.collection.objects.link(o);o.location=v(x,z,h);o.rotation_euler=(math.pi/2,0,-math.pi/2);c.materials.append(M['letter']);return tag(o,'mounted_sign')

# Aft backs become a supported nested repose edge, facing the open studio.
# No occupied raised floor or decorative stair is introduced.
for n,xa,xb in [('west',9.0,21.6),('east',23.5,40.0)]:
    poly=[(xa,-398.42),(xb,-398.42),(xb,-399.0),(xb-.65,-399.28),(xa+.65,-399.28),(xa,-399.0)]
    prism('Rest_weighted_base_'+n,poly,0,.32,'quiet_stone')
    prism('Rest_coping_'+n,poly,.32,.40,'warm_stone')
    box('Rest_backing_'+n,(xa+xb)/2,-398.70,1.31,xb-xa-.65,.48,1.82,'walnut')
    box('Rest_touch_panel_'+n,(xa+xb)/2,-398.963,1.43,xb-xa-1.1,.045,1.28,'teal_weave',bevel=.018)
    for x in [xa+.2,xb-.2]:
        box('Rest_end_standard_'+str((n,x)),x,-398.95,2.15,.4,.68,4.3,'quiet_stone')
        box('Rest_end_cap_'+str((n,x)),x,-398.95,4.28,.58,.8,.12,'champagne_metal')
    box('Rest_shadow_return_'+n,(xa+xb)/2,-398.78,2.26,xb-xa-.7,.58,.16,'warm_stone')

# Deep lined niche ends and real bar attachment plates. Keep all mat approaches clear.
for i,zc in enumerate([-442.5,-427.5,-412.5],1):
    for zz in [zc-4.5,zc+4.5]:
        signside=1 if zz<zc else -1
        box('Niche_wear_base_'+str((i,zz)),12,zz+signside*.17,.24,7.2,.10,.48,'quiet_stone')
        box('Niche_lined_return_'+str((i,zz)),12,zz+signside*.175,2.0,6.6,.055,2.9,'walnut')
        box('Niche_soft_inset_'+str((i,zz)),12,zz+signside*.208,2.16,5.8,.035,2.15,'teal_weave')
        box('Niche_return_head_'+str((i,zz)),12,zz,3.97,7.4,.43,.16,'warm_stone')
        # Three flutes are actual recessed-facing ribs at the substantial end post.
        for off in [-.12,0,.12]:box('Niche_pier_face_'+str((i,zz,off)),18.845,zz+off,2.07,.025,.055,3.35,'champagne_metal',bevel=.008)
    for zz in [zc-3,zc,zc+3]:
        box('Bar_bearing_plate_'+str((i,zz)),8.48,zz,1.02,.16,.24,.62,'quiet_stone')
        for h in [.88,1.16]:
            rod('Bar_brace_'+str((i,zz,h)),v(8.57,zz,h-.17),v(8.99,zz,h),.025)
            rod('Bar_fastener_'+str((i,zz,h)),v(8.55,zz,h+.045),v(8.595,zz,h+.045),.027)
    # Shallow equipment-end cabinet occupies the wall return, not the exercise stance.
    zz=zc+3.82
    box('Niche_block_bin_base_'+str(i),12.1,zz,.18,2.9,.7,.36,'walnut')
    for x in [10.7,13.5]:box('Niche_block_bin_end_'+str((i,x)),x,zz,.68,.12,.7,.64,'walnut')
    box('Niche_block_bin_back_'+str(i),12.1,zz+.31,.68,2.68,.08,.64,'walnut')
    for x in [11.0,11.65,12.3,12.95]:box('Niche_supported_block_'+str((i,x)),x,zz,.58,.5,.48,.44,'clay_weave','equipment')

# Evaluated folded-deck contact planes are .170/.509m; .192/.525 are raised rim bounds.
# Positive native X is the open bay; yaw -pi/2 maps it to world +Z.
STOCK_SUPPORT=[]
for idx,z in enumerate([-429,-426,-423],1):
    for j,zz in enumerate([z+.20,z+.52]):
        bottom=.509
        if idx!=2:
            box('Care_bottle_'+str((idx,j)),51.76,zz,bottom+.125,.20,.20,.25,'deep_teal','care_stock',.035)
            box('Care_bottle_shoulder_'+str((idx,j)),51.76,zz,bottom+.265,.14,.14,.04,'deep_teal','care_stock',.018)
            box('Care_bottle_cap_'+str((idx,j)),51.76,zz,bottom+.299,.085,.085,.028,'champagne_metal','care_stock',.012)
            box('Care_bottle_label_'+str((idx,j)),51.654,zz,bottom+.125,.008,.16,.10,'quiet_stone','care_stock',.003)
            label('Care_bottle_text_'+str((idx,j)),'CARE',51.647,zz,bottom+.105,.035)
        else:
            for k in range(3):box('Care_folded_cloth_'+str((j,k)),51.76,zz,bottom+.022+k*.044,.28,.25,.044,'ivory_enamel','care_stock',.018)
        STOCK_SUPPORT.append({'stock_group':[idx,j],'source_support':'SHELF_open_folded_mid_deck','bottom_m':bottom,'cabinet_world':[51.8,35.5,z],'open_bay_offset_z':zz-z})
    box('Care_pad_pack_'+str(idx),51.76,z+.36,.170+.13,.30,.50,.26,'sage','care_stock',.025)
    label('Care_pad_text_'+str(idx),'PADS',51.601,z+.36,.283,.064)
    # Fitted wall return, protected toe and secured washable panels behind each station.
    box('Care_wall_panel_'+str(idx),53.53,z,1.70,.13,2.65,2.9,'quiet_stone')
    for zz in [z-1.16,z+1.16]:
        for h in [.45,2.8]:rod('Care_panel_fixing_'+str((idx,zz,h)),v(53.43,zz,h),v(53.48,zz,h),.026)

# Discreet truthful information, physically mounted and distinct from inactive handles.
box('StudioInfoPost',49.7,-461.5,.70,.14,.14,1.4,'quiet_stone')
box('StudioInfoFoot',49.7,-461.5,.07,.42,.42,.14,'quiet_stone')
box('StudioInfoPlaque',49.7,-461.5,1.58,.12,1.12,.40,'deep_teal')
label('StudioInfoText','SUNCORP / MOVEMENT',49.633,-461.5,1.57,.067)
box('CareInfoRiser',52.045,-426,1.255,.08,.80,.630,'quiet_stone')
box('CareInfoPlaque',51.992,-426,1.43,.025,.72,.25,'deep_teal')
label('CareInfoText','CARE / CLOTHS / PADS',51.974,-426,1.40,.044)
(P/'runtime').mkdir(exist_ok=True)
candidates=[{'id':'WP11_info_studio_01','visual_node':'StudioInfoPlaque','action':'read_information','label':'Read studio information','information':'SunCorp Movement Studio. Open practice floor, sheltered stretching niches and resting seats. Equipment returns are beside the entrance.','focus_world_m':[49.63,37.08,-461.5],'approach_feet_world_m':[47.8,35.5,-461.5],'target_size_m':[.035,.30,.90],'access':'public','status':'proposed; source and receiving validation pending'},
{'id':'WP11_info_care_01','visual_node':'CareInfoPlaque','action':'read_information','label':'Read care stock information','information':'Care stock: cloths and pads on the open shelves. Leave the cabinet worktop and the clear approach available for preparation.','focus_world_m':[51.97,36.93,-426],'approach_feet_world_m':[50.05,35.5,-426],'target_size_m':[.025,.18,.61],'access':'staff','status':'proposed; source and receiving validation pending'}]
(P/'runtime/interaction_candidates.json').write_text(json.dumps({'schema':1,'status':'isolated receiving proposal; no live edits','coordinate_space':'Godot world metres after declared package placement','candidates':candidates},indent=2))
(P/'tests/revision02_stock_support_intent.json').write_text(json.dumps(STOCK_SUPPORT,indent=2))
