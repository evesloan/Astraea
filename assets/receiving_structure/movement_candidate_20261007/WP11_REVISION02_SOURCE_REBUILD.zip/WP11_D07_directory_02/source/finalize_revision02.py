"""Run only after owner has inspected all final actual views; root approval stays pending."""
from pathlib import Path
import json,hashlib,datetime
P=Path(__file__).resolve().parents[1];cfg=json.loads((P/'docs/revision02_finalization_config.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pins={'native':sha(P/cfg['native']),'glb':sha(P/cfg['glb'])}
checks=[]
for file in cfg['qa']:
 p=P/file;r=json.loads(p.read_text());assert r.get('passed',r.get('pass',r.get('status')=='pass')) is True,file
 if 'pins'in r:assert r['pins']==pins,file
 if 'source_sha256'in r:assert r['source_sha256']==pins['native'] and r['glb_sha256']==pins['glb'],file
 if 'sha256'in r:assert r['sha256']==pins['glb'],file
 checks.append({'path':file,'sha256':sha(p)})
views=[]
if P.name.startswith('WP11'):
 for name in cfg['views']:
  r=json.loads((P/'tests/views'/f'{name}_receipt.json').read_text());assert r['source_sha256']==pins['native'] and not r['section_roof_removed'];im=P/'tests/views'/f'SOURCE_ONLY_{name}.png';assert sha(im)==r['image_sha256'];views.append({'name':name,'path':str(im.relative_to(P)),'sha256':sha(im),'camera_receipt':r})
else:
 r=json.loads((P/'qa'/('revision02_render_'+cfg['views'][0]+'.json')).read_text());assert r['pins']==pins and len(r['views'])==len(cfg['views'])
 for view in r['views']:
  name=view['view'];im=P/'renders'/((name+'_source_only.png') if P.name.startswith('WP09') else ('source_'+name+'.png'));assert sha(im)==view['image_sha256'];views.append(dict(view,path=str(im.relative_to(P))))
findings=[{'id':k,'disposition':'Source correction demonstrated; independent root closure pending','change':v,'evidence':'Exact final native/export and bound final source views/checks in this receipt; receiving limits below'} for k,v in cfg['changes'].items()]
limits=['Source candidate only; independent root review and Higgins receiving/live adoption remain pending.','Actual native route samples are bounded source checks, not installed collision/cart/species pose, acoustic or engineering certification.','Preview floor excluded; receiving parent owns floor/slab and external4m approach.','No internal-edge exterior window or skylight invented. Genuine outward observation connection remains held for current hull/frontage/services reconciliation.','Named small visible information targets are proposed. Actual engine binding/input/reach/occlusion and target performance remain receiving gates.']
if P.name.startswith('WP11'):limits.append('Native effective AREA lights require receiving adaptation; physical mounted fixtures export, no GLB light equivalence claim.')
if P.name.startswith('WP09'):limits.append('Higgins repaired predecessor is attributed in retained receipt only; no local repairedGLB bytes, conversion-script recovery or remote byte equivalence claim.')
receipt={'package':P.name,'revision':'02','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'source candidate ready for independent root review','root_accepted':False,'live_accepted':False,'pins':pins,'placement_translation':cfg['placement'],'checks':checks,'findings':findings,'final_views':views,'owner_visual_review':'All listed final actual ordinary-eye views inspected; no hidden architecture or camera-only material/light adjustments.','reference_study_sha256':sha(P/'docs/reference_library/REFERENCE_STUDY.json'),'receiving_limits':limits}
(P/'docs/REVISION02_CORRECTION_RECEIPT.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
body='# '+P.name+' — revision02\n\nFitted isolated source candidate ready for independent root review. Not installed or live accepted. Original shipments remain frozen.\n\n'+ '\n\n'.join(cfg['changes'].values())+'\n\nExact artifacts: '+cfg['native']+' and '+cfg['glb']+'. Placement translation '+str(cfg['placement'])+', identity rotation/unit scale. Editable native text and packed assets remain; exchange uses actual mesh lettering and UV. Preview floor is excluded.\n\nUse docs/REVISION02_RUNBOOK.md for serialized Blender4.3.2 CPU12/exit-code1 reproduction. docs/REVISION02_CORRECTION_RECEIPT.json binds final native/export/check/image hashes and each prior finding. docs/EXPERIENCE_BRIEF.md and docs/reference_library retain current design and exact reference applications. Proposed fitted information targets are under runtime/.\n\n'+'\n\n'.join(limits)+'\n'
(P/'README.md').write_text(body,encoding='utf-8');print('REVISION02_FINAL_RECEIPT_READY',P.name,pins)
