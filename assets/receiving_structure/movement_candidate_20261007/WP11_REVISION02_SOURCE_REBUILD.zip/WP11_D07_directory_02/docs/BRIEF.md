# WP11 Movement studio — proposed complete section

Dedicated owner: section_owner_04, dispatched by the coordinator after WP09 handoff. Only WP11_D07_directory_02 is writable. Current owner confirmation in the pinned intake supersedes the earlier conditional Downloads handoff. Source-only work; no GLB build/render has yet run.

Programme D07_directory_02 occupies X8…54, Z−466…−398 at Y35.5. Next datum44 gives8.5m total datum difference, not a certified ceiling. Portal [8,35.5,−456] avoids protected core shells. Its exterior X4…8 connection is unbuilt and receiving-parent-owned. Below: WP03 Cloud conservatory D06/Y27; above: D08 Tidal thermal baths/Y44; across the axis: Orbit Court and its pool bearing ownership. No exterior windows, slab cuts, overhead plant penetrations, new capacity, gravity simulator or scored activity.

Complete chapters4,5,7,19,21,30,32 and current overlays read. Relevant blocks123 (datums),133–145 (spatial hierarchy/routes),165–173 (care),334–343 (recreation scope),365–380 (architectural craft/light),506–541 (references),556–571 (protected architecture). Historical implemented claims remain historical. Existing six species canon and later admission/luxury decisions remain untouched; proposed furnishing heights are not universal-body acceptance.

Actual atlas page9 was rendered and inspected: directory02 is a distinct starboard fore studio, separate from Court01. The public-sheet sports row, printedD08, shows activity areas with perimeter circulation and adjacent support; canonical D07/Y35.5 controls. No printed activity capacity is imported. The retro benchmark was opened: substantial supporting piers, deep thresholds, warm materials and integrated visible lighting apply; its stores, plants, skylight and extra levels do not. Reference files/hash provenance and read chapters are retained in this package.

## Plan and section

| Reservation | World X/Z | Purpose |
|---|---|---|
| Deep entrance and orientation | X8…23 / Z−464…−450 | 8m-wide opening centredZ−456; direct view to practice volume; backed signage and rest outside turning area |
| Principal practice | X23…43 / Z−449…−406 | Clear20×43m working envelope, smaller composed activity mats at one end, broad free movement at the other; no invented sport or participant count |
| Public circulation | X19…23 / Z−450…−404 | Nominal4m uninterrupted corridor outside practice floor |
| Three sheltered niches | X10…19 / Z−447…−438, −432…−423, −417…−408 | Lower sheltered volumes, supported wall bars, exercise mats, local storage and a clear central approach |
| Equipment/care support | X47…53 / Z−451…−400 | Equipment store, screened care/stock and return staging |
| Internal staff spine | X43.5…47 / Z−452…−400 | 3.5m nominal clear route with separate parking; external end sealed |
| Aft recovery/rest | X10…42 / Z−405…−399 | Supported benches and useful tables on the quiet edge, preserve through passage |

All figures are design proposals within the pinned allocation. Inner partitions create meaningful separate volumes, not facade strips on one box. Main practice uses a folded roof profile, underside6.5…7.55m above datum, supported by transverse beams and piers at its edges. Niches/arrival/support ceilings sit4.2…4.8m above datum, with visible return fascia and bearings. Maximum export height7.85m above datum (Y43.35), leaving0.65m to the next datum. Upper enclosure stays opaque. Exact receiving slab underside and load adequacy remain unverified.

The entire support floor is SOURCE_PREVIEW_ONLY and absent from GLB. A receiving floor/material/contact proposal carries the polygon and finishedY35.5; parent controls slab/collision adoption. Floor mats are ordinary supported furnishing props, not independent structural floors. Internal openings are architectural apertures, not operating doors. Equipment/care routes remain geometric reservations until capsule/cart checks.

Only approved AST-FUR-001/003, AST-STF-007, AST-SAL-001, AST-LGT-001 sources are permitted. Native source and GLB/manifest pins are verified. Cache each native family once, preserve evaluated hierarchy transforms and copy objects sharing mesh datablocks; no repeated .blend reads. Original packed native sources remain editable dependencies. New architecture has package identities, no AST registration.

First pass includes actual materials/textures, supported bench/table/stock items, exercise mats, restrained wall-mounted practice bars and equipment shelves, backed signs, mounted effective lights. No reflection-as-window, blank first pass, emission-only light or detached ceiling panels. Source lighting proposals accompany physical GLB fixtures; runtime lighting requires receiving adaptation.

Review cameras: entry1.65m, practice1.65m, niche1.65m, rest1.15m, care1.65m, ceiling support1.65m and diagrammatic section. Inspect actual source and native GLB bounds, packed assets, repeated component transforms, floor exclusion, route reservations and support contacts. Root schedules Blender4.3.2 builds/exports/renders CPU12 and independent image review. Live Godot appearance, source-to-runtime lights, actor/cart/door tests, species fit, performance and receiver/floor adoption remain open.
