# Revision02: build the experience and correct the review

Human authorization, 7 October 2026: perform another pass, actually carry out the corrections, build every amenity believably, faithfully follow tiered terraces and SunCorp luxury, remember the custodial player's role, and integrate intuitive interaction. Specifically the Moss Sanctuary must offer a peaceful stream, trees in tiered planters, moss on large rocks and ground cover. This latest instruction supersedes the earlier WP10 review restriction against adding water. It does not authorize intrusion into neighbours or random new programmes elsewhere.

## Isolated ownership

Read the full current master/application overlay, architectural and coordinate contracts, complete catalog sheets and relevant original pixels, plus the exact WPxx fresh review and original final build history. Original packages in external_packages/windows and all dispatched archives are frozen. Work in external_packages/windows_revision02/WPxx_... with the same package basename. Copy originals without deleting anything; preserve predecessor hashes and prior failed attempts. Do not touch Game, the original BlenderCatalogue, shared IDs/materials/controllers or backup/publisher state. Current receiving state remains Higgins-owned and must be reconciled, especially WP09's already repaired exported labels.

Exclusive ownership:

- section_owner_05: WP10 first, then WP03, WP04, WP14, WP15.
- section_owner_06: WP02 first, then WP11, WP01, WP08, WP09.
- section_owner_07: WP06 first, then WP07, WP05, WP12, WP13.

All 15 get a new experience/design pass; WP15 previously passed but must still be assessed against the new experience/branding instruction. Rebuild only where warranted, explaining any unchanged successful parts. Root integrates reviews/runtime adapter/delivery. Never edit another owner's files. Heavy Blender/import/render work is serialized by root; ask for the slot with exact command and stage. Use Blender4.3.2 CPU12 and --python-exit-code1, preserve failed evidence. No paid generation or downloads needed.

## Experience before repeated modules

Each section needs a concise EXPERIENCE_BRIEF.md: guest or worker arrival, focal experience, a purposeful quiet/occupied edge, coherent tiered plan/section, public versus staff transition, and what a custodian actually notices/reaches/cares for. Derive tiering from function: planted levels, substantial terraces, nested seating/book/display edges and supported ceiling hierarchy. Do not turn every room into arbitrary steps or compromise level cart access. Keep courts and work aisles deliberately clear. Architectural luxury means coherent forms, material depth, comfortable useful groupings and believable local light, not a logo pasted onto a bare box.

SunCorp owns hospitality; Astralis is manufacturer. Follow current fiction and approved source references. Use restrained original SunCorp destination/amenity and service identification, not copied reference brands or invented campaign slogans/canon. Guests get the warm layered promise; staff get practical cooler fixtures, panels, services and humane signs of use. Supply shelves need actual readable supported products; worktops need usable clear areas. Do not force all staff areas into luxury guest treatment.

Moss Sanctuary: compose a visible coherent peaceful stream with contained bed/banks and believable inlet/outlet/maintenance intent, substantial mossy rocks, layered ground cover/shrubs/tree canopy, trees rooted in supported tiered planters, resting places facing the scene, and a continuous dry custodial/guest route. Keep water/structure above the protected lower interface; no unapproved slab cuts. Any bridge/raised occupied terrace needs real support, guards where appropriate and proven access. Water motion/audio/playability are separately stated; no static blue plane passed off as operating water. Root will help portable runtime integration.

## Intuitive interaction contract

Existing player uses RMB focus and E, ray reach2.5m, parent lookup for get_interaction_label()/interact(player). Do not invent another key scheme or modify live controllers. Provide package-local runtime/interaction_candidates.json with stable proposed IDs, actual named visual/marker nodes, action intent, focus point and clear approach in Godot world metres, and access category. Choose real meaningful targets: a reachable care product, supported storage handle, a service control or readable amenity information. Do not scatter invisible giant trigger boxes or claim unimplemented restocking/cleaning/inventory/playback. Root supplies and tests a common portable adapter; owners provide actual well-placed geometry and evidence. Label source-only proposals and real tested interactions separately.

## Completion gates

Fix every local review finding or supply precise contrary evidence. Preserve capacity/IDs/datums/bounds and actual successful approaches. Review sign fronts and service/seat working faces from real approach; verify privacy from shared routes. Every added stock/rock/planter/ledge counts as an obstacle. Explicitly retain unchanged runtime holds without pretending they are source defects.

Supply editable native, portable export/packed textures, exact predecessor/current hashes, actual geometry/support/route/resource/text checks, plan/section and fresh normal-eye arrival/activity/quiet/service/close views from the final saved native. Compare actual pixels to originals, not only tests/counts. Render at unchanged honest exposure and effective visible fixture light. New relevant references must be retained exactly with full catalog manifest and all-sheet coverage receipt. Mark historical prose historical; final README describes what exists. Root reviews before packaging. Do not stop after a plan or hand unfinished geometry to Higgins as complete.

## Exterior views — latest human instruction
Integrate grand sweeping outer-space views whenever physically possible. Inspect and retain relevant catalog originals for panoramic glazing, curved observation edges and layered terraces. Verify actual hull exposure, exterior sightlines and adjoining allocations before cutting an opening: no windows through occupied neighbours, no invented exterior orientation or unsupported structural cuts. Compose views from arrival, seated positions and walking routes, with substantial framing, supported glazing, comfortable resting edges and practical cleaning access. Preserve protected interfaces and level circulation. Record the hull/allocation evidence and chosen reference IDs in EXPERIENCE_BRIEF.md. Where exterior exposure cannot be established, explicitly hold that opening for receiving verification; do not substitute a simulated screen and call it a real window. This requirement applies to every assigned amenity alongside all prior corrections.
