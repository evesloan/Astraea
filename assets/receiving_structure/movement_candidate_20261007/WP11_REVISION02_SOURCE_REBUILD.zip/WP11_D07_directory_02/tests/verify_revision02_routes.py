"""Final-native source routes, contacts and proposed targets. No source saves."""
from pathlib import Path
import bpy,json,hashlib,math
from mathutils import Vector
from mathutils.bvhtree import BVHTree
P=Path(__file__).resolve().parents[1];source=P/'source/WP11_movement_studio.blend'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins={'native':sha(source),'glb':sha(P/'exports/WP11_movement_studio.glb')}
bpy.ops.wm.open_mainfile(filepath=str(source));bpy.context.view_layer.update();dg=bpy.context.evaluated_depsgraph_get()
def v(x,z,h):return Vector((x-8,-(z+456),h))
verts=[];faces=[];owners=[]
for o in bpy.context.scene.objects:
 if o.type not in {'MESH','FONT','CURVE'} or o.name.startswith('SOURCE_PREVIEW_ONLY'):continue
 ev=o.evaluated_get(dg);me=ev.to_mesh();off=len(verts);verts.extend(tuple(ev.matrix_world@p.co) for p in me.vertices)
 for f in me.polygons:faces.append(tuple(off+i for i in f.vertices));owners.append(o.name)
 ev.to_mesh_clear()
tree=BVHTree.FromPolygons(verts,faces);errors=[]
routes={'public_spine':[(10,-456),(22,-456),(22,-449),(21,-448),(21,-405),(39.5,-405)],
'staff_care':[(38,-454),(45.3,-454),(45.3,-423),(50.1,-423)],
'care_worktops':[(50.1,-423),(50.1,-429)]}
for x in (13,18,29,35):routes['aft_seat_'+str(x)]=[(x,-405),(x,-402.0)]
hits=[];samples=0
for name,path in routes.items():
 for radius in (.30,.65):
  for a,b in zip(path,path[1:]):
   count=max(1,math.ceil(math.dist(a,b)/.15))
   for k in range(count+1):
    x=a[0]+(b[0]-a[0])*k/count;z=a[1]+(b[1]-a[1])*k/count;samples+=1
    for h in (.25,.8,1.4,1.75):
     for i in range(16):
      hit,normal,idx,d=tree.ray_cast(v(x,z,h),Vector((math.cos(i*math.tau/16),math.sin(i*math.tau/16),0)),radius)
      if hit is not None:hits.append({'route':name,'radius_m':radius,'point':[x,z,h],'object':owners[idx]})
if hits:errors.append({'route_hits':len(hits),'first':hits[:15]})
interaction=[]
for c in json.loads((P/'runtime/interaction_candidates.json').read_text())['candidates']:
 fx,fy,fz=c['focus_world_m'];ax,ay,az=c['approach_feet_world_m'];a=v(ax,az,ay-35.5+1.65);b=v(fx,fz,fy-35.5);d=b-a
 hit,n,idx,dist=tree.ray_cast(a,d.normalized(),d.length+.06);name=owners[idx] if hit is not None else None
 good=d.length<=2.5 and name is not None and name.startswith('StudioInfo' if c['access']=='public' else 'CareInfo')
 interaction.append({'id':c['id'],'range_m':d.length,'first_hit':name,'passed':good})
 if not good:errors.append({'interaction':interaction[-1]})

def support_identity(actual,expected):
 return actual is not None and all(part in actual for part in expected)
def intended_support(name):
 import ast
 if name=='CareInfoRiser':return ('Care_cabinet_-426','COUNTER_continuous_rolled_nose')
 if name.startswith('Rolled_mat_'):
  z,i=ast.literal_eval(name.removeprefix('Rolled_mat_'));return ('Equipment_shelf_'+str((z,1.05)),)
 if name.startswith('Niche_supported_block_'):i,x=ast.literal_eval(name.removeprefix('Niche_supported_block_'));return ('Niche_block_bin_base_'+str(i),)
 if name.startswith('Care_bottle_'):i,j=ast.literal_eval(name.removeprefix('Care_bottle_'));return ('Care_cabinet_'+str([-429,-426,-423][i-1]),'SHELF_open_folded_mid_deck')
 if name.startswith('Care_pad_pack_'):i=int(name.removeprefix('Care_pad_pack_'));return ('Care_cabinet_'+str([-429,-426,-423][i-1]),'BASE_continuous_folded_catch_deck')
 if name.startswith('Care_folded_cloth_'):
  j,k=ast.literal_eval(name.removeprefix('Care_folded_cloth_'));return ('Care_cabinet_-426','SHELF_open_folded_mid_deck') if k==0 else ('Care_folded_cloth_'+str((j,k-1)),)
 raise AssertionError(('unmapped stock',name))
# Actual evaluated stock bottoms against actual native and stacked-item surfaces.
supports=[]
items=[o for o in bpy.context.scene.objects if o.type=='MESH' and (o.name.startswith(('Care_bottle_(', 'Care_folded_cloth_', 'Care_pad_pack_', 'Niche_supported_block_', 'Rolled_mat_', 'CareInfoRiser')))]
assert items, 'No actual stock meshes selected'
stock_names={o.name for o in items}
for o in items:
 ev=o.evaluated_get(dg);me=ev.to_mesh();points=[ev.matrix_world@p.co for p in me.vertices];lo=[min(p[i] for p in points) for i in range(3)];hi=[max(p[i] for p in points) for i in range(3)];ev.to_mesh_clear()
 sf=[(f,n) for f,n in zip(faces,owners) if n!=o.name and (n in stock_names or n.startswith('Niche_block_bin_base_') or 'SHELF_open_folded_mid_deck' in n or 'BASE_continuous_folded_catch_deck' in n or 'COUNTER_continuous_rolled_nose' in n or n.startswith('Equipment_shelf_'))]
 st=BVHTree.FromPolygons(verts,[f for f,n in sf]);origin=Vector(((lo[0]+hi[0])/2,(lo[1]+hi[1])/2,lo[2]+.02));hit,no,i,d=st.ray_cast(origin,Vector((0,0,-1)),.04)
 actual=sf[i][1] if hit is not None else None;expected=intended_support(o.name);good=hit is not None and abs(hit.z-lo[2])<.001 and support_identity(actual,expected)
 footprint=[]
 for fx,fy in [(0.5,0.5),(.2,.2),(.2,.8),(.8,.2),(.8,.8)]:
  probe=Vector((lo[0]+(hi[0]-lo[0])*fx,lo[1]+(hi[1]-lo[1])*fy,lo[2]+.02));ph,pn,pi,pd=st.ray_cast(probe,Vector((0,0,-1)),.04);ps=sf[pi][1] if ph is not None else None
  # Cylinders have a tangent contact line, checked at their actual lowest centre; flat stock uses five bearing points.
  pg=ph is not None and abs(ph.z-lo[2])<.001 and support_identity(ps,expected)
  footprint.append({'xy_fraction':[fx,fy],'support':ps,'top':ph.z if ph is not None else None,'passed':pg})
 if not o.name.startswith('Rolled_mat_'):good=good and all(f['passed'] for f in footprint)
 supports.append({'footprint_contact':footprint,'item':o.name,'actual_bounds':[lo,hi],'actual_bottom':lo[2],'support':actual,'expected_support_identity':expected,'actual_support_top':hit.z if hit is not None else None,'passed':good})
if not all(c['passed'] for c in supports):errors.append({'stock_contact':supports})
camera_hits=[]
for o in bpy.context.scene.objects:
 if o.type=='CAMERA' and o.name!='SOURCE_ONLY_section':
  for axis in [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]:
   hit,n,idx,d=tree.ray_cast(o.location,Vector(axis),.16)
   if hit is not None:camera_hits.append({'camera':o.name,'object':owners[idx]})
if camera_hits:errors.append({'camera_hits':camera_hits})
receipt={'scope':'Evaluated final-native bounded source checks, not installed body/cart or species acceptance','pins':pins,'routes':routes,'radius_m':[.30,.65],'route_samples':samples,'route_hits':hits,'stock_support':supports,'interaction':interaction,'camera_hits':camera_hits,'errors':errors,'passed':not errors}
(P/'tests/revision02_routes_support.json').write_text(json.dumps(receipt,indent=2));print(json.dumps({'passed':not errors,'errors':errors},indent=2));assert not errors
