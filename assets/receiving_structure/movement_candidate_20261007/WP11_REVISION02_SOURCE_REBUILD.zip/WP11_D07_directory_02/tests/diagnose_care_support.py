from pathlib import Path
import bpy,json
P=Path(__file__).resolve().parents[1];bpy.ops.wm.open_mainfile(filepath=str(P/'source/WP11_movement_studio.blend'));bpy.context.view_layer.update();dg=bpy.context.evaluated_depsgraph_get();out=[]
for o in bpy.context.scene.objects:
 if o.type!='MESH' or not o.name.startswith('Care_cabinet_-426__'):continue
 if not any(s in o.name for s in ['SHELF_open_folded_mid_deck','BASE_continuous_folded_catch_deck','COUNTER']):continue
 ev=o.evaluated_get(dg);m=ev.to_mesh();pts=[ev.matrix_world@v.co for v in m.vertices];out.append({'name':o.name,'bounds':[[min(p[i] for p in pts)for i in range(3)],[max(p[i] for p in pts)for i in range(3)]],'world_vertices':[list(p) for p in pts]});ev.to_mesh_clear()
(P/'qa/actual_care_support_diagnostic.json').write_text(json.dumps(out,indent=2));print(json.dumps([{k:v for k,v in r.items() if k!='world_vertices'}for r in out],indent=2))
