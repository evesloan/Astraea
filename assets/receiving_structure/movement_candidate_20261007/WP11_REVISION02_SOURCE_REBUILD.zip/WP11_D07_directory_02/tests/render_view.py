from pathlib import Path
import bpy,json,sys,hashlib
from mathutils import Vector
P=Path(__file__).resolve().parents[1];args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else ['entry'];name=args[0]
src=P/'source/WP11_movement_studio.blend';bpy.ops.wm.open_mainfile(filepath=str(src));s=bpy.context.scene;s.camera=bpy.data.objects['SOURCE_ONLY_'+name]
if name=='rest':
    # Render-only eye in the clear practice approach, ahead of the resting bays.
    # Accepted native geometry, lighting, materials, and exposure stay untouched.
    eye=Vector((30-8,-(-407+456),1.65));target=Vector((28-8,-(-400.5+456),1.9))
    s.camera.location=eye;s.camera.rotation_euler=(target-eye).to_track_quat('-Z','Y').to_euler()
s.render.engine='CYCLES';s.cycles.samples=int(args[1]) if len(args)>1 else 24;s.render.image_settings.file_format='PNG'
s.render.filepath=str(P/'tests/views'/f'SOURCE_ONLY_{name}.png');s.render.use_stamp=True;s.render.use_stamp_note=True;s.render.stamp_note_text='SOURCE ONLY | WP11 Movement studio | no live adoption';s.render.stamp_font_size=14
if name=='section':
    for o in s.objects:
        if o.get('role')=='supported_ceiling' or o.name in ['Opaque_roof_cap','Orientation_coffer','Entry_coffer','Service_ceiling'] or o.name.startswith(('Niche_roof_','Inward_boundary_','Opaque_end_-465.8')):o.hide_render=True
bpy.ops.render.render(write_still=True)
(P/'tests/views'/f'{name}_receipt.json').write_text(json.dumps({'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'camera':name,'eye_height':1.65 if name!='section' else None,'render_camera_source_location':list(s.camera.location),'render_camera_world_location':[s.camera.location.x+8,s.camera.location.z+35.5,-s.camera.location.y-456],'section_roof_removed':name=='section','status':'rendered; not independently reviewed','image_sha256':hashlib.sha256(Path(s.render.filepath).read_bytes()).hexdigest()},indent=2))
