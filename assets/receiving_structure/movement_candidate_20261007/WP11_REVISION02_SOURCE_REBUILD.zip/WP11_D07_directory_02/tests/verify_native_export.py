from pathlib import Path
import bpy,json,math,hashlib,struct
P=Path(__file__).resolve().parents[1];m=json.loads((P/'manifest.json').read_text())
source=P/'source/WP11_movement_studio.blend';glb=P/'exports/WP11_movement_studio.glb'
assert hashlib.sha256(source.read_bytes()).hexdigest()==m['source_sha256'];assert hashlib.sha256(glb.read_bytes()).hexdigest()==m['glb_sha256']
bpy.ops.wm.open_mainfile(filepath=str(source));bpy.context.view_layer.update()
fonts=[o.name for o in bpy.data.objects if o.type=='FONT'];assert fonts,'editable native FONT lost'
# Fresh native reloads can leave packed pixels lazy-loaded (has_data=False).
# Packing is a persistence property: inspect every used FILE image datablock.
images=[i for i in bpy.data.images if i.source=='FILE' and i.users>0]
assert images,'native scene has no used FILE textures'
unpacked=[i.name for i in images if not i.packed_file]
assert not unpacked,('used native textures are not packed',unpacked)
native_image_receipt=[{'name':i.name,'users':i.users,'packed':bool(i.packed_file),'pixels_loaded':i.has_data} for i in images]
assert len([o for o in bpy.data.objects if o.type=='LIGHT'])>=25
assert len([o for o in bpy.data.objects if o.name.startswith('SOURCE_PREVIEW_ONLY')])==2
raw=glb.read_bytes();n,_=struct.unpack_from('<II',raw,12);g=json.loads(raw[20:20+n]);nodes={n.get('name'):n for n in g['nodes']}
for name in fonts:
    assert name in nodes and 'mesh' in nodes[name],name
    ps=g['meshes'][nodes[name]['mesh']]['primitives'];assert any(g['accessors'][q['attributes']['POSITION']]['count']>0 for q in ps),name
    assert all('TEXCOORD_0' in q['attributes'] for q in ps),('font UV missing',name)
bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(glb));bpy.context.view_layer.update()
assert not any('SOURCE_PREVIEW_ONLY' in o.name for o in bpy.data.objects)
lo=[float('inf')]*3;hi=[float('-inf')]*3;count=0
for o in bpy.data.objects:
    if o.type!='MESH':continue
    count+=1
    for pt in o.data.vertices:
        p=o.matrix_world@pt.co;assert all(math.isfinite(q) for q in p)
        for i in range(3):lo[i]=min(lo[i],p[i]);hi[i]=max(hi[i],p[i])
assert lo[0]>=-.005 and hi[0]<=46.005 and lo[1]>=-58.005 and hi[1]<=10.005 and lo[2]>=-.005 and hi[2]<=7.855,(lo,hi)
r={'status':'pass','scope':'fresh native reload + actual GLB binary label census and Blender reimport; no live engine proof','native_font_count':len(fonts),'exported_font_mesh_count':len(fonts),'font_UVs':True,'packed_images':len(native_image_receipt),'used_file_texture_count':len(native_image_receipt),'native_images':native_image_receipt,'GLB_import_meshes':count,'roundtrip_bounds_source_basis':[lo,hi],'preview_floor_excluded':True,'source_sha256':m['source_sha256'],'glb_sha256':m['glb_sha256'],'pending':['actual visual review','floor adoption','capsule/cart/door tests','species fit','runtime light adaptation','target hardware']}
(P/'tests/native_export_receipt.json').write_text(json.dumps(r,indent=2)+'\n');print('WP11_NATIVE_EXPORT_PASS', 'packed_used_FILE_images',len(native_image_receipt))
