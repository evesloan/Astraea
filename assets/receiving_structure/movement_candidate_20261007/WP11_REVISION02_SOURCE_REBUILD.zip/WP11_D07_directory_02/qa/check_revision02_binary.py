"""Independent actual GLB world-geometry, embedded-resource and containment check."""
from pathlib import Path
import json,struct,math,hashlib
P=Path(__file__).resolve().parents[1];f=P/'exports/WP11_movement_studio.glb';raw=f.read_bytes()
assert raw[:4]==b'glTF';assert struct.unpack_from('<I',raw,8)[0]==len(raw)
n=struct.unpack_from('<I',raw,12)[0];d=json.loads(raw[20:20+n]);binary=raw[28+n:]
def mul(a,b):return [[sum(a[i][k]*b[k][j]for k in range(4))for j in range(4)]for i in range(4)]
I=[[float(i==j)for j in range(4)]for i in range(4)]
ORIGIN=[8, 35.5, -456];LOW=[8, 35.5, -466];HIGH=[54, 43.35, -398]
for k in range(3):I[k][3]=ORIGIN[k]
def matrix(node):
 if 'matrix'in node:return [[node['matrix'][c*4+r]for c in range(4)]for r in range(4)]
 x,y,z,w=node.get('rotation',[0,0,0,1]);sx,sy,sz=node.get('scale',[1,1,1]);tx,ty,tz=node.get('translation',[0,0,0])
 return [[(1-2*y*y-2*z*z)*sx,(2*x*y-2*z*w)*sy,(2*x*z+2*y*w)*sz,tx],[(2*x*y+2*z*w)*sx,(1-2*x*x-2*z*z)*sy,(2*y*z-2*x*w)*sz,ty],[(2*x*z-2*y*w)*sx,(2*y*z+2*x*w)*sy,(1-2*x*x-2*y*y)*sz,tz],[0,0,0,1]]
def accessor(i):
 a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];width={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];kind={5126:'f',5123:'H',5125:'I',5121:'B'}[a['componentType']];size=struct.calcsize(kind);stride=v.get('byteStride',width*size);off=v.get('byteOffset',0)+a.get('byteOffset',0)
 return [struct.unpack_from('<'+kind*width,binary,off+j*stride)for j in range(a['count'])]
lo=[math.inf]*3;hi=[-math.inf]*3;count=0;nodes=[];family=set();light_count=0
def walk(i,parent):
 global count,light_count
 node=d['nodes'][i];m=mul(parent,matrix(node));name=node.get('name','');assert 'PREVIEW_ONLY'not in name
 ex=node.get('extras',{});assert ex.get('role')!='preview_floor';family.add(ex['existing_family']) if 'existing_family'in ex else None
 if 'KHR_lights_punctual'in node.get('extensions',{}):light_count+=1
 if 'mesh'in node:
  mn=[math.inf]*3;mx=[-math.inf]*3
  for prim in d['meshes'][node['mesh']]['primitives']:
   attrs=prim['attributes'];assert 'NORMAL'in attrs and 'TEXCOORD_0'in attrs,(name,attrs)
   for role,idx in attrs.items():
    if role in['POSITION','NORMAL','TEXCOORD_0']:assert all(all(math.isfinite(x)for x in v)for v in accessor(idx)),name
   for p in accessor(attrs['POSITION']):
    q=[sum(m[j][k]*(*p,1)[k]for k in range(4))for j in range(3)];count+=1
    assert all(LOW[k]-.002<=q[k]<=HIGH[k]+.002 for k in range(3)),(name,q)
    for j in range(3):lo[j]=min(lo[j],q[j]);hi[j]=max(hi[j],q[j]);mn[j]=min(mn[j],q[j]);mx[j]=max(mx[j],q[j])
  nodes.append({'name':name,'world_min':mn,'world_max':mx})
 for child in node.get('children',[]):walk(child,m)
for i in d['scenes'][d.get('scene',0)]['nodes']:walk(i,I)
assert count>0
assert all('bufferView'in i for i in d.get('images',[])), 'External texture resource'
assert all('uri'not in b for b in d['buffers'])
# Family/light budgets are separately reviewed; no fabricated minimum as visual acceptance.
r={'pass':True,'scope':'actual exported geometry/resource/axes only, not route/lighting/visual/runtime acceptance','sha256':hashlib.sha256(raw).hexdigest(),'vertices_checked':count,'bounds':[lo,hi],'mesh_nodes':len(nodes),'embedded_images':len(d.get('images',[])),'punctual_light_nodes':light_count,'retained_families':sorted(family),'no_preview_floor':True,'node_bounds':nodes}
(P/'qa/revision02_binary_export.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items()if k!='node_bounds'},indent=2))
