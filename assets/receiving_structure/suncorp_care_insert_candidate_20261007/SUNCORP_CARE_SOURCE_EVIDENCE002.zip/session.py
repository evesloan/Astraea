import bpy,json,time,os,hashlib
from mathutils import Vector
D='/workspace/scratch/375c2e438292/suncorp_care_insert_successor001'
src='/workspace/shared/Astraea_recovery_20261007_AXWr5x/BlenderCatalogue/assets/receiving_structure/sports_care_candidate_20261007/WP02_sports_care.blend'
assert hashlib.sha256(open(src,'rb').read()).hexdigest()=='335c2097c3e204e04963211b93d821081f2203aeb4268956f40ef35f330c7bb1'
bpy.ops.wm.open_mainfile(filepath=src)
def info(o):
 return dict(name=o.name,type=o.type,loc=list(o.location),rot=list(o.rotation_euler),scale=list(o.scale),bounds=[list(o.matrix_world@Vector(v)) for v in o.bound_box],mat=[m.name if m else None for m in o.data.materials] if hasattr(o.data,'materials') else [],body=getattr(o.data,'body',None),props=dict(o.items()))
json.dump({'version':bpy.app.version_string,'objects':[info(o) for o in bpy.data.objects if any(s in o.name for s in ['CareInfo','StaffShallow','CareStock','SunCorp'])],'materials':[{ 'name':m.name,'diffuse':list(m.diffuse_color)} for m in bpy.data.materials]},open(D+'/inspection.json','w'),indent=2)
print('INSPECTION_READY',flush=True)
while not os.path.exists(D+'/build.py'):time.sleep(1)
exec(compile(open(D+'/build.py').read(),D+'/build.py','exec'))
