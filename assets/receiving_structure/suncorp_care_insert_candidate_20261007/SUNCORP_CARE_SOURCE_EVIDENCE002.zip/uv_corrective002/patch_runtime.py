import json,struct,copy,hashlib,pathlib
D=pathlib.Path(__file__).parent
SRC=pathlib.Path('/workspace/shared/Astraea_recovery_20261007_AXWr5x/Game/assets/models/WP02_sports_care_runtime_names_inert001.glb')
def read(p):
 b=p.read_bytes();assert b[:4]==b'glTF';jlen=struct.unpack_from('<I',b,12)[0];j=json.loads(b[20:20+jlen]);blen=struct.unpack_from('<I',b,20+jlen)[0];return j,b[28+jlen:28+jlen+blen]
def sha(b):return hashlib.sha256(b).hexdigest()
a,ab=read(SRC);b,bb=read(D/'care_insert_four_nodes002.glb');c=copy.deepcopy(a);binary=ab+b'\0'*((-len(ab))%4);offset=len(binary);binary+=bb
vbase=len(c['bufferViews']);abase=len(c['accessors'])
for v in b['bufferViews']:
 v=copy.deepcopy(v);v['buffer']=0;v['byteOffset']=v.get('byteOffset',0)+offset;c['bufferViews'].append(v)
for v in b['accessors']:
 v=copy.deepcopy(v);v['bufferView']+=vbase;c['accessors'].append(v)
matmap={i:next(j for j,m in enumerate(a['materials']) if m['name']==v['name']) for i,v in enumerate(b['materials'])}
mp={'CareInfoCopy':'WP02N_0051','CareInfoPlaque':'WP02N_0052','CareInfoStand':'WP02N_0053','CareInfoTitle':'WP02N_0054'}
changed=[];meshids=[]
for n in b['nodes']:
 idx=next(i for i,v in enumerate(a['nodes']) if v.get('name')==mp[n['name']]);old=a['nodes'][idx];m=copy.deepcopy(b['meshes'][n['mesh']]);mi=old['mesh'];meshids.append(mi)
 for p in m['primitives']:
  p['indices']+=abase;p['attributes']={k:v+abase for k,v in p['attributes'].items()};p['material']=matmap[p['material']]
 c['meshes'][mi]=m;new=copy.deepcopy(n);new['mesh']=mi;new['name']=old['name'];c['nodes'][idx]=new;changed.append(idx)
c['buffers'][0]['byteLength']=len(binary)
# No other scene, extension, hierarchy, material, image, texture or resource was changed.
for k in a:
 if k not in ['nodes','meshes','buffers','bufferViews','accessors']:assert a[k]==c[k],k
assert all(a['nodes'][i]==c['nodes'][i] for i in range(len(a['nodes'])) if i not in changed)
assert all(a['meshes'][i]==c['meshes'][i] for i in range(len(a['meshes'])) if i not in meshids)
assert c['bufferViews'][:vbase]==a['bufferViews'] and c['accessors'][:abase]==a['accessors']
assert binary[:len(ab)]==ab
j=json.dumps(c,separators=(',',':')).encode();j+=b' '*((-len(j))%4);binary+=b'\0'*((-len(binary))%4)
result=struct.pack('<4sII',b'glTF',2,28+len(j)+len(binary))+struct.pack('<I4s',len(j),b'JSON')+j+struct.pack('<I4s',len(binary),b'BIN\0')+binary
out=D/'WP02_sports_care_runtime_suncorp_insert002.glb';out.write_bytes(result)
cc,cb=read(out);assert cc==c;assert cb[:len(ab)]==ab
# Plaque has identity transform; bounds come directly from POSITION accessor.
node=next(n for n in cc['nodes'] if n.get('name')=='WP02N_0052');access=cc['accessors'][cc['meshes'][node['mesh']]['primitives'][0]['attributes']['POSITION']]
report={'source_path':str(SRC),'source_sha256':sha(SRC.read_bytes()),'candidate_path':str(out),'candidate_sha256':sha(result),'node_count':len(c['nodes']),'mesh_count':len(c['meshes']),'replaced_geometry_nodes':mp,'changed_node_records':[a['nodes'][i]['name'] for i in changed if a['nodes'][i]!=c['nodes'][i]],'replaced_mesh_indices':meshids,'untouched_nodes':len(c['nodes'])-4,'untouched_meshes':len(c['meshes'])-4,'untouched_original_binary_bytes':len(ab),'original_binary_sha256':sha(ab),'all_original_materials_images_textures_accessors_bufferviews_and_other_top_level_fields_preserved':True,'visible_plaque_bounds_local':{'min':access['min'],'max':access['max']},'note':'CareInfoPlaque node record remains byte-semantically identical because identity transform and stable mesh index are preserved; its mesh content changes. Exactly four semantic geometry nodes change.'}
(D/'glb_preservation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
