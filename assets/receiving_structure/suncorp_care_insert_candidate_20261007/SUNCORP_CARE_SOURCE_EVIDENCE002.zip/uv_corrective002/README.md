# UV-corrected source pilot 002

Use this revision rather than revision001. Native and complete bounded runtime GLB hashes are in CANDIDATE_MANIFEST.json. The original four-node source diff is preserved; only UV fields on CareInfoPlaque and CareInfoStand differ from 001. UVMap is per-face box projection at 1 metre per tile using existing material family textures. No geometry, transforms, text, target parameters or materials were changed during this correction.

Source inspection: source_uv_oblique.png shows final textured face/frame and unchanged shelf contact. Prior ../source_normal_eye_vertical72_360p.png and ../source_normal_eye_360p.png show identical geometry/layout from walking height; these are CPU Cycles source views, not Godot/CRT acceptance. No final texture legibility claim from those prior views.

Exact receiving patch is runtime_adoption.json. exact_patch_mapping.json contains old/new node and mesh records, append offsets and material mapping. stable_reopen_verification.json and glb_preservation.json are the preservation proof. All revision001 bytes, renders and failed audit evidence remain retained. No Game/Catalogue writes, Godot import, backup or push was performed.
