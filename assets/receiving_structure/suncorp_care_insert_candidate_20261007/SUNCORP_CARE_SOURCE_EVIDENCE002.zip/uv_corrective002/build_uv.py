import bpy,json,hashlib,math,runpy
from pathlib import Path
from mathutils import Vector
P=Path('/workspace/scratch/375c2e438292/suncorp_care_insert_successor001');D=P/'uv_corrective002'
# Import the already validated stable comparator, without executing any file reads/renders.
setup=(P/'verify_render.py').read_text().split('bpy.ops.wm.open_mainfile(filepath=src);')[0]
exec(setup)
D=str(P/'uv_corrective002')
bpy.ops.wm.open_mainfile(filepath=str(P/'WP02_sports_care_suncorp_insert001.blend'));bpy.context.view_layer.update();previous=snapshot();materials=matsnapshot()
uvaudit={}
for name in ['CareInfoPlaque','CareInfoStand']:
 o=bpy.data.objects[name];me=o.data;assert len(me.uv_layers)==0;uv=me.uv_layers.new(name='UVMap');lo=[min(v.co[i] for v in me.vertices) for i in range(3)]
 for poly in me.polygons:
  axis=max(range(3),key=lambda i:abs(poly.normal[i]));axes=[i for i in range(3) if i!=axis]
  # Front/back use X,Z; side uses Y,Z; top uses X,Y. Values are metres, 1 tile/m.
  for li in poly.loop_indices:
   co=me.vertices[me.loops[li].vertex_index].co;uv.data[li].uv=(co[axes[0]]-lo[axes[0]],co[axes[1]]-lo[axes[1]])
 me.update();values=[list(x.uv) for x in uv.data];assert all(math.isfinite(v) for x in values for v in x)
 uvaudit[name]={'loop_count':len(values),'uv_min':[min(x[i] for x in values) for i in range(2)],'uv_max':[max(x[i] for x in values) for i in range(2)],'method':'Per-face axis-aligned box projection with shared mesh-minimum origin, 1 metre per texture tile','layer':uv.name}
bpy.context.view_layer.update();after=snapshot();changed=[n for n in previous if previous[n]!=after[n]];assert sorted(changed)==['CareInfoPlaque','CareInfoStand']
for n in changed:assert [k for k in previous[n] if previous[n][k]!=after[n][k]]==['uv']
assert matsnapshot()==materials
bpy.ops.wm.save_as_mainfile(filepath=D+'/WP02_sports_care_suncorp_insert002.blend',check_existing=False)
bpy.ops.object.select_all(action='DESELECT')
for n in ALLOW:bpy.data.objects[n].select_set(True)
bpy.context.view_layer.objects.active=bpy.data.objects['CareInfoTitle'];bpy.ops.object.convert(target='MESH')
bpy.ops.export_scene.gltf(filepath=D+'/care_insert_four_nodes002.glb',export_format='GLB',use_selection=True,export_extras=True,export_cameras=False,export_lights=False,export_animations=False)
bpy.ops.wm.open_mainfile(filepath=src);bpy.context.view_layer.update();original=snapshot();om=matsnapshot()
bpy.ops.wm.open_mainfile(filepath=D+'/WP02_sports_care_suncorp_insert002.blend');bpy.context.view_layer.update();reloaded=snapshot();rm=matsnapshot()
changed=[n for n in original if original[n]!=reloaded[n]];assert sorted(changed)==sorted(ALLOW);assert om==rm==materials;assert reloaded==after
json.dump({'original_changed_objects':changed,'revision001_changed_objects':['CareInfoPlaque','CareInfoStand'],'revision001_changed_fields':['uv'],'unchanged_materials':True,'object_count':len(original),'reopened_successor_equal_to_saved_state':True,'uv':uvaudit,'original_hashes':{n:digest(v) for n,v in original.items()},'successor_hashes':{n:digest(v) for n,v in reloaded.items()},'material_hashes':rm},open(D+'/stable_reopen_verification.json','w'),indent=2)
runpy.run_path(D+'/patch_runtime.py')
print('UV_CORRECTIVE_EXACT_PRESERVATION_PASS',flush=True)
# One smaller source-only appearance check under identical source lights. No source save.
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.device='CPU';s.cycles.samples=24;s.cycles.use_denoising=False;s.render.use_compositing=False;s.render.threads_mode='FIXED';s.render.threads=2;s.render.resolution_percentage=100;s.render.resolution_x=640;s.render.resolution_y=320;s.render.image_settings.file_format='PNG';s.view_settings.view_transform='Standard'
c=bpy.data.cameras.new('UV_SOURCE_REVIEW');o=bpy.data.objects.new(c.name,c);s.collection.objects.link(o);s.camera=o;o.location=(39.64,-4.12,2.06);o.rotation_euler=(Vector((38.82,-4.98,2.01))-o.location).to_track_quat('-Z','Y').to_euler();c.lens=36;c.clip_start=.05;s.render.filepath=D+'/source_uv_oblique.png';bpy.ops.render.render(write_still=True)
print('DONE_UV_CORRECTION',flush=True)
