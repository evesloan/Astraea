import bpy,json,hashlib,os,math
from mathutils import Vector
from idprop.types import IDPropertyGroup
D='/workspace/scratch/375c2e438292/suncorp_care_insert_successor001'
src='/workspace/shared/Astraea_recovery_20261007_AXWr5x/BlenderCatalogue/assets/receiving_structure/sports_care_candidate_20261007/WP02_sports_care.blend'
def info(o):
 return dict(name=o.name,type=o.type,loc=list(o.location),rot=list(o.rotation_euler),scale=list(o.scale),bounds=[list(o.matrix_world@Vector(v)) for v in o.bound_box],mat=[m.name if m else None for m in o.data.materials] if hasattr(o.data,'materials') else [],body=getattr(o.data,'body',None),props=dict(o.items()))
base=open(D+'/build.py').read().split('before=snapshot();')[0]
exec(compile(base,D+'/build.py','exec'))
# Stable modifier settings instead of Python repr memory addresses.
def semantic(v):
 if isinstance(v,(int,str,float,bool)) or v is None:return v
 if isinstance(v,bpy.types.ID):return (v.bl_rna.identifier,v.name)
 if isinstance(v,(dict,IDPropertyGroup)):return {str(k):semantic(x) for k,x in v.items()}
 try:return [semantic(x) for x in v]
 except:return str(type(v))
def modifiers(o):
 return [{p.identifier:semantic(getattr(m,p.identifier)) for p in m.bl_rna.properties if p.identifier not in ['rna_type']} for m in o.modifiers]
stable=base[base.index('def snapshot():'):base.index('def matsnapshot():')].replace("[(m.name,m.type,str(m)) for m in o.modifiers]","modifiers(o)").replace("out[o.name]=digest(x)","out[o.name]=semantic(x)")
exec(stable)
bpy.ops.wm.open_mainfile(filepath=src);bpy.context.view_layer.update();a=snapshot();ma=matsnapshot()
bpy.ops.wm.open_mainfile(filepath=D+'/WP02_sports_care_suncorp_insert001.blend');bpy.context.view_layer.update();b=snapshot();mb=matsnapshot()
changed=[n for n in a if a[n]!=b.get(n)]
report={'method':'Reopened original and successor, stable full mesh/UV/transforms/material assignment/text/light/modifier RNA comparison','changed_objects':changed,'material_hashes_equal':ma==mb,'object_count':len(a),'field_differences':{n:[k for k in a[n] if a[n][k]!=b[n].get(k)] for n in changed},'original_hashes':{n:digest(v) for n,v in a.items()},'successor_hashes':{n:digest(v) for n,v in b.items()},'original_material_hashes':ma,'successor_material_hashes':mb}
json.dump(report,open(D+'/stable_reopen_verification.json','w'),indent=2)
assert sorted(changed)==sorted(ALLOW),(changed,ALLOW)
assert ma==mb
assert set(a)==set(b)
print('STABLE_REOPEN_EXACT_FOUR_PASS',flush=True)
# Diagnose earlier hash failure separately, preserving initial report unchanged.
exec(base[base.index('def snapshot():'):base.index('def matsnapshot():')]);volatile=snapshot();initial=json.load(open(D+'/native_preservation.json'))['after'];dif=[n for n in initial if initial[n]!=volatile.get(n)]
json.dump({'earlier_hash_mismatch_objects':dif,'stable_semantic_check_passed':True,'objects_with_modifiers':{o.name:[(m.name,m.type) for m in o.modifiers] for o in bpy.data.objects if o.modifiers},'cause':'Initial saved-source reopen mismatch affected 921 objects with modifiers because repr included memory addresses. First recovery then compared 56 custom-property array wrappers by identity. Stable comparator recursively materializes every property to values before reopening files. Modifier RNA is also normalized rather than repr.'},open(D+'/initial_assertion_diagnosis.json','w'),indent=2)
# Only review camera/render changes occur after verification; source file never saved here.
render_code=open(D+'/build.py').read().split('# Review renders are isolated scene-state changes after save, never adopted lighting.')[1]
render_code=render_code.replace("scene.cycles.samples=12;","scene.cycles.samples=24;scene.cycles.use_denoising=False;scene.render.use_compositing=False;")
exec(render_code)
