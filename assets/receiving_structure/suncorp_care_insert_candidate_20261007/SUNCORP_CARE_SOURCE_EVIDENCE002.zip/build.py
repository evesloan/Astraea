import math,struct,copy
ALLOW=['CareInfoCopy','CareInfoPlaque','CareInfoStand','CareInfoTitle']
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),default=str).encode()).hexdigest()
def snapshot():
 out={}
 for o in bpy.data.objects:
  x=info(o);x['matrix']=[list(r) for r in o.matrix_world];x['parent']=o.parent.name if o.parent else None;x['hide']=[o.hide_render,o.hide_viewport];x['data_name']=o.data.name if o.data else None
  if o.type=='MESH':
   x['vertices']=[list(v.co) for v in o.data.vertices];x['polygons']=[(list(p.vertices),p.material_index,p.use_smooth) for p in o.data.polygons];x['uv']=[(uv.name,[list(t.uv) for t in uv.data]) for uv in o.data.uv_layers]
  if o.type=='FONT':x['font']=[o.data.size,o.data.align_x,o.data.align_y,o.data.extrude,o.data.bevel_depth,o.data.space_character,o.data.space_line]
  if o.type=='LIGHT':x['light']=[o.data.type,o.data.energy,list(o.data.color),o.data.shadow_soft_size]
  x['modifiers']=[(m.name,m.type,str(m)) for m in o.modifiers]
  out[o.name]=digest(x)
 return out
def matsnapshot():
 out={}
 for m in bpy.data.materials:
  x={'diffuse':list(m.diffuse_color),'nodes':[],'links':[]}
  if m.node_tree:
   for n in m.node_tree.nodes:
    inp=[]
    for i in n.inputs:
     if hasattr(i,'default_value'):
      v=i.default_value
      try:v=list(v)
      except TypeError:pass
      inp.append((i.name,v))
    x['nodes'].append((n.name,n.type,inp))
   x['links']=[(l.from_node.name,l.from_socket.name,l.to_node.name,l.to_socket.name) for l in m.node_tree.links]
  out[m.name]=digest(x)
 return out
before=snapshot();mbefore=matsnapshot()
# Rounded eight-corner extruded outlines in world Blender coordinates. No modifier dependencies.
def solid(name,cx,cz,w,h,yfront,yback,r,mat):
 pts=[(-w/2+r,-h/2),(w/2-r,-h/2),(w/2,-h/2+r),(w/2,h/2-r),(w/2-r,h/2),(-w/2+r,h/2),(-w/2,h/2-r),(-w/2,-h/2+r)]
 verts=[(cx+x,y,cz+z) for y in [yfront,yback] for x,z in pts]
 faces=[tuple(reversed(range(8))),tuple(range(8,16))]+[(i,(i+1)%8,(i+1)%8+8,i+8) for i in range(8)]
 mesh=bpy.data.meshes.new(name+'_integrated001');mesh.from_pydata(verts,[],faces);mesh.materials.append(bpy.data.materials[mat]);mesh.update()
 o=bpy.data.objects[name];o.data=mesh
 return o
plaque=solid('CareInfoPlaque',38.82,1.963,.858,.17,-4.933,-4.947,.018,'WP02_ivory_enamel')
housing=solid('CareInfoStand',38.82,1.965,.9,.2,-4.947,-4.972,.024,'ASTRAEA_staff_bluegrey_paint')
# Add full-width folded return to the same housing mesh. It intersects shelf underside by 3mm.
mesh=housing.data;v=[tuple(p.co) for p in mesh.vertices];f=[tuple(p.vertices) for p in mesh.polygons];i=len(v)
v += [(x,y,z) for x in [38.39,39.25] for y in [-4.955,-5.08] for z in [2.024,2.043]]
f += [tuple(i+j for j in q) for q in [(0,4,6,2),(1,3,7,5),(0,1,5,4),(2,6,7,3),(0,2,3,1),(4,5,7,6)]]
mesh.clear_geometry();mesh.from_pydata(v,[],f);mesh.update();housing['material_role']='staff_bluegrey_paint'
for name,body,size,z in [('CareInfoTitle','CARE STOCK',.08,1.978),('CareInfoCopy','SunCorp  |  CLOTHS / PADS',.045,1.905)]:
 o=bpy.data.objects[name];o.data=o.data.copy();o.data.body=body;o.data.size=size;o.data.align_x='CENTER';o.data.extrude=.0005;o.data.bevel_depth=0;o.data.resolution_u=4;o.location=(38.82,-4.931,z);o['original_text']=body
bpy.context.view_layer.update()
after=snapshot();mafter=matsnapshot();changed=[k for k in before if before[k]!=after.get(k)]
assert sorted(changed)==sorted(ALLOW),(changed,ALLOW)
assert mbefore==mafter
json.dump({'changed_objects':changed,'object_count':len(before),'all_untouched_object_hashes_identical':True,'all_material_hashes_identical':True,'before':before,'after':after,'materials':mbefore,'pilot_objects':[info(bpy.data.objects[n]) for n in ALLOW]},open(D+'/native_preservation.json','w'),indent=2)
bpy.ops.wm.save_as_mainfile(filepath=D+'/WP02_sports_care_suncorp_insert001.blend',check_existing=False)
# Selected export only. Full source has been saved with editable FONT objects.
bpy.ops.object.select_all(action='DESELECT')
for n in ALLOW:bpy.data.objects[n].select_set(True)
bpy.context.view_layer.objects.active=bpy.data.objects['CareInfoTitle']
bpy.ops.object.convert(target='MESH')
bpy.ops.export_scene.gltf(filepath=D+'/care_insert_four_nodes001.glb',export_format='GLB',use_selection=True,export_extras=True,export_cameras=False,export_lights=False,export_animations=False)
print('SOURCE_SAVED_AND_EXPORTED',flush=True)
# Re-open saved editable native, verifying the persisted source matches pre-save fingerprints.
bpy.ops.wm.open_mainfile(filepath=D+'/WP02_sports_care_suncorp_insert001.blend')
reopened=snapshot();assert reopened==after;assert matsnapshot()==mbefore
json.dump({'persisted_native_reopen_hash_check':True,'objects':len(reopened),'materials':len(mbefore)},open(D+'/reopen_check.json','w'),indent=2)
# Review renders are isolated scene-state changes after save, never adopted lighting.
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=12;scene.render.threads_mode='FIXED';scene.render.threads=2
scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG';scene.view_settings.view_transform='Standard'
camdata=bpy.data.cameras.new('SOURCE_REVIEW_CAMERA');cam=bpy.data.objects.new('SOURCE_REVIEW_CAMERA',camdata);scene.collection.objects.link(cam);scene.camera=cam;camdata.lens=40;camdata.clip_start=.05
# Existing source fixtures remain untouched. Close review uses the source's illumination.
def render(name,pos,target,w,h,lens):
 cam.location=pos;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();camdata.lens=lens;scene.render.resolution_x=w;scene.render.resolution_y=h;scene.render.filepath=D+'/'+name+'.png';bpy.ops.render.render(write_still=True)
render('source_close_face', (38.82,-3.90,1.98),(38.82,-4.96,1.98),1200,600,48)
render('source_oblique_attachment',(39.64,-4.12,2.06),(38.82,-4.98,2.01),1000,700,48)
render('source_normal_eye_360p',(38.70,-2.50,1.65),(38.32,-4.98,1.77),640,360,28)
print('DONE_SOURCE_PILOT',flush=True)
