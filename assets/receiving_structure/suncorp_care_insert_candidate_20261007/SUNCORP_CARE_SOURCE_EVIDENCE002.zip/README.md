# SunCorp care-stock shelf insert: source pilot 001

**Not installed. Not runtime/CRT accepted.** No Game or Catalogue file was written. This directory is a new isolated successor; original native and all original GLB bytes remain intact.

## Result

The original standalone 0.60 × 0.40 m care board and pole become a 0.858 × 0.170 m eased enamel face in a 0.90 × 0.20 m bluegrey return housing, mechanically joined to the existing shallow stock shelf. CARE STOCK remains the primary copy. SunCorp | CLOTHS / PADS sits below. No invented emblem, animated display, emission or new fixture lighting. The optional digital direction was not needed for this pilot.

CareInfoStand/WP02N_0053 retains its identity but now owns the shallow housing plus full-width folded return. No new housing ID is necessary. The return overlaps the unchanged shelf underside by 3 mm over a 0.86 × 0.10 m contact footprint. Existing brackets and cartons remain untouched.

## Deliverables

- `WP02_sports_care_suncorp_insert001.blend`: full successor native with editable FONT text. Exact four-object semantic diff, verified after reopening both original and successor.
- `care_insert_four_nodes001.glb`: selected-only export used for bounded patching. **Not a whole district.**
- `WP02_sports_care_runtime_suncorp_insert001.glb`: complete inert runtime candidate derived by patching only four original mesh slots/node transforms into the current installed GLB.
- `CANDIDATE_MANIFEST.json`: artifact SHA256s and independent GLB structure checks.
- `stable_reopen_verification.json`: 1,928 native object comparisons, including mesh topology/UVs, transforms, material assignments, properties, text, light settings, and stable modifier RNA values. Exactly four object differences; shared material hashes unchanged.
- `glb_preservation.json`: 1,904 untouched nodes, 1,381 untouched meshes, original materials/images/textures and every original accessor/bufferView preserved. All 3,186,296 original BIN bytes preserved byte-for-byte. Exactly four semantic geometry nodes change, although the plaque node JSON is identical because its original mesh index/identity transform remain stable.
- `runtime_adoption.json`: precise geometry mapping, shelf contact, fitted information target, unchanged interaction contract, adoption checklist and limitations.
- `source_close_face.png`, `source_oblique_attachment.png`, `source_normal_eye_360p.png`: source fixture-lit Cycles reviews. The 28 mm context view is narrower than runtime, not a legibility verdict.
- `source_normal_eye_vertical72_360p.png`: expected runtime-FOV source review from the original approach, 1.65 m eye height, 640 × 360. Still no CRT or Godot proof.

## Runtime adoption

Keep WP02_info_care_01, WP02N_0052, original label/action/full information/staff classification and RMB/E behavior. Set only focus to [46.82,37.463,464.932] and target size to [0.76,0.12,0.026]. Existing approach [46.85,35.5,462.5] is unchanged. Eight corners pass the existing visible-bounds-plus-0.06 m rule. The eye-to-focus distance is 2.452 m, close to the 2.5 m ray limit; actual unobstructed reach remains root's engine test.

Update only targeted exact preservation/hash records, source label ledger and source/native provenance. Do not weaken guards. Re-test screenshots 06/07, ordinary 72°/360p walking, default CRT/effects-off, oblique mounting, RMB focus/E open-close. Verify no old pole collider/target remains. No controller/HUD/light changes are proposed.

## Limitations and failed evidence

New plaque/housing meshes are uniformly shaded by existing texture-origin sampling rather than UV-mapped. Existing material resources are unchanged; inspect actual imported appearance before acceptance. Detail copy is intended for close inspection/focus and the unchanged E information, not distant small print.

Initial reopen assertion included modifier repr memory addresses. First stable recovery then compared opaque custom-property array wrappers by identity. Full stable-value normalization now passes; logs/reports for failed attempts are retained. Rendering also hit unavailable OIDN in this Blender build; read-only review renders use CPU2, denoising disabled. No source edits were made during verification/render recovery.

## Authority/reference review

Read complete chapter 21 plus current master application, pilot plan, original native and runtime package. Viewed actual prior Sports captures 06/07, guest_suite_hall.png and staff_corridor_services.png. References inform compact integrated fittings and practical support, not photoreal output or borrowed logos. The user's latest direction for built-in intuitive SunCorp signage controls the redesign. This is a bounded pilot; the unchanged larger CareStockLabel/reception/Moss signs are separate work.
