#!/usr/bin/env python3
"""Rebuild source002 from hash-pinned retained inputs. Never writes into an input repository."""
import argparse,ast,hashlib,pathlib,shutil,subprocess,json,os
p=argparse.ArgumentParser();p.add_argument('--original-native',required=True);p.add_argument('--original-runtime',required=True);p.add_argument('--output',required=True);p.add_argument('--blender',default='blender');p.add_argument('--render',action='store_true');a=p.parse_args()
root=pathlib.Path(__file__).resolve().parent;out=pathlib.Path(a.output).resolve();native=pathlib.Path(a.original_native).resolve();runtime=pathlib.Path(a.original_runtime).resolve()
expected={'native':'335c2097c3e204e04963211b93d821081f2203aeb4268956f40ef35f330c7bb1','runtime':'546748e35bf1572233634a24dbc2f395c197fbe02e373c99548fe5f03dd4c26d'}
for key,path in [('native',native),('runtime',runtime)]:
 if hashlib.sha256(path.read_bytes()).hexdigest()!=expected[key]:raise SystemExit('Dependency hash mismatch: '+key)
if out.exists():raise SystemExit('Output must be a new nonexistent directory; refusing to overwrite surviving work.')
out.mkdir(parents=True);(out/'uv_corrective002').mkdir()
oldroot='/workspace/scratch/375c2e438292/suncorp_care_insert_successor001';oldnative='/workspace/shared/Astraea_recovery_20261007_AXWr5x/BlenderCatalogue/assets/receiving_structure/sports_care_candidate_20261007/WP02_sports_care.blend';oldruntime='/workspace/shared/Astraea_recovery_20261007_AXWr5x/Game/assets/models/WP02_sports_care_runtime_names_inert001.glb'
for rel in ['build.py','session.py','verify_render.py','uv_corrective002/build_uv.py','uv_corrective002/patch_runtime.py']:
 s=(root/rel).read_text().replace(oldroot,str(out)).replace(oldnative,str(native)).replace(oldruntime,str(runtime));(out/rel).write_text(s)
# Production stage intentionally omits the superseded volatile reopen comparator and review renders.
# Final UV stage performs the stable reopened-original comparison before producing the complete patch.
session=(out/'session.py').read_text();tree=ast.parse(session);info=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='info');info_source=ast.get_source_segment(session,info)
build=(out/'build.py').read_text().split('# Re-open saved editable native')[0]
entry='import bpy,json,hashlib,os,math\nfrom mathutils import Vector\nassert bpy.app.version == (4,3,2), bpy.app.version_string\nD='+repr(str(out))+'\nsrc='+repr(str(native))+'\nbpy.ops.wm.open_mainfile(filepath=src)\n'+info_source+'\n'+build
(out/'build_stage001.py').write_text(entry)
uv=(out/'uv_corrective002/build_uv.py').read_text()
if not a.render:uv=uv.split('# One smaller source-only appearance check')[0]
(out/'uv_corrective002/build_uv.py').write_text(uv)
env=dict(os.environ,OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2')
for stage in ['build_stage001.py','uv_corrective002/build_uv.py']:
 subprocess.run([a.blender,'-b','-t','2','--python-exit-code','1','--python',str(out/stage)],check=True,env=env)
print('Rebuilt source candidate. Stable semantic and bounded runtime preservation proofs are in',out/'uv_corrective002')
print('Blender file headers/timestamps can change file hashes; compare semantic preservation and mesh resources, not byte reproducibility of .blend.')
