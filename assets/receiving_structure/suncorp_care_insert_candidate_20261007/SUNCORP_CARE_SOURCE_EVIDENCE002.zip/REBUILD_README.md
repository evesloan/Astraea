# Reproducible source/evidence package

This archive excludes original and duplicate full-scene native/runtime files. It retains source authoring scripts, four-node patch, stable audits, failed-attempt diagnostics, final source views, and precise adoption target/mapping.

## Retained dependencies

- Blender 4.3.2, CPU, two threads. No Godot, engine changes, network, or source-repository writes.
- Original native: Catalogue `assets/receiving_structure/sports_care_candidate_20261007/WP02_sports_care.blend`, SHA256 `335c2097c3e204e04963211b93d821081f2203aeb4268956f40ef35f330c7bb1`.
- Original inert runtime: Game `assets/models/WP02_sports_care_runtime_names_inert001.glb`, SHA256 `546748e35bf1572233634a24dbc2f395c197fbe02e373c99548fe5f03dd4c26d`. Use the retained original if live Game later adopts a successor.
- Native includes its existing packed material dependencies. No new external font/logo/image dependency is introduced.

Run `python rebuild_from_retained.py --original-native <verified original .blend> --original-runtime <verified original .glb> --output <new nonexistent scratch directory> --blender <Blender4.3.2 executable>`. Optional `--render` adds the final UV source view. The launcher checks dependency hashes, refuses an existing output, uses two sequential CPU2 jobs, skips the superseded volatile comparator, and runs the final stable original/successor comparison and bounded GLB patch. The production build steps were executed and validated; the portable launcher is syntax-checked but was not redundantly rerun during retention.

Reproducibility is semantic: Blender headers/timestamps may change `.blend` bytes. Native topology, transforms, UVs, materials, text and stable identity are audited; GLB resources are mapped and old bytes retained. This source candidate is accepted only for runtime evaluation, not CRT legibility or installed acceptance.
