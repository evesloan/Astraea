import bpy,math
from mathutils import Vector
D='/workspace/scratch/375c2e438292/suncorp_care_insert_successor001'
bpy.ops.wm.open_mainfile(filepath=D+'/WP02_sports_care_suncorp_insert001.blend')
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.device='CPU';s.cycles.samples=24;s.cycles.use_denoising=False;s.render.use_compositing=False;s.render.threads_mode='FIXED';s.render.threads=2;s.render.resolution_percentage=100;s.render.resolution_x=640;s.render.resolution_y=360;s.render.image_settings.file_format='PNG';s.view_settings.view_transform='Standard'
c=bpy.data.cameras.new('SourceReview_RuntimeFOV');o=bpy.data.objects.new(c.name,c);s.collection.objects.link(o);s.camera=o;o.location=(38.85,-2.5,1.65);o.rotation_euler=(Vector((38.82,-4.932,1.963))-o.location).to_track_quat('-Z','Y').to_euler();c.sensor_fit='VERTICAL';c.sensor_height=24;c.lens=24/(2*math.tan(math.radians(72)/2));c.clip_start=.05;s.render.filepath=D+'/source_normal_eye_vertical72_360p.png';bpy.ops.render.render(write_still=True)
