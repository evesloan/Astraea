"""Restore verified catalogue dependencies only into this unpacked package.
python copy_dependencies.py --catalogue-root /path/to/BlenderCatalogue
Existing matching files are left untouched. Any mismatch fails before writes.
"""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,os
ROOT=Path(__file__).resolve().parent
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
def confined(root,rel):
    rel=rel.replace('\\','/')
    pure=PurePosixPath(rel)
    if pure.is_absolute() or '..' in pure.parts or ':' in rel or not pure.parts:raise ValueError('Unsafe relative path: '+rel)
    target=(root/Path(*pure.parts)).resolve()
    if not target.is_relative_to(root):raise ValueError('Path escapes root: '+rel)
    return target
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--catalogue-root',type=Path,required=True);a=ap.parse_args();cat=a.catalogue_root.resolve(strict=True)
    if cat==ROOT or cat.is_relative_to(ROOT) or ROOT.is_relative_to(cat):raise ValueError('Catalogue and unpacked package must be separate trees')
    manifest=json.loads((ROOT/'dependency_map.json').read_text(encoding='utf8'));jobs=[]
    for rec in manifest['dependencies']:
        src=confined(cat,rec['catalogue_relative_path']);dst=confined(ROOT,rec['package_relative_path'])
        if not src.is_file() or src.stat().st_size!=rec['bytes'] or sha(src)!=rec['sha256']:raise ValueError('Missing/mismatched catalogue source: '+rec['catalogue_relative_path'])
        if dst.exists():
            if not dst.is_file() or sha(dst)!=rec['sha256']:raise ValueError('Refusing existing mismatched target: '+rec['package_relative_path'])
        else:jobs.append((src,dst,rec))
    # All source and pre-existing target checks completed before the first write.
    for src,dst,rec in jobs:
        dst.parent.mkdir(parents=True,exist_ok=True)
        if confined(ROOT,rec['package_relative_path'])!=dst:raise ValueError('Destination changed during copy')
        data=src.read_bytes()
        if hashlib.sha256(data).hexdigest()!=rec['sha256']:raise ValueError('Catalogue source changed during copy')
        with dst.open('xb') as f:f.write(data)
    for rel in ['exports','renders','qa','tests/views','docs/views']:
        confined(ROOT,rel).mkdir(parents=True,exist_ok=True)
    print(json.dumps({'restored':len(jobs),'already_present':len(manifest['dependencies'])-len(jobs),'package':str(ROOT),'live_files_modified':False}))
if __name__=='__main__':main()
