# Imported contact census API basis

The parsed diagnostic uses Shape3D.get_debug_mesh().get_aabb() only to choose a conservative set of neighboring shapes, then reads actual ConcavePolygonShape3D.get_faces() for the continuous surface test. This does not rely on a headless RenderingServer instance-transform readback.

Godot4.6.3 source inspected on2026-10-06:

- ArrayMesh.get_aabb returns its stored CPU AABB: https://github.com/godotengine/godot/blob/4.6.3-stable/scene/resources/mesh.cpp#L1860
- Shape3D builds the debug ArrayMesh from its shape-generated edge vertices: https://github.com/godotengine/godot/blob/4.6.3-stable/scene/resources/3d/shape_3d.cpp#L94
- Concave shape debug edges include its stored triangle corners, and get_faces returns the same faces sent to PhysicsServer: https://github.com/godotengine/godot/blob/4.6.3-stable/scene/resources/3d/concave_polygon_shape_3d.cpp#L33 and https://github.com/godotengine/godot/blob/4.6.3-stable/scene/resources/3d/concave_polygon_shape_3d.cpp#L84

No runtime code or tolerances were changed for this check. Actual imported contact census and operation remain pending until the reviewed integration window.

The related material pixel read is also supported by this exact headless backend: ImageTexture.get_image delegates to texture_2d_get, and Godot4.6.3's dummy TextureStorage retains a duplicate Image at initialization and returns it. This is cached source-pixel correspondence, separate from native appearance acceptance.

- https://github.com/godotengine/godot/blob/4.6.3-stable/scene/resources/image_texture.cpp#L106
- https://github.com/godotengine/godot/blob/4.6.3-stable/servers/rendering/dummy/storage/texture_storage.h#L75
