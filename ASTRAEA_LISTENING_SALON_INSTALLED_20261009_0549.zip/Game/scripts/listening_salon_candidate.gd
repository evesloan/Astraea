extends RefCounted
# Exact retained source plus separately owned floors. Installed construction WIP; operational and final-art acceptance remain open.
static func build(ship: Node3D) -> Node3D:
	var definition: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://data/architecture/SALON_RECEIVING_FLOORS_CANDIDATE.json"))
	assert(FileAccess.get_sha256("res://data/generated/structural_meshes.json")==str(definition.source_checks.baseline_structural_sha256))
	assert(FileAccess.get_sha256("res://data/generated/received_structural_meshes.json")==str(definition.source_checks.preceding_receiving_sha256))
	var file := "res://assets/models/SOL_D12_directory_03_remaining_r001.glb"
	assert(FileAccess.get_sha256(file)=="bea516d8227f76ba5c1436d225392877a942679a2c7409e3bcbc3e17cb94f36c")
	var districts := ship.get_node("ShipSpace/Districts")
	assert(districts.get_node_or_null("ListeningSalonReceiving_WIP")==null)
	var room := Node3D.new()
	room.name = "ListeningSalonReceiving_WIP"
	room.position = Vector3(-31,78,-324)
	room.set_meta("programme_key","D12_directory_03")
	room.set_meta("installed_acceptance",false)
	room.set_meta("listening_transfer","pending")
	var source: Node3D = (load(file) as PackedScene).instantiate()
	var originals := source.find_children("*","Light3D",true,false)
	assert(originals.size()==42)
	var lights: Array[Light3D] = []
	for original: SpotLight3D in originals:
		original.visible=false
		original.shadow_enabled=false
		original.set_meta("fixture_powered",false)
		original.set_meta("retained_source_light_witness",true)
		var light := SpotLight3D.new()
		light.name = str(original.name)+"_PhysicalSource"
		light.transform=original.transform
		light.light_color=original.light_color
		light.light_energy=1.2
		light.spot_range=8.0
		light.spot_angle=minf(original.spot_angle,65.0)
		light.spot_attenuation=1.0
		light.visible=false
		light.shadow_enabled=false
		light.set_meta("fixture_powered",true)
		light.set_meta("source_light_name",str(original.name))
		light.set_meta("calibration","bounded_initial_unaccepted")
		original.get_parent().add_child(light)
		lights.append(light)
	room.add_child(source)
	districts.add_child(room)
	var meshes := source.find_children("*","MeshInstance3D",true,false)
	assert(meshes.size()==3214)
	for mesh: MeshInstance3D in meshes:
		load("res://scripts/static_contact_cache.gd").attach(mesh)
	load("res://scripts/structural_floor_builder.gd").build_regions(ship.get_node("ShipSpace"),ship.stone,ship.ivory,definition.regions,{},"SalonCandidateStructuralFloors")
	# Register with the sole existing manager after the main scene's initial scan.
	# Preserve its8-source/32-candidate limits and avoid rescanning duplicate sources.
	var budget := ship.get_node("ShipSystems/LocalShadowSourceBudget")
	assert(budget.shadow_source_budget==8)
	for light: Light3D in lights:
		assert(not budget.sources.has(light))
		budget.sources.append(light)
		budget.requested_shadow[light.get_instance_id()]=true
	budget.refresh()
	room.set_meta("normalized_source_count",lights.size())
	return room
