# WP07 Listening salon — source design brief

Status: construction released by coordinator after current-manifest verification. Current inputs ARCHITECTURAL_DELIVERY_RULES.md supersedes older local map-first shorthand: complete first-pass materials, effective fixture lighting, usable furnishings and signage are required. Owner section_owner_07. Programme D12_directory_03, historical alias D12_listening2, audit AME-068. Every new identifier begins WP07 and is provisional, not a catalogue registration.

## Authority read and applied

Complete master chapters 5,19,21,23,30 read from MASTER_FULL_CONTENT_INDEX.json, retained locally in READ_SOURCE_CHAPTERS.json. MASTER_CURRENT_APPLICATION.json overrides historical implementation claims, species descriptions, views, presentation and accommodation assumptions. Architectural delivery rules, whole-ship coordination, coordinate contract and current Higgins receiving brief apply. Master **python-docx paragraph P516** is the social observation lounge/reference plate10: conversation groups, useful table reach, organizing ceiling curve, coordinated timber/fabric/light, diverse bodies, actual hull allocation. This equals content-index body_index534; index516 is a different heading. No assumed historical audio implementation.

## Allocation and section

Engine Y-up metres: X[-54,-8], Z[-358,-290], floorY78, nextY84. Origin[-31,78,-324]. Source Blender(x,y,z) becomes local GLB(x,z,-y), then translation by origin, no yaw or rescaling. Local engine X[-23,23], Z[-34,34], height0..6. All geometry stays inside the envelope. D11 music room partly overlaps below; D13 residences and every neighbour remain opaque and protected. No exterior window, skylight, cross-deck cut, loft or mezzanine.

One accessible floor, with distinct overhead zones: vestibule underside3.25m; quiet perimeter alcoves3.5m; main listening canopy underside4.6m, supported by inner pier pairs and wall bearings; top construction capped5.75m. Ceiling ribs terminate visibly into a continuous fascia and supporting piers; panels infill between supports. Every light has a modelled stem/bracket and a fixture body, plus a real source light. The entire plan is one coherent room with sheltered edges, not several unconnected display boxes.

## Plan and activity

The public portal is engine[-8,78,-324], clear4m wide and3.4m high. Its external4m link to axial route is unbuilt and parent-owned. Reserve the inward approach X[-18,-8], Z[-329,-319]. A deep acoustic vestibule uses two staggered screen walls and a wide turn; no functioning acoustic door is claimed. Visitors turn into a clear longitudinal promenade, then see three differently oriented listening/social islands beneath an articulated ceiling spine. Quiet edges curve around their own conversation groups and face the actual interior; no simulated exterior panorama.

Planned local engine zones (X,Z metres):

| Zone | Bounds | Purpose |
|---|---|---|
| Entry vestibule | X[13,23], Z[-5,5] | Nested solid reveals, offset acoustic screen and legible entrance sign |
| Interior promenade | X[7,12], Z[-29,29] | Continuous cart/public route, ends turn around into quiet edges |
| Main listening gallery | X[-18,6], Z[-23,23] | Three focal listening islands, supported ceiling bays, seated and broad-body open positions |
| Forward quiet edge | X[-19,7], Z[-32,-25] | Sheltered conversation groups with low screens and inset lamps |
| Aft quiet edge | X[-19,7], Z[25,32] | Alternative intimate resting pockets and reversible route |
| Inner listening/media wall | X[-22,-19], Z[-23,23] | Recessed audio consoles, modeled speaker cabinets, access panels and local media niches |
| Care/storage | X[14,21], Z[19,29] | Screened approach, reachable worktop/stock cupboard/cart parking |
| Arrival resting bays | X[14,21], Z[-29,-9] and Z[8,16] | Short-stay seats near entrance without obstructing the main approach |

Listening islands are staggered rather than copied rows. Curved upholstered benches and individual broad seats face each island's low, clearly modeled speaker/console focus. Tables are close to seats with an open service side. Counts describe placed source furniture only; there is **no invented certified venue capacity**. Exact source instances and reach/route clearances will be measured after construction. No canonical species-fit acceptance is inferred from generic seat dimensions; varied widths, open positions and broad routes provide a reviewable starting point for the receiving body's real envelopes.

## Material and reference application

The actual lounge S/REF-d0f54a5bb3 was opened: paired chairs, genuinely reachable side tables, coherent timber ceiling curve and distinct peripheral circulation. Transfer the composition; reject its exterior glazing. Library L/REF-b74349b557 was opened: deep circular reading retreat, thick arch and integrated light; use shallow ground-level curved listening alcoves, reject its upper gallery and external view. REF-980fe8b7e6 was also opened: inhabited upholstered shelf edge, integrated warm local lighting and framed focal scene; transfer layering only. Exact byte hashes are in REFERENCE_EVIDENCE.json. Q retro_atrium_quality_benchmark was opened: thick supported architecture, inhabited edges, structured material transitions and visible lighting hardware. Its atrium scale, glass lifts, stair systems and branded text are not assigned here.

Retain semantic warm_walnut, ivory_enamel, teal_weave, oatmeal_weave, champagne_metal, dark_rubber and warm_stone roles from standards/materials.py. Use packed original low-resolution catalogue textures with recorded provenance, purposeful UV metre scale and economical beveled silhouettes. Dark acoustic inserts are framed panels; bronze edges describe junctions, not strips concealing blank geometry. No copied reference branding or architecture.

## Physical and integration contract

No package extension beyond the allocation or modification of receiving core. Internal screened care route connects through the public-side promenade for this pass; every possible external staff link stays sealed/planned. Source-only route targets:4m portal,5m spine,3m connecting lanes, generous turning pockets; actual cart/capsule and species validation remains Higgins's integration task. Furniture has visible support, accessible front/side care stances, and named seat/table/fixture markers. Equipment models establish purpose but do not prove sound, interaction, music rights or NPC use.

Floor top stays exactlyY78. Coordinator-approved: source preview support slab below the datum is tagged SOURCE_PREVIEW_ONLY and excluded from delivered GLB. Deliver a separate floor polygon/contact JSON; receiver structural/collision ownership remains pending. No coplanar visual floor is exported. Ceiling closes belowY84. Review must check all walls/screens/fixtures against route reservations and all actual mesh bounds against the allocation.

## Evidence required before handoff

Reproducible Blender4.3.2 authoring script, editable .blend, portable textured GLB, exact object/source hashes, actual node-resolved exchange bounds, source reload check, support/contact markers and collision proposals. Source previews: ordinary-height arrival, main activity, quiet-edge reverse, care point and section. Independent visual review compares those exact renders with references; no source preview proves engine CRT appearance or traversal. Final states remain separate: constructed, source/export verified, visually reviewed, packaged for Higgins, installed, live accepted.
