# Scheduled execution for WP07

Native source is authored by source/build_listening_salon.py, syntax checked with Python before scheduling. Portable approved Blender4.3.2 lives at C:/Users/cered/Dolphin/AstraeaTools/blender-4.3.2-windows-x64/blender.exe. All commands below use the package as working directory. Coordinator executes heavy jobs serially.

1. Build/export: `blender.exe --background --python source/build_listening_salon.py`
2. Independent source reload and actual view capture: `blender.exe --background --python source/render_review.py -- arrival activity care quiet section`
3. Export/file validation: `python source/verify_package.py`

The builder fails on evaluated source bounds exceeding local Blender X[-23,23], Y[-34,34], Z[0,5.75]. Verify script resolves actual GLB scene node transforms and reads POSITION arrays; rejects preview floor export, boundary violations, external texture references or changed approved furniture sources. This is source and exchange QA, not cart/actor tests.

The source contains three fully supported shallow vaults above three staggered listening/social islands. Each has four clusters of four original approved chairs and two reachable tables. Seven western sheltered bench/media niches, four curved end retreats and three entry resting groups inhabit remaining edges. A screened care pocket has a cupboard, working surface, stock and cart reservation. Actual speaker cabinets, controls and media cases establish the listening programme. Every exported fixture has a visible mounting socket/stem/body and actual punctual spotlight; effective game-side lighting and budget remain untested.

The architectural shell remains opaque and enclosed. Native source floor, inlays and slab are SOURCE_PREVIEW_ONLY, excluded from GLB. Floor polygon and contact JSON must be adopted by receiver; the package does not magically become walkable when imported. Origin engine[-31,78,-324], zero rotation, unit scale. Portal engine[-8,78,-324],4m clear. The parent-owned4m lateral gap is unbuilt. No staff link is claimed connected.

Open each actual render, not just logs. Review arrival threshold depth and offset screen bypass, ceiling fascia/end conditions, pier-to-capital-to-vault joins, lamp mounts, table reach and usable chair approaches, ordinary view of speaker focus, quiet edges and care point. Do not infer approval from file production. Preserve any failed renders/logs for revision comparisons. Source preview captures are labelled SOURCE_ONLY in filenames; they are not Godot/CRT acceptance evidence.

Construction refinement: acoustic vestibule soffit spans local sourceY[-6.5,6.5], with bearing centresY+/-6.2. Its lower-screen bypass has a nominal4.2m gap to the south bearing face. This deliberate expansion stays inside allocation and leaves the public portal unchanged. Update acceptance measurements from exported geometry before declaring route clearance. No moving doors, audio playback, NPC actions or species-fit validation are implemented here.

## Current status

Source construction, source reload/capture and actual GLB verification have run. Coordinator inspected final preview-floor-corrected arrival, activity, quiet and care views and recorded source-candidate visual PASS. Section image is diagnostic only. Final hashes and review observations are bound in root_review.json and qa/final_native_binding.json. The preview backing repair has already been applied; do not rerun source/repair_preview_floor.py against this accepted native source. Installed traversal, floor/connector adoption, species fit, runtime lighting and receiving review remain open. This is a reviewed source candidate, not a completed installed section.
