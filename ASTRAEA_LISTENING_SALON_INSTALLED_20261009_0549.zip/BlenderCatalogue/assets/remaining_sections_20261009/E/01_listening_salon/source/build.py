import bpy,json,hashlib,pathlib,sys
from mathutils import Vector
P=pathlib.Path(__file__).resolve().parents[1];B=P.parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
base=P/'dependencies/WP07_retained.blend'
assert sha(base)=='7a66ea9ec7b14ba5f0fe4966d3fd290a7b5445f4f25334e0193bd9000de1dac6'
bpy.ops.wm.open_mainfile(filepath=str(base));s=bpy.context.scene
excluded=[];active=[]
for o in s.objects:
 if o.type=='LIGHT':
  if '_upper_source' in o.name:
   o['SOURCE_PREVIEW_ONLY']=True;o.hide_render=True;excluded.append(o.name)
  else:
   active.append(dict(id=o.name,watts=o.data.energy,world_xyz=[o.location.x-31,o.location.z+78,-o.location.y-324],fixture_preserved=True))
for im in bpy.data.images:
 if im.source=='FILE':
  if not im.packed_file:im.pack()
  assert im.packed_file
  if im.size[0]:_=im.pixels[0]
s['programme_key']='D12_directory_03';s['source_only']=True
rows=[];roofs=[];feet=[];dg=bpy.context.evaluated_depsgraph_get()
for o in s.objects:
 if o.type not in ['MESH','FONT'] or o.get('SOURCE_PREVIEW_ONLY'):continue
 ev=o.evaluated_get(dg);me=ev.to_mesh();points=[ev.matrix_world@v.co for v in me.vertices]
 if not points:ev.to_mesh_clear();continue
 lo=[min(v.x for v in points)-31,min(v.z for v in points)+78,-max(v.y for v in points)-324]
 hi=[max(v.x for v in points)-31,max(v.z for v in points)+78,-min(v.y for v in points)-324]
 r=dict(id=o.name,min_world=lo,max_world=hi,vertices=len(me.vertices),has_uv=bool(me.uv_layers));rows.append(r)
 if hi[1]>83:roofs.append(r)
 if lo[1]<=78.015:feet.append(r)
 ev.to_mesh_clear()
assert all(-54.002<=r['min_world'][0] and r['max_world'][0]<=-7.998 and 77.998<=r['min_world'][1] and r['max_world'][1]<=83.752 and -358.002<=r['min_world'][2] and r['max_world'][2]<=-289.998 for r in rows)
(P/'qa/SOURCE_GEOMETRY.json').write_text(json.dumps(rows,indent=2))
(P/'docs/ROOF_AND_CONTACT_ENVELOPE.json').write_text(json.dumps(dict(source_only=True,placement=[-31,78,-324],roof_objects=roofs,floor_contact_objects=feet,roof_top_y=max(r['max_world'][1] for r in rows),tidal_floor_underside_y=83.76,root_interface_hold='Longitudinal member centres X -45.8,-42.2,-28.75,-12.4,-8.55 at Y83.42 can intersect retained ceiling. No root beams inserted, deleted or shortened.',external_entry='X -8..-4 receiver/link held by root; retained portal width 4m height 3.4m',no_structural_certification=True),indent=2))
(P/'docs/LIGHT_BUDGET.json').write_text(json.dumps(dict(active_count=len(active),active=active,excluded_uplight_count=len(excluded),native_preserved_uplights=excluded,policy='Duplicate uplights disabled in source and excluded from export; all physical fixture bodies retained. Root must adopt bounded per-bay light groups and profile target GPU; watts are Blender source units, not verified photometry.',runtime_acceptance=False),indent=2))
contacts=json.loads((P/'exports/contact_markers.json').read_text());contacts['lights']=[a for a in contacts['lights'] if a['id'] not in excluded];contacts['source_continuation']='Retained geometry and seat/table markers unchanged; duplicate uplights excluded';(P/'exports/contact_markers.json').write_text(json.dumps(contacts,indent=2))
(P/'docs/PLACEMENT.json').write_text(json.dumps(dict(programme_key='D12_directory_03',translation=[-31,78,-324],rotation_degrees=[0,0,0],scale=[1,1,1],source_axes='Blender Z-up local',export_axes='glTF Y-up local (x,z,-y)',floor_y=78,roof_top_y=83.75),indent=2))
(P/'docs/PLAYBACK_AND_ACOUSTIC_READINESS.json').write_text(json.dumps(dict(source='Retained speaker cabinets, media niches, controls and access panels; acoustic vestibule and quiet screens preserved',runtime_audio='Root-held playback, attenuation, source limits, occupied acoustic audition; no finished soundtrack claimed',interaction='Existing RMB focus / E vocabulary preserved; no controllers changed',capacity='60 retained source seat instances and 52 table instances, not invented venue capacity',body_cart='4m portal, 5m promenade; seated fit, loaded cart and receiving floor/connector validation remain root gates',reference_application='Directly inspected original observation lounge and library pixels: reachable tables, nested alcoves, organizing timber ceiling. No exterior glazing copied.'),indent=2))
bpy.ops.wm.save_as_mainfile(filepath=str(P/'source/D12_directory_03.blend'))
# Export fonts as evaluated geometry, while the saved native retains editable text.
bpy.ops.object.select_all(action='DESELECT')
for o in list(s.objects):
 if o.type=='FONT' and not o.get('SOURCE_PREVIEW_ONLY'):
  o.select_set(True);bpy.context.view_layer.objects.active=o;bpy.ops.object.convert(target='MESH');o.select_set(False)
for o in s.objects:
 if not o.get('SOURCE_PREVIEW_ONLY') and o.type not in ['CAMERA']:o.select_set(True)
bpy.ops.export_scene.gltf(filepath=str(P/'exports/D12_directory_03.glb'),export_format='GLB',use_selection=True,export_apply=True,export_yup=True,export_extras=True,export_lights=True,export_cameras=False,export_texcoords=True)
native=sha(P/'source/D12_directory_03.blend');glb=sha(P/'exports/D12_directory_03.glb')
s.render.threads_mode='FIXED';s.render.threads=2;s.render.resolution_x=960;s.render.resolution_y=540;s.render.resolution_percentage=100
s.render.engine='CYCLES';s.cycles.samples=12;s.cycles.use_denoising=True
views=[]
for key in ['arrival','activity','quiet','care']:
 cam=bpy.data.objects['WP07_'+key];s.camera=cam;assert abs(cam.location.z-1.65)<.001
 s.render.filepath=str(P/'qa/views'/('SOURCE_ONLY_'+key+'.png'));bpy.ops.render.render(write_still=True)
 views.append(dict(file=pathlib.Path(s.render.filepath).name,sha256=sha(pathlib.Path(s.render.filepath)),camera_world=[cam.location.x-31,79.65,-cam.location.y-324],eye_m=1.65))
(P/'qa/view_receipt.json').write_text(json.dumps(dict(source_sha256=native,export_sha256=glb,source_only=True,views=views),indent=2))
print('LISTENING_SOURCE_BUILD',native,glb,len(active),flush=True)
