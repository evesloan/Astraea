import pathlib,struct,json,sys,math
sys.path.insert(0,r'C:\Users\cered\Dolphin\AstraeaTools\pythondeps')
import numpy as np
from shapely.geometry import Polygon,LineString,box
P=pathlib.Path(sys.argv[1]);place=json.loads((P/'docs/PLACEMENT.json').read_text());SEC=place['programme_key'];data=(P/'exports'/f'{SEC}.glb').read_bytes();off=12;chunks={}
while off<len(data):
 n,t=struct.unpack_from('<II',data,off);chunks[t]=data[off+8:off+8+n];off+=8+n
j=json.loads(chunks[0x4e4f534a]);binary=chunks[0x004e4942]
def acc(i):
 a=j['accessors'][i];b=j['bufferViews'][a['bufferView']];typ={5120:'i1',5121:'u1',5122:'<i2',5123:'<u2',5125:'<u4',5126:'<f4'}[a['componentType']];size={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']];dt=np.dtype(typ);start=b.get('byteOffset',0)+a.get('byteOffset',0);stride=b.get('byteStride',size*dt.itemsize)
 return np.ndarray((a['count'],size),dtype=dt,buffer=binary,offset=start,strides=(stride,dt.itemsize)).copy()
def mat(n):
 if 'matrix' in n:return np.array(n['matrix']).reshape(4,4).T
 x,y,z,w=n.get('rotation',[0,0,0,1]);r=np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])
 m=np.eye(4);m[:3,:3]=r@np.diag(n.get('scale',[1,1,1]));m[:3,3]=n.get('translation',[0,0,0]);return m
geometry={};places=[];light_count=0
def node(i,parent):
 global light_count
 n=j['nodes'][i];m=parent@mat(n);name=n.get('name',str(i));e=n.get('extras',{})
 if e.get('source_place_id'):places.append(e['source_place_id'])
 if 'KHR_lights_punctual' in n.get('extensions',{}):light_count+=1
 if 'mesh' in n:
  prims=[]
  for p in j['meshes'][n['mesh']]['primitives']:
   xyz=acc(p['attributes']['POSITION']);xyz=(np.c_[xyz,np.ones(len(xyz))]@m.T)[:,:3]+place['translation'];indices=acc(p['indices']).reshape(-1) if 'indices' in p else np.arange(len(xyz));tri=xyz[indices].reshape(-1,3,3);prims.append(tri)
  geometry[name]=np.concatenate(prims)
 for c in n.get('children',[]):node(c,m)
for i in j['scenes'][j.get('scene',0)]['nodes']:node(i,np.eye(4))
allpts=np.concatenate([a.reshape(-1,3) for a in geometry.values()]);bounds=[allpts.min(axis=0).tolist(),allpts.max(axis=0).tolist()]
source_scope=json.loads((pathlib.Path(__file__).resolve().parent/'SOURCE_SCOPE_RECONCILIATION.json').read_text());c=next(c for c in source_scope if c['programme_key']==SEC);poly=c['boundary_xz'];lo=[min(p[0] for p in poly),c['floor_y'],min(p[1] for p in poly)];hi=[max(p[0] for p in poly),83.75 if SEC.startswith('D12') else 76.84,max(p[1] for p in poly)]
contain=all(bounds[0][i]>=lo[i]-.002 and bounds[1][i]<=hi[i]+.002 for i in range(3))
def clip(v,plane):
 out=[]
 for a,b in zip(v,v[1:]+v[:1]):
  da=float(np.dot(plane[:3],a)+plane[3]);db=float(np.dot(plane[:3],b)+plane[3]);
  if da>=-1e-8:out.append(a)
  if (da<0)!=(db<0):out.append(a+(b-a)*(da/(da-db)))
 return out
# Actual finite triangles intersecting a floor-to-body band; sloped members use clipped
# surfaces, not a full AABB rectangle. Vertical thin faces retain their line footprint.
obstacles=[];F=c['floor_y']
for name,ts in geometry.items():
 for tri in ts:
  if tri[:,1].max()<F+.06 or tri[:,1].min()>F+1.9:continue
  vs=clip(list(tri),[0,1,0,-(F+.06)]);vs=clip(vs,[0,-1,0,F+1.9]) if vs else []
  if len(vs)<2:continue
  pts=[(float(v[0]),float(v[2])) for v in vs];p=Polygon(pts) if len(pts)>2 else LineString(pts)
  if not p.is_valid:p=p.buffer(0)
  if p.area<1e-10:p=LineString(pts).buffer(.002)
  obstacles.append((name,p))
routes=[]
cfg=json.loads((P/'docs/APPROACH_PROPOSALS.json').read_text())
for r in cfg:
 capsule=LineString(r['points_xz']).buffer(r['radius_m'],cap_style='round',join_style='round');hits={}
 for name,p in obstacles:
  if capsule.intersects(p):
   area=capsule.intersection(p).area
   if area>1e-6:hits[name]=hits.get(name,0)+area
 routes.append(dict(r,pass_screen=not hits,hits=[dict(name=n,overlap_m2=a) for n,a in hits.items()]))
(P/'qa/APPROACH_SCREENS.json').write_text(json.dumps(dict(scope='Actual GLB node-resolved triangle band, swept plan radius on proposed floor; no live cart or species acceptance',routes=routes),indent=2))
optics=None
if SEC=='D11_directory_06':
 zs=252.19;zl=308.47;L=zl-zs;planes=[]
 for side,v0,v1 in [('left',24,35.85),('right',48,36.15),('bottom',70.85,75.66),('top',75.65,75.88)]:
  k=(v1-v0)/L;sign=1 if side in ['left','bottom'] else -1;ax=0 if side in ['left','right'] else 1;p=[0.,0.,-sign*k,-sign*(v0-k*zs)];p[ax]=sign;planes.append(p)
 planes.extend([[0,0,1,-zs],[0,0,-1,zl]])
 hits=[]
 for name,ts in geometry.items():
  if name=='E_screen' or any(k in name for k in ['screen_notice','original_still','film_title','projector_']):continue
  for tri in ts:
   v=list(tri)
   for p in planes:
    v=clip(v,p) if v else []
   if len(v)>=3:
    area=sum(np.linalg.norm(np.cross(v[k]-v[0],v[k+1]-v[0]))/2 for k in range(1,len(v)-1))
    if area>1e-7:hits.append(dict(object=name,clipped_area_m2=float(area)));break
 optics=dict(screen_plane_z=zs,lens_plane_z=zl,finite_aperture=[[35.85,75.66],[36.15,75.88]],screen_field=[[24,70.85],[48,75.65]],pass_screen=not hits,hits=hits,scope='Actual exported triangles and finite projection frustum; original still surfaces and projector assembly intentionally excluded; source geometry test only')
 (P/'qa/OPTICAL_FRUSTUM.json').write_text(json.dumps(optics,indent=2))
receipt=dict(programme_key=SEC,actual_world_bounds=bounds,containment=contain,embedded_images=len(j.get('images',[])),embedded_image_uris=all('uri' not in im for im in j.get('images',[])),mesh_nodes=len(geometry),source_place_ids=len(places),unique_place_ids=len(set(places)),punctual_lights=light_count,preview_floor_absent=not any('QA_ONLY' in n or 'preview' in n.lower() for n in geometry),routes_pass=all(r['pass_screen'] for r in routes),optics=optics)
(P/'qa/ACTUAL_GLB_SOURCE_CHECK.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2));print('ROUTE_HITS',[(r['name'],[x['name'] for x in r['hits'][:8]]) for r in routes])
