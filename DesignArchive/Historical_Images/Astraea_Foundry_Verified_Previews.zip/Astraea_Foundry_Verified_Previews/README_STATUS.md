# Astraea Asset Foundry — verified preview handoff

## Status
Partial. This archive contains four recovered preview PNGs, not the complete production asset library.

The editable workbook/registries, individual texture files and material resources, 3D mesh exports, source generators, and complete Godot drop-in package were not located in the files available during this status check. Their existence or readiness is therefore unverified. No new source assets have been fabricated to fill those gaps.

## What is visible in the recovered previews
- Hero_Materials_Contact_Sheet.png: 24 labeled material swatches.
- Wayfinding_Contact_Sheet.png: 24 sign designs.
- Prop_Prototypes_Contact_Sheet.png: 12 prop illustrations/renders with labels, dimensions, and triangle counts. The image labels describe GLB prototypes, but the GLB files themselves are not present in this archive.
- Workbook_Overview.png: an overview screenshot, NOT an editable spreadsheet. It lists a proposed library of 128 room archetypes, 48 architectural families, 64 material families, 192 material finishes, 320 prop designs, 750 prop variants, 32 graphic systems, and 12 compatibility profiles. These are screenshot-reported scope figures, not a verified inventory of delivered files.

The workbook screenshot also claims first-wave outputs (72 tile finishes, 8 trim sets, 12 GLB prototypes, 24 signs, 16 hero-room recipes, 9 source conflicts). Those underlying files were not recovered here. Treat these claims as unverified, not completed delivery.

## Validation
The preview PNGs exist and can be opened. No Godot rendering, collisions, interaction, performance, import/reimport, or production visual-approval test is established by these images. The workbook screenshot itself marks these Godot checks NOT RUN.

This handoff is for reviewing the visible direction and accurately reporting status. It is not a Godot-ready pack.
