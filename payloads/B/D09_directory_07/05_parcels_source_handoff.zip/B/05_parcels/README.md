# Post & parcels / Batch B

Editable Blender 4.3.2 native: source/native.blend. Actual exchange asset: exports/section.glb. Exact placement: placements.json. Rebuild source and dependencies accompany the archive under B/. Run `python B/heavy_job.py 05_parcels full` from a restored project layout with the installed Blender path, or update the local tool path only. The wrapper holds the shared Windows named mutex and uses four Blender CPU threads.

QA includes five inspected normal 1.65m views, imported-native/export parity, actual surface support contacts, UV/resource/normal screens and sampled player, broad-body and actual-cart turning-envelope approaches. Floors, receiving connections, working doors and main Godot runtime adoption are root-owned and untested here. Source completion is not installed-ship acceptance.
