Programme: D02_directory_06 / Emergency stores

Dispatch throat opens into a stock street with four transverse shelving bays and separated checking/return edges. Fitted cases are inert; emergency inventory amounts remain unknown.

Authority: exact source checkpoint7955f22b2e1301bcfc8b5972f65073668377b803; full contract checkpointd2c54b3d60e663d7e77c16f694784fa947c9e0b3. All118 supplied input lengths and SHA256 verified. Master v0.3 remains unchanged; applicable full chapters and overlays reviewed. Original technical_reference.png pixels reviewed for programme separation, practical work edges and canonical remapping. Reference quantities do not create capacity.

No common/preview floor in native or GLB. Root must receive slab/support, entry connections, doors, collisions and live Godot adoption. Source screens do not establish live cart/species/CRT/performance, operation or occupancy acceptance. Fixture lighting and sparse furniture remain construction-stage proposals for Higgins to refine. No exterior opening or fabricated space-facing view.
