"""Batch B original fitted source proposals. Blender 4.3.2; metres.
Each rebuild is independent. Root owns structural adoption, floors, doors and runtime.
Run via heavy_job.py so all heavy work holds the shared Windows mutex.
"""
import bpy,math,json,sys,hashlib,random
from pathlib import Path
from mathutils import Vector
BASE=Path(__file__).resolve().parent
USED_SOURCE=Path(__file__).read_bytes()
USED_PROFILES=(BASE/'section_profiles.json').read_bytes()
CONFIG=json.loads(USED_PROFILES)
section=sys.argv[sys.argv.index('--')+1];mode=sys.argv[sys.argv.index('--')+2];C=CONFIG[section];P=BASE/section
for n in ['source','exports','qa/views','docs']: (P/n).mkdir(parents=True,exist_ok=True)
M={};A=[];LIGHTS=[];POLY=[];COL=None
if not mode.startswith('render'):
 (P/'source/build_used.py').write_bytes(USED_SOURCE)
 (P/'source/profiles_used.json').write_bytes(USED_PROFILES)
else:(P/'qa/render_used.py').write_bytes(USED_SOURCE)

def xyz(u,h,v):return (C['sign']*u,-v,h)
def uv(o):
 if o.type!='MESH':return
 o.data.update();layer=o.data.uv_layers.active or o.data.uv_layers.new(name='UV0')
 for f in o.data.polygons:
  drop=max(range(3),key=lambda i:abs(f.normal[i]));axes=[i for i in range(3) if i!=drop]
  for li in f.loop_indices:
   co=o.data.vertices[o.data.loops[li].vertex_index].co;layer.data[li].uv=(co[axes[0]]*.8,co[axes[1]]*.8)

def finish(o,n,mat,support='ROOT_FLOOR',role='fitted',bev=.025):
 o.name=n
 for c in list(o.users_collection):c.objects.unlink(o)
 COL.objects.link(o)
 if o.type=='MESH':
  if bev:
   bpy.context.view_layer.objects.active=o;mod=o.modifiers.new('Manufactured radius','BEVEL');mod.width=bev;mod.segments=2;bpy.ops.object.modifier_apply(modifier=mod.name)
  bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.normals_make_consistent(inside=False);bpy.ops.object.mode_set(mode='OBJECT');o.select_set(False)
  uv(o)
 o.data.materials.append(M[mat]);o['programme_key']=C['key'];o['support']=support;o['role']=role;A.append(o);return o

def box(n,u,h,v,w,ht,d,mat='wood',support='ROOT_FLOOR',role='fitted',bev=.025):
 bpy.ops.mesh.primitive_cube_add(size=1,location=xyz(u,h,v));o=bpy.context.object;o.dimensions=(w,d,ht);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,n,mat,support,role,min(bev,min(w,ht,d)*.3))
def prism(n,poly,h,ht,mat,sup='ROOT_FLOOR',role='fitted',bev=.025):
 vs=[xyz(u,h,v) for u,v in poly]+[xyz(u,h+ht,v) for u,v in poly];count=len(poly);faces=[tuple(reversed(range(count))),tuple(range(count,2*count))]+[(i,(i+1)%count,(i+1)%count+count,i+count) for i in range(count)]
 me=bpy.data.meshes.new(n);me.from_pydata(vs,[],faces);me.update();o=bpy.data.objects.new(n,me);COL.objects.link(o);return finish(o,n,mat,sup,role,bev)
def rod(n,a,b,r,mat='brass',sup='ROOT_FLOOR',role='support',vertices=12):
 pa=Vector(xyz(*a));pb=Vector(xyz(*b));delta=pb-pa;bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=r,depth=delta.length,location=(pa+pb)/2);o=bpy.context.object;o.rotation_euler=delta.to_track_quat('Z','Y').to_euler();bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,n,mat,sup,role,.007)
def disc(n,u,h,v,r,ht,mat,sup='ROOT_FLOOR',role='fitted'):
 return rod(n,(u,h,v),(u,h+ht,v),r,mat,sup,role,24)
def edge(n,a,b,h,ht,width,mat,sup='ROOT_FLOOR',role='enclosure'):
 du,dv=b[0]-a[0],b[1]-a[1];ln=math.hypot(du,dv);nu,nv=-dv/ln*width/2,du/ln*width/2
 return prism(n,[(a[0]+nu,a[1]+nv),(b[0]+nu,b[1]+nv),(b[0]-nu,b[1]-nv),(a[0]-nu,a[1]-nv)],h,ht,mat,sup,role)
def arc(n,u,v,r,a0,a1,h,ht,width,mat,sup='ROOT_FLOOR',role='fitted',steps=16):
 outer=[(u+(r+width/2)*math.cos(a0+(a1-a0)*i/steps),v+(r+width/2)*math.sin(a0+(a1-a0)*i/steps)) for i in range(steps+1)];inner=[(u+(r-width/2)*math.cos(a0+(a1-a0)*i/steps),v+(r-width/2)*math.sin(a0+(a1-a0)*i/steps)) for i in reversed(range(steps+1))];return prism(n,outer+inner,h,ht,mat,sup,role,.018)
def text(n,body,u,h,v,size=.18,sup='ROOT_FLOOR',face='entry'):
 cu=bpy.data.curves.new(n,'FONT');cu.body=body;cu.size=size;cu.align_x='CENTER';cu.extrude=.001;o=bpy.data.objects.new(n,cu);COL.objects.link(o);o.location=xyz(u,h,v);o.rotation_euler=(math.pi/2,0,-C['sign']*math.pi/2) if face=='entry' else (math.pi/2,0,0);o.data.materials.append(M['ivory']);o['support']=sup;o['role']='editable_sign';o['programme_key']=C['key'];A.append(o)
def lamp(n,u,v,h=3.2,sup='ROOT_FLOOR',cool=False):
 disc(n+'_foot',u,0,v,.22,.08,'brass');rod(n+'_stem',(u,.08,v),(u,h,v),.045,'brass',n+'_foot');disc(n+'_shade',u,h-.15,v,.33,.28,'cool' if cool else 'orange',n+'_stem');disc(n+'_lens',u,h-.18,v,.27,.04,'light',n+'_shade');LIGHTS.append(dict(name=n,pos=(u,h-.23,v),power=130 if cool else 180,color=(.72,.86,1) if cool else (1,.72,.40),size=1.0))
def ceiling_light(n,u,v,h,sup,power=350):
 rod(n+'_suspension',(u,h+.02,v),(u,C['ceiling']+.04,v),.04,'brass',sup);box(n+'_housing',u,h,v,1.7,.12,.85,'brass',n+'_suspension');box(n+'_lens',u,h-.075,v,1.55,.04,.7,'light',n+'_housing');LIGHTS.append(dict(name=n,pos=(u,h-.11,v),power=power,color=(1,.80,.58),size=2.5))
def counter(n,poly,mat='orange',top='stone',height=1.02):
 prism(n+'_base',poly,0,height-.1,mat,role='floor_contact');prism(n+'_top',poly,height-.1,.1,top,n+'_base',role='work_surface',bev=.045);return n+'_top'
def table(n,u,v,w=1.8,d=1.4,game=False):
 box(n+'_foot',u,.045,v,w*.58,.09,d*.65,'brass',role='floor_contact');box(n+'_stem',u,.42,v,.22,.68,.22,'brass',n+'_foot');box(n+'_top',u,.80,v,w,.12,d,'wood',n+'_stem','activity_surface',.055)
 if game:
  box(n+'_board',u,.876,v,w*.62,.035,d*.64,'teal',n+'_top','inert_tabletop_display',.015)
  for i in range(5):
   disc(n+'_piece'+str(i),u-.42+i*.21,.895,v-.18+(i%2)*.34,.065,.08,'ivory' if i%2 else 'orange',n+'_board','inert_tabletop_piece')
 return n+'_top'
def chair(n,u,v,angle=0):
 disc(n+'_foot',u,0,v,.35,.07,'brass',role='floor_contact');disc(n+'_stem',u,.07,v,.08,.33,'brass',n+'_foot');box(n+'_seat',u,.46,v,.78,.12,.78,'cloth',n+'_stem','supported_rest',.05)
 du,dv=math.cos(angle)*.33,math.sin(angle)*.33;back=box(n+'_back',u+du,.87,v+dv,.16,.79,.72,'cloth',n+'_seat','supported_rest',.05)
 if C['kind']=='games':back.rotation_euler[2]=-C['sign']*angle
def bench(n,u,v,length=3.8,back='north'):
 box(n+'_plinth',u,.19,v,length,.38,.92,'wood',role='floor_contact');box(n+'_cushion',u,.46,v,length-.12,.16,.88,'cloth',n+'_plinth','supported_rest',.065);box(n+'_back',u,.92,v+.41 if back=='north' else v-.41,length,1.00,.18,'cloth',n+'_plinth','supported_rest',.055)
def shelf(n,u,v,length=4.0,height=2.6,items='books',mat='wood',reverse=False):
 box(n+'_back',u+(-.5 if reverse else .5),height/2,v,.16,height,length,mat,role='floor_contact');box(n+'_plinth',u,.08,v,1.15,.16,length,mat,role='floor_contact')
 for j in range(4):
  h=.32+j*.64;box(n+'_shelf'+str(j),u,h,v,1.1,.08,length,mat,n+'_back','stock_surface')
  for i in range(int(length/.45)-1):
   vv=v-length/2+.4+i*.45;hh=.36 if items=='books' else .30
   if items=='bread':
    disc(n+'_tray'+str(j)+'_'+str(i),u,h+.04,vv,.20,.035,'brass',n+'_shelf'+str(j));box(n+'_loaf'+str(j)+'_'+str(i),u,h+.04+.035+hh/2,vv,.42,hh,.27,'oatmeal',n+'_tray'+str(j)+'_'+str(i),'display_bakery_food',.09)
   else:
    box(n+'_stock'+str(j)+'_'+str(i),u,h+.04+hh/2,vv,.50,hh,.22 if items=='books' else .36,['teal','orange','ivory'][i%3],n+'_shelf'+str(j),'book_stock' if items=='books' else 'parcel_stock',.015)
 for vv in [v-length/2+.06,v+length/2-.06]:box(n+'_end'+str(vv),u,height/2,vv,1.1,height,.12,mat,n+'_plinth')
def plant(n,u,v):
 disc(n+'_pot',u,0,v,.55,.65,'orange',role='floor_contact');rod(n+'_stem',(u,.65,v),(u,1.75,v),.065,'wood',n+'_pot')
 for i in range(6):
  a=i*math.tau/6;bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1,radius=.7,location=xyz(u+.32*math.cos(a),1.4+.20*(i%2),v+.32*math.sin(a)));o=bpy.context.object;o.scale=(.7,.5,1.0);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);finish(o,n+'_leaf'+str(i),'green',n+'_stem','plant',0)
def catalogue(n,id,u,v,angle=0):
 cat=json.loads((BASE/'dependencies/catalogue_manifest.json').read_text());rec=next(a for a in cat['assets'] if a['catalogue_id']==id);path=BASE/'dependencies/catalogue'/rec['source'];loaded=[]
 with bpy.data.libraries.load(str(path),link=False) as (src,dst):dst.objects=[o for o in src.objects]
 objs=[o for o in dst.objects if o and o.type=='MESH']; pts=[o.matrix_world@Vector(c) for o in objs for c in o.bound_box];minz=min(p.z for p in pts);cx=(min(p.x for p in pts)+max(p.x for p in pts))/2;cy=(min(p.y for p in pts)+max(p.y for p in pts))/2
 for i,o in enumerate(objs):
  COL.objects.link(o);o.hide_viewport=False;o.hide_render=False;o.hide_select=False;o.hide_set(False);world=o.matrix_world.copy();o.parent=None;me=o.data.copy();o.data=me
  for vert in me.vertices:
   q=world@vert.co;xx=q.x-cx;yy=q.y-cy;uu=u+xx*math.cos(angle)-yy*math.sin(angle);vv=v-xx*math.sin(angle)-yy*math.cos(angle);vert.co=xyz(uu,q.z-minz,vv)
  o.matrix_world.identity();
  if world.to_3x3().determinant()*C['sign']<0:me.flip_normals()
  me.update();o.name=n+'_'+str(i);o['support']='ROOT_FLOOR' if min((o.matrix_world@Vector(c)).z for c in o.bound_box)<.02 else n+'_0';o['role']='catalogue_'+id;o['programme_key']=C['key'];uv(o);A.append(o)
 for im in bpy.data.images:
  if im.source=='FILE' and not im.packed_file:
   try:im.pack()
   except Exception:pass

def materials():
 specs={'wood':'warm_walnut','brass':'champagne_metal','cloth':'clay_weave','oatmeal':'oatmeal_weave','ivory':'ivory_enamel','rubber':'dark_rubber','stone':'warm_stone','teal':'teal_weave','cool':'staff_bluegrey_paint','zinc':'staff_zinc','white':'staff_white_paint','light':'staff_opal','orange':'ivory_enamel','green':'teal_weave'}
 for key,fn in specs.items():
  ma=bpy.data.materials.new('B_'+key);ma.use_nodes=True;bs=ma.node_tree.nodes.get('Principled BSDF');bs.inputs['Roughness'].default_value=.78;bs.inputs['Metallic'].default_value=.45 if key in ['brass','zinc'] else 0;im=bpy.data.images.load(str(BASE/'dependencies/materials'/(fn+'.png')),check_existing=True);im.pack();tx=ma.node_tree.nodes.new('ShaderNodeTexImage');tx.image=im;tx.interpolation='Closest'
  if key in ['orange','green']:
   mix=ma.node_tree.nodes.new('ShaderNodeMixRGB');mix.blend_type='MULTIPLY';mix.inputs[0].default_value=1;mix.inputs[2].default_value=(.85,.24,.045,1) if key=='orange' else (.22,.55,.25,1);ma.node_tree.links.new(tx.outputs['Color'],mix.inputs[1]);ma.node_tree.links.new(mix.outputs['Color'],bs.inputs['Base Color'])
  else:ma.node_tree.links.new(tx.outputs['Color'],bs.inputs['Base Color'])
  if key=='light':bs.inputs['Emission Color'].default_value=(1,.7,.35,1);bs.inputs['Emission Strength'].default_value=2
  M[key]=ma


def fan_roof(poly,edgeh,peak,centre):
 for i,(a,b) in enumerate(zip(poly,poly[1:]+poly[:1])):
  coords=[(a[0],edgeh,a[1]),(b[0],edgeh,b[1]),(centre[0],peak,centre[1])];vs=[xyz(*q) for q in coords]+[xyz(q[0],q[1]+.20,q[2]) for q in coords]
  me=bpy.data.meshes.new('Folded_roof_'+str(i));me.from_pydata(vs,[],[(2,1,0),(3,4,5),(0,1,4,3),(1,2,5,4),(2,0,3,5)]);me.update();o=bpy.data.objects.new('Folded_roof_'+str(i),me);COL.objects.link(o);finish(o,'Folded_roof_'+str(i),'ivory','Perimeter_'+str(min(i,len(poly)-2)),'folded_ceiling',0)
def fan_height(u,v):
 c=(26,34)
 for a,b in zip(POLY,POLY[1:]+POLY[:1]):
  den=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1])
  if abs(den)<1e-8:continue
  wa=((b[1]-c[1])*(u-c[0])+(c[0]-b[0])*(v-c[1]))/den;wb=((c[1]-a[1])*(u-c[0])+(a[0]-c[0])*(v-c[1]))/den;wc=1-wa-wb
  if min(wa,wb,wc)>=-.0001:return 4.8+(C['ceiling']-4.8)*wc
 return C['ceiling']
def clip_u(poly,limit,left):
 out=[]
 for a,b in zip(poly,poly[1:]+poly[:1]):
  ia=a[0]<=limit if left else a[0]>=limit;ib=b[0]<=limit if left else b[0]>=limit
  if ia:out.append(a)
  if ia!=ib:
   t=(limit-a[0])/(b[0]-a[0]);out.append((limit,a[1]+t*(b[1]-a[1])))
 return out


def architecture():
 global POLY
 kind=C['kind']
 if kind in ['stores','crewcare','breakroom','dining','hydration','waiting','pharmacy']:return expanded_architecture()
 if kind=='archive':POLY=[(0,31.6),(6,31.6),(6,10),(13,5),(39,5),(43,10),(43,58),(38,63),(13,63),(6,58),(6,36.4),(0,36.4)]
 elif kind=='inspection':POLY=[(0,31.6),(6,31.6),(6,24),(12,20),(12,7),(40,7),(43,12),(43,56),(40,61),(12,61),(12,48),(6,44),(6,36.4),(0,36.4)]
 else:POLY=[(0,31.6),(6,31.6),(6,12),(12,8),(40,8),(43,12),(43,56),(38,61),(12,61),(6,56),(6,36.4),(0,36.4)]
 for i,(a,b) in enumerate(zip(POLY,POLY[1:]+POLY[:1])):
  if a[0]==b[0]==0:continue
  edge('Enclosure_'+str(i),a,b,0,4.35,.20,'cool',role='floor_contact')
 # A shallow solid folded lid carried by actual walls, with a raised longitudinal work spine.
 fan_roof(POLY,4.35,5.15,(26,34))
 for vv in [31.2,36.8]:box('Portal_cheek'+str(vv),4,1.45,vv,4,2.9,.25,'cool',role='floor_contact')
 box('Portal_head',4,2.98,34,4,.16,5.9,'cool','Portal_cheek31.2')
 box('Identity_panel',5.9,2.0,31.2,.15,.45,2.7,'white','Portal_cheek31.2');text('Identity',C['name'].upper(),5.80,2.0,31.2,.11,'Identity_panel')
 for j,(u,v) in enumerate([(16,15),(34,15),(16,51),(34,51),(26,34)]):ceiling_light('Work_light'+str(j),u,v,4.1,'Folded_roof_2',800)
 (P/'docs/floor_proposal.json').write_text(json.dumps({'status':'Root receiving proposal only; absent from native/export','programme_key':C['key'],'local_xz':[[C['sign']*u,v]for u,v in POLY],'translation_xyz':[C['sign']*C['x'],C['floor'],C['z']],'entry_proposal_xyz':[C['sign']*C['x'],C['floor'],C['z']+34],'clear_width_m':3.6,'clear_height_m':2.65,'portal_keep_clear_world_xz':[[C['sign']*C['x']-2,C['z']+32],[C['sign']*C['x']+2,C['z']+32],[C['sign']*C['x']+2,C['z']+36],[C['sign']*C['x']-2,C['z']+36]],'holds':'Root slab support, connections, shared portals, installed collision/navigation and operation'},indent=2))

def cabinet(n,u,v,w=1.8,d=1.2,h=2.6):
 box(n+'_body',u,h/2,v,w,h,d,'cool',role='floor_contact');box(n+'_front',u-w/2-.02,h/2,v,.06,h-.16,d-.12,'white',n+'_body');box(n+'_grip',u-w/2-.08,h*.55,v,.06,.34,.07,'zinc',n+'_front')

def worktop(n,u,v,w,d,h=.92):
 return counter(n,[(u-w/2,v-d/2),(u+w/2,v-d/2),(u+w/2,v+d/2),(u-w/2,v+d/2)],'cool','zinc',h)

def archive():
 # Four archive streets terminate on a central consultation court, leaving a separate service aisle.
 for j,u in enumerate([20,33]):
  for i,v in enumerate([14,23,46,55]):
   for k in range(3):cabinet('Archive_bank_'+str(j)+'_'+str(i)+'_'+str(k),u,v-2.8+k*2.8,1.5,2.5,2.7)
 counter('Consultation_core',[(14,31),(24,31),(27,34),(24,37),(14,37)],'cool','zinc',.92)
 for i,u in enumerate([17,21]):box('Archive_document'+str(i),u,.965,34,1.3,.09,1.8,'ivory','Consultation_core_top','inert_document_case')
 worktop('Intake_sorting',38,34,3,8)
 for v in [31,37]:box('Transfer_case'+str(v),38,1.17,v,1.8,.50,1.1,'white','Intake_sorting_top')
 for i,v in enumerate([17,52]):bench('Staff_consultation'+str(i),11,v,4);table('Consultation_table'+str(i),11,v-1.7,2.5,1.1)
 catalogue('Care_cabinet','AST-STF-007',38,58)
 for v in [12,25,44,57]:box('Archive_aisle_end'+str(v),27,1.55,v,.25,3.1,.4,'zinc',role='floor_contact');rod('Archive_aisle_header'+str(v),(20,3.05,v),(34,3.05,v),.08,'zinc','Archive_aisle_end'+str(v))

def inspection():
 # Long inspection lane remains floor-free and unoccupied; fitted inspection edges remain on both sides.
 for j,v in enumerate([17,31,47]):
  for u in [18,35]:
   worktop('Inspection_station'+str(j)+'_'+str(u),u,v,2.5,5)
   box('Inspection_console'+str(j)+'_'+str(u),u,1.17,v,1.7,.50,.8,'white','Inspection_station'+str(j)+'_'+str(u)+'_top')
  for u in [20,33]:box('Inspection_frame'+str(j)+'_'+str(u),u,1.65,v,.30,3.3,.30,'zinc',role='floor_contact')
  edge('Inspection_gantry'+str(j),(20,v),(33,v),3.2,.20,.35,'cool','Inspection_frame'+str(j)+'_20')
 for v in [15,54]:cabinet('Inspection_stow'+str(v),40,v,2,4,2.7)
 catalogue('Care_cabinet','AST-STF-007',39,58)
 worktop('Intake_desk',11,28,3,3);bench('Inspection_wait',9,42,4)

def workshop():
 # A broad cruciform work aisle separates fabrication, repair and clean bench pockets.
 for j,(u,v) in enumerate([(17,18),(34,18),(17,50),(34,50)]):
  worktop('Repair_bench'+str(j),u,v,5,5)
  for k in range(3):box('Tool_case'+str(j)+'_'+str(k),u-1.5+k*1.5,1.08,v,.9,.32,1.1,'white','Repair_bench'+str(j)+'_top')
  cabinet('Workshop_stock'+str(j),u,v+5,2,4,2.6)
 worktop('Shared_assembly',26,34,6,8)
 for v in [11,57]:box('Workshop_rackpost'+str(v),41,1.7,v,.5,3.4,.5,'zinc',role='floor_contact');rod('Workshop_angled_service'+str(v),(41,3.3,v),(15,4.0,v+2),.10,'zinc','Workshop_rackpost'+str(v))
 catalogue('Care_cabinet','AST-STF-007',39,55)


def expanded_architecture():
 global POLY
 kind=C['kind'];low=C['key'].startswith('D03')
 if kind=='crewcare':
  POLY=[(0,31.6),(6,31.6),(6,28),(38,28),(42,32),(42,58),(38,63),(12,63),(6,58),(6,36.4),(0,36.4)]
  polys=[POLY,[(6,5),(38,5),(42,9),(42,16),(38,20),(6,20)]]
 elif kind=='dining':
  POLY=[(0,31.6),(6,31.6),(6,4),(39.5,4),(40,8),(40,60),(39.5,64),(6,64),(6,36.4),(0,36.4)];polys=[POLY]
 elif kind=='breakroom':
  POLY=[(0,31.6),(6,31.6),(6,10),(15,5),(35,5),(40,12),(40,58),(34,63),(14,63),(6,57),(6,36.4),(0,36.4)];polys=[POLY]
 elif kind=='hydration':
  POLY=[(0,31.6),(6,31.6),(6,22),(13,18),(13,7),(36,7),(43,14),(43,59),(36,63),(13,63),(6,55),(6,36.4),(0,36.4)];polys=[POLY]
 elif kind=='waiting':
  POLY=[(0,31.6),(6,31.6),(6,14),(15,6),(34,6),(43,15),(43,53),(34,62),(15,62),(6,54),(6,36.4),(0,36.4)];polys=[POLY]
 elif kind=='pharmacy':
  POLY=[(0,31.6),(6,31.6),(6,12),(12,7),(38,7),(43,12),(43,58),(37,63),(12,63),(6,57),(6,36.4),(0,36.4)];polys=[POLY]
 else:
  POLY=[(0,31.6),(6,31.6),(6,20),(12,16),(12,7),(39,7),(43,12),(43,58),(38,63),(12,63),(12,52),(6,48),(6,36.4),(0,36.4)];polys=[POLY]
 edgeh=3.25 if low else 4.35;peak=3.70 if low else 5.15
 for j,poly in enumerate(polys):
  for i,(a,b)in enumerate(zip(poly,poly[1:]+poly[:1])):
   if a[0]==b[0]==0:continue
   if kind in ['breakroom','dining'] and a[0]==b[0]==40:
    vv=46 if kind=='breakroom' else 34
    edge('Retained_interface_lower',a,(40,vv-1.8),0,edgeh,.20,'cool',role='floor_contact')
    edge('Retained_interface_upper',(40,vv+1.8),b,0,edgeh,.20,'cool',role='floor_contact');continue
   if kind=='crewcare'and j==1 and a[0]==b[0]==6:
    edge('Pod_open_lower',a,(6,16),0,edgeh,.2,'cool',role='floor_contact');edge('Pod_open_upper',(6,12),b,0,edgeh,.2,'cool',role='floor_contact');continue
   edge('Enclosure_'+str(j)+'_'+str(i),a,b,0,edgeh,.20,'wood'if kind=='waiting'else'cool',role='floor_contact')
  # Independent folded lids never cross the protected retained corridor.
  before=set(o.name for o in A);fan_roof(poly,edgeh,peak,(25,13 if j else 44 if kind=='crewcare'else 34))
  for o in A:
   if o.name not in before and o.name.startswith('Folded_roof_'):o.name='Pod'+str(j)+'_'+o.name
 for vv in [31.2,36.8]:box('Portal_cheek'+str(vv),4,1.40,vv,4,2.8,.25,'wood'if kind=='waiting'else'cool',role='floor_contact')
 box('Portal_head',4,2.88,34,4,.16,5.9,'cool','Portal_cheek31.2');box('Identity_panel',5.9,2,31.2,.15,.45,2.7,'white','Portal_cheek31.2');text('Identity',C['name'].upper(),5.8,2,31.2,.11,'Identity_panel')
 pts=[(18,34),(34,48),(18,56),(34,32),(24,14)]if kind=='crewcare'else[(16,15),(34,15),(16,51),(34,51),(25,34)]
 for j,(u,v)in enumerate(pts):ceiling_light('Work_light'+str(j),u,v,2.90 if low else 4.1,'Pod0_Folded_roof_2',650 if low else 800)
 C['preview_polygons']=polys
 (P/'docs/floor_proposal.json').write_text(json.dumps({'status':'Root receiving proposal; no floor native/export','programme_key':C['key'],'polygons_local_xz':[[[C['sign']*u,v]for u,v in p]for p in polys],'translation_xyz':[C['sign']*C['x'],C['floor'],C['z']],'protected_corridors':'Exact retained polygons and actual geometry excluded; root connection/adoption pending','entry_kind':'Internal source arrival; exact retained root interface in source_gate contract governs'},indent=2))

def stores():
 for j,v in enumerate([15,25,43,53]):
  for side,u in enumerate([17,36]):
   shelf('Emergency_bay'+str(j)+'_'+str(side),u,v,6,2.8,'parcels','cool')
 worktop('Dispatch_check',36,34,6,4);worktop('Returned_cases',15,58,3,4)
 catalogue('Care_cabinet','AST-STF-007',39,58)
 for j,v in enumerate([14,53]):
  box('Stock_end_post'+str(j),29,1.6,v,.25,3.2,.35,'zinc',role='floor_contact');rod('Stock_aisle_service'+str(j),(17,3.15,v),(36,3.15,v),.065,'zinc','Stock_end_post'+str(j))

def crewcare():
 worktop('Crew_help',15,38,5,3)
 for j,v in enumerate([45,54]):
  bench('Private_conversation'+str(j),35,v,4);table('Conversation_table'+str(j),35,v-2,2.5,1.2)
  edge('Privacy_return'+str(j),(29,v-3),(29,v+2),0,2.2,.15,'cool',role='floor_contact')
 catalogue('Care_cabinet','AST-STF-007',38,58)
 worktop('Supply_check',35,16,4,3);cabinet('Crew_supply',38,8,3,3,2.6)
 bench('Quiet_staff_pause',17,10,6);table('Quiet_table',17,12,3,1.2)
 edge('Quiet_screen',(25,16),(25,19),0,2.2,.16,'cool',role='floor_contact')

def breakroom():
 places=[]
 for j,(u,v)in enumerate([(15,15),(33,15),(15,25),(33,25),(15,43),(33,43),(15,54)]):
  table('Break_table'+str(j),u,v,1.5,1.4)
  for k,du in enumerate([-1.35,1.35]):
   chair('Break_place'+str(j)+'_'+str(k),u+du,v,math.pi if du<0 else 0);places.append({'name':'Break_place'+str(j)+'_'+str(k)+'_seat','u':u+du,'v':v,'seat_y':.52})
 arc('Conversation_crescent',24,19,14,0.15,2.8,0,1.65,.20,'cool',role='floor_contact')
 worktop('Kettle_return',34,58,6,3);cabinet('Break_supply',37,52,2,2,2.4)
 box('Kettle_vessel',34,1.13,58,.7,.42,.6,'white','Kettle_return_top');(P/'source/place_contacts.json').write_text(json.dumps({'historical_break_places':14,'physical_places':places,'no_new_berths':True},indent=2))

def dining():
 places=[]
 for j,v in enumerate([10,19,28,40,49,58]):
  for i,u in enumerate([12,18,24,30,36]):
   n='Mess_'+str(j)+'_'+str(i);worktop(n,u,v,2.2,5.4,.80)
   for side in [-1,1]:
    bu=u+side*1.7;box(n+'_bench'+str(side),bu,.20,v,.9,.4,5.2,'cool',role='floor_contact')
    for k in range(5):
     vv=v-2+k;sn=n+'_seat'+str(side)+'_'+str(k);box(sn,bu,.48,vv,.9,.16,.9,'cloth',n+'_bench'+str(side),'supported_meal_place',.03)
     places.append({'name':sn,'u':bu,'v':vv,'seat_y':.56,'approach_u':u+side*2.9,'approach_v':vv})
 for n,v in [('Serving',4.9),('Return',63.1)]:worktop(n,25,v,18,1.2,.92)
 catalogue('Care_cabinet','AST-STF-007',38.5,34)
 (P/'source/place_contacts.json').write_text(json.dumps({'historical_meal_places':300,'physical_places':places,'live_occupancy_unaccepted':True,'crew_total_unchanged':400},indent=2))

def hydration():
 worktop('Hydration_help',14,27,5,3)
 for j,v in enumerate([15,30,46]):
  bench('Support_bay'+str(j),35,v,4);table('Hydration_side_surface'+str(j),35,v-2,2.2,1.2)
  edge('Hydration_privacy'+str(j),(30,v-3),(30,v+2),0,2.25,.18,'cool',role='floor_contact')
 worktop('Wash_dispense_edge',15,53,4,6);cabinet('Sealed_hydration_supplies',39,55,2,3,2.6)
 for j,v in enumerate([51,54]):
  box('Wash_tray'+str(j),15,.99,v,2,.14,1.2,'white','Wash_dispense_edge_top')
  rod('Fitted_spout'+str(j),(15,1.02,v),(15,1.35,v),.045,'zinc','Wash_tray'+str(j))
 catalogue('Care_cabinet','AST-STF-007',38,59)

def waiting():
 counter('Assistance_front',[(13,24),(17,24),(19,26),(19,30),(13,30)],'wood','stone',.94)
 for j,(u,v)in enumerate([(16,16),(34,16),(16,47),(34,47)]):
  bench('Companion_cluster'+str(j),u,v,4,'south'if j<2 else'north');table('Companion_table'+str(j),u,v+(2 if j<2 else-2),2.5,1.3)
  backv=v-1.4 if j<2 else v+1.4
  edge('Cluster_shelter'+str(j),(u-2.5,backv),(u+2.5,backv),0,1.75,.16,'wood',role='floor_contact')
 bench('Quiet_alcove',33,55,5);table('Quiet_side',33,53,2.5,1.2)
 edge('Quiet_return',(38,51),(38,57),0,2.15,.18,'wood',role='floor_contact')
 catalogue('Care_cabinet','AST-STF-007',36,58);worktop('Staff_check',13,57,4,3)
 for u,v in [(10,21),(40,21)]:plant('Waiting_plant'+str(u),u,v)

def pharmacy():
 worktop('Guest_help',19,24,3,7);worktop('Dispensing_proposal',19,43,3,8)
 for v in [19,50]:edge('Frontage_privacy'+str(v),(21,v-5),(21,v+5),0,2.5,.16,'cool',role='floor_contact')
 for j,u in enumerate([30,38]):
  for k,v in enumerate([16,25,45,54]):cabinet('Pharmacy_bank'+str(j)+'_'+str(k),u,v,1.8,6,2.7)
 worktop('Inventory_check',35,34,5,4);worktop('Returned_item_check',12,53,3,3)
 catalogue('Care_cabinet','AST-STF-007',38,59)

VIEWS_EXTRA={
 'stores':[('arrival',(2,34),(26,34)),('stock',(26,20),(35,25)),('dispatch',(30,30),(36,34)),('return',(20,58),(15,58)),('care',(35,60),(39,58))],
 'crewcare':[('arrival',(2,34),(22,38)),('help',(10,34),(15,38)),('conversation',(31,43),(35,45)),('forward_pod',(8,14),(29,13)),('care',(35,61),(38,58))],
 'breakroom':[('arrival',(2,34),(24,34)),('pairs',(29,15),(33,15)),('crescent',(24,23),(15,25)),('return',(29,55),(34,58)),('receiving',(34,46),(40,46))],
 'dining':[('arrival',(2,34),(26,34)),('meal_field',(8,19),(25,19)),('cross_aisle',(24,34),(36,40)),('serving',(13,6.4),(25,4.9,1.05)),('return',(13,61.6),(25,63.1,1.05))],
 'hydration':[('arrival',(2,34),(23,34)),('support',(31,18),(35,15)),('wash',(20,53),(15,53)),('privacy',(23,42),(35,46)),('care',(35,61),(38,59))],
 'waiting':[('arrival',(2,34),(24,34)),('companions',(24,18),(34,16)),('help',(11,34),(17,27)),('quiet',(30,52),(33,55)),('service',(32,59),(36,58,1.05))],
 'pharmacy':[('arrival',(2,34),(19,34)),('help',(13,24),(19,24)),('stock',(26,23),(33,25)),('checking',(28,34),(35,34)),('care',(35,61),(38,59))]
}

VIEWS={
 'archive':[('arrival',(2,34),(23,34)),('consultation',(11,34),(23,34)),('collection',(15,18),(22,23)),('service',(32,34),(39,34)),('care',(35,61),(38,58))],
 'inspection':[('arrival',(2,34),(25,34)),('inspection',(25,26),(25,47)),('station',(29,33.5),(35,31)),('intake',(7,29),(12,28)),('care',(34,58),(39,58))],
 'workshop':[('arrival',(2,34),(26,34)),('assembly',(20,34),(27,34)),('repair',(11,18),(17,18)),('storage',(30,24),(34,23)),('care',(36,58),(39,55))]}
VIEWS.update(VIEWS_EXTRA)

def bbox(o):
 pts=[o.matrix_world@Vector(c) for c in o.bound_box];return [[min(p[i] for p in pts),max(p[i] for p in pts)] for i in range(3)]
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def export():
 bpy.context.view_layer.update();bpy.ops.object.select_all(action='DESELECT');temp=[]
 for o in A:
  if o.type=='FONT':
   copy=o.copy();copy.data=o.data.copy();COL.objects.link(copy);copy.name=o.name+'_export';bpy.context.view_layer.objects.active=copy;copy.select_set(True);bpy.ops.object.convert(target='MESH');temp.append(bpy.context.object);o.select_set(False)
  else:o.select_set(True)
 (P/'qa/export_selection.json').write_text(json.dumps([{'name':o.name,'selected':o.select_get(),'hide':o.hide_get(),'hide_viewport':o.hide_viewport,'hide_render':o.hide_render,'visible':o.visible_get()} for o in A],indent=2))
 bpy.ops.export_scene.gltf(filepath=str(P/'exports'/('section.glb')),export_format='GLB',use_selection=True,export_apply=True,export_extras=True,export_texcoords=True,export_normals=True,export_cameras=False,export_lights=False)
 for o in temp:bpy.data.objects.remove(o,do_unlink=True)

def validation():
 errors=[];rows=[]
 for o in A:
  bb=bbox(o);ok=bb[0][0]>=(-46 if C['sign']==-1 else 0)-.002 and bb[0][1]<=(0 if C['sign']==-1 else 46)+.002 and bb[1][0]>=-68-.002 and bb[1][1]<=.002 and bb[2][0]>=-.002 and bb[2][1]<=C['roof']-C['floor']+.002
  if not ok:errors.append({'name':o.name,'containment':bb})
  if o.type=='MESH':
   if not o.data.uv_layers:errors.append({'name':o.name,'error':'UV missing'})
   if any(not math.isfinite(float(x)) for v in o.data.vertices for x in v.co):errors.append({'name':o.name,'error':'nonfinite'})
   if any(p.normal.length<.9 for p in o.data.polygons):errors.append({'name':o.name,'error':'degenerate normal'})
  rows.append({'name':o.name,'type':o.type,'bounds_blender':bb,'support':o.get('support'),'role':o.get('role')})
 imgs=[{'name':im.name,'packed':bool(im.packed_file)} for im in bpy.data.images if im.source=='FILE'];
 if any(not i['packed'] for i in imgs):errors.append({'error':'unpacked image'})
 report={'scope':'source containment/UV/normal/resource screen; not installed Godot acceptance','programme_key':C['key'],'errors':errors,'objects':len(A),'images':imgs,'source_sha256':digest(P/'source/native.blend'),'export_sha256':digest(P/'exports/section.glb'),'no_preview_floor_in_saved_native':not any(o.name.startswith('QA_') for o in bpy.context.scene.objects)}
 (P/'qa/validation.json').write_text(json.dumps(report,indent=2));(P/'qa/objects.json').write_text(json.dumps(rows,indent=2));print('SOURCE VALIDATION',len(errors),'errors',flush=True)
 if errors:raise RuntimeError('Source checks failed; evidence retained')

def render():
 sc=bpy.context.scene;sc.render.engine='BLENDER_EEVEE_NEXT';sc.render.resolution_x=960;sc.render.resolution_y=540;sc.render.resolution_percentage=100;sc.render.threads_mode='FIXED';sc.render.threads=4;sc.render.image_settings.file_format='PNG';sc.world=sc.world or bpy.data.worlds.new('QA low ambient');sc.world.color=(.075,.075,.075);sc.view_settings.view_transform='AgX';sc.render.film_transparent=False
 # Preview slab is made after final native/export and is never saved into final source.
 for j,p in enumerate(C.get('preview_polygons',[POLY])):
  preview=prism('QA_RECEIVING_SLAB'+str(j),p,-.1,.1,'stone',role='qa_only_preview_floor',bev=0);A.remove(preview)
 for l in LIGHTS:
  ld=bpy.data.lights.new('QA_'+l['name'],'AREA');ld.energy=l['power'];ld.color=l['color'];ld.shape='DISK';ld.size=l['size'];o=bpy.data.objects.new('QA_'+l['name'],ld);sc.collection.objects.link(o);o.location=xyz(*l['pos'])
 camd=bpy.data.cameras.new('QA_Eye');cam=bpy.data.objects.new('QA_Eye',camd);sc.collection.objects.link(cam);sc.camera=cam;camd.lens=21;camd.clip_end=180
 views=[]
 for n,(u,v),target_point in VIEWS[C['kind']]:
  tu,tv=target_point[:2];th=target_point[2]if len(target_point)>2 else 1.65
  if '_' in mode and mode.startswith('render') and n!=mode.split('_',1)[1]:continue
  cam.location=xyz(u,1.65,v);target=Vector(xyz(tu,th,tv));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();sc.render.filepath=str(P/'qa/views'/(n+'.png'));bpy.ops.render.render(write_still=True);views.append({'name':n,'eye_local_xyz':[C['sign']*u,1.65,v],'target_local_xyz':[C['sign']*tu,th,tv],'image_sha256':digest(sc.render.filepath)})
 if mode.startswith('render') and '_' in mode:
  old=json.loads((P/'qa/view_receipt.json').read_text());merged={x['name']:x for x in old['views']};merged.update({x['name']:x for x in views});views=list(merged.values())
 (P/'qa/view_receipt.json').write_text(json.dumps({'source_sha256':digest(P/'source/native.blend'),'export_sha256':digest(P/'exports/section.glb'),'views':views,'render_scope':'source preview with proposed receiving slab; not installed Godot acceptance'},indent=2))

def run():
 global COL
 if mode.startswith('render'):
  bpy.ops.wm.open_mainfile(filepath=str(P/'source/native.blend'));COL=bpy.data.collections.get('Batch B '+C['name']);A.extend(o for o in COL.objects);materials() # materials reused for QA slab only
  meta=json.loads((P/'source/build_metadata.json').read_text());C.update(meta['section']);POLY.extend(meta['polygon']);LIGHTS.extend(meta['lights']);render();return
 bpy.ops.wm.read_factory_settings(use_empty=True);COL=bpy.data.collections.new('Batch B '+C['name']);bpy.context.scene.collection.children.link(COL);bpy.context.scene.unit_settings.system='METRIC';materials();architecture();globals()[C['kind']]()
 bpy.context.scene['programme_key']=C['key'];bpy.context.scene['placement_xyz']=[C['sign']*C['x'],C['floor'],C['z']];bpy.context.scene['status']='Independent fitted source proposal; root adoption and Godot acceptance pending'
 meta={'section':C,'polygon':POLY,'lights':LIGHTS,'builder_sha256':hashlib.sha256(USED_SOURCE).hexdigest(),'profiles_sha256':hashlib.sha256(USED_PROFILES).hexdigest(),'rebuild':'Python deterministic geometry; Catalogue native appends pinned in dependencies'};(P/'source/build_metadata.json').write_text(json.dumps(meta,indent=2))
 bpy.ops.wm.save_as_mainfile(filepath=str(P/'source/native.blend'));export();validation();render()
run()
