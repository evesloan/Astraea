"""Batch B original fitted source proposals. Blender 4.3.2; metres.
Each rebuild is independent. Root owns structural adoption, floors, doors and runtime.
Run via heavy_job.py so all heavy work holds the shared Windows mutex.
"""
import bpy,math,json,sys,hashlib,random
from pathlib import Path
from mathutils import Vector
BASE=Path(__file__).resolve().parent
USED_SOURCE=Path(__file__).read_bytes()
CONFIG={
 '01_starlight':dict(key='D09_directory_09',alias='D09_cafe8',name='Starlight bakery',sign=-1,z=398,kind='bakery',ceiling=6.3),
 '02_copper':dict(key='D09_directory_02',alias='D09_tea1',name='The copper kettle',sign=1,z=-466,kind='tea',ceiling=5.8),
 '03_companion':dict(key='D09_directory_10',alias='D09_arcade9',name='Companion games',sign=1,z=398,kind='games',ceiling=6.6),
 '04_papermoon':dict(key='D09_directory_03',alias='D09_books2',name='Paper moon books',sign=-1,z=-250,kind='books',ceiling=5.9),
 '05_parcels':dict(key='D09_directory_07',alias='D09_parcel6',name='Post & parcels',sign=-1,z=182,kind='parcels',ceiling=5.5)}
section=sys.argv[sys.argv.index('--')+1];mode=sys.argv[sys.argv.index('--')+2];C=CONFIG[section];P=BASE/section
for n in ['source','exports','qa/views','docs']: (P/n).mkdir(parents=True,exist_ok=True)
M={};A=[];LIGHTS=[];POLY=[];COL=None
if not mode.startswith('render'):(P/'source/build_used.py').write_bytes(USED_SOURCE)
else:(P/'qa/render_used.py').write_bytes(USED_SOURCE)

def xyz(u,h,v):return (C['sign']*u,-v,h)
def uv(o):
 if o.type!='MESH':return
 o.data.update();layer=o.data.uv_layers.active or o.data.uv_layers.new(name='UV0')
 for f in o.data.polygons:
  drop=max(range(3),key=lambda i:abs(f.normal[i]));axes=[i for i in range(3) if i!=drop]
  for li in f.loop_indices:
   co=o.data.vertices[o.data.loops[li].vertex_index].co;layer.data[li].uv=(co[axes[0]]*.8,co[axes[1]]*.8)

def finish(o,n,mat,support='ROOT_FLOOR',role='fitted',bev=.025):
 o.name=n
 for c in list(o.users_collection):c.objects.unlink(o)
 COL.objects.link(o)
 if o.type=='MESH':
  if bev:
   bpy.context.view_layer.objects.active=o;mod=o.modifiers.new('Manufactured radius','BEVEL');mod.width=bev;mod.segments=2;bpy.ops.object.modifier_apply(modifier=mod.name)
  bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.normals_make_consistent(inside=False);bpy.ops.object.mode_set(mode='OBJECT');o.select_set(False)
  uv(o)
 o.data.materials.append(M[mat]);o['programme_key']=C['key'];o['support']=support;o['role']=role;A.append(o);return o

def box(n,u,h,v,w,ht,d,mat='wood',support='ROOT_FLOOR',role='fitted',bev=.025):
 bpy.ops.mesh.primitive_cube_add(size=1,location=xyz(u,h,v));o=bpy.context.object;o.dimensions=(w,d,ht);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,n,mat,support,role,min(bev,min(w,ht,d)*.3))
def prism(n,poly,h,ht,mat,sup='ROOT_FLOOR',role='fitted',bev=.025):
 vs=[xyz(u,h,v) for u,v in poly]+[xyz(u,h+ht,v) for u,v in poly];count=len(poly);faces=[tuple(reversed(range(count))),tuple(range(count,2*count))]+[(i,(i+1)%count,(i+1)%count+count,i+count) for i in range(count)]
 me=bpy.data.meshes.new(n);me.from_pydata(vs,[],faces);me.update();o=bpy.data.objects.new(n,me);COL.objects.link(o);return finish(o,n,mat,sup,role,bev)
def rod(n,a,b,r,mat='brass',sup='ROOT_FLOOR',role='support',vertices=12):
 pa=Vector(xyz(*a));pb=Vector(xyz(*b));delta=pb-pa;bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=r,depth=delta.length,location=(pa+pb)/2);o=bpy.context.object;o.rotation_euler=delta.to_track_quat('Z','Y').to_euler();bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,n,mat,sup,role,.007)
def disc(n,u,h,v,r,ht,mat,sup='ROOT_FLOOR',role='fitted'):
 return rod(n,(u,h,v),(u,h+ht,v),r,mat,sup,role,24)
def edge(n,a,b,h,ht,width,mat,sup='ROOT_FLOOR',role='enclosure'):
 du,dv=b[0]-a[0],b[1]-a[1];ln=math.hypot(du,dv);nu,nv=-dv/ln*width/2,du/ln*width/2
 return prism(n,[(a[0]+nu,a[1]+nv),(b[0]+nu,b[1]+nv),(b[0]-nu,b[1]-nv),(a[0]-nu,a[1]-nv)],h,ht,mat,sup,role)
def arc(n,u,v,r,a0,a1,h,ht,width,mat,sup='ROOT_FLOOR',role='fitted',steps=16):
 outer=[(u+(r+width/2)*math.cos(a0+(a1-a0)*i/steps),v+(r+width/2)*math.sin(a0+(a1-a0)*i/steps)) for i in range(steps+1)];inner=[(u+(r-width/2)*math.cos(a0+(a1-a0)*i/steps),v+(r-width/2)*math.sin(a0+(a1-a0)*i/steps)) for i in reversed(range(steps+1))];return prism(n,outer+inner,h,ht,mat,sup,role,.018)
def text(n,body,u,h,v,size=.18,sup='ROOT_FLOOR',face='entry'):
 cu=bpy.data.curves.new(n,'FONT');cu.body=body;cu.size=size;cu.align_x='CENTER';cu.extrude=.001;o=bpy.data.objects.new(n,cu);COL.objects.link(o);o.location=xyz(u,h,v);o.rotation_euler=(math.pi/2,0,-C['sign']*math.pi/2) if face=='entry' else (math.pi/2,0,0);o.data.materials.append(M['ivory']);o['support']=sup;o['role']='editable_sign';o['programme_key']=C['key'];A.append(o)
def lamp(n,u,v,h=3.2,sup='ROOT_FLOOR',cool=False):
 disc(n+'_foot',u,0,v,.22,.08,'brass');rod(n+'_stem',(u,.08,v),(u,h,v),.045,'brass',n+'_foot');disc(n+'_shade',u,h-.15,v,.33,.28,'cool' if cool else 'orange',n+'_stem');disc(n+'_lens',u,h-.18,v,.27,.04,'light',n+'_shade');LIGHTS.append(dict(name=n,pos=(u,h-.23,v),power=130 if cool else 180,color=(.72,.86,1) if cool else (1,.72,.40),size=1.0))
def ceiling_light(n,u,v,h,sup,power=350):
 rod(n+'_suspension',(u,h+.02,v),(u,C['ceiling']+.04,v),.04,'brass',sup);box(n+'_housing',u,h,v,1.7,.12,.85,'brass',n+'_suspension');box(n+'_lens',u,h-.075,v,1.55,.04,.7,'light',n+'_housing');LIGHTS.append(dict(name=n,pos=(u,h-.11,v),power=power,color=(1,.80,.58),size=2.5))
def counter(n,poly,mat='orange',top='stone',height=1.02):
 prism(n+'_base',poly,0,height-.1,mat,role='floor_contact');prism(n+'_top',poly,height-.1,.1,top,n+'_base',role='work_surface',bev=.045);return n+'_top'
def table(n,u,v,w=1.8,d=1.4,game=False):
 box(n+'_foot',u,.045,v,w*.58,.09,d*.65,'brass',role='floor_contact');box(n+'_stem',u,.42,v,.22,.68,.22,'brass',n+'_foot');box(n+'_top',u,.80,v,w,.12,d,'wood',n+'_stem','activity_surface',.055)
 if game:
  box(n+'_board',u,.876,v,w*.62,.035,d*.64,'teal',n+'_top','inert_tabletop_display',.015)
  for i in range(5):
   disc(n+'_piece'+str(i),u-.42+i*.21,.895,v-.18+(i%2)*.34,.065,.08,'ivory' if i%2 else 'orange',n+'_board','inert_tabletop_piece')
 return n+'_top'
def chair(n,u,v,angle=0):
 disc(n+'_foot',u,0,v,.35,.07,'brass',role='floor_contact');disc(n+'_stem',u,.07,v,.08,.33,'brass',n+'_foot');box(n+'_seat',u,.46,v,.78,.12,.78,'cloth',n+'_stem','supported_rest',.05)
 du,dv=math.cos(angle)*.33,math.sin(angle)*.33;back=box(n+'_back',u+du,.87,v+dv,.16,.79,.72,'cloth',n+'_seat','supported_rest',.05)
 if C['kind']=='games':back.rotation_euler[2]=-C['sign']*angle
def bench(n,u,v,length=3.8,back='north'):
 box(n+'_plinth',u,.19,v,length,.38,.92,'wood',role='floor_contact');box(n+'_cushion',u,.46,v,length-.12,.16,.88,'cloth',n+'_plinth','supported_rest',.065);box(n+'_back',u,.92,v+.41 if back=='north' else v-.41,length,1.00,.18,'cloth',n+'_plinth','supported_rest',.055)
def shelf(n,u,v,length=4.0,height=2.6,items='books',mat='wood',reverse=False):
 box(n+'_back',u+(-.5 if reverse else .5),height/2,v,.16,height,length,mat,role='floor_contact');box(n+'_plinth',u,.08,v,1.15,.16,length,mat,role='floor_contact')
 for j in range(4):
  h=.32+j*.64;box(n+'_shelf'+str(j),u,h,v,1.1,.08,length,mat,n+'_back','stock_surface')
  for i in range(int(length/.45)-1):
   vv=v-length/2+.4+i*.45;hh=.36 if items=='books' else .30
   if items=='bread':
    disc(n+'_tray'+str(j)+'_'+str(i),u,h+.04,vv,.20,.035,'brass',n+'_shelf'+str(j));box(n+'_loaf'+str(j)+'_'+str(i),u,h+.04+.035+hh/2,vv,.42,hh,.27,'oatmeal',n+'_tray'+str(j)+'_'+str(i),'display_bakery_food',.09)
   else:
    box(n+'_stock'+str(j)+'_'+str(i),u,h+.04+hh/2,vv,.50,hh,.22 if items=='books' else .36,['teal','orange','ivory'][i%3],n+'_shelf'+str(j),'book_stock' if items=='books' else 'parcel_stock',.015)
 for vv in [v-length/2+.06,v+length/2-.06]:box(n+'_end'+str(vv),u,height/2,vv,1.1,height,.12,mat,n+'_plinth')
def plant(n,u,v):
 disc(n+'_pot',u,0,v,.55,.65,'orange',role='floor_contact');rod(n+'_stem',(u,.65,v),(u,1.75,v),.065,'wood',n+'_pot')
 for i in range(6):
  a=i*math.tau/6;bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1,radius=.7,location=xyz(u+.32*math.cos(a),1.4+.20*(i%2),v+.32*math.sin(a)));o=bpy.context.object;o.scale=(.7,.5,1.0);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);finish(o,n+'_leaf'+str(i),'green',n+'_stem','plant',0)
def catalogue(n,id,u,v,angle=0):
 cat=json.loads((BASE/'dependencies/catalogue_manifest.json').read_text());rec=next(a for a in cat['assets'] if a['catalogue_id']==id);path=BASE/'dependencies/catalogue'/rec['source'];loaded=[]
 with bpy.data.libraries.load(str(path),link=False) as (src,dst):dst.objects=[o for o in src.objects]
 objs=[o for o in dst.objects if o and o.type=='MESH']; pts=[o.matrix_world@Vector(c) for o in objs for c in o.bound_box];minz=min(p.z for p in pts);cx=(min(p.x for p in pts)+max(p.x for p in pts))/2;cy=(min(p.y for p in pts)+max(p.y for p in pts))/2
 for i,o in enumerate(objs):
  COL.objects.link(o);o.hide_viewport=False;o.hide_render=False;o.hide_select=False;o.hide_set(False);world=o.matrix_world.copy();o.parent=None;me=o.data.copy();o.data=me
  for vert in me.vertices:
   q=world@vert.co;xx=q.x-cx;yy=q.y-cy;uu=u+xx*math.cos(angle)-yy*math.sin(angle);vv=v-xx*math.sin(angle)-yy*math.cos(angle);vert.co=xyz(uu,q.z-minz,vv)
  o.matrix_world.identity();
  if world.to_3x3().determinant()*C['sign']<0:me.flip_normals()
  me.update();o.name=n+'_'+str(i);o['support']='ROOT_FLOOR' if min((o.matrix_world@Vector(c)).z for c in o.bound_box)<.02 else n+'_0';o['role']='catalogue_'+id;o['programme_key']=C['key'];uv(o);A.append(o)
 for im in bpy.data.images:
  if im.source=='FILE' and not im.packed_file:
   try:im.pack()
   except Exception:pass

def materials():
 specs={'wood':'warm_walnut','brass':'champagne_metal','cloth':'clay_weave','oatmeal':'oatmeal_weave','ivory':'ivory_enamel','rubber':'dark_rubber','stone':'warm_stone','teal':'teal_weave','cool':'staff_bluegrey_paint','zinc':'staff_zinc','white':'staff_white_paint','light':'staff_opal','orange':'ivory_enamel','green':'teal_weave'}
 for key,fn in specs.items():
  ma=bpy.data.materials.new('B_'+key);ma.use_nodes=True;bs=ma.node_tree.nodes.get('Principled BSDF');bs.inputs['Roughness'].default_value=.78;bs.inputs['Metallic'].default_value=.45 if key in ['brass','zinc'] else 0;im=bpy.data.images.load(str(BASE/'dependencies/materials'/(fn+'.png')),check_existing=True);im.pack();tx=ma.node_tree.nodes.new('ShaderNodeTexImage');tx.image=im;tx.interpolation='Closest'
  if key in ['orange','green']:
   mix=ma.node_tree.nodes.new('ShaderNodeMixRGB');mix.blend_type='MULTIPLY';mix.inputs[0].default_value=1;mix.inputs[2].default_value=(.85,.24,.045,1) if key=='orange' else (.22,.55,.25,1);ma.node_tree.links.new(tx.outputs['Color'],mix.inputs[1]);ma.node_tree.links.new(mix.outputs['Color'],bs.inputs['Base Color'])
  else:ma.node_tree.links.new(tx.outputs['Color'],bs.inputs['Base Color'])
  if key=='light':bs.inputs['Emission Color'].default_value=(1,.7,.35,1);bs.inputs['Emission Strength'].default_value=2
  M[key]=ma

def architecture():
 global POLY
 # Actual source perimeter contains chamfered gathering wings, a narrow entry and service depth.
 if C['kind']=='bakery':POLY=[(0,29),(6,29),(6,5),(13,2),(39,2),(44,8),(44,60),(38,66),(14,66),(6,61),(6,39),(0,39)]
 elif C['kind']=='tea':POLY=[(0,30),(5,30),(5,10),(13,3),(34,3),(44,13),(44,55),(34,65),(13,65),(5,58),(5,38),(0,38)]
 elif C['kind']=='games':POLY=[(0,29),(6,29),(6,7),(16,2),(39,2),(44,7),(44,61),(37,66),(15,66),(6,60),(6,39),(0,39)]
 elif C['kind']=='books':POLY=[(0,30),(6,30),(6,5),(12,2),(39,2),(44,7),(44,61),(39,66),(11,66),(6,61),(6,38),(0,38)]
 else:POLY=[(0,30),(6,30),(6,6),(11,2),(40,2),(44,6),(44,62),(40,66),(12,66),(6,60),(6,38),(0,38)]
 h=C['ceiling']
 for i in range(len(POLY)-1):edge('Perimeter_'+str(i),POLY[i],POLY[i+1],0,h,.22,'ivory',role='enclosure')
 # Closing edge is the open receiving-owned doorway, never an authored door leaf.
 prism('Enclosure_top',POLY,h,.20,'ivory','Perimeter_5','supported_ceiling')
 # Deep threshold cheeks, orange recess and broad changing-height mouth.
 for vv in [29.4,38.6]:
  box('Entry_base_'+str(vv),3,.06,vv,5.8,.12,.70,'stone',role='floor_contact');box('Entry_pier_'+str(vv),3,2,vv,5.8,3.88,.40,'orange','Entry_base_'+str(vv),'deep_threshold',.08)
 box('Entry_lintel',3,4.03,34,6,.26,9.6,'orange','Entry_pier_29.4','deep_threshold',.07)
 ceiling_light('Entry_light',3,34,3.93,'Entry_lintel',650)
 box('Identity_panel',5.93,2.2,30.15,.15,.65,2.8,'orange','Entry_pier_29.4');text('Identity',C['name'].upper(),5.84,2.23,30.15,.13,'Identity_panel')
 # Ceiling ribs follow activity cross sections instead of copy-pasted rectangular canopies.
 for j,vv in enumerate([10,22,46,58]):
  hh=h-.35
  for u in [7.0,42.5]:box('Rib_pier_'+str(j)+'_'+str(u),u,hh/2,vv,.35,hh,.6,'wood',role='floor_contact')
  points=[(7,hh-.4,vv),(14,hh+.05,vv),(25,hh+.22,vv),(35,hh+.05,vv),(42.5,hh-.4,vv)]
  for i in range(4):rod('Rib_'+str(j)+'_'+str(i),points[i],points[i+1],.16,'wood','Rib_pier_'+str(j)+'_7.0',role='ceiling_rib')
  for u in [15,29,39]:ceiling_light('Room_'+str(j)+'_'+str(u),u,vv,hh-.25,'Enclosure_top',750)
 # Independent receiving floor proposal; explicitly absent from final native and exchange.
 (P/'docs/floor_proposal.json').write_text(json.dumps({'status':'proposal for root structural author; not exported or installed','programme_key':C['key'],'local_xz':[[C['sign']*u,v] for u,v in POLY],'translation_xyz':[C['sign']*8,52.5,C['z']],'floor_y':52.5,'preview_thickness':.1,'requested_receiver':'Root-owned supported slab and external connection','clear_entry_local_xz':[0,34]},indent=2))

def bakery():
 # Three faceted display bays bend around an ordering pocket, not a straight wall counter.
 p=[(14,24),(17,22),(20,24),(19.4,25.1),(17,23.5),(15.2,24.6),(15.2,30),(17.2,32),(17.2,38),(15.2,40),(16.4,42),(21,42),(21,43.2),(15.8,43.2),(14,40),(16,37.6),(16,32.6),(14,30.6)]
 top=counter('Display_frontage',p)
 for j,(tu,v) in enumerate([(14.6,26),(16.6,34),(16.6,37),(18.4,42.6)]):
  box('Display_tray'+str(j),tu,1.05,v,.75,.06,.8,'brass',top)
  for i in range(4):box('Pastry_'+str(j)+'_'+str(i),tu+(-.18 if i%2 else .18),1.20,v-.2+(i//2)*.4,.28,.24,.25,'oatmeal','Display_tray'+str(j),'inert_bakery_display',.075)
  rod('Display_frame'+str(j),(tu+.35,1.02,v),(tu+.35,1.85,v),.035,'brass',top)
 # Visible enclosing glass display, not an exterior opening.
 ma=bpy.data.materials.new('Display_glass');ma.use_nodes=True;bs=ma.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(.35,.65,.62,1);bs.inputs['Transmission Weight'].default_value=.55;bs.inputs['Alpha'].default_value=.38;bs.inputs['Roughness'].default_value=.22;M['glass']=ma
 for j,(tu,v) in enumerate([(14.6,26),(16.6,34),(16.6,37),(18.4,42.6)]):box('Display_glass'+str(j),tu+.35,1.48,v,.05,.82,.8,'glass','Display_frame'+str(j),'internal_display_glass',.002)
 box('Order_plaque',16,1.15,36,.16,.45,1.4,'orange','Display_frontage_base');box('Collect_plaque',14.6,1.15,41,.16,.45,1.4,'orange','Display_frontage_base');text('Order_label','ORDER',15.91,1.12,36,.18,'Order_plaque');text('Collect_label','COLLECT',14.51,1.12,41,.17,'Collect_plaque')
 # Open preparation edge, tall cooler and fitted ovens behind public display.
 counter('Preparation',[(33,15),(36,15),(36,47),(33,47)],'cool','white',.92)
 for i,v in enumerate([19,27,35,43]):
  box('Oven_'+str(i),40,.85,v,2.2,1.7,2.1,'cool',role='floor_contact');box('Oven_door_'+str(i),38.87,.91,v,.08,.94,1.68,'rubber','Oven_'+str(i));box('Oven_pull_'+str(i),38.79,1.24,v,.09,.06,1.3,'brass','Oven_door_'+str(i));box('Prep_tray_'+str(i),34.4,.95,v,1.5,.06,1.5,'brass','Preparation_top');box('Dough_'+str(i),34.4,1.09,v,.85,.22,.62,'oatmeal','Prep_tray_'+str(i),bev=.085)
 for i,v in enumerate([9,54,60]):shelf('Bakery_rack'+str(i),40,v,4,2.6,'bread','cool')
 # Branched pause wings share long fitted benches and grouped tables.
 for j,v in enumerate([9,17,51,59]):
  bench('Pause_bench'+str(j),23,v,6);table('Pause_table'+str(j),23,v-1.8,3.4,1.2);chair('Pause_chair'+str(j),23,v-3.1,-math.pi/2);plant('Pause_plant'+str(j),29,v);lamp('Pause_lamp'+str(j),18,v)
 catalogue('Care_cabinet','AST-STF-007',39,63)
 catalogue('Waiting_bench','AST-FUR-001',10,43,math.pi/2)
 # Focal raised scalloped bakery fascia tied to piers at counter ends.
 for vv in [22,44]:box('Display_pier'+str(vv),26,2.45,vv,.6,4.9,.6,'orange',role='floor_contact')
 for i in range(9):
  vv=23+i*2.5;box('Scalloped_fascia'+str(i),26,4.65,vv,.5,.70,2.6,'orange','Display_pier22','profiled_fascia',.15)
 ceiling_light('Display_worklight',24,34,4.14,'Scalloped_fascia4',1000)

def tea():
 # Low octagonal tea-serving island gives guests a view of preparation without a simulation claim.
 poly=[(20,28),(26,28),(28,30),(28,38),(26,40),(20,40),(18,38),(18,30)]
 for i,(aa,bb) in enumerate(zip(poly,poly[1:]+poly[:1])):
  if i==2:continue
  edge('Tea_edge'+str(i)+'_base',aa,bb,0,.86,1.2,'wood',role='floor_contact');edge('Tea_edge'+str(i)+'_top',aa,bb,.86,.10,1.24,'stone','Tea_edge'+str(i)+'_base','serving_surface')
 for i,(aa,bb) in enumerate([((28,30),(28,32)),((28,36),(28,38))]):
  edge('Tea_staff_return'+str(i),aa,bb,0,.86,1.2,'wood',role='floor_contact');edge('Tea_staff_top'+str(i),aa,bb,.86,.10,1.24,'stone','Tea_staff_return'+str(i),'serving_surface')
 top='Tea_edge6_top'
 for i,v in enumerate([30.9,34,37.1]):
  disc('Urn_base'+str(i),18.15,.96,v,.45,.12,'brass',top);disc('Tea_urn'+str(i),18.15,1.08,v,.38,.78,'brass','Urn_base'+str(i));disc('Urn_lid'+str(i),18.15,1.86,v,.43,.09,'brass','Tea_urn'+str(i));rod('Urn_spout'+str(i),(17.82,1.32,v),(17.50,1.25,v),.06,'brass','Tea_urn'+str(i));cv=[32,35.1,36][i];box('Cup_tray'+str(i),18,.995,cv,.8,.07,.6,'brass',top)
  for j in range(4):disc('Cup_'+str(i)+'_'+str(j),17.8+(j%2)*.4,1.03,cv-.15+(j//2)*.3,.10,.18,'ivory','Cup_tray'+str(i))
 counter('Tea_return',[(32,47),(36,47),(36,51),(32,51)],'cool','zinc',.95);shelf('Tea_crockery',40,47,7,2.6,'parcels','cool');shelf('Tea_tins',40,21,10,2.6,'parcels','wood')
 # Conversations nest in opposed curved walls open to the central serving court.
 for j,v in enumerate([10,20,49,59]):
  for side,u in enumerate([17,33]):
   n='Alcove_'+str(j)+'_'+str(side);a0,a1=(0,math.pi) if v<34 else (math.pi,2*math.pi)
   arc(n+'_screen',u,v,4,a0,a1,0,2.5,.25,'wood',role='floor_contact');arc(n+'_bench',u,v,3.25,a0+.22,a1-.22,0,.4,.90,'wood',role='floor_contact');arc(n+'_cushion',u,v,3.25,a0+.22,a1-.22,.4,.14,.85,'cloth',n+'_bench','supported_rest');table(n+'_tea',u,v,2.2,1.5);lamp(n+'_lamp',u+3.8,v,3,'ROOT_FLOOR');plant(n+'_planter',u-3.8,v)
   arc(n+'_brow',u,v,4,a0,a1,2.5,.34,.9,'orange',n+'_screen','sheltered_alcove_brow')
 catalogue('Care_cabinet','AST-STF-007',40,54)
 # Serving core high crown, visibly carried by four posts; conversation brows stay lower.
 for u,v in [(18,24),(29,24),(18,43),(29,43)]:rod('Tea_crown_post'+str(u)+str(v),(u,0,v),(u,4.7,v),.11,'brass',role='floor_contact')
 arc('Tea_crown',23.5,33.5,10.7,-math.pi/2,math.pi/2,4.55,.22,.75,'wood','Tea_crown_post2924','serving_crown')
 ceiling_light('Tea_core_light',23,33,4.5,'Tea_crown',950)

def games():
 # Alternating lobes create short spectator edges along an unblocked main gallery.
 for j,(u,v) in enumerate([(20,10),(34,16),(20,23),(34,30),(20,45),(34,51),(20,57)]):
  n='Game_cluster'+str(j);table(n,u,v,3.0,2.0,True)
  for i,(du,dv,a) in enumerate([(-2,0,0),(2,0,math.pi),(0,-1.8,math.pi/2),(0,1.8,-math.pi/2)]):chair(n+'_chair'+str(i),u+du,v+dv,a)
  # An open crescent holds spectators close enough to see the tabletop.
  arc(n+'_restbase',u+2,v+4,3.7,0,math.pi,0,.4,.9,'wood',role='floor_contact');arc(n+'_restcushion',u+2,v+4,3.7,0,math.pi,.4,.15,.83,'cloth',n+'_restbase','spectator_rest');arc(n+'_restback',u+2,v+4,4.10,0,math.pi,.40,.85,.16,'cloth',n+'_restbase','spectator_rest');lamp(n+'_lamp',u-3.8,v+2.5,3.4)
 # Board storage, large shared layout table and modest refreshment shelf.
 for j,v in enumerate([8,24,42,59]):shelf('Games_store'+str(j),41,v,5,2.6,'parcels','wood')
 counter('Shared_puzzle',[(15,31),(24,31),(26,33),(24,38),(15,38),(13,36)],'wood','stone',.80)
 for i in range(12):box('Shared_piece'+str(i),16+(i%4)*1.6,.83,32+(i//4)*1.7,.8,.06,.8,'orange' if i%2 else 'teal','Shared_puzzle_top','inert_tabletop_piece')
 bench('Shared_spectators',21,40,8,'north');catalogue('Care_cabinet','AST-STF-007',39,61)
 # Branching ceiling beams align the sociable pockets, carried at the shelving side.
 for i,v in enumerate([13,27,48,61]):
  rod('Branch_trunk'+str(i),(41,0,v),(41,5.4,v),.16,'orange',role='floor_contact');rod('Branch_arm'+str(i),(41,5.4,v),(18,5.95,v-3),.16,'orange','Branch_trunk'+str(i));rod('Branch_fork'+str(i),(30,5.65,v-1.5),(21,5.95,v+3),.13,'orange','Branch_arm'+str(i))

def books():
 # Three staggered collection streets, with cross aisles rather than a Long Library hall.
 for j,u in enumerate([18,28,38]):
  for k,v in enumerate([10,21,47,58]):
   shelf('Collection_'+str(j)+'_'+str(k),u,v,7,2.65,'books','wood')
   shelf('Collection_reverse_'+str(j)+'_'+str(k),u+1.15,v,7,2.65,'books','wood',True)
 # Low stepped editorial focal island remains accessible from the main court.
 for k,(poly,hh,uu,vv) in enumerate([([(15,30),(18,29),(20,30),(20,33),(18,34),(15,33)],.70,16,31), ([(18,34),(21,33),(24,34),(24,37),(21,38),(18,37)],.85,20,35), ([(15,38),(18,37),(20,38),(20,41),(18,42),(15,41)],.75,16,39.5)]):
  n='Editorial_branch'+str(k);counter(n,poly,'orange','wood',hh)
  for i in range(2):
   box('Editorial_riser_'+str(k)+'_'+str(i),uu+i*2,hh+.125,vv,1.4,.25,1.1,'wood',n+'_top');box('Featured_book_'+str(k)+'_'+str(i),uu+i*2,hh+.33,vv,1.1,.16,.9,'teal' if i%2 else 'ivory','Editorial_riser_'+str(k)+'_'+str(i),'editorial_display')
 # Reading niches turn away from browsing bustle and share a fitted shelf return.
 for i,v in enumerate([9,20,48,59]):
  arc('Reading_screen'+str(i),10.5,v,3.1,math.pi/2,math.pi*1.5,0,2.5,.20,'wood',role='floor_contact');bench('Reading_seat'+str(i),10.8,v,3.2);catalogue('Reading_table'+str(i),'AST-FUR-003',10.8,v-1.6);lamp('Reading_lamp'+str(i),8.5,v,2.6)
 counter('Books_help',[(32,30),(39,30),(39,32),(32,32)],'wood','stone',.9);catalogue('Care_cabinet','AST-STF-007',34,64)
 # Stacked folded ceiling strips organize each street at different heights and terminate in solid end returns.
 for j,u in enumerate([18,28,38]):
  for v in [4,64]:box('Bookstreet_end_'+str(j)+'_'+str(v),u,(4.85+j*.18)/2,v,.30,4.85+j*.18,.40,'orange',role='floor_contact')
  prism('Bookstreet_fold'+str(j),[(u-1.8,4),(u+1.8,4),(u+2.8,10),(u+1.8,58),(u+.8,64),(u-1.8,64)],4.8+j*.18,.18,'wood','Bookstreet_end_'+str(j)+'_4','folded_street_soffit')
  for v in [16,34,53]:ceiling_light('Browse_light_'+str(j)+'_'+str(v),u,v,4.68+j*.18,'Bookstreet_fold'+str(j),650)

def parcels():
 # Guest collection frontage opens into a staffed help pocket; back-of-house is screened.
 for j,v in enumerate([10,20,47,58]):shelf('Guest_collection'+str(j),18,v,7,2.6,'parcels','orange')
 top=counter('Help_front',[(17,29),(23,27),(27,30),(27,38),(23,41),(17,39),(15,34)],'orange','stone',.98)
 box('Accessible_help',14.9,.74,34,2,.12,3,'stone','Help_front_base','lower_help_surface');box('Help_screen',23,1.28,34,.3,.60,1.1,'cool',top,'inert_help_equipment');box('Help_plaque',16.6,1.15,30,.16,.45,2.1,'orange','Help_front_base');text('Collection_label','COLLECTION / HELP',16.51,1.12,30,.13,'Help_plaque')
 # Three openings are deliberately inside this proposal, unrelated to external working doors.
 for v0,v1 in [(3,26),(42,65)]:edge('Staff_separator_'+str(v0),(29.5,v0),(29.5,v1),0,3.15,.26,'cool',role='floor_contact')
 for vv in [27,41]:box('Service_jamb'+str(vv),29.5,1.5,vv,.50,3,.40,'zinc',role='floor_contact')
 box('Service_lintel',29.5,3.12,34,.50,.25,14.5,'cool','Service_jamb27')
 # Clearly distinct incoming sorting and outgoing sorted stores.
 for i,v in enumerate([10,20,47,58]):
  counter('Sortbench'+str(i),[(34,v-3),(38,v-3),(38,v+3),(34,v+3)],'cool','zinc',.94)
  for j in range(4):box('Sorting_parcel_'+str(i)+'_'+str(j),35+(j%2)*1.8,1.13,v-1.7+(j//2)*2.7,1.1,.38,1.0,'oatmeal' if j%2 else 'ivory','Sortbench'+str(i)+'_top','inert_sorting_parcel')
  shelf('Sorted_store'+str(i),41,v,6,2.6,'parcels','cool');lamp('Sort_lamp'+str(i),31,v,3.0,cool=True)
 # Return transfer and custodial storage occupy separate ends of the service edge.
 counter('Parcel_return',[(31,29),(35,29),(35,32),(31,32)],'cool','zinc',.94);shelf('Custodial_stock',39,35,4,2.6,'parcels','cool');catalogue('Care_cabinet','AST-STF-007',39,63)
 for j,v in enumerate([12,54]):bench('Guest_wait'+str(j),10,v,4);catalogue('Guest_side_table'+str(j),'AST-FUR-003',10,v-1.5);plant('Guest_plant'+str(j),10,v+3);lamp('Guest_waitlamp'+str(j),8,v,2.8)
 # Industrial serrated overhead changes the section between guest and staffed edges.
 for i,v in enumerate([8,20,48,60]):
  rod('Sort_beam'+str(i),(29,3.2,v),(43,4.6,v),.13,'zinc','Staff_separator_3');ceiling_light('Sort_strip'+str(i),36,v,4.0,'Sort_beam'+str(i),600)

VIEWS={
 'bakery':[( 'arrival',(2,34),(19,34)),('display',(11,32),(20,35)),('preparation',(30,17),(36,26)),('pause',(13,49),(23,51)),('collection',(11,40),(22,41))],
 'tea':[('arrival',(2,34),(23,34)),('serving',(13,33),(25,33)),('conversation',(17,6),(17,11)),('return',(37.5,52.5),(35,49)),('quiet',(26,62),(33,59))],
 'games':[('arrival',(2,34),(21,34)),('tabletop',(15,10),(20,10)),('spectators',(26,16),(34,16)),('shared',(11,34),(21,34)),('rest',(15,53),(23,58))],
 'books':[('arrival',(2,34),(22,34)),('editorial',(11,34),(22,34)),('browse',(23,16),(28,21)),('reading',(14,9),(10,9)),('help',(30,35),(36,31))],
 'parcels':[('arrival',(2,34),(21,34)),('collection',(12,20),(18,20)),('help',(11,34),(22,34)),('sorting',(31,16),(36,20)),('care',(34,57),(39,63))]}

def bbox(o):
 pts=[o.matrix_world@Vector(c) for c in o.bound_box];return [[min(p[i] for p in pts),max(p[i] for p in pts)] for i in range(3)]
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def export():
 bpy.context.view_layer.update();bpy.ops.object.select_all(action='DESELECT');temp=[]
 for o in A:
  if o.type=='FONT':
   copy=o.copy();copy.data=o.data.copy();COL.objects.link(copy);copy.name=o.name+'_export';bpy.context.view_layer.objects.active=copy;copy.select_set(True);bpy.ops.object.convert(target='MESH');temp.append(bpy.context.object);o.select_set(False)
  else:o.select_set(True)
 (P/'qa/export_selection.json').write_text(json.dumps([{'name':o.name,'selected':o.select_get(),'hide':o.hide_get(),'hide_viewport':o.hide_viewport,'hide_render':o.hide_render,'visible':o.visible_get()} for o in A],indent=2))
 bpy.ops.export_scene.gltf(filepath=str(P/'exports'/('section.glb')),export_format='GLB',use_selection=True,export_apply=True,export_extras=True,export_texcoords=True,export_normals=True,export_cameras=False,export_lights=False)
 for o in temp:bpy.data.objects.remove(o,do_unlink=True)

def validation():
 errors=[];rows=[]
 for o in A:
  bb=bbox(o);ok=bb[0][0]>=(-46 if C['sign']==-1 else 0)-.002 and bb[0][1]<=(0 if C['sign']==-1 else 46)+.002 and bb[1][0]>=-68-.002 and bb[1][1]<=.002 and bb[2][0]>=-.002 and bb[2][1]<=8.2+.002
  if not ok:errors.append({'name':o.name,'containment':bb})
  if o.type=='MESH':
   if not o.data.uv_layers:errors.append({'name':o.name,'error':'UV missing'})
   if any(not math.isfinite(float(x)) for v in o.data.vertices for x in v.co):errors.append({'name':o.name,'error':'nonfinite'})
   if any(p.normal.length<.9 for p in o.data.polygons):errors.append({'name':o.name,'error':'degenerate normal'})
  rows.append({'name':o.name,'type':o.type,'bounds_blender':bb,'support':o.get('support'),'role':o.get('role')})
 imgs=[{'name':im.name,'packed':bool(im.packed_file)} for im in bpy.data.images if im.source=='FILE'];
 if any(not i['packed'] for i in imgs):errors.append({'error':'unpacked image'})
 report={'scope':'source containment/UV/normal/resource screen; not installed Godot acceptance','programme_key':C['key'],'errors':errors,'objects':len(A),'images':imgs,'source_sha256':digest(P/'source/native.blend'),'export_sha256':digest(P/'exports/section.glb'),'no_preview_floor_in_saved_native':not any(o.name.startswith('QA_') for o in bpy.context.scene.objects)}
 (P/'qa/validation.json').write_text(json.dumps(report,indent=2));(P/'qa/objects.json').write_text(json.dumps(rows,indent=2));print('SOURCE VALIDATION',len(errors),'errors',flush=True)
 if errors:raise RuntimeError('Source checks failed; evidence retained')

def render():
 sc=bpy.context.scene;sc.render.engine='BLENDER_EEVEE_NEXT';sc.render.resolution_x=960;sc.render.resolution_y=540;sc.render.resolution_percentage=100;sc.render.threads_mode='FIXED';sc.render.threads=4;sc.render.image_settings.file_format='PNG';sc.world=sc.world or bpy.data.worlds.new('QA low ambient');sc.world.color=(.075,.075,.075);sc.view_settings.view_transform='AgX';sc.render.film_transparent=False
 # Preview slab is made after final native/export and is never saved into final source.
 preview=prism('QA_RECEIVING_SLAB',POLY,-.1,.1,'stone',role='qa_only_preview_floor',bev=0);A.remove(preview)
 for l in LIGHTS:
  ld=bpy.data.lights.new('QA_'+l['name'],'AREA');ld.energy=l['power'];ld.color=l['color'];ld.shape='DISK';ld.size=l['size'];o=bpy.data.objects.new('QA_'+l['name'],ld);sc.collection.objects.link(o);o.location=xyz(*l['pos'])
 camd=bpy.data.cameras.new('QA_Eye');cam=bpy.data.objects.new('QA_Eye',camd);sc.collection.objects.link(cam);sc.camera=cam;camd.lens=21;camd.clip_end=180
 views=[]
 for n,(u,v),(tu,tv) in VIEWS[C['kind']]:
  if '_' in mode and mode.startswith('render') and n!=mode.split('_',1)[1]:continue
  cam.location=xyz(u,1.65,v);target=Vector(xyz(tu,1.65,tv));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();sc.render.filepath=str(P/'qa/views'/(n+'.png'));bpy.ops.render.render(write_still=True);views.append({'name':n,'eye_local_xyz':[C['sign']*u,1.65,v],'target_local_xyz':[C['sign']*tu,1.65,tv],'image_sha256':digest(sc.render.filepath)})
 if mode.startswith('render') and '_' in mode:
  old=json.loads((P/'qa/view_receipt.json').read_text());merged={x['name']:x for x in old['views']};merged.update({x['name']:x for x in views});views=list(merged.values())
 (P/'qa/view_receipt.json').write_text(json.dumps({'source_sha256':digest(P/'source/native.blend'),'export_sha256':digest(P/'exports/section.glb'),'views':views,'render_scope':'source preview with proposed receiving slab; not installed Godot acceptance'},indent=2))

def run():
 global COL
 if mode.startswith('render'):
  bpy.ops.wm.open_mainfile(filepath=str(P/'source/native.blend'));COL=bpy.data.collections.get('Batch B '+C['name']);A.extend(o for o in COL.objects);materials() # materials reused for QA slab only
  meta=json.loads((P/'source/build_metadata.json').read_text());POLY.extend(meta['polygon']);LIGHTS.extend(meta['lights']);render();return
 bpy.ops.wm.read_factory_settings(use_empty=True);COL=bpy.data.collections.new('Batch B '+C['name']);bpy.context.scene.collection.children.link(COL);bpy.context.scene.unit_settings.system='METRIC';materials();architecture();globals()[C['kind']]()
 bpy.context.scene['programme_key']=C['key'];bpy.context.scene['placement_xyz']=[C['sign']*8,52.5,C['z']];bpy.context.scene['status']='Independent fitted source proposal; root adoption and Godot acceptance pending'
 meta={'section':C,'polygon':POLY,'lights':LIGHTS,'builder_sha256':hashlib.sha256(USED_SOURCE).hexdigest(),'rebuild':'Python deterministic geometry; Catalogue native appends pinned in dependencies'};(P/'source/build_metadata.json').write_text(json.dumps(meta,indent=2))
 bpy.ops.wm.save_as_mainfile(filepath=str(P/'source/native.blend'));export();validation();render()
run()
