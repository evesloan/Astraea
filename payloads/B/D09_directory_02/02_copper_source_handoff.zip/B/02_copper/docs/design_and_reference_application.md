# The copper kettle source proposal

Octagonal serving island and three tea urns form the main activity. Opposed partial-circle conversation alcoves have lower sheltering brows and supported curved seating. A higher serving crown creates the sectional hierarchy; return ledge and crockery storage are kept beyond the conversation approach.

The complete relevant master blocks (chapters 1,3,4,5,7,16,19,21,24,28,30,32,33) and current overlays were read. Original embedded image4 public sheet, image7 threshold, image8 shelves/source light, image11 conversation lounge and image12 integrated dining edge pixels were inspected. Deep thresholds and useful sightlines translate image7; grouped stock/shelf depth and fixture bulbs translate image8; supported conversation clusters and ceiling hierarchy translate image11; integrated rest edges and working routes translate image12. Real hull frontage is unproved, so their exterior glazing is excluded. Printed reference deck/count contradictions do not override the current ledger.

Existing AST-FUR-001/003 furniture and AST-STF-007 care-family source parts are appended where called by the deterministic builder. Their original sources and role material pixels are pinned and preserved; no Catalogue IDs or shared registries changed.

RMB focus / E vocabulary remains owned by the existing ship; no new controller, binding, operating game or retail/capacity claim is introduced. Signage is small native editable text with exported matching mesh geometry. Source supports are actual imported-triangle contacts reaching the proposed receiving datum. Root must provide/compile the receiving slab: the pinned current structural regions do not cover this scope.

The first ordinary exec attempt failed with setup refresh errors; the supported access-reviewed exec route succeeded. No publisher, credential, remote write, install, OS setting or original package mutation was made. Requested Sol 6.1 medium is not exposed runtime verification.
