import json,pathlib,hashlib,datetime,sys,subprocess
BASE=pathlib.Path(__file__).resolve().parent;ROOT=BASE.parents[2]; section=sys.argv[1]
configs={'01_starlight':('D09_directory_09','D09_cafe8','Starlight bakery',-1,398,'Panoramic repose','Moonfruit parlor'), '02_copper':('D09_directory_02','D09_tea1','The copper kettle',1,-466,'Tidal thermal baths','Sunward dining'), '03_companion':('D09_directory_10','D09_arcade9','Companion games',1,398,'Towels & care','Observation cafe'), '04_papermoon':('D09_directory_03','D09_books2','Paper moon books',-1,-250,'Mineral springs','Lantern restaurant'), '05_parcels':('D09_directory_07','D09_parcel6','Post & parcels',-1,182,'Universal changing','The night table')}
key,alias,name,sign,z,below,above=configs[section];d=json.loads((BASE/'inputs/Game/data/programme_ledger.json').read_text());record=next(x for x in d['destinations'] if x['programme_key']==key);assert record['historical_room_id']==alias;assert record['current_geometry_owner'] is None
region=[]
for x in json.loads((BASE/'inputs/Game/data/spatial_layout.json').read_text())['regions']:
 if x.get('deck')!='D09':continue
 pp=x['boundary'];bb=[min(a[0] for a in pp),max(a[0] for a in pp),min(a[1] for a in pp),max(a[1] for a in pp)];xmin,xmax=sorted([sign*8,sign*54])
 if bb[0]<xmax and bb[1]>xmin and bb[2]<z+68 and bb[3]>z:region.append({'id':x['id'],'bounds':bb,'owner':x.get('authoring_owner')})
void=[]
for x in json.loads((BASE/'inputs/Game/data/spatial_layout.json').read_text())['voids']:
 if 'D09' not in x['decks']:continue
 pp=x['boundary'];bb=[min(a[0] for a in pp),max(a[0] for a in pp),min(a[1] for a in pp),max(a[1] for a in pp)]
 if bb[0]<xmax and bb[1]>xmin and bb[2]<z+68 and bb[3]>z:void.append({'id':x['id'],'bounds':bb})
assert not region and not void,(region,void)
# Exclusive source scopes are user's direct reservation, not a shared registry edit.
info={'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'host':'MousyLaptop','root_checkpoint':'bfa49ac2cf8c53829ad82e4b4be2f6a2e9902182','programme_record':record,'local_claim_search':'Local delivery and windows/revision02 retained claims inspected; matches are neighbour/below references, historical inventories and scoped other-deck packets. No Batch B actual source owner found. User reserved these exact scopes exclusively.','intersecting_D09_actual_floor_regions':region,'intersecting_D09_protected_voids':void,'neighbours':{'below':below,'below_datum_y':44,'above':above,'above_datum_y':61,'maximum_source_roof_y':60.7,'proposal_peak_roof_y':52.5+{'01_starlight':6.5,'02_copper':6,'03_companion':6.8,'04_papermoon':6.1,'05_parcels':5.7}[section]},'source_policy':'Contained fitted source only. No exterior openings, receiving slabs, root connections, live door changes or structural adoption. Existing root network at +/-7.8 preserved; entry at +/-8 leaves 0.2m receiving interface for root.','pending':'Proposed slab required: pinned current structural_meshes has no receiving slab within this programme envelope. Root must compile/adopt support before installation.'}
p=BASE/section/'docs';p.mkdir(parents=True,exist_ok=True);(p/'source_gate.json').write_text(json.dumps(info,indent=2));print(key,'gate pass; no intersecting region/void, source owner absent; root receiving slab needed')
