"""Independent reload/import QA. Run inside Blender under the batch heavy mutex."""
import bpy,json,sys,math,pathlib,hashlib
from mathutils import Vector
P=pathlib.Path(sys.argv[sys.argv.index('--')+1]);SEC=json.loads((P/'docs/PLACEMENT.json').read_text())['programme_key'];rect=json.loads((P/'docs/PLACEMENT.json').read_text())['boundary'];F=json.loads((P/'docs/PLACEMENT.json').read_text())['floor_y'];CAP=json.loads((P/'docs/CONTRACT.json').read_text())['maximum_source_roof_or_service_top_y']

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def geom(o):
 ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get());me=ev.to_mesh();pts=[ev.matrix_world@v.co for v in me.vertices]
 if not pts:ev.to_mesh_clear();return None
 b=[min(v.x for v in pts),min(v.z for v in pts),-max(v.y for v in pts),max(v.x for v in pts),max(v.z for v in pts),-min(v.y for v in pts)]
 finite=all(math.isfinite(c) for v in pts for c in v);uv=bool(me.uv_layers);good=0;total=0
 if uv:
  me.calc_loop_triangles();data=me.uv_layers.active.data
  for tri in me.loop_triangles:
   a,buv,c=[data[i].uv for i in tri.loops];area=abs((buv.x-a.x)*(c.y-a.y)-(buv.y-a.y)*(c.x-a.x));total+=1;good+=area>1e-10
 norm=all(abs(poly.normal.length-1)<.01 for poly in me.polygons if poly.area>1e-10)
 ev.to_mesh_clear();return {'bounds':b,'finite':finite,'uv':uv,'uv_nondegenerate_triangles':good,'triangles':total,'unit_face_normals':norm}

bpy.ops.wm.open_mainfile(filepath=str(P/'source'/f'{SEC}.blend'));native={};fonts={};contact=[];supports=[]
for o in bpy.data.objects:
 if o.type in ['MESH','FONT']:
  if o.type=='FONT':fonts[o.name]=o.data.body
  native[o.name]=geom(o)
  role=o.get('role','');bb=native[o.name]['bounds']
  if 'floor_contact' in role:contact.append({'object':o.name,'minimum_y':bb[1],'floor_contact':abs(bb[1]-F)<.002})
  sup=o.get('support','')
  if sup.startswith('E_') and sup in bpy.data.objects:
   # Bounded contact proposal; actual triangle/collision support remains integration work.
   other=bpy.data.objects[sup]
   if other.type in ['MESH','FONT']:
    ob=geom(other)['bounds'];sep=max(max(bb[i]-ob[i+3],ob[i]-bb[i+3],0) for i in range(3));supports.append({'object':o.name,'support':sup,'aabb_gap_m':sep,'contact_or_small_mount_gap':sep<=.065})
packed=[{'name':im.name,'packed':bool(im.packed_file),'dimensions':list(im.size)} for im in bpy.data.images if im.source=='FILE']
noqa=not any('QA_ONLY' in o.name for o in bpy.data.objects)
native_places=[o.get('source_place_id') for o in bpy.data.objects if o.get('source_place_id')]
bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(P/'exports'/f'{SEC}.glb'));export={o.name:geom(o) for o in bpy.data.objects if o.type=='MESH'}
parity=[]
for n,row in native.items():
 ex=export.get(n);err=max(abs(a-b) for a,b in zip(row['bounds'],ex['bounds'])) if ex else None;parity.append({'object':n,'maximum_bound_delta_m':err,'pass':err is not None and err<.002})
allb=[v['bounds'] for v in export.values()];B=[min(b[i] for b in allb) for i in range(3)]+[max(b[i] for b in allb) for i in range(3,6)]
contain=B[0]>=rect[0]-.002 and B[3]<=rect[1]+.002 and B[2]>=rect[2]-.002 and B[5]<=rect[3]+.002 and B[1]>=F-.002 and B[4]<=CAP+.002
qa={'programme_key':SEC,'native_sha256':digest(P/'source'/f'{SEC}.blend'),'export_sha256':digest(P/'exports'/f'{SEC}.glb'),'actual_export_bounds':B,'containment':contain,'preview_floor_absent_native':noqa,'preview_floor_absent_export':not any('QA_ONLY' in n for n in export),'native_mesh_or_text_count':len(native),'actual_export_mesh_count':len(export),'text_parity':all(n in export for n in fonts),'editable_sign_text':fonts,'packed_resources':packed,'native_export_bound_parity':parity,'floor_contact_checks':contact,'support_aabb_contact_proposals':supports,'actual_export_mesh_checks':export,'scope':'Saved native reload and actual GLB import; bounded source geometry screens, not installed Godot/player/cart/species acceptance'}
expected=json.loads((P/'docs/CONTRACT.json').read_text()).get('capacity');export_places=[o.get('source_place_id') for o in bpy.data.objects if o.get('source_place_id')];qa['source_places']={'expected':expected,'native_count':len(native_places),'export_count':len(export_places),'parity':sorted(native_places)==sorted(export_places),'scope':'Source proposal place IDs only; no new registry capacity'}
qa['pass']=(expected is None or len(export_places)==expected) and sorted(native_places)==sorted(export_places) and contain and noqa and all(im['packed'] for im in packed) and all(x['pass'] for x in parity) and all(v['finite'] and v['uv'] and v['unit_face_normals'] for v in export.values()) and all(x['floor_contact'] for x in contact) and qa['text_parity']
(P/'qa/INDEPENDENT_NATIVE_EXPORT_QA.json').write_text(json.dumps(qa,indent=2));print('INDEPENDENT_QA',qa['pass'],'bounds',B,'meshes',len(export),'contact_fail',[x for x in contact if not x['floor_contact']],'parity_fail',[x for x in parity if not x['pass']],flush=True)
if not qa['pass']:raise RuntimeError('Saved-source/export QA failed; retain evidence and repair')
