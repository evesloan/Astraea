import json,pathlib,math,sys
sys.path.insert(0,r'C:\Users\cered\Dolphin\AstraeaTools\pythondeps')
from shapely.geometry import box,LineString,Polygon
P=pathlib.Path(sys.argv[1]);rows=json.loads((P/'qa/INDEPENDENT_NATIVE_EXPORT_QA.json').read_text())['actual_export_mesh_checks'];cfg=json.loads((P/'docs/APPROACH_PROPOSALS.json').read_text());F=json.loads((P/'docs/PLACEMENT.json').read_text())['floor_y'];obstacles=[]
for n,q in rows.items():
 b=q['bounds']
 if b[1]<F+1.9 and b[4]>F+.04:obstacles.append((n,box(b[0],b[2],b[3],b[5])))
reports=[]
for r in cfg:
 line=LineString(r['points_xz']);capsule=line.buffer(r['radius_m'],cap_style='round',join_style='round');hits=[{'name':n,'overlap_m2':capsule.intersection(p).area} for n,p in obstacles if capsule.intersection(p).area>1e-6];reports.append(dict(r,pass_screen=not hits,hits=hits))
(P/'qa/APPROACH_SCREENS.json').write_text(json.dumps({'scope':'Conservative actual-export AABB swept plan screens over proposed receiving floor; no driven cart or species acceptance','routes':reports},indent=2));print('APPROACH',[ (r['name'],r['pass_screen'],[x['name'] for x in r['hits'][:5]]) for r in reports])
