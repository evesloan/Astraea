import math,json,bpy
from mathutils import Vector
import toolkit as t;import assembly as a

def build(sec,folder,z0,variant,title):
 R=(11,61,z0,z0+72);t.init(sec,folder,69.5,7.2);t.ZONE='cinema_arrival';t.enclosure(R,z0+36)
 # Two200-place blocks: linked retained seats, local raked plinths and one replacement transfer place.
 t.ZONE='raked_audience';rows=[]
 for r in range(10):
  z=z0+20+3.3*r;y=.12+.26*r;rows.append({'row':r+1,'z':z,'tier_y':t.F+y,'places':20})
  for b,(xa,xb) in enumerate([(21,34),(38,51)]):t.prism('tier_'+str(r)+'_'+str(b),[(xa,z-1.5),(xb,z-1.5),(xb,z+1.8),(xa,z+1.8)],0,y,'blue',role='programme_tier_ground_contact')
  # Broad center aisle split into two modest rises per row; floor support remains local.
  for j in range(2):t.prism('aisle_step_'+str(r)+'_'+str(j),[(34,z-1.5+j*1.65),(38,z-1.5+j*1.65),(38,z+.15+j*1.65),(34,z+.15+j*1.65)],0,max(.04,y-.13+j*.13),'quiet',role='programme_tier_ground_contact')
  for c in range(20):
   x=22+1.2*c if c<10 else 39.2+1.2*(c-10);pid=sec+'_R'+str(r+1).zfill(2)+'P'+str(c+1).zfill(2)
   if r==0 and c==0:
    o=t.box('transfer_place_marker',(x,y+.015,z-1.1),(1.1,.03,.10),'zinc',sup='E_tier_0_0');o['source_place_id']=pid;a.PLACES.append({'source_place_id':pid,'xyz':[x,t.F+y,z],'replacement_transfer_place':True,'new_capacity':0})
   else:a.family('seat_'+str(r)+'_'+str(c),'AST-CUL-003.glb',x,z,math.pi,y,place_id=pid,support='E_tier_'+str(r)+'_'+str(0 if c<10 else 1))
 #1:12.11 physical return ramps rise to the highest row; top/far-side return is explicit.
 t.ZONE='accessible_return_ramps'
 for i,(xa,xb) in enumerate([(16.5,19.9),(52.1,55.5)]):
  za,zb=z0+18.2,z0+48;h=2.46;verts=[t.xyz((xa,0,za)),t.xyz((xb,0,za)),t.xyz((xa,0,zb)),t.xyz((xb,0,zb)),t.xyz((xa,h,zb)),t.xyz((xb,h,zb))];faces=[(0,1,3,2),(2,3,5,4),(0,2,4),(1,5,3),(0,4,5,1)]
  me=bpy.data.meshes.new('return_ramp'+str(i));me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new('return_ramp'+str(i),me);bpy.context.scene.collection.objects.link(o);bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.normals_make_consistent(inside=False);bpy.ops.object.mode_set(mode='OBJECT');o.select_set(False);t.tag(o,'return_ramp'+str(i),'quiet',role='programme_ramp_ground_contact')
  t.prism('ramp_top_landing'+str(i),[(xa,z0+48),(xb,z0+48),(xb,z0+54),(xa,z0+54)],0,h,'quiet',role='programme_tier_ground_contact')
  for j,z in enumerate([z0+19,z0+29,z0+39,z0+48]):
   yy=h*min(max((z-za)/(zb-za),0),1);t.rod('ramp_guard_post'+str(i)+str(j),(xa if i==0 else xb,yy,z),(xa if i==0 else xb,yy+1.05,z),.045,'zinc',sup='E_return_ramp'+str(i))
  t.rod('ramp_handrail'+str(i),(xa if i==0 else xb,1.05,za),(xa if i==0 else xb,h+1.05,zb),.055,'zinc',sup='E_ramp_guard_post'+str(i)+'0')
 t.prism('rear_crossing',[(16.5,z0+51.5),(55.5,z0+51.5),(55.5,z0+55),(16.5,z0+55)],0,2.46,'quiet',role='programme_tier_ground_contact')
 # Screen end is a deep supported focus, with service gap behind it; four original still identities.
 t.ZONE='screen_and_acoustic_focus';base=t.box('screen_base',(36,.55,z0+8),(25,1.1,1.2),'blue',role='screen_floor_contact');screen=t.box('screen',(36,3.75,z0+8),(24,4.8,.24),'rubber',sup='E_screen_pier0')
 for i,x in enumerate([24,48]):t.box('screen_pier'+str(i),(x,3.1,z0+8),(1.0,6.2,1.0),'blue',role='screen_floor_contact')
 t.box('screen_lintel',(36,6.28,z0+8),(25,.3,1),'white',sup='E_screen_pier0')
 # Bounded abstract source still, not a claim of running media or borrowed artwork.
 for j in range(7):
  xx=28+j*2.6;yy=2.2+(.3*j if variant==0 else .8*math.sin(j*.9+variant));t.box('original_still_'+str(j),(xx,yy,z0+8.145),(1.1,.18+(.15*j),.015),'zinc' if j%2 else 'cloth',sup=screen.name,bev=0)
 t.box('screen_notice',(36,1.5,z0+8.16),(4,.4,.02),'blue',sup=screen.name);t.sign('film_title',title,36,z0+8.19,1.42,.11,sup='E_screen_notice')
 # Section-specific acoustic shoulders, never a copied Cinema1 identity.
 t.ZONE='acoustic_room_form'
 for i,z in enumerate([z0+16,z0+28,z0+40]):
  for j,x in enumerate([12.3,59.7]):
   post=t.box('acoustic_shoulder'+str(i)+str(j),(x,2.9,z),(.6,5.8,2.5 if variant%2==0 else 1.5),'blue',role='acoustic_floor_contact')
   t.rod('fan_roof_rib'+str(i)+str(j),(x,5.65,z),(36,6.9,z+(-2 if variant%2 else 2)),.13,'white',sup=post.name)
 # Quiet foyer pocket and practical, separated projection workshop in the rear.
 t.ZONE='foyer_rest';t.bench('foyer_pause',24,z0+66,8,0,'quiet');t.table('foyer_table',24,z0+64,3,1.6)
 t.ZONE='projection_service';t.linewall('booth_front_l',(31,z0+61),(33.8,z0+61),3.2,'blue');t.linewall('booth_front_r',(38.2,z0+61),(41,z0+61),3.2,'blue');t.linewall('booth_side_l',(31,z0+61),(31,z0+68),3.2,'blue');t.linewall('booth_side_r',(41,z0+61),(41,z0+68),3.2,'blue');t.linewall('booth_back',(31,z0+68),(41,z0+68),3.2,'blue');t.table('projection_bench',36,z0+65,5,1.5)
 t.box('projector_base',(36,1.02,z0+65),(1.4,.32,.8),'rubber',sup='E_projection_benchtop');t.box('projector_lens',(36,1.05,z0+64.54),(.3,.22,.14),'zinc',sup='E_projector_base')
 t.ZONE='care_stock';t.cabinet('cinema_care',56,z0+67,math.pi)
 for i,z in enumerate([z0+12,z0+23,z0+35,z0+47,z0+58,z0+65]):
  for j,x in enumerate([15,36,57]):t.light('cinema_worklight_'+str(i)+str(j),x,z,l=3)
 contract=next(x for x in json.loads((t.BASE/'inputs/Game/docs/coordination/sol_fifty_sections_20261008/BATCH_E.json').read_text())['sections'] if x['programme_key']==sec);contract['capacity']=200;(t.P/'docs/CONTRACT.json').write_text(json.dumps(contract,indent=2));a.save_places(200)
 h=t.save_export(R);routes=[{'name':'level_guest_cart','radius_m':1.7,'points_xz':[[13,z0+36],[14.55,z0+36],[14.55,z0+12],[57.45,z0+12],[57.45,z0+58],[36,z0+58]]},{'name':'projection_body','radius_m':.65,'points_xz':[[36,z0+58],[36,z0+61],[36,z0+63.5]]},{'name':'screen_service_cart','radius_m':1.7,'points_xz':[[14.55,z0+12],[14.55,z0+4.5],[57.45,z0+4.5],[57.45,z0+12]]}];(t.P/'docs/APPROACH_PROPOSALS.json').write_text(json.dumps(routes,indent=2));(t.P/'docs/RAKE_RAMPS_AND_SIGHTLINES.json').write_text(json.dumps({'rows':rows,'places':200,'linked_physical_seats':199,'replacement_transfer_places':1,'ramp_rise_m':2.46,'ramp_run_m':29.8,'slope_ratio':29.8/2.46,'outer_level_cart_aisles_m':3.4,'center_aisle_m':4,'rear_return_crossing_m':3.5,'screen_top_y':t.F+6.15,'lowest_eye_y':t.F+.12+1.65,'highest_eye_y':t.F+2.46+1.65,'optical_sightline_acceptance':'Root target-species dynamic heads/screen optical review required','ramp_acceptance':'Source slope and contacts only; actual loaded cart traversal root hold'},indent=2));(t.P/'docs/DESIGN_INTENT.json').write_text(json.dumps({'purpose':'Single-deck200-place cinema with projection service and foyer rest','primary_form':['Paired raked blocks under outward swept fan ribs','Orchard rhythm of deep staggered acoustic shoulders','Quiet letterbox focus under offset folded ribs','Cloud focus with broad compressed shoulder intervals'][variant],'arrival':'West level aisle retains threshold; turns front or rear without crossing seating blocks','capacity':200,'new_capacity':0,'film_title':title,'source_original_static_still':True},indent=2));t.render(R,[('01_arrival',(13,z0+36),(36,z0+29)),('02_audience_focus',(36,4.11,z0+50),(36,3.4,z0+8)),('03_ramp_edge',(58,z0+32),(39,z0+29)),('04_projection',(36,z0+59),(36,z0+65))],h);print('COMPLETE',sec,h)
