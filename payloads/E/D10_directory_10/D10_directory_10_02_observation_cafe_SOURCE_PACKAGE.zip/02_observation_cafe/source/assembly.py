import math,bpy,json
from mathutils import Matrix,Vector
import toolkit as t
TEMPLATES={};PLACES=[]
def family(n,filename,x,z,yaw=0,y=0,place_id=None,support=None):
 if filename not in TEMPLATES:
  before=set(bpy.data.objects);bpy.ops.import_scene.gltf(filepath=str(t.BASE/'dependencies'/filename));obs=set(bpy.data.objects)-before
  records=[]
  for o in sorted(obs,key=lambda o:o.name):
   if o.type=='MESH':records.append((o.data.copy(),o.matrix_world.copy(),o.name))
  for o in obs:bpy.data.objects.remove(o,do_unlink=True)
  TEMPLATES[filename]=records
 T=Matrix.Translation(Vector(t.xyz((x,y,z))))@Matrix.Rotation(-yaw,4,'Z')
 objects=[]
 base_index=min(range(len(TEMPLATES[filename])),key=lambda k:min((TEMPLATES[filename][k][1]@v.co).z for v in TEMPLATES[filename][k][0].vertices))
 for k,(mesh,mat,name) in enumerate(TEMPLATES[filename]):
  o=bpy.data.objects.new('E_'+n+'_'+str(k),mesh);bpy.context.scene.collection.objects.link(o);o.matrix_world=T@mat;o['programme_key']=t.SEC;o['zone']=t.ZONE;o['support']=support if support and k==base_index else 'Pinned Catalogue internal component contacts; base receiving support';o['role']='retained_editable_family_instance';t.A.append(o);objects.append(o)
 if place_id:
  objects[0]['source_place_id']=place_id;objects[0]['source_capacity_proposal']=True;PLACES.append({'source_place_id':place_id,'xyz':[x,t.F+y,z],'yaw':yaw,'family':filename,'support':support or 'Root receiving floor'})
 return objects
def dining(n,x,z,count=6):
 t.table(n+'_table',x,z,3.2,2)
 offsets=[(-2.4,0),(2.4,0),(-1.1,-1.75),(1.1,-1.75),(-1.1,1.75),(1.1,1.75)]
 for k,(dx,dz) in enumerate(offsets[:count]):family(n+'_seat'+str(k),'AST-DIN-002.glb',x+dx,z+dz,math.atan2(-dx,-dz),place_id=n+'_'+str(k))
def save_places(expected):
 assert len(PLACES)==expected
 (t.P/'docs/SOURCE_PLACES.json').write_text(json.dumps({'existing_programme_capacity':expected,'authored_source_places':PLACES,'new_capacity':0,'root_registry_untouched':True,'species_and_live_reservation_acceptance':False},indent=2))
