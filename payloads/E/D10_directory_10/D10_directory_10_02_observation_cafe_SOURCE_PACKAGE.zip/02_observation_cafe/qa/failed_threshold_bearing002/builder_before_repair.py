import sys,pathlib,math,json
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent));import toolkit as t;import assembly as a
R=(8,54,398,466);t.init('D10_directory_10','02_observation_cafe',61,6.4);t.ZONE='cafe_arrival';t.enclosure(R,432)
# Twenty conversation tables retain the existing120 dining places, around a broad arrival street.
t.ZONE='cafe_seating'
for iz,z in enumerate([408,420,444,456]):
 for ix,x in enumerate([14,22,30,38,46]):a.dining('cafe_'+str(iz)+'_'+str(ix),x,z,6)
# Observation is inward, toward an original bounded art/garden focal island. No celestial-window claim.
t.ZONE='inward_observation_focal';poly=[(27,429),(32,429),(34,431),(34,433),(31,435),(27,434),(25,432)];base=t.prism('observation_plinth',poly,0,.6,'blue',role='exhibit_floor_contact')
for i,(x,z) in enumerate([(28,431),(31,432)]):a.family('cafe_garden_'+str(i),'AST-BOT-002.glb',x,z,y=.6,support=base.name)
# Splayed pavilion shoulders and unequal ceiling drops organize the seating without a uniform canopy grid.
for i,(x,z) in enumerate([(12,404),(12,459),(49,404),(49,459)]):
 t.rod('cafe_pier'+str(i),(x,0,z),(x,4.5,z),.28,'white');t.rod('cafe_branch'+str(i),(x,4.35,z),(30,6.24,z),.15,'white',sup='E_cafe_pier'+str(i))
for i,z in enumerate([410,420,444,454]):
 for j,x in enumerate([18,34,46]):t.light('cafe_dining_light_'+str(i)+str(j),x,z,l=3)
# Separate clean finishing and used-dish return, reached from the east service edge.
t.ZONE='clean_finishing';a.family('clean_counter','AST-HSP-001.glb',42,463,math.pi);t.linewall('finishing_screen',(38,461.3),(44,461.3),2.2,'blue')
t.ZONE='used_return';a.family('used_return','AST-HSP-004.glb',48,463,math.pi);t.ZONE='care';t.cabinet('cafe_care',51,404,math.pi)
t.light('service_light',46,463,l=4);t.light('arrival_focus',29,432,l=4)
t.box('small_cafe_notice',(12,1.6,435),(3,.5,.15),'blue',sup='E_cafe_notice_post');t.rod('cafe_notice_post',(12,0,435),(12,1.9,435),.07,'zinc');t.sign('cafe_notice','OBSERVATION CAFE',12,435.09,1.56,.12,sup='E_small_cafe_notice')
contract=next(r for r in json.loads((t.BASE/'VISIBLE_SCOPE_AND_HOLDS.json').read_text()) if r['programme_key']==t.SEC);contract.update({'entry_xyz':[8,61,432],'portal_minimum_clear_width_m':3.6,'root_exclusive_reservation':True,'protected_threshold_xz':[[6,430],[10,430],[10,434],[6,434]],'observation_hold':'No proven hull exposure. This source provides inward focal observation; root must resolve actual exterior view independently.'});(t.P/'docs/CONTRACT.json').write_text(json.dumps(contract,indent=2));a.save_places(120)
h=t.save_export(R);routes=[{'name':'arrival_cart','radius_m':.85,'points_xz':[[10,432],[20,432],[20,436],[51.5,436]]},{'name':'east_service_cart','radius_m':.85,'points_xz':[[51.5,436],[51.5,460.6],[48,460.6],[48,461.2]]},{'name':'care_body','radius_m':.65,'points_xz':[[51.5,432],[51.5,407]]}];(t.P/'docs/APPROACH_PROPOSALS.json').write_text(json.dumps(routes,indent=2));(t.P/'docs/DESIGN_INTENT.json').write_text(json.dumps({'purpose':'120-place cafe with inward observation focal island','form':'Broad central street divides two nested dining fields; splayed pavilion shoulders lift the section','service':'Separated clean and used handling at the north edge; eastern clear care approach','capacity':120,'new_capacity':0,'receiving_holds':['Actual supported common floor and exterior connection','Hull observation view unavailable','Live seat reservation and species fit']},indent=2));t.render(R,[('01_arrival',(10,432),(30,428)),('02_programme',(18,436),(30,444)),('03_observation',(22,435),(30,431)),('04_service',(48,460),(48,463))],h);print('COMPLETE',t.SEC,h)
