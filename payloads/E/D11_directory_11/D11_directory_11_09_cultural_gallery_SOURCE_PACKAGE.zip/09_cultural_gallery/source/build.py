import sys,pathlib,math,json
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent));import toolkit as t;import assembly as a
R=(-103,-57,290,358);t.init('D11_directory_11','09_cultural_gallery',69.5,6.8);t.ZONE='gallery_arrival';t.enclosure(R,324)
# Alternating deep display folds make a meandering but legible curatorial sequence.
t.ZONE='folded_exhibition_sequence'
for i,(x,z,sgn) in enumerate([(-88,301,1),(-74,312,-1),(-88,337,1),(-74,348,-1)]):
 wall=t.linewall('display_fold_'+str(i),(x-5,z+sgn),(x+5,z+7*sgn),3.8,'blue',.35)
 base=t.prism('exhibit_plinth_'+str(i),[(x-2,z-1.5),(x+2,z-1.5),(x+2.5,z),(x+1,z+1.7),(x-2,z+1)],0,.7,'white',role='exhibit_floor_contact')
 # Original abstract assembled forms stand in for root's eventual verified cultural collection.
 for j in range(3):t.rod('abstract_form_'+str(i)+str(j),(x-1.2+j*1.2,.7,z),(x-1.2+j*1.2,1.7+.4*((i+j)%3),z+.2),.13,'zinc',sup=base.name)
 t.box('exhibit_label_'+str(i),(x,.76,z-1.43),(1.1,.12,.05),'blue',sup=base.name);t.sign('exhibit_text_'+str(i),'STUDY '+str(i+1),x,z-1.47,.72,.08,face='north',sup='E_exhibit_label_'+str(i))
# Central shared interpretation ring has open opposed gateways, level common floor untouched.
t.ZONE='shared_interpretation'
for i,(a0,a1) in enumerate([(25,155),(205,335)]):
 poly=[]
 for ang in range(a0,a1+1,10):poly.append((-81+9*math.cos(math.radians(ang)),324+7*math.sin(math.radians(ang))))
 for ang in range(a1,a0-1,-10):poly.append((-81+8.4*math.cos(math.radians(ang)),324+6.4*math.sin(math.radians(ang))))
 t.prism('interpretation_arc_'+str(i),poly,0,1.05,'quiet',role='bench_floor_contact')
 t.bench('reading_pause_'+str(i),-81,324+(-10 if i==0 else 10),7,math.pi if i==0 else 0,'cloth')
# Fitted conservation handling is kept apart from the guest circuit.
t.ZONE='conservation_edge';t.linewall('conservation_screen',(-99,349),(-89,349),2.8,'blue');t.shelf('archive_stock',-94,355,7,2.4,'records');t.table('conservation_work',-94,352,5,1.8);t.cabinet('gallery_care',-62,355,math.pi)
for i,z in enumerate([299,311,324,338,350]):
 for j,x in enumerate([-98,-81,-62]):t.light('gallery_light_'+str(i)+str(j),x,z,l=3)
t.rod('gallery_notice_post',(-67,0,328),(-67,2,328),.07,'zinc');t.box('gallery_notice',(-67,1.7,328),(3,.45,.12),'blue',sup='E_gallery_notice_post');t.sign('gallery_name','CULTURAL GALLERY',-67,328.08,1.63,.12,sup='E_gallery_notice')
contract=next(x for x in json.loads((t.BASE/'inputs/Game/docs/coordination/sol_fifty_sections_20261008/BATCH_E.json').read_text())['sections'] if x['programme_key']==t.SEC);(t.P/'docs/CONTRACT.json').write_text(json.dumps(contract,indent=2));h=t.save_export(R)
routes=[{'name':'gallery_arrival_cart','radius_m':.85,'points_xz':[[-59,324],[-69,324],[-81,324],[-100,324]]},{'name':'guest_loop_body','radius_m':.65,'points_xz':[[-64,324],[-64,294],[-100,294],[-100,345],[-87,345],[-87,351],[-64,351],[-64,324]]},{'name':'care_cart','radius_m':.85,'points_xz':[[-61,324],[-61,352.5]]}];(t.P/'docs/APPROACH_PROPOSALS.json').write_text(json.dumps(routes,indent=2));(t.P/'docs/DESIGN_INTENT.json').write_text(json.dumps({'purpose':'Cultural exhibition, shared interpretation and separate conservation edge','primary_form':'Alternating folded display edges lead to two open interpretation arcs','arrival':'Straight east-west sightline, level perimeter loop with open ring gateways','collection_status':'Four original abstract source studies; root selects verified cultural contents','capacity_change':False,'service':'Screened conservation work and independent eastern care run'},indent=2));t.render(R,[('01_arrival',(-59,324),(-81,324)),('02_exhibition',(-83,299),(-88,301)),('03_interpretation',(-70,324),(-81,324)),('04_conservation',(-87,350),(-94,353))],h);print('COMPLETE',t.SEC,h)
