import pathlib,sys
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
from cinema_source import build
build('D11_directory_03','04_cinema_2',-316,0,'MAP OF SMALL SUNS')
