import sys,pathlib,math,json
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent));import toolkit as t;import assembly as a
R=(-54,-8,182,250);t.init('D11_directory_10','08_games_companionship',69.5,6.6);t.ZONE='games_arrival';t.enclosure(R,216)
# A branching social street separates active fitted play bays from quieter shared tables.
t.ZONE='active_game_bays'
for i,z in enumerate([191,202,230,241]):
 t.linewall('game_bay_shoulder'+str(i),(-50,z+4),(-43,z+2),2.7,'blue',.3);top=t.table('game_console'+str(i),-45,z,4,1.8)
 for j,x in enumerate([-46,-44]):
  t.rod('console_screen_stem'+str(i)+str(j),(x,.85,z+.45),(x,1.25,z+.45),.05,'zinc',sup=top.name);t.box('console_screen'+str(i)+str(j),(x,1.48,z+.45),(1.3,.65,.15),'rubber',sup='E_console_screen_stem'+str(i)+str(j));t.chair('console_task'+str(i)+str(j),x,z-1.6,0)
 t.box('stored_game_cartridge'+str(i),(-45,.99,z),(1.1,.25,.65),'cloth',sup=top.name)
# Shared tabletop companionship is warm and unhurried; marker pieces remain editable static props.
t.ZONE='shared_play_tables'
for i,(x,z) in enumerate([(-31,194),(-31,205),(-31,228),(-31,239)]):
 top=t.table('shared_game'+str(i),x,z,3.6,2.2)
 for j,(dx,dz) in enumerate([(-2.6,0),(2.6,0),(0,-2),(0,2)]):a.family('shared_chair'+str(i)+str(j),'AST-DIN-002.glb',x+dx,z+dz,math.atan2(-dx,-dz))
 board=t.box('game_board'+str(i),(x,.89,z),(1.6,.06,1.4),'blue',sup=top.name)
 for j in range(6):t.box('game_piece'+str(i)+str(j),(x-.6+.24*j,1.0,z),( .1,.16,.1),'zinc' if j%2 else 'cloth',sup=board.name,bev=.02)
# Fitted quiet recess on a dogleg edge, rather than a second crew recreation plan.
t.ZONE='quiet_companionship';t.linewall('quiet_fold_a',(-23,225),(-20,228),2.5,'blue');t.linewall('quiet_fold_b',(-20,228),(-20,241),2.5,'blue');t.bench('quiet_conversation',-15,236,8,-math.pi/2,'quiet');t.table('quiet_side',-17,236,2,1.7)
# Deep game storage and maintenance remain apart from used equipment.
t.ZONE='equipment_storage';t.shelf('clean_games',-40,247,8,2.4,'clean');t.shelf('used_equipment',-27,247,5,2.4,'records');t.ZONE='care';t.cabinet('game_care',-12,247,math.pi)
for i,z in enumerate([193,205,228,240]):
 for j,x in enumerate([-46,-31,-14]):t.light('games_pool'+str(i)+str(j),x,z,l=3)
t.rod('games_notice_post',(-16,0,221),(-16,2.0,221),.07,'zinc');t.box('games_notice',(-16,1.7,221),(3,.45,.12),'blue',sup='E_games_notice_post');t.sign('games_label','GAMES & COMPANIONSHIP',-16,221.08,1.63,.10,sup='E_games_notice')
contract=next(x for x in json.loads((t.BASE/'inputs/Game/docs/coordination/sol_fifty_sections_20261008/BATCH_E.json').read_text())['sections'] if x['programme_key']==t.SEC);(t.P/'docs/CONTRACT.json').write_text(json.dumps(contract,indent=2));h=t.save_export(R)
routes=[{'name':'social_street_cart','radius_m':.85,'points_xz':[[-10,216],[-41,216],[-50.5,216]]},{'name':'east_care_cart','radius_m':.85,'points_xz':[[-11,216],[-11,244.5]]},{'name':'shared_tables_body','radius_m':.65,'points_xz':[[-35.5,216],[-35.5,185],[-21,185]]}];(t.P/'docs/APPROACH_PROPOSALS.json').write_text(json.dumps(routes,indent=2));(t.P/'docs/DESIGN_INTENT.json').write_text(json.dumps({'purpose':'Guest active gaming and unhurried tabletop companionship','primary_form':'Branching central street with deep slanted play bays and a dogleg quiet edge','service':'Clean game stock, independent used equipment and clear eastern care run','capacity_change':False,'static_source_props_only':True,'working_interactions':'No new controllers; retain established RMB-focus/E vocabulary'},indent=2));t.render(R,[('01_arrival',(-10,216),(-36,215)),('02_active_play',(-39,217),(-45,202)),('03_shared_tables',(-35.5,218),(-31,228)),('04_quiet_care',(-11,230),(-16,236))],h);print('COMPLETE',t.SEC,h)
