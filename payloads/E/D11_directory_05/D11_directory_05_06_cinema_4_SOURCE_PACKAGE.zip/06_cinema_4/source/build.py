import pathlib,sys
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
from cinema_source import build
build('D11_directory_05','06_cinema_4',92,2,'LETTERS TO A QUIET MOON')
