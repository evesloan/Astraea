# Simulation suites

Two independently enclosed immersive source suites use unequal chamber proportions and deep open thresholds off a staffed dispatch spine. Tall supported roofs and static internal panels define spatial immersion. No simulation software, moving portal, projected capacity or hull opening is asserted.

No gameplay, capacity, live collision, species-wide traversal, performance or installed Godot acceptance is implied. No shared registry entry, hull opening, exterior view, working door or receiving floor was changed. Small signs are editable; no controls are rebound. RMB-focus/E vocabulary is retained.
