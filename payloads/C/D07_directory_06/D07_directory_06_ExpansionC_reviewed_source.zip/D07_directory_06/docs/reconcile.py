import pathlib,json,hashlib,sys,datetime
R=pathlib.Path(__file__).resolve().parent;W=R.parents[2];I=R/'inputs';N=int(sys.argv[1]);cfg=json.loads((I/'SECTION_CONTRACTS.json').read_text())[N];KEY=cfg['programme_key'];P=R/KEY;P.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins=json.loads((I/'PIN_RECEIPT.json').read_text())
contracts=json.loads((I/'CONTRACT_PIN_RECEIPT.json').read_text())
for a in contracts['files']:assert sha(I/pathlib.Path(a['path']).name)==a['sha256'],a['path']
assert KEY in json.loads((I/'RESERVATIONS.json').read_text())['batches']['C']['programme_keys']
for a in pins['files']:assert sha(I/a['path'])==a['sha256'],a['path']
ledger=json.loads((I/'Game/data/programme_ledger.json').read_text());row=next(x for x in ledger['destinations'] if x['programme_key']==KEY);assert row['current_geometry_owner'] is None
live=json.loads((W/'Game/data/programme_ledger.json').read_text());live_row=next(x for x in live['destinations'] if x['programme_key']==KEY);assert live_row.get('current_geometry_owner') is None
claims=[]
for p in (W/'external_packages').rglob('PLACEMENT.json'):
 if P in p.parents or 'failed' in p.parts:continue
 try:
  a=json.loads(p.read_text(encoding='utf-8'))
  if a.get('programme_key')==KEY:claims.append(dict(path=str(p),sha256=sha(p),placement=a))
 except (ValueError,UnicodeError):pass
regions=json.loads((I/'Game/data/spatial_layout.json').read_text())['regions'];floor_owners=[];b=row['historical_envelope']
for a in regions:
 if a['deck']!=cfg['deck']:continue
 xs=[p[0] for p in a['boundary']];zs=[p[1] for p in a['boundary']]
 if min(max(xs),b['x'][1])-max(min(xs),b['x'][0])>0 and min(max(zs),b['z'][1])-max(min(zs),b['z'][0])>0:floor_owners.append(a)
receipt=dict(checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),programme=row,root_reservation=json.loads((I/'EXCLUSIVE_RESERVATION.json').read_text()),source_contract=cfg,live_receiving_owner=live_row.get('current_geometry_owner'),existing_exact_source_claims=claims,receiving_floor_overlap_records=floor_owners,protected_source='Complete authoritative BATCH_C and PROTECTED_VOLUMES at d2c54b3; pinned7955 source geometry; actual saved bounds independently checked.',floor_policy='No common/preview floor authored; root owns slab and connections.',capacity_policy='Unknown registered occupancy remains null. Proposed fixtures do not alter capacity.',source_checkpoint=pins['checkpoint'],independent_checkpoint_manifest_sha256=pins['checkpoint_manifest_sha256'],pins_verified=True,blocked=bool(claims) or cfg['roof_cap_y'] is None)
(P/'RECONCILIATION.json').write_text(json.dumps(receipt,indent=2));print(KEY,'CONFLICT_OR_MISSING_CAP' if receipt['blocked'] else 'UNCONTESTED',row['name'])
assert not receipt['blocked']
