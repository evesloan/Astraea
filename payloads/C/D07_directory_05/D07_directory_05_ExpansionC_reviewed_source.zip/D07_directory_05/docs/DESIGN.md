# Training commons

A branching level commons reaches two unequal demonstration clearings with grounded training frames, fitted review bench and nearby rest edge. Deep angled backdrops separate working sightlines from through movement. Static equipment proxies imply no invented exercise mechanics, species suitability or capacity.

No gameplay, capacity, live collision, species-wide traversal, performance or installed Godot acceptance is implied. No shared registry entry, hull opening, exterior view, working door or receiving floor was changed. Small signs are editable; no controls are rebound. RMB-focus/E vocabulary is retained.
