import pathlib, struct, json, hashlib, math,sys
R=pathlib.Path(__file__).resolve().parent
results=[]
N=int(sys.argv[1]);key=json.loads((R/'inputs/SECTION_CONTRACTS.json').read_text())[N]['programme_key']
for key in [key]:
 p=R/key/'exports/section.glb';raw=p.read_bytes();jl=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+jl]);off=20+jl;bl,bt=struct.unpack_from('<II',raw,off);assert bt==0x004e4942;binary=raw[off+8:off+8+bl]
 def values(ai):
  a=g['accessors'][ai];assert a['componentType']==5126 and not a.get('sparse');v=g['bufferViews'][a['bufferView']];n={'VEC2':2,'VEC3':3}[a['type']];stride=v.get('byteStride',n*4);start=v.get('byteOffset',0)+a.get('byteOffset',0)
  return [struct.unpack_from('<'+'f'*n,binary,start+k*stride) for k in range(a['count'])]
 normals=uvs=0;worst=0;errors=[]
 for m in g['meshes']:
  for q in m['primitives']:
   ns=values(q['attributes']['NORMAL']);ts=values(q['attributes']['TEXCOORD_0']);normals+=len(ns);uvs+=len(ts)
   for n in ns:
    if not all(math.isfinite(a) for a in n):errors.append('nonfinite normal');continue
    e=abs(math.sqrt(sum(a*a for a in n))-1);worst=max(worst,e)
    if e>.005:errors.append('nonunit normal')
   if not all(math.isfinite(a) for t in ts for a in t):errors.append('nonfinite UV')
 results.append(dict(programme_key=key,glb_sha256=hashlib.sha256(raw).hexdigest(),normal_vectors=normals,uv_pairs=uvs,maximum_normal_length_error=worst,passed=not errors,errors=sorted(set(errors))))
out=dict(scope='Direct final actual GLB binary NORMAL/TEXCOORD_0 float-value checks; no Blender launch or installed runtime acceptance.',sections=results,passed=all(x['passed'] for x in results))
(R/key/'qa/GLB_VALUE_CHECK.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2));assert out['passed']
