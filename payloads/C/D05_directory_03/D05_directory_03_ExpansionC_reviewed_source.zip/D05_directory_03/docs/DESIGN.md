# Clinical research

Three interlocking instrument/research wings face a continuous clean analysis spine. Shaped opaque returns protect work edges; overhead supported service bridges and a separate preparation/return corner define staffed research. Eight workbench fixtures are proposed construction furniture, not registered laboratory or treatment capacity.

No gameplay, capacity, live collision, species-wide traversal, performance or installed Godot acceptance is implied. No shared registry entry, hull opening, exterior view, working door or receiving floor was changed. Small signs are editable; no controls are rebound. RMB-focus/E vocabulary is retained.
