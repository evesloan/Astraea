"""Construction-first compositions. One exclusive programme per invocation."""
def construct(G,N):
 box,rod,disc,asset,sign,lamp,bed= [G[x] for x in ['box','rod','disc','asset','sign','lamp','bed']]
 math,bpy,xyz,finish= [G[x] for x in ['math','bpy','xyz','finish']]
 points,carts,lights=G['POINTS'],G['CART_POINTS'],G['LIGHTS']
 counts={};walk=[]
 def wall(n,u,v,w,l,h=3.6,mat='staff'):
  return box(n,(u,h/2,v),(w,h,l),mat)
 def edge(n,a,b,h=3.6,mat='staff',thick=.22):
  pa,pb=xyz((a[0],h/2,a[1])),xyz((b[0],h/2,b[1]));d=pb-pa
  bpy.ops.mesh.primitive_cube_add(size=1,location=(pa+pb)/2);o=bpy.context.object;o.dimensions=(thick,d.length,h);o.rotation_euler.z=math.atan2(-d.x,d.y);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,n,mat)
 def bench(n,u,v,yaw=0):
  g=asset('AST-FUR-001',n,u,v,yaw=yaw);points.append((n,(u-1.8,v)));carts.append((n+'_cart',(u-2.8,v)));return g
 def canopy(n,u,v,w,l,h=3.6,mat='staff'):
  supports=[]
  for q,(x,z) in enumerate([(u-w/2,v-l/2),(u+w/2,v-l/2),(u-w/2,v+l/2),(u+w/2,v+l/2)]):
   supports.append(wall(n+'_pier'+str(q),x,z,.32,.32,h,mat))
  return box(n+'_header',(u,h+.1,v),(w+.35,.2,l+.35),mat,supports[0].name)
 def workbench(n,u,v,w=6,l=1.8,mat='staff'):
  b=box(n+'_base',(u,.47,v),(w,.94,l),mat);t=box(n+'_top',(u,1.02,v),(w+.15,.15,l+.15),'ivory',b.name)
  for q in (-1,1):
   s=box(n+'_instrument'+str(q),(u+q*w*.28,1.29,v),(.65,.4,.5),'staff',t.name);box(n+'_instrument_face'+str(q),(u+q*w*.28,1.32,v-.26),(.48,.22,.035),'opal',s.name)
  return t
 def service(n,u,v):
  workbench(n,u,v,5,1.7);asset('AST-MED-002',n+'_wash',u,v+4);asset('AST-MED-004',n+'_trolley',u+4,v+4)
  points.append((n+'_approach',(u+2.5,v+4)));carts.append((n+'_cart',(u+2.5,v+4)))
 def header_entry():
  # No external leaf or shared portal; the root's 4x4m keep-clear remains empty.
  for q,v in enumerate((29.5,38.5)):
   p=wall('threshold_pier'+str(q),4,v,.8,1.1,3.2,'stone')
   rod('threshold_branch'+str(q),(4,3.1,v),(8,3.65,v+(-1 if q==0 else 1)),.16,'wood',p.name)
  p=wall('wayfinding_post',3,27.5,.3,.3,2.25,'staff');sign('section_name',G['TITLE'].upper(),2.89,27.5,1.9,p.name)
 header_entry()
 # Shared practical stocked cupboard is a compatible kit, not the room's form.
 G['care'](5,8)
 if N==0:
  # Three interlocking research wings around an open clean analysis spine.
  for j,v in enumerate((15,34,53)):
   wall('research_back'+str(j),41,v,.28,13,3.9)
   edge('research_return'+str(j),(41,v-6.5),(31,v-8),3.9)
   edge('research_short_return'+str(j),(41,v+6.5),(36,v+7.5),3.9)
   canopy('research_service_bridge'+str(j),35.5,v+5.8,9.5,1.5,4.2)
   workbench('analysis_island'+str(j),31,v,8,2.2)
   workbench('instrument_edge'+str(j),38,v-3.5,4,1.6)
   asset('AST-MED-002','clean_wash'+str(j),38,v+3.5)
   lamp('research_task'+str(j),26,v+4,3.1)
   points.append(('analysis_work'+str(j),(31,v+2.5)));carts.append(('analysis_cart'+str(j),(31,v+2.8)))
  wall('controlled_prep_back',15,57,12,.28,3.4);service('prep_and_return',16,60)
  wall('archive_screen',13,20,.28,13,3.5);workbench('records_and_readout',10,20,5,1.6)
  routes=[[(1,34),(23,34),(23,10),(23,61),(29,61)],[(23,10),(8.3,10),(8.3,8)],[(23,17.8),(31,17.8)],[(23,36.8),(31,36.8)],[(23,55.8),(31,55.8)]]
  views=[('arrival',(1,34),(32,34)),('research',(23,37),(37,34)),('clean_prep',(23,60),(16,60)),('service',(10,8),(5,8))]
  purpose='Three interlocking instrument/research wings face a continuous clean analysis spine. Shaped opaque returns protect work edges; overhead supported service bridges and a separate preparation/return corner define staffed research. Eight workbench fixtures are proposed construction furniture, not registered laboratory or treatment capacity.'
  counts={'registered_destinations_preserved':1,'research_wings':3,'workbench_fixtures':8,'clinical_occupancy':None}
 elif N==1:
  # Sheltered recovery pockets along two offset, quiet-facing edges.
  for j,v in enumerate((15,31,50)):
   for k,u in enumerate((23,39)):
    wall('recovery_back'+str(j)+'_'+str(k),u+3.6,v,.25,9,3.2,'stone')
    edge('recovery_screen'+str(j)+'_'+str(k),(u+3.6,v-4.5),(u-1,v-5.5),2.8,'wood')
    asset('AST-MED-003','neutral_rest'+str(j)+'_'+str(k),u,v)
    bench('accompanying_seat'+str(j)+'_'+str(k),u,v+3.5,math.pi/2)
    lamp('recovery_light'+str(j)+'_'+str(k),u+2.5,v+3.5,2.6)
   canopy('quiet_soffit'+str(j),40,v,6,8,3.6,'wood')
  service('assisted_care',11,58)
  routes=[[(1,34),(15,34),(15,10),(15,59),(30,59),(30,10)],[(15,10),(8.3,10),(8.3,8)]]
  views=[('arrival',(1,34),(28,34)),('recovery',(29.5,31),(39,31)),('quiet_bay',(34,50),(39,50)),('service',(18,58),(11,58))]
  purpose='Offset recovery pockets provide adaptable neutral support surfaces and nearby accompanying seats. Opaque angled returns interrupt busy sightlines; low supported soffits shelter the quiet edge. An assisted-care work zone sits apart from resting pockets. No overnight berth or treatment suitability is registered.'
  counts={'registered_destinations_preserved':1,'neutral_support_proposals':6,'clinical_occupancy':None}
 elif N==2:
  # Sealed samples form a central experimental procession, clear perimeter service.
  for j,(u,v,radius) in enumerate([(25,18,3.2),(32,34,4),(25,51,3.2)]):
   b=disc('sample_cell_base'+str(j),u,v,radius,0,.65,'staff')
   for q in range(8):
    a=q*math.tau/8;rod('sample_cell_mullion'+str(j)+'_'+str(q),(u+radius*math.cos(a),.6,v+radius*math.sin(a)),(u+radius*math.cos(a),3.8,v+radius*math.sin(a)),.07,'staff',b.name)
   disc('sealed_sample_shell'+str(j),u,v,radius-.15,.65,2.9,'glass',b.name)
   disc('sample_cap'+str(j),u,v,radius,.0+3.55,.25,'staff','C_sample_cell_mullion'+str(j)+'_0')
   for q in (-1,1):
    p=wall('manifold_post'+str(j)+'_'+str(q),u+q*(radius+1),v,.3,.3,4.3)
    rod('manifold_branch'+str(j)+'_'+str(q),(u+q*(radius+1),4.2,v),(u,4.6,v),.16,'staff',p.name)
  wall('control_back',41,33,.25,35,3.2);workbench('atmosphere_readout',38,28,3,7)
  service('calibration_and_filters',11,58)
  routes=[[(1,34),(17,34),(17,10),(17,59),(39,59),(39,42)],[(17,10),(8.3,10),(8.3,8)]]
  views=[('arrival',(1,34),(32,34)),('sample_cells',(18,27),(32,34)),('controls',(33,42),(38,28)),('service',(19,58),(11,58))]
  purpose='Three sealed static sample columns and supported manifolds organize an atmosphere research procession. A protected control edge and distinct calibration/filter corner preserve operational separation. Transparent shells are internal research vessels, with no hull opening, gas simulation or life-support certification.'
  counts={'registered_destinations_preserved':1,'static_sample_columns':3,'clinical_occupancy':None}
 elif N==3:
  # Staggered consultation chambers; entrances face a branching staffed commons.
  for j,v in enumerate((14,33,52)):
   for k,u in enumerate((22,39)):
    wall('pod_rear'+str(j)+'_'+str(k),u+4,v,.24,12,3.25)
    wall('pod_north'+str(j)+'_'+str(k),u,v-6,8,.24,3.25)
    wall('pod_south'+str(j)+'_'+str(k),u,v+6,8,.24,3.25)
    for t,z in enumerate((v-4.25,v+4.25)):wall('pod_entry_return'+str(j)+'_'+str(k)+'_'+str(t),u-4,z,.24,3.5,3.25)
    roof=box('pod_roof'+str(j)+'_'+str(k),(u,3.35,v),(8.2,.2,12.2),'staff','C_pod_rear'+str(j)+'_'+str(k))
    asset('AST-DIN-001','consultation_table'+str(j)+'_'+str(k),u,v)
    for t,z in enumerate((v-1.6,v+1.6)):asset('AST-DIN-002','consultation_chair'+str(j)+'_'+str(k)+'_'+str(t),u,z,yaw=math.pi if t else 0)
    asset('AST-MED-003','adaptable_consult_support'+str(j)+'_'+str(k),u+2,v+3)
    lamp('consultation_task'+str(j)+'_'+str(k),u+2.7,v-3.8,2.8)
  service('consultation_records',10,60)
  routes=[[(1,34),(14,34),(14,9),(14,62),(29,62),(29,9)],[(14,10),(8.3,10),(8.3,8)]]
  views=[('arrival',(1,34),(23,33)),('consultation',(18.8,33),(23,33)),('branching_common',(29,33),(35,33)),('service',(18,60),(10,60))]
  purpose='Six proposed opaque consultation chambers form staggered paired banks around a branching level common route. Deep open source thresholds, supported roofs and adaptable support furnishing preserve privacy and staffed care. No moving door, treatment gameplay, species certification or clinical occupancy is claimed.'
  counts={'registered_destinations_preserved':1,'proposed_consultation_chambers':6,'clinical_occupancy':None}
 elif N==4:
  # Quiet care: nested inward-facing rest bays shielded from service spine.
  for j,(u,v) in enumerate([(24,14),(38,25),(24,37),(38,49),(24,59)]):
   wall('care_bay_rear'+str(j),u+4,v,.25,10,3.5,'stone')
   edge('care_bay_fore'+str(j),(u+4,v-5),(u-2,v-6),3.3,'wood')
   edge('care_bay_aft'+str(j),(u+4,v+5),(u,v+6),3.3,'wood')
   asset('AST-MED-003','quiet_support'+str(j),u,v)
   asset('AST-FUR-001','quiet_companion'+str(j),u,v+3.4,yaw=math.pi/2)
   lamp('quiet_care_light'+str(j),u+2.7,v-3,2.7)
  wall('observation_return',12,55,.25,15,3.2);service('quiet_staff_support',7,57)
  routes=[[(1,34),(16,34),(16,10),(16,63),(31,63),(31,10)],[(16,10),(8.3,10),(8.3,8)]]
  views=[('arrival',(1,34),(24,37)),('quiet_care',(18.5,37),(25,37)),('screened_rest',(32,49),(39,49)),('service',(13,57),(7,57))]
  purpose='Five inward-facing rest bays are nested behind staggered opaque acoustic/privacy returns. A level shared path and separate practical staff edge support quiet assisted care without adding guest berths, a medical procedure or assumptions about alien treatment.'
  counts={'registered_destinations_preserved':1,'neutral_rest_proposals':5,'clinical_occupancy':None}
 else:
  raise RuntimeError('Remaining D07 construction is staged until the complete approved roof/interface contract is accessible.')
 return dict(routes=routes,views=views,purpose=purpose,counts=counts,walkable_groups=walk)
