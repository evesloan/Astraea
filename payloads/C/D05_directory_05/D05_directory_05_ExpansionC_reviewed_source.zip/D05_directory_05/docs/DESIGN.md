# Recovery lounge

Offset recovery pockets provide adaptable neutral support surfaces and nearby accompanying seats. Opaque angled returns interrupt busy sightlines; low supported soffits shelter the quiet edge. An assisted-care work zone sits apart from resting pockets. No overnight berth or treatment suitability is registered.

No gameplay, capacity, live collision, species-wide traversal, performance or installed Godot acceptance is implied. No shared registry entry, hull opening, exterior view, working door or receiving floor was changed. Small signs are editable; no controls are rebound. RMB-focus/E vocabulary is retained.
