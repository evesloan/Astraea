# Sports viewing

Two stepped viewing bands preserve level adjacent access and each has an independent broad1:12 ramp. Fitted seating faces a supported internal static display wall, shortened and offset to reveal both tiers from the inward arrival. Cross-spine sports adjacency remains a root connection proposal; no real court view, hull opening, crowd capacity or screen gameplay is claimed.

No gameplay, capacity, live collision, species-wide traversal, performance or installed Godot acceptance is implied. No shared registry entry, hull opening, exterior view, working door or receiving floor was changed. Small signs are editable; no controls are rebound. RMB-focus/E vocabulary is retained.
