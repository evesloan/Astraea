# Horizon room — Batch D isolated source package

Programme `D12_directory_01`; source checkpoint `bfa49ac2cf8c53829ad82e4b4be2f6a2e9902182`.

Fan-shaped observation gathering with a broad central walking axis, separate radial seated axis, two sheltering side leaves and a tactile multi-optic console. Arrive through a deep open timber threshold; see the optical frame and receiving hold ahead. Side conversation groups and low view benches offer different resting postures.

image11: conversation clusters share an orientation, tables are within reach. image7: substantial portal reveals and weighted central object. image4: observation and library programme hierarchy, conflicting printed counts/datums rejected. Real frontage remains unproven; an opaque removable connection-hold panel occupies the proposed receiving face.

Placement: GLB vertices already use Godot world XYZ metres. Instance at identity position/rotation/scale. Deck floor datum Y78m; exclusive source roof limit83.7m. Blender is(X,-Z,Y). The entry hold is(-8,78,-432); root must adopt the receiving slab and external connection. `docs/floor_proposal.json` is a separate unadopted proposal. Native and export contain no preview floor. All cinema/theater below and D13 above remain protected; no hull cuts, slabs, existing doors or neighbour moves.

Rebuild with Blender4.3.2 through the included Windows named-mutex wrapper, `--background --factory-startup --threads4 --python source/build_section.py` (use separate `--threads 4` arguments). The wrapper uses Local\Astraea_SolBatch_20261008_HeavyBuild and holds/release-in-finally throughout one heavy invocation. Deterministic geometry rebuild source includes existing packed catalogue furniture and textures copied with exact dependency hashes. No new catalogue identity or shared registry write.

QA includes reload of actual saved native/export, packed-resource/UV/normal/text parity, containment, actual triangle contacts and conservative body/cart approach samples. Five final 1.65m views are renders of the reimported final GLB with QA-only proposed floor and preview fixture illumination. This is source/exchange evidence; installed Godot, real controller/loaded cart, root floor support, lighting budgets, CRT/motion and target hardware remain integration gates. Model/effort selection was requested by the owner; it is not independently exposed/verified here.

Original failed revisions remain locally under qa/failed_* and numbered logs; only final reviewed outputs are in this delivery archive. Original references are retained in isolated Batch D inputs, not shipped as production art. Relevant master source SHA256:222e547eb695f51b11aa928ac30fb36e437866c3bccd8d857c81c5901a700008. Complete relevant chapter blocks and current-overlay pin identity accompany this source. No source archive was uploaded.
