"""Actual glTF binary accessor inspection, independent of Blender import."""
import struct,json,math,hashlib,sys
from pathlib import Path
P=Path(sys.argv[1]);raw=(P/'exports'/(P.name+'.glb')).read_bytes();pos=12;doc=None;blob=None
while pos<len(raw):
 size,kind=struct.unpack_from('<II',raw,pos);pos+=8
 if kind==0x4e4f534a:doc=json.loads(raw[pos:pos+size])
 if kind==0x004e4942:blob=raw[pos:pos+size]
 pos+=size
sizes={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4};formats={5126:'f',5125:'I',5123:'H',5121:'B'}
def values(i):
 a=doc['accessors'][i];v=doc['bufferViews'][a['bufferView']];n=sizes[a['type']];fmt='<'+formats[a['componentType']]*n;step=v.get('byteStride',struct.calcsize(fmt));start=v.get('byteOffset',0)+a.get('byteOffset',0);return [struct.unpack_from(fmt,blob,start+j*step) for j in range(a['count'])]
rows=[]
for m in doc['meshes']:
 for pr in m['primitives']:
  at=pr['attributes'];ps=values(at['POSITION']);ns=values(at['NORMAL']);uv=values(at['TEXCOORD_0']);ix=[v[0] for v in values(pr['indices'])] if 'indices'in pr else list(range(len(ps)));badnormal=sum(not .98<math.sqrt(sum(x*x for x in n))<1.02 for n in ns);nonfinite=sum(not math.isfinite(x) for seq in [ps,ns,uv] for v in seq for x in v);area=0;wrong=0;tri=0
  for j in range(0,len(ix),3):
   ids=ix[j:j+3];a,b,c=[ps[k] for k in ids];ab=[b[k]-a[k] for k in range(3)];ac=[c[k]-a[k] for k in range(3)];cross=[ab[1]*ac[2]-ab[2]*ac[1],ab[2]*ac[0]-ab[0]*ac[2],ab[0]*ac[1]-ab[1]*ac[0]];norm=[sum(ns[k][l] for k in ids)/3 for l in range(3)];dot=sum(cross[k]*norm[k] for k in range(3));wrong+=dot< -1e-7;tri+=1
   a,b,c=[uv[k] for k in ids];area+=abs((b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]))/2
  rows.append({'mesh':m.get('name'),'triangles':tri,'nonunit_normals':badnormal,'nonfinite_components':nonfinite,'negative_winding_normal_dot_triangles':wrong,'total_uv_triangle_area':round(area,7),'pass':not badnormal and not nonfinite and not wrong and area>0})
r={'status':'PASS' if all(x['pass'] for x in rows) else 'FAIL','scope':'Raw final GLB binary accessor UV/normal/winding checks','glb_sha256':hashlib.sha256(raw).hexdigest(),'rows':rows};(P/'qa/raw_glb_validation.json').write_text(json.dumps(r,indent=2));print(r['status'],len(rows),'primitives',[x for x in rows if not x['pass']][:8])
