"""One mutex-held Blender invocation builds, reimports, renders and validates one assigned section."""
import runpy
from pathlib import Path
P=Path(__file__).resolve().parents[1]
runpy.run_path(str(P/'source/build_section.py'),run_name='__main__')
runpy.run_path(str(P/'qa/validate_section.py'),run_name='__main__')
