"""Live standard Windows mutex owner for each serialized heavy job."""
import ctypes,subprocess,sys,time
from ctypes import wintypes
k=ctypes.WinDLL('kernel32',use_last_error=True)
k.CreateMutexW.argtypes=[ctypes.c_void_p,wintypes.BOOL,wintypes.LPCWSTR];k.CreateMutexW.restype=wintypes.HANDLE
k.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD];k.WaitForSingleObject.restype=wintypes.DWORD
k.ReleaseMutex.argtypes=[wintypes.HANDLE];k.CloseHandle.argtypes=[wintypes.HANDLE]
h=k.CreateMutexW(None,False,r'Local\Astraea_SolBatch_20261008_HeavyBuild')
if not h:raise ctypes.WinError(ctypes.get_last_error())
owned=False
try:
 while True:
  r=k.WaitForSingleObject(h,10000)
  if r in (0,0x80):owned=True;break
  if r!=258:raise RuntimeError('mutex wait failed '+str(r))
  print('WAITING_SHARED_HEAVY_MUTEX',flush=True)
 # Inspect all surviving heavy executables after acquiring; no force stopping.
 q=subprocess.check_output(['powershell','-NoProfile','-Command',"Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(blender|godot).*\\.exe$' } | Select-Object ProcessId,Name | ConvertTo-Json -Compress"],text=True).strip()
 if q and q!='null':raise RuntimeError('Surviving heavy processes require inspection; no overlapping launch: '+q)
 print('HEAVY_MUTEX_ACQUIRED abandoned='+str(r==0x80),flush=True)
 code=subprocess.call(sys.argv[1:]);sys.exit(code)
finally:
 if owned:k.ReleaseMutex(h)
 k.CloseHandle(h)
