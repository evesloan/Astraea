"""Independent reload of saved native and GLB, actual triangle surfaces, exported resource/UV/text checks."""
import bpy,json,math,hashlib,struct,sys
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
P=Path(__file__).resolve().parents[1];c=json.loads((P/'docs/design.json').read_text());KEY=c['key'];S=c['side'];Z=c['z'];F=c['floor_y'];XB=c['xbase'];U=c['max_u'];CAP=c['source_roof_cap']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def extract(o):
 eo=o.evaluated_get(bpy.context.evaluated_depsgraph_get());me=eo.to_mesh();me.calc_loop_triangles();v=[o.matrix_world@x.co for x in me.vertices];t=[tuple(x.vertices) for x in me.loop_triangles];eo.to_mesh_clear();return v,t
def bounds(v):return [min(a.x for a in v),min(a.z for a in v),-max(a.y for a in v),max(a.x for a in v),max(a.z for a in v),-min(a.y for a in v)]
def inside(p,poly):
 x,y=p;yes=False
 for a,b in zip(poly,poly[1:]+poly[:1]):
  if (a[1]>y)!=(b[1]>y) and x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0]:yes=not yes
 return yes
def dist(p,a,b):
 d=[b[i]-a[i] for i in range(2)];den=sum(x*x for x in d);t=0 if not den else max(0,min(1,sum((p[i]-a[i])*d[i] for i in range(2))/den));return math.hypot(*(p[i]-a[i]-t*d[i] for i in range(2)))
def clip(poly,y,up):
 out=[]
 for a,b in zip(poly,poly[1:]+poly[:1]):
  ia=a[1]>=y if up else a[1]<=y;ib=b[1]>=y if up else b[1]<=y
  if ia:out.append(a)
  if ia!=ib:
   t=(y-a[1])/(b[1]-a[1]);out.append(tuple(a[k]+t*(b[k]-a[k]) for k in range(3)))
 return out
bpy.ops.wm.open_mainfile(filepath=str(P/'source/section.blend'));native={};nuv=[];fonts=[];source_hash=bpy.context.scene.get('deterministic_source_sha256','unrecorded')
for o in bpy.context.scene.objects:
 if o.get('section')!=KEY:continue
 v,t=extract(o);native[o.name]={'bounds':bounds(v),'support':o['support'],'zone':o['zone'],'type':o.type,'shelf_support':o.get('shelf_support','')}
 if o.type=='FONT':fonts.append(o.name)
 elif not o.data.uv_layers:nuv.append(o.name)
(P/'qa/native_inventory.json').write_text(json.dumps([{'name':o.name,'type':o.type,'hide_render':o.hide_render,'hide_viewport':o.hide_viewport,'hide_get':o.hide_get(),'collections':[x.name for x in o.users_collection],'parent':o.parent.name if o.parent else None,'vertex_count':len(o.data.vertices) if o.type=='MESH' else None} for o in bpy.context.scene.objects],indent=2))
packed=[{'name':i.name,'packed':bool(i.packed_file)} for i in bpy.data.images if i.source=='FILE' and i.size[0]]
raw=(P/'exports'/(KEY+'.glb')).read_bytes();magic,ver,total=struct.unpack_from('<4sII',raw);size,kind=struct.unpack_from('<II',raw,12);doc=json.loads(raw[20:20+size]);external=[x.get('uri') for group in ['buffers','images'] for x in doc.get(group,[]) if 'uri'in x]
bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(P/'exports'/(KEY+'.glb')));rows={};geom={};bad=[];uvbad=[];finite=[];obs=[]
for o in bpy.context.scene.objects:
 if o.type!='MESH':continue
 v,t=extract(o);b=bounds(v);rows[o.name]=b;geom[o.name]=(v,t,BVHTree.FromPolygons(v,t,all_triangles=True))
 if not o.data.uv_layers:uvbad.append(o.name)
 if any(not math.isfinite(z) for p in v for z in p):finite.append(o.name)
 # Source reservation rectangle is the exclusive containment boundary; form outline is separate.
 us=[S*p.x-XB for p in v];vs=[-p.y-Z for p in v]
 if min(us)<-.001 or max(us)>U+.001 or min(vs)<-34.001 or max(vs)>34.001 or b[1]<F-.001 or b[4]>CAP+.001:bad.append(o.name)
 for tri in t:
  poly=[(S*v[i].x-XB,v[i].z,-v[i].y-Z) for i in tri];poly=clip(poly,F+.10,True)
  if poly:poly=clip(poly,F+1.90,False)
  if poly:
   q=[(p[0],p[2]) for p in poly];obs.append((o.name,q,[min(p[0] for p in q),min(p[1] for p in q),max(p[0] for p in q),max(p[1] for p in q)]))
contacts=[]
def surface_gap(n,s):
 a0,b0=rows[n],rows[s];lower=math.sqrt(sum(max(a0[i]-b0[i+3],b0[i]-a0[i+3],0)**2 for i in range(3)))
 if lower>.026:return lower
 va,ta,a=geom[n];vb,tb,b=geom[s]
 if a.overlap(b):return 0.0
 return min([b.find_nearest(p)[3] for p in va]+[a.find_nearest(p)[3] for p in vb])
for n,r in native.items():
 if n not in rows:continue
 sup=r['support'];b=rows[n]
 if sup=='root_floor_proposal':gap=abs(b[1]-F);method='actual minimum vs proposed root floor datum'
 elif sup=='catalogue_contact_graph':
  if abs(b[1]-F)<.025:gap=abs(b[1]-F);sup='root_floor_proposal';method='existing catalogue floor contact'
  else:
   family=r['zone'];others=[s for s in geom if s!=n and native.get(s,{}).get('zone')==family];metrics=[(surface_gap(n,s),s) for s in others]+([(surface_gap(n,r['shelf_support']),r['shelf_support'])] if r.get('shelf_support') in geom else []);gap,sup=min(metrics) if metrics else (999,'missing');method='actual catalogue same-instance nearest triangle contact'
 elif sup in geom:gap=surface_gap(n,sup);method='actual bidirectional vertex/triangle distance or triangle intersection'
 else:gap=999;method='missing support'
 contacts.append({'part':n,'support':sup,'gap_m':round(gap,6),'method':method,'pass':gap<.026})
paths=c['routes']
routes=[]
for name,path in paths.items():
 pts=[]
 for a,b in zip(path,path[1:]):
  ct=max(1,math.ceil(math.dist(a,b)/.2));pts += [(a[0]+(b[0]-a[0])*i/ct,a[1]+(b[1]-a[1])*i/ct) for i in range(ct+1)]
 mind=999;nearest='';outside=0
 for p in pts:
  if not inside(p,c['footprint']):outside+=1
  for n,q,bb in obs:
   low=math.hypot(max(bb[0]-p[0],p[0]-bb[2],0),max(bb[1]-p[1],p[1]-bb[3],0))
   if low>mind:continue
   ds=min(dist(p,a,b) for a,b in zip(q,q[1:]+q[:1]));ds=0 if len(q)>2 and inside(p,q) else ds
   if ds<mind:mind=ds;nearest=n
 for mode,r in [('body',.60),('cart_conservative_disk',.80)]:routes.append({'name':name+'_'+mode,'path_local_uv':path,'sample_count':len(pts),'radius':r,'minimum_surface_margin_m':round(mind-r,4),'nearest':nearest,'outside_proposal':outside,'pass':mind>r+.005 and not outside})
# Ground connectivity of contact evidence prevents a floating internally connected group from passing.
adj={n:set() for n in rows};ground=set()
for r in contacts:
 if not r['pass']:continue
 n,sup=r['part'],r['support']
 if sup=='root_floor_proposal':ground.add(n)
 elif sup in adj:adj[n].add(sup);adj[sup].add(n)
# Catalogue assemblies retain all touching same-instance candidates, not just the reported nearest one.
for n,r in native.items():
 if r['support']!='catalogue_contact_graph' or n not in geom:continue
 for other in geom:
  if other!=n and native.get(other,{}).get('zone')==r['zone'] and surface_gap(n,other)<.026:adj[n].add(other);adj[other].add(n)
seen=set(ground);todo=list(ground)
while todo:
 n=todo.pop()
 for other in adj[n]-seen:seen.add(other);todo.append(other)
ungrounded=sorted(set(rows)-seen)
errors=[max(abs(a-b) for a,b in zip(native[n]['bounds'],rows[n])) for n in native if n in rows]
# GLB declares normals and UV for every material primitive.
primitive_missing=[]
for me in doc.get('meshes',[]):
 for pr in me['primitives']:
  if not all(x in pr['attributes'] for x in ['POSITION','NORMAL','TEXCOORD_0']):primitive_missing.append(me.get('name'))
checks={'deterministic_source_sha256':source_hash,'deterministic_source_matches':source_hash==sha(P/'source/build_section.py'),'ungrounded_contact_components':ungrounded,'native_count':len(native),'glb_mesh_count':len(rows),'names_equal':set(native)==set(rows),'native_missing_export':sorted(set(native)-set(rows)),'export_missing_native':sorted(set(rows)-set(native)),'max_bounds_delta_m':max(errors,default=999),'fonts_mesh_parity':all(n in rows for n in fonts),'native_fonts':fonts,'native_missing_uv':nuv,'glb_missing_uv':uvbad,'primitive_missing_normal_uv':primitive_missing,'packed_native_images':packed,'embedded_glb_images':len(doc.get('images',[])),'external_uris':external,'containment_violations':bad,'nonfinite':finite,'support_contacts':contacts,'support_failures':[r for r in contacts if not r['pass']],'routes':routes,'route_failures':[r for r in routes if not r['pass']],'floor_or_QA_in_native_or_export':[n for n in rows if 'QA_ONLY' in n or 'FLOOR' in n],'actual_world_bounds':bounds([p for v,t,b in geom.values() for p in v])}
fail=not checks['deterministic_source_matches'] or not checks['names_equal'] or checks['max_bounds_delta_m']>.001 or not checks['fonts_mesh_parity'] or any(checks[k] for k in ['native_missing_uv','glb_missing_uv','primitive_missing_normal_uv','external_uris','containment_violations','nonfinite','support_failures','ungrounded_contact_components','route_failures','floor_or_QA_in_native_or_export']) or not all(x['packed'] for x in packed) or total!=len(raw) or magic!=b'glTF'
out={'status':'FAIL' if fail else 'PASS','scope':'Actual saved-native/export source containment, contacts and conservative approach sweeps; floor support is proposed; no Godot/loaded-cart/installed acceptance','native_sha256':sha(P/'source/section.blend'),'glb_sha256':sha(P/'exports'/(KEY+'.glb')),'checks':checks};(P/'qa/validation.json').write_text(json.dumps(out,indent=2));print('RESULT',out['status'],'parts',len(rows));print('CONTACT FAILURES',checks['support_failures']);print('ROUTE FAILURES',checks['route_failures']);print('OTHER',bad,nuv,uvbad,primitive_missing,checks['max_bounds_delta_m'])
