import json,struct,math,sys,hashlib
from pathlib import Path
P=Path(sys.argv[1]);data=(P/'exports'/(P.name+'.glb')).read_bytes();at=12
while at<len(data):
 n,k=struct.unpack_from('<II',data,at);at+=8
 if k==0x4e4f534a:d=json.loads(data[at:at+n])
 if k==0x004e4942:blob=data[at:at+n]
 at+=n
ident=lambda:[[1 if i==j else 0 for j in range(4)] for i in range(4)]
def mul(a,b):return [[sum(a[i][k]*b[k][j] for k in range(4)) for j in range(4)] for i in range(4)]
def matrix(node):
 if 'matrix' in node:return [[node['matrix'][j*4+i] for j in range(4)] for i in range(4)]
 x,y,z,w=node.get('rotation',[0,0,0,1]);s=node.get('scale',[1,1,1]);t=node.get('translation',[0,0,0]);r=[[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]];m=ident()
 for i in range(3):
  for j in range(3):m[i][j]=r[i][j]*s[j]
  m[i][3]=t[i]
 return m
parents={c:i for i,n in enumerate(d['nodes']) for c in n.get('children',[])};cache={}
def world(i):
 if i not in cache:cache[i]=mul(world(parents[i]),matrix(d['nodes'][i])) if i in parents else matrix(d['nodes'][i])
 return cache[i]
def vertices(a):
 q=d['accessors'][a];v=d['bufferViews'][q['bufferView']];assert q['componentType']==5126 and q['type']=='VEC3';base=v.get('byteOffset',0)+q.get('byteOffset',0);step=v.get('byteStride',12);return [struct.unpack_from('<fff',blob,base+j*step) for j in range(q['count'])]
rows={}
for i,n in enumerate(d['nodes']):
 if 'mesh' not in n:continue
 m=world(i);points=[]
 for pr in d['meshes'][n['mesh']]['primitives']:
  for v in vertices(pr['attributes']['POSITION']):points.append([sum(m[j][k]*v[k] for k in range(3))+m[j][3] for j in range(3)])
 rows[n['name']]=[min(p[k] for p in points) for k in range(3)]+[max(p[k] for p in points) for k in range(3)]
(P/'qa/actual_glb_world_bounds.json').write_text(json.dumps({'glb_sha256':hashlib.sha256(data).hexdigest(),'scope':'Independent rawGLB node world transforms and binary accessor bounds','objects':rows},indent=2))
if P.name=='D08_directory_02':
 get=lambda n:rows[P.name+'__'+n];r=get('accessible_wet_ramp');land=get('wet_landing');F=44;checks={'basin_minimum_bottom_y':min(get('bath_basin_bottom'+str(i))[1] for i in range(2)),'ramp_actual_run_m':r[3]-r[0],'ramp_actual_width_m':r[5]-r[2],'ramp_actual_rise_m':r[4]-r[1],'ramp_gradient':(r[4]-r[1])/(r[3]-r[0]),'wet_landing_actual_top_y':land[4],'normal_wet_entry_eye_height_above_native_platform_m':F+2.55-land[4],'coping_entry_clear_widths_m':[get('near_coping_right'+str(i))[0]-get('near_coping_left'+str(i))[3] for i in range(2)],'handrail_clear_width_m':get('accessible_wet_ramp_handrail1')[2]-get('accessible_wet_ramp_handrail0')[5]};status=checks['basin_minimum_bottom_y']>=F-.001 and abs(checks['ramp_actual_run_m']-12)<.001 and checks['ramp_actual_width_m']>3.99 and checks['ramp_gradient']<=1/12 and abs(checks['normal_wet_entry_eye_height_above_native_platform_m']-1.65)<.001 and min(checks['coping_entry_clear_widths_m'])>3.99 and checks['handrail_clear_width_m']>3.88;(P/'qa/wet_structure_check.json').write_text(json.dumps({'status':'PASS' if status else 'FAIL','glb_sha256':hashlib.sha256(data).hexdigest(),'checks':checks,'limits':'Actual geometry source screen only; no installed collision, loaded cart, swimming or species compatibility acceptance'},indent=2));print('WET_STRUCTURE',status,checks);assert status
print('RAW_WORLD_BOUNDS',len(rows))
