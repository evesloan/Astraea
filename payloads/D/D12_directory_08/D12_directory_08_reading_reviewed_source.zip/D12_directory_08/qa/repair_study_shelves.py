import bpy,json,hashlib,importlib.util,runpy
from pathlib import Path
P=Path(__file__).resolve().parents[1];old=P/'source/section.blend'
assert hashlib.sha256(old.read_bytes()).hexdigest()=='4cb45f7d250db4662e332ce0380ea16854c430d5d5cf9d0572d0b996a99cea41'
s=importlib.util.spec_from_file_location('section',P/'source/build_section.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
bpy.ops.wm.open_mainfile(filepath=str(old));changed=[]
def move(name,delta):
 o=bpy.data.objects[P.name+'__'+name];o.location+=m.Vector(delta);changed.append({'part':o.name,'blender_translation':list(delta)})
for i in range(2):
 move('study_bench'+str(i)+'_back',(1.12,0,0))
 for tail in ['foot','stem','top','cup','folio']:move('study_table'+str(i)+'_'+tail,(.5,0,0))
for h in [.20,.91,1.62,2.33]:
 for k in range(2):
  for tail in ['pages','spine']:move('collection_a_volume'+str(h)+'_24_'+str(k)+'_'+tail,(0,.18,0))
bpy.context.view_layer.update();m.A=[o for o in bpy.context.scene.objects if o.get('section')==P.name and o.type in ['MESH','FONT']];m.LIGHTS=json.loads((P/'qa/fixtures.json').read_text());m.native_export();m.preview()
(P/'qa/native_repair.json').write_text(json.dumps({'scope':'Minimal native transformations matching the corrected deterministic rebuild source; all other geometry preserved','changes':changed,'final_native_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'final_source_sha256':hashlib.sha256((P/'source/build_section.py').read_bytes()).hexdigest()},indent=2))
runpy.run_path(str(P/'qa/validate_section.py'),run_name='__main__')
