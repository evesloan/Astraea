# Reading nooks — Batch D isolated source package

Programme `D12_directory_08`; source checkpoint `bfa49ac2cf8c53829ad82e4b4be2f6a2e9902182`.

An intuitive level quiet route links a shared crescent, a low family reading leaf, two deep study pockets and a sheltered writing edge. Book spines and fitted shelves provide real collection density; varying return depths and low lids give each pocket privacy without identical chair rows.

library original191914: book-lined protected reading recess and useful working edges; no copied window or balcony. intimate original: warm fitted seating and compact table relationships. image8: substantial shelves, grouped object silhouettes and visible task-source light. No added inaccessible upper level or berth/capacity claim.

Placement: GLB vertices already use Godot world XYZ metres. Instance at identity position/rotation/scale. Deck floor datum Y78m; exclusive source roof limit83.7m. Blender is(X,-Z,Y). The entry hold is(8,78,216); root must adopt the receiving slab and external connection. `docs/floor_proposal.json` is a separate unadopted proposal. Native and export contain no preview floor. All cinema/theater below and D13 above remain protected; no hull cuts, slabs, existing doors or neighbour moves.

Rebuild with Blender4.3.2 through the included Windows named-mutex wrapper, `--background --factory-startup --threads 4 --python source/build_section.py` (use separate `--threads 4` arguments). The wrapper uses Local\Astraea_SolBatch_20261008_HeavyBuild and holds/release-in-finally throughout one heavy invocation. Deterministic geometry rebuild source includes existing packed catalogue furniture and textures copied with exact dependency hashes. No new catalogue identity or shared registry write.

QA includes reload of actual saved native/export, packed-resource/UV/normal/text parity, containment, actual triangle contacts and conservative body/cart approach samples. Five final 1.65m views are renders of the reimported final GLB with QA-only proposed floor and preview fixture illumination. This is source/exchange evidence; installed Godot, real controller/loaded cart, root floor support, lighting budgets, CRT/motion and target hardware remain integration gates. Model/effort selection was requested by the owner; it is not independently exposed/verified here.

Original failed revisions remain locally under qa/failed_* and numbered logs; only final reviewed outputs are in this delivery archive. Original references are retained in isolated Batch D inputs, not shipped as production art. Relevant master source SHA256:222e547eb695f51b11aa928ac30fb36e437866c3bccd8d857c81c5901a700008. Complete relevant chapter blocks and current-overlay pin identity accompany this source. No source archive was uploaded.
