# Many worlds gallery — Batch D isolated source package

Programme `D12_directory_07`; source checkpoint `bfa49ac2cf8c53829ad82e4b4be2f6a2e9902182`.

A lower branching exhibition threshold frames an arrival forecourt. Three exhibit spines establish a varied sequence: grouped geological forms, branching specimens and layered art. A wide central route branches to smaller pauses and a framed stratum relief. Plinths and fitted low labels are deliberately distinct from the resting benches; rear spine access stays legible.

image4: distinct cultural/exhibition programme rather than extra business or capacity. image7: deep thresholds and primary sculpture/plinth hierarchy. image8: grouped tactile objects and fixture light, translated into specimen islands. Groupings are original artwork, with no invented scientific claims.

Placement: GLB vertices already use Godot world XYZ metres. Instance at identity position/rotation/scale. Deck floor datum Y78m; exclusive source roof limit83.7m. Blender is(X,-Z,Y). The entry hold is(-8,78,216); root must adopt the receiving slab and external connection. `docs/floor_proposal.json` is a separate unadopted proposal. Native and export contain no preview floor. All cinema/theater below and D13 above remain protected; no hull cuts, slabs, existing doors or neighbour moves.

Rebuild with Blender4.3.2 through the included Windows named-mutex wrapper, `--background --factory-startup --threads4 --python source/build_section.py` (use separate `--threads 4` arguments). The wrapper uses Local\Astraea_SolBatch_20261008_HeavyBuild and holds/release-in-finally throughout one heavy invocation. Deterministic geometry rebuild source includes existing packed catalogue furniture and textures copied with exact dependency hashes. No new catalogue identity or shared registry write.

QA includes reload of actual saved native/export, packed-resource/UV/normal/text parity, containment, actual triangle contacts and conservative body/cart approach samples. Five final 1.65m views are renders of the reimported final GLB with QA-only proposed floor and preview fixture illumination. This is source/exchange evidence; installed Godot, real controller/loaded cart, root floor support, lighting budgets, CRT/motion and target hardware remain integration gates. Model/effort selection was requested by the owner; it is not independently exposed/verified here.

Original failed revisions remain locally under qa/failed_* and numbered logs; only final reviewed outputs are in this delivery archive. Original references are retained in isolated Batch D inputs, not shipped as production art. Relevant master source SHA256:222e547eb695f51b11aa928ac30fb36e437866c3bccd8d857c81c5901a700008. Complete relevant chapter blocks and current-overlay pin identity accompany this source. No source archive was uploaded.
