"""Batch D source authoring. Blender4.3.2; metres. Authored local (u,height,v) maps to world XYZ then Blender(X,-Z,Y). Native/export omit floors and QA context. No registry IDs created."""
import bpy,math,json,hashlib,importlib.util,sys
from pathlib import Path
from mathutils import Vector,Matrix
P=Path(__file__).resolve().parents[1]; C=P/'dependencies/Catalogue';CONFIG=json.loads((P/'docs/design.json').read_text());SIDE=CONFIG['side'];Z=CONFIG['z'];KEY=CONFIG['key']; A=[];LIGHTS=[];M={};seq=0

def world(p):u,y,v=p;return (SIDE*(CONFIG['xbase']+u),CONFIG['floor_y']+y,Z+v)
def xyz(p):x,y,z=world(p);return Vector((x,-z,y))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def uv(o):
 if o.type!='MESH':return
 me=o.data;me.update();layer=me.uv_layers.get('UV0') or me.uv_layers.new(name='UV0')
 for f in me.polygons:
  drop=max(range(3),key=lambda a:abs(f.normal[a]));ax=[a for a in range(3) if a!=drop]
  for li in f.loop_indices:
   v=me.vertices[me.loops[li].vertex_index].co;layer.data[li].uv=(v[ax[0]],v[ax[1]])

def finish(o,n,mat='ivory_enamel',support='root_floor_proposal',zone='architecture',bev=.03):
 o.name=KEY+'__'+n
 if o.type=='MESH':
  bpy.context.view_layer.objects.active=o
  if bev:
   b=o.modifiers.new('Edge craft','BEVEL');b.width=bev;b.segments=2;bpy.ops.object.modifier_apply(modifier=b.name)
  o.data.materials.clear();o.data.materials.append(M[mat]);uv(o)
  bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.normals_make_consistent(inside=False);bpy.ops.object.mode_set(mode='OBJECT')
 o['section']=KEY;o['support']=support if support.startswith(('root_',KEY)) else KEY+'__'+support;o['zone']=zone;A.append(o);return o

def box(n,p,d,mat='ivory_enamel',sup='root_floor_proposal',zone='architecture',bev=.03):
 bpy.ops.mesh.primitive_cube_add(size=1,location=xyz(p));o=bpy.context.object;o.dimensions=(d[0],d[2],d[1]);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,n,mat,sup,zone,min(bev,min(d)*.3))

def rod(n,a,b,r=.06,mat='champagne_metal',sup='root_floor_proposal',zone='architecture',verts=12):
 va,vb=xyz(a),xyz(b);delta=vb-va;bpy.ops.mesh.primitive_cylinder_add(vertices=verts,radius=r,depth=delta.length,location=(va+vb)/2);o=bpy.context.object;o.rotation_euler=delta.to_track_quat('Z','Y').to_euler();bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,n,mat,sup,zone,.008)

def prism(n,poly,y,h,mat='warm_walnut',sup='root_floor_proposal',zone='architecture'):
 vs=[xyz((u,y,v)) for u,v in poly]+[xyz((u,y+h,v)) for u,v in poly];k=len(poly);faces=[tuple(range(k-1,-1,-1)),tuple(range(k,2*k))]+[(i,(i+1)%k,(i+1)%k+k,i+k) for i in range(k)];me=bpy.data.meshes.new(n);me.from_pydata(vs,[],faces);me.update();o=bpy.data.objects.new(n,me);bpy.context.collection.objects.link(o);return finish(o,n,mat,sup,zone,.025)

def cyl(n,p,r,h,mat='champagne_metal',sup='root_floor_proposal',zone='programme'):
 return rod(n,p,(p[0],p[1]+h,p[2]),r,mat,sup,zone,32)

def wall(n,a,b,h=4.9,w=.36,mat='ivory_enamel',y=0,sup='root_floor_proposal',zone='architecture'):
 u,v=a;du,dv=b[0]-u,b[1]-v;l=math.hypot(du,dv);o=box(n,((u+b[0])/2,y+h/2,(v+b[1])/2),(l,w,h) if False else (l,h,w),mat,sup,zone,.045)
 # Long box local BlenderX must align actual converted wall vector.
 vec=xyz((b[0],y,b[1]))-xyz((a[0],y,a[1]));o.rotation_euler[2]=math.atan2(vec.y,vec.x);return o

def sign(n,body,u,v,y=1.7,sup='root_floor_proposal'):
 back=box(n+'_plate',(u,y,v),(.10,.50,2.0),'warm_walnut',sup,zone='wayfinding');cu=bpy.data.curves.new(n,'FONT');cu.body=body;cu.align_x='CENTER';cu.align_y='CENTER';cu.size=.16;cu.extrude=.001;o=bpy.data.objects.new(n,cu);bpy.context.collection.objects.link(o);o.location=xyz((u-.06,y,v));o.rotation_euler=(math.pi/2,0, math.pi/2 if SIDE<0 else -math.pi/2);o.data.materials.append(M['ivory_enamel']);finish(o,n+'_text',support=back.name,zone='wayfinding',bev=0)

def asset(n,file,u,v,y=0,yaw=None,sup=None):
 with bpy.data.libraries.load(str(C/file),link=False) as (data,to):to.objects=data.objects
 os=[o for o in to.objects if o and o.type=='MESH']
 for ob in os:bpy.context.collection.objects.link(ob)
 bpy.context.view_layer.update()
 original_world={o:o.matrix_world.copy() for o in os}
 for ob in os:ob.parent=None
 rot=Matrix.Rotation((SIDE*math.pi/2 if yaw is None else yaw),4,'Z');trans=Matrix.Translation(xyz((u,y,v)))
 for o in os:
  o.hide_render=False;o.hide_viewport=False;o.hide_select=False;o.hide_set(False);o.parent=None;o.matrix_world=trans@rot@original_world[o];o.name=KEY+'__'+n+'__'+o.name;o['section']=KEY;o['zone']='catalogue_'+n;o['support']='catalogue_contact_graph';o['shelf_support']=sup or '';A.append(o)
  for im in bpy.data.images:
   if im.source=='FILE' and not im.packed_file:
    try:im.pack()
    except:pass
 return os

def seat(n,u,v,length=5,face=1,cloth='teal_weave',zone='rest'):
 b=box(n+'_plinth',(u,.17,v),(1.3,.34,length),'warm_walnut',zone=zone,bev=.08)
 box(n+'_pad',(u,.45,v),(1.4,.22,length-.15),cloth,b.name,zone,.075)
 back=box(n+'_back',(u-.56*face,.86,v),(.24,1.10,length),cloth,b.name,zone,.08)
 for k in [-1,1]:box(n+'_arm'+str(k),(u,.52,v+k*(length/2-.12)),(1.42,.40,.24),'warm_walnut',b.name,zone,.06)
 return b.name

def arcseat(n,u,v,r,start,end,cloth='oatmeal_weave'):
 # Faceted continuous fitted seating with radial depth; generous gap in arrival sector.
 count=max(3,int(abs(end-start)/18));poly=[]
 for j in range(count+1):a=math.radians(start+(end-start)*j/count);poly.append((u+(r+.55)*math.cos(a),v+(r+.55)*math.sin(a)))
 for j in range(count,-1,-1):a=math.radians(start+(end-start)*j/count);poly.append((u+(r-.55)*math.cos(a),v+(r-.55)*math.sin(a)))
 b=prism(n+'_base',poly,0,.33,'warm_walnut',zone='gathering');prism(n+'_cushion',poly,.33,.20,cloth,b.name,'gathering')
 for j in range(count):
  a0=math.radians(start+(end-start)*j/count);a1=math.radians(start+(end-start)*(j+1)/count)
  pa=(u+(r+.54)*math.cos(a0),v+(r+.54)*math.sin(a0));pb=(u+(r+.54)*math.cos(a1),v+(r+.54)*math.sin(a1));wall(n+'_back'+str(j),pa,pb,.78,.20,cloth,.33,b.name,'gathering')

def table(n,u,v,r=.85):
 f=cyl(n+'_foot',(u,0,v),r*.60,.08,'dark_rubber');p=cyl(n+'_stem',(u,.08,v),.11,.61,'champagne_metal',f.name);t=cyl(n+'_top',(u,.69,v),r,.10,'warm_walnut',p.name)
 cyl(n+'_cup',(u+.20,.79,v),.09,.13,'ivory_enamel',t.name);box(n+'_folio',(u-.20,.815,v-.10),(.34,.05,.45),'clay_weave',t.name,'rest',.008);return t.name

def fixture(n,u,v,y=4.4,power=900):
 # Floor-supported blade pendant: roof frame and visible diffuser.
 post=box(n+'_post',(u,y/2,v),(.16,y,.16),'champagne_metal',zone='light_support')
 box(n+'_arm',(u+.5,y-.12,v),(1.14,.16,.18),'warm_walnut',post.name,'fixture')
 box(n+'_shade',(u+.86,y-.24,v),(.60,.32,.90),'ivory_enamel',n+'_arm','fixture',.09)
 box(n+'_lens',(u+.86,y-.42,v),(.48,.04,.74),'oatmeal_weave',n+'_shade','fixture',.01)
 LIGHTS.append((n,(u+.86,y-.47,v),power,.65,.85))

def books(n,u,v,length=5):
 b=box(n+'_back',(u,1.5,v),(.18,3,length),'warm_walnut',zone='collection')
 for h in [.20,.91,1.62,2.33,2.95]:
  shelf=box(n+'_shelf'+str(h),(u-.44,h,v),(1.0,.08,length),'warm_walnut',b.name,'collection')
  if h<2.9:
   # One detailed existing stock group anchors each shelf; fitted bound volumes fill the remaining bays economically.
   q=v-length/2+.45
   asset(n+'_books'+str(h)+'_catalogue','assets/library_contents/AST-LIB-006_upright_book_group.blend',u-.40,q,h+.04,yaw=SIDE*math.pi/2,sup=shelf.name)
   for j in range(1,int(length/.48)):
    q=v-length/2+.45+j*.48
    for k in range(2):
     ht=.32+.07*((j+k)%3);z=q+k*.13;name=n+'_volume'+str(h)+'_'+str(j)+'_'+str(k)
     pages=box(name+'_pages',(u-.43,h+.04+ht/2,z),(.36,ht,.11),'ivory_enamel',shelf.name,'collection',.009)
     box(name+'_spine',(u-.61,h+.04+(ht+.02)/2,z),(.045,ht+.02,.14),'teal_weave' if (j+k)%2 else 'clay_weave',shelf.name,'collection',.008)
 return b.name

def cupboard(n,u,v):
 b=box(n+'_body',(u,1.1,v),(1.20,2.2,4.0),'warm_walnut',zone='service')
 for q in [-1,1]:box(n+'_door'+str(q),(u-.62,1.20,v+q*.98),(.08,1.85,1.84),'ivory_enamel',b.name,'service')
 for q in [-1,1]:box(n+'_handle'+str(q),(u-.70,1.30,v+q*.35),(.09,.30,.09),'champagne_metal',n+'_door'+str(q),'service')
 sign(n,'CARE / STOCK',u-.67,v,2.02,n+'_door-1')


def enclosure():
 poly=CONFIG['footprint']
 for i,(a,b) in enumerate(zip(poly,poly[1:]+poly[:1])):
  if a[0]==2.5 and b[0]==2.5:
   wall('screened_entry_south',a,(2.5,-4.5),4.0,.36,'ivory_enamel');wall('screened_entry_north',(2.5,4.5),b,4.0,.36,'ivory_enamel')
  else:wall('staff_enclosure_'+str(i),a,b,6.2,.36,'ivory_enamel')
 for v in [-4.5,4.5]:box('service_jamb'+str(v),(4.3,1.8,v),(3.5,3.6,.50),'ivory_enamel')
 box('service_crown',(4.3,3.75,0),(3.5,.30,9.5),'ivory_enamel','service_jamb-4.5');sign('arrival','TOWELS / STAFF CARE',4.3,-4.78,1.7,'service_jamb-4.5')
 # Lower work ceiling at the arrival; the rear sorting/storage hall rises for inspection and handling.
 for j,v in enumerate([-27,27]):
  a=box('service_roof_post'+str(j),(40,2.9,v),(.4,5.8,.4),'champagne_metal')
  rod('supported_service_run'+str(j),(9,3.65,v),(40,5.8,v),.18,'ivory_enamel',a.name)
 for i,(u,v) in enumerate([(9,-9),(9,9),(20,-22),(20,22),(30,5),(38,-20),(38,20)]):fixture('work_light'+str(i),u,v,3.3,1450)

def rack(n,u,v,length=12):
 base=box(n+'_base',(u,.12,v),(1.8,.24,length),'dark_rubber',zone='clean_storage')
 back=box(n+'_back',(u+.85,1.6,v),(.16,3.2,length),'ivory_enamel',base.name,'clean_storage')
 for j,y in enumerate([.35,1.10,1.85,2.60]):
  shelf=box(n+'_shelf'+str(j),(u,y,v),(1.8,.08,length),'ivory_enamel',back.name,'clean_storage')
  for k in range(max(1,int(length/2.2))):
   q=v-length/2+1.2+k*2.2
   if n in ['care_products','local_supply']:
    bottle=cyl(n+'_bottle'+str(j)+'_'+str(k),(u-.1,y+.04,q),.16,.40,'ivory_enamel',shelf.name,'care_products')
    cyl(n+'_cap'+str(j)+'_'+str(k),(u-.1,y+.44,q),.17,.06,'champagne_metal',bottle.name,'care_products')
   else:box(n+'_textile'+str(j)+'_'+str(k),(u-.10,y+.24,q),(1.1,.4,1.5),'oatmeal_weave',shelf.name,'clean_textiles')

def workbench(n,u,v,length=8):
 base=box(n+'_body',(u,.42,v),(2.8,.84,length),'ivory_enamel',zone='work')
 top=box(n+'_top',(u,.9,v),(3.1,.12,length+.2),'champagne_metal',base.name,'work')
 for j,q in enumerate([-length/3,length/3]):box(n+'_textile'+str(j),(u,.99,v+q),(1.7,.06,1.8),'oatmeal_weave',top.name,'work')

def care():
 # Offset two-front work cells preserve a clear central cart spine and sightline to both controlled stocks.
 workbench('sorting_workcell',16,-15,10);workbench('folding_workcell',16,15,10)
 for j,(a,b) in enumerate([((24,-31),(24,-6)),((24,6),(24,31))]):wall('rear_stock_screen'+str(j),a,b,3.6,.30,'ivory_enamel',zone='staff_screen')
 # Clean reserve is separately screened from used-textile receivers; no on-site laundry machine is invented.
 rack('clean_reserve',34,18,12);rack('care_products',34,-18,12)
 for j,v in enumerate([-20,-12]):
  b=box('used_textile_receiver'+str(j),(29,.65,v),(2,1.3,3),'dark_rubber',zone='used_textiles')
  box('receiver_rim'+str(j),(29,1.28,v),(2.15,.10,3.15),'ivory_enamel',b.name,'used_textiles')
 # A fitted checking/writing station gives staffed operations a clear focal activity.
 base=box('staff_checking_base',(10,.43,-10),(2,.86,5),'ivory_enamel',zone='staff_checking')
 top=box('staff_checking_top',(10,.92,-10),(2.5,.12,5.2),'champagne_metal',base.name,'staff_checking')
 box('editable_workfolio',(10,.99,-10),(1,.04,1.3),'clay_weave',top.name,'staff_checking')
 # Practical local care stock lives at its own cart-reachable front edge.
 rack('local_supply',8,-25,5)

def native_export():
 bpy.context.view_layer.update()
 # All bitmap resources embedded in actual editable source.
 for im in bpy.data.images:
  if im.source=='FILE' and not im.packed_file:im.pack()
 bpy.context.scene['deterministic_source_sha256']=sha(__file__)
 bpy.ops.wm.save_as_mainfile(filepath=str(P/'source/section.blend'))
 # Export evaluated production copies into a clean scene: no inherited collection selection/visibility state.
 dg=bpy.context.evaluated_depsgraph_get();prepared=[]
 for i,o in enumerate(A):
  name=o.name;eo=o.evaluated_get(dg);me=bpy.data.meshes.new_from_object(eo,preserve_all_data_layers=True,depsgraph=dg);prepared.append((name,me,o.matrix_world.copy(),dict(o.items())))
 for i,o in enumerate(A):o.name='NATIVE_HOLD_'+str(i)
 ex=bpy.data.scenes.new('Production exchange only');bpy.context.window.scene=ex
 for name,me,matrix,extra in prepared:
  clone=bpy.data.objects.new(name,me);ex.collection.objects.link(clone);clone.matrix_world=matrix
  for k,v in extra.items():clone[k]=v
  if not me.uv_layers:uv(clone)
 bpy.ops.export_scene.gltf(filepath=str(P/'exports'/(KEY+'.glb')),export_format='GLB',use_selection=False,use_active_scene=True,export_yup=True,export_extras=True,export_apply=True,export_texcoords=True,export_materials='EXPORT')
 (P/'qa/fixtures.json').write_text(json.dumps(LIGHTS,indent=2))


def preview():
 # Reload actual exported GLB for all reviewed pixels; retain native independently.
 bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(P/'exports'/(KEY+'.glb')))
 # QA floor from the separate proposal; never saved/exported with section.
 poly=CONFIG['footprint'];me=bpy.data.meshes.new('QA_FLOOR');me.from_pydata([xyz((u,0,v)) for u,v in poly],[],[tuple(range(len(poly)))]);me.update();o=bpy.data.objects.new('QA_ONLY_FLOOR_PROPOSAL',me);bpy.context.collection.objects.link(o);o.data.materials.append(next((m for m in bpy.data.materials if 'warm_stone' in m.name),next(iter(bpy.data.materials))));uv(o)
 for n,p,power,w,l in LIGHTS:
  da=bpy.data.lights.new(n,'AREA');da.energy=power;da.color=tuple(CONFIG.get('light_color',[1,.82,.60]));da.shape='RECTANGLE';da.size=w;da.size_y=l;ob=bpy.data.objects.new(n,da);bpy.context.collection.objects.link(ob);ob.location=xyz(p)
 sc=bpy.context.scene;sc.render.engine='CYCLES';sc.cycles.samples=8;sc.cycles.use_denoising=True;sc.render.threads_mode='FIXED';sc.render.threads=4;sc.render.resolution_x=960;sc.render.resolution_y=540;sc.render.resolution_percentage=100
 sc.world=bpy.data.worlds.new('Dim QA neutral');sc.world.use_nodes=True;sc.world.node_tree.nodes['Background'].inputs['Color'].default_value=(.18,.20,.23,1);sc.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.17;sc.view_settings.view_transform='AgX';sc.view_settings.exposure=.8
 camd=bpy.data.cameras.new('Eye165');cam=bpy.data.objects.new('Eye165',camd);bpy.context.collection.objects.link(cam);sc.camera=cam;camd.lens=18;camd.clip_start=.05;camd.clip_end=120
 rows=[]
 for n,p,t in CONFIG['views']:
  cam.location=xyz(p);cam.rotation_euler=(xyz(t)-cam.location).to_track_quat('-Z','Y').to_euler();sc.render.filepath=str(P/'qa/views'/(n+'.png'));bpy.ops.render.render(write_still=True);rows.append({'name':n,'eye_world':world(p),'eye_above_proposed_floor':p[1],'target_world':world(t),'file':'qa/views/'+n+'.png','sha256':sha(sc.render.filepath)})
 (P/'qa/view_receipt.json').write_text(json.dumps({'deterministic_source_sha256':sha(__file__),'scope':'Actual exported GLB reimport; source preview floor and fixture preview illumination; no Godot/CRT acceptance','native_sha256':sha(P/'source/section.blend'),'glb_sha256':sha(P/'exports'/(KEY+'.glb')),'views':rows},indent=2))


if __name__=='__main__':
 bpy.ops.wm.read_factory_settings(use_empty=True);s=importlib.util.spec_from_file_location('materials',C/'standards/materials.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);M=m.materials();enclosure();care();native_export();preview();print('SECTION_BUILD_COMPLETE',KEY,len(A))
