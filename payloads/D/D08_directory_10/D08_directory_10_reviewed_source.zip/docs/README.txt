Editable isolated source construction base: Towels & care
Programme D08_directory_10; world XYZ metres; identity GLB placement. Native Blender basis X,-Z,Y.
No common/preview floor or fabricated exterior window in native/export. Root-owned support and runtime acceptance pending.
Rebuild from section folder: Blender4.3.2 --background --factory-startup --threads 4 --python source/build_section.py
Run all Blender/Godot heavy jobs using heavy_job.py and shared Local\Astraea_SolBatch_20261008_HeavyBuild mutex.
All exact dependencies included, materials packed and GLB embedded. Source screening and eye-level image review are not installed Godot acceptance.
