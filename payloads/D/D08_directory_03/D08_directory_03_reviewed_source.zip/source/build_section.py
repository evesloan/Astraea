"""Batch D source authoring. Blender4.3.2; metres. Authored local (u,height,v) maps to world XYZ then Blender(X,-Z,Y). Native/export omit floors and QA context. No registry IDs created."""
import bpy,math,json,hashlib,importlib.util,sys
from pathlib import Path
from mathutils import Vector,Matrix
P=Path(__file__).resolve().parents[1]; C=P/'dependencies/Catalogue';CONFIG=json.loads((P/'docs/design.json').read_text());SIDE=CONFIG['side'];Z=CONFIG['z'];KEY=CONFIG['key']; A=[];LIGHTS=[];M={};seq=0

def world(p):u,y,v=p;return (SIDE*(CONFIG['xbase']+u),CONFIG['floor_y']+y,Z+v)
def xyz(p):x,y,z=world(p);return Vector((x,-z,y))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def uv(o):
 if o.type!='MESH':return
 me=o.data;me.update();layer=me.uv_layers.get('UV0') or me.uv_layers.new(name='UV0')
 for f in me.polygons:
  drop=max(range(3),key=lambda a:abs(f.normal[a]));ax=[a for a in range(3) if a!=drop]
  for li in f.loop_indices:
   v=me.vertices[me.loops[li].vertex_index].co;layer.data[li].uv=(v[ax[0]],v[ax[1]])

def finish(o,n,mat='ivory_enamel',support='root_floor_proposal',zone='architecture',bev=.03):
 o.name=KEY+'__'+n
 if o.type=='MESH':
  bpy.context.view_layer.objects.active=o
  if bev:
   b=o.modifiers.new('Edge craft','BEVEL');b.width=bev;b.segments=2;bpy.ops.object.modifier_apply(modifier=b.name)
  o.data.materials.clear();o.data.materials.append(M[mat]);uv(o)
  bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.normals_make_consistent(inside=False);bpy.ops.object.mode_set(mode='OBJECT')
 o['section']=KEY;o['support']=support if support.startswith(('root_',KEY)) else KEY+'__'+support;o['zone']=zone;A.append(o);return o

def box(n,p,d,mat='ivory_enamel',sup='root_floor_proposal',zone='architecture',bev=.03):
 bpy.ops.mesh.primitive_cube_add(size=1,location=xyz(p));o=bpy.context.object;o.dimensions=(d[0],d[2],d[1]);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,n,mat,sup,zone,min(bev,min(d)*.3))

def rod(n,a,b,r=.06,mat='champagne_metal',sup='root_floor_proposal',zone='architecture',verts=12):
 va,vb=xyz(a),xyz(b);delta=vb-va;bpy.ops.mesh.primitive_cylinder_add(vertices=verts,radius=r,depth=delta.length,location=(va+vb)/2);o=bpy.context.object;o.rotation_euler=delta.to_track_quat('Z','Y').to_euler();bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,n,mat,sup,zone,.008)

def prism(n,poly,y,h,mat='warm_walnut',sup='root_floor_proposal',zone='architecture'):
 vs=[xyz((u,y,v)) for u,v in poly]+[xyz((u,y+h,v)) for u,v in poly];k=len(poly);faces=[tuple(range(k-1,-1,-1)),tuple(range(k,2*k))]+[(i,(i+1)%k,(i+1)%k+k,i+k) for i in range(k)];me=bpy.data.meshes.new(n);me.from_pydata(vs,[],faces);me.update();o=bpy.data.objects.new(n,me);bpy.context.collection.objects.link(o);return finish(o,n,mat,sup,zone,.025)

def cyl(n,p,r,h,mat='champagne_metal',sup='root_floor_proposal',zone='programme'):
 return rod(n,p,(p[0],p[1]+h,p[2]),r,mat,sup,zone,32)

def wall(n,a,b,h=4.9,w=.36,mat='ivory_enamel',y=0,sup='root_floor_proposal',zone='architecture'):
 u,v=a;du,dv=b[0]-u,b[1]-v;l=math.hypot(du,dv);o=box(n,((u+b[0])/2,y+h/2,(v+b[1])/2),(l,w,h) if False else (l,h,w),mat,sup,zone,.045)
 # Long box local BlenderX must align actual converted wall vector.
 vec=xyz((b[0],y,b[1]))-xyz((a[0],y,a[1]));o.rotation_euler[2]=math.atan2(vec.y,vec.x);return o

def sign(n,body,u,v,y=1.7,sup='root_floor_proposal'):
 back=box(n+'_plate',(u,y,v),(.10,.50,2.0),'warm_walnut',sup,zone='wayfinding');cu=bpy.data.curves.new(n,'FONT');cu.body=body;cu.align_x='CENTER';cu.align_y='CENTER';cu.size=.16;cu.extrude=.001;o=bpy.data.objects.new(n,cu);bpy.context.collection.objects.link(o);o.location=xyz((u-.06,y,v));o.rotation_euler=(math.pi/2,0, math.pi/2 if SIDE<0 else -math.pi/2);o.data.materials.append(M['ivory_enamel']);finish(o,n+'_text',support=back.name,zone='wayfinding',bev=0)

def asset(n,file,u,v,y=0,yaw=None,sup=None):
 with bpy.data.libraries.load(str(C/file),link=False) as (data,to):to.objects=data.objects
 os=[o for o in to.objects if o and o.type=='MESH']
 for ob in os:bpy.context.collection.objects.link(ob)
 bpy.context.view_layer.update()
 original_world={o:o.matrix_world.copy() for o in os}
 for ob in os:ob.parent=None
 rot=Matrix.Rotation((SIDE*math.pi/2 if yaw is None else yaw),4,'Z');trans=Matrix.Translation(xyz((u,y,v)))
 for o in os:
  o.hide_render=False;o.hide_viewport=False;o.hide_select=False;o.hide_set(False);o.parent=None;o.matrix_world=trans@rot@original_world[o];o.name=KEY+'__'+n+'__'+o.name;o['section']=KEY;o['zone']='catalogue_'+n;o['support']='catalogue_contact_graph';o['shelf_support']=sup or '';A.append(o)
  for im in bpy.data.images:
   if im.source=='FILE' and not im.packed_file:
    try:im.pack()
    except:pass
 return os

def seat(n,u,v,length=5,face=1,cloth='teal_weave',zone='rest'):
 b=box(n+'_plinth',(u,.17,v),(1.3,.34,length),'warm_walnut',zone=zone,bev=.08)
 box(n+'_pad',(u,.45,v),(1.4,.22,length-.15),cloth,b.name,zone,.075)
 back=box(n+'_back',(u-.56*face,.86,v),(.24,1.10,length),cloth,b.name,zone,.08)
 for k in [-1,1]:box(n+'_arm'+str(k),(u,.52,v+k*(length/2-.12)),(1.42,.40,.24),'warm_walnut',b.name,zone,.06)
 return b.name

def arcseat(n,u,v,r,start,end,cloth='oatmeal_weave'):
 # Faceted continuous fitted seating with radial depth; generous gap in arrival sector.
 count=max(3,int(abs(end-start)/18));poly=[]
 for j in range(count+1):a=math.radians(start+(end-start)*j/count);poly.append((u+(r+.55)*math.cos(a),v+(r+.55)*math.sin(a)))
 for j in range(count,-1,-1):a=math.radians(start+(end-start)*j/count);poly.append((u+(r-.55)*math.cos(a),v+(r-.55)*math.sin(a)))
 b=prism(n+'_base',poly,0,.33,'warm_walnut',zone='gathering');prism(n+'_cushion',poly,.33,.20,cloth,b.name,'gathering')
 for j in range(count):
  a0=math.radians(start+(end-start)*j/count);a1=math.radians(start+(end-start)*(j+1)/count)
  pa=(u+(r+.54)*math.cos(a0),v+(r+.54)*math.sin(a0));pb=(u+(r+.54)*math.cos(a1),v+(r+.54)*math.sin(a1));wall(n+'_back'+str(j),pa,pb,.78,.20,cloth,.33,b.name,'gathering')

def table(n,u,v,r=.85):
 f=cyl(n+'_foot',(u,0,v),r*.60,.08,'dark_rubber');p=cyl(n+'_stem',(u,.08,v),.11,.61,'champagne_metal',f.name);t=cyl(n+'_top',(u,.69,v),r,.10,'warm_walnut',p.name)
 cyl(n+'_cup',(u+.20,.79,v),.09,.13,'ivory_enamel',t.name);box(n+'_folio',(u-.20,.815,v-.10),(.34,.05,.45),'clay_weave',t.name,'rest',.008);return t.name

def fixture(n,u,v,y=4.4,power=900):
 # Floor-supported blade pendant: roof frame and visible diffuser.
 post=box(n+'_post',(u,y/2,v),(.16,y,.16),'champagne_metal',zone='light_support')
 box(n+'_arm',(u+.5,y-.12,v),(1.14,.16,.18),'warm_walnut',post.name,'fixture')
 box(n+'_shade',(u+.86,y-.24,v),(.60,.32,.90),'ivory_enamel',n+'_arm','fixture',.09)
 box(n+'_lens',(u+.86,y-.42,v),(.48,.04,.74),'oatmeal_weave',n+'_shade','fixture',.01)
 LIGHTS.append((n,(u+.86,y-.47,v),power,.65,.85))

def books(n,u,v,length=5):
 b=box(n+'_back',(u,1.5,v),(.18,3,length),'warm_walnut',zone='collection')
 for h in [.20,.91,1.62,2.33,2.95]:
  shelf=box(n+'_shelf'+str(h),(u-.44,h,v),(1.0,.08,length),'warm_walnut',b.name,'collection')
  if h<2.9:
   # One detailed existing stock group anchors each shelf; fitted bound volumes fill the remaining bays economically.
   q=v-length/2+.45
   asset(n+'_books'+str(h)+'_catalogue','assets/library_contents/AST-LIB-006_upright_book_group.blend',u-.40,q,h+.04,yaw=SIDE*math.pi/2,sup=shelf.name)
   for j in range(1,int(length/.48)):
    q=v-length/2+.45+j*.48
    for k in range(2):
     ht=.32+.07*((j+k)%3);z=q+k*.13;name=n+'_volume'+str(h)+'_'+str(j)+'_'+str(k)
     pages=box(name+'_pages',(u-.43,h+.04+ht/2,z),(.36,ht,.11),'ivory_enamel',shelf.name,'collection',.009)
     box(name+'_spine',(u-.61,h+.04+(ht+.02)/2,z),(.045,ht+.02,.14),'teal_weave' if (j+k)%2 else 'clay_weave',shelf.name,'collection',.008)
 return b.name

def cupboard(n,u,v):
 b=box(n+'_body',(u,1.1,v),(1.20,2.2,4.0),'warm_walnut',zone='service')
 for q in [-1,1]:box(n+'_door'+str(q),(u-.62,1.20,v+q*.98),(.08,1.85,1.84),'ivory_enamel',b.name,'service')
 for q in [-1,1]:box(n+'_handle'+str(q),(u-.70,1.30,v+q*.35),(.09,.30,.09),'champagne_metal',n+'_door'+str(q),'service')
 sign(n,'CARE / STOCK',u-.67,v,2.02,n+'_door-1')


def enclosure():
 poly=CONFIG['footprint']
 for i,(a,b) in enumerate(zip(poly,poly[1:]+poly[:1])):
  if a[0]==b[0]==2.5:wall('threshold_a',a,(2.5,-4.5),3.8,.36);wall('threshold_b',(2.5,4.5),b,3.8,.36)
  else:wall('spring_shell'+str(i),a,b,5.8,.36)
 for v in [-4.5,4.5]:box('arrival_jamb'+str(v),(4.3,1.7,v),(3.5,3.4,.5),'warm_stone')
 box('arrival_crown',(4.3,3.55,0),(3.5,.3,9.5),'warm_walnut','arrival_jamb-4.5');sign('arrival','MINERAL SPRINGS',4.3,-4.78,1.7,'arrival_jamb-4.5');cupboard('care',5.5,-12)
 for i,(u,v) in enumerate([(12,-28),(12,28),(40,-25),(40,25),(40,2),(18,-5),(18,6)]):fixture('spring_light'+str(i),u,v,3.7,1500)
 # Offset high ribs form two different courts rather than a single repeated canopy.
 for i,(u,v,h) in enumerate([(22,-27,6.4),(35,28,5.2)]):
  post=box('court_rib_post'+str(i),(u,h/2,v),(.45,h,.45),'warm_stone');rod('court_rib'+str(i),(u,h,v),(u,h-1.1,v+(18 if v<0 else -18)),.18,'warm_walnut',post.name)

def ramp(n,u0,u1,v,w,h):
 vs=[xyz(p) for p in [(u0,0,v-w/2),(u1,0,v-w/2),(u1,0,v+w/2),(u0,0,v+w/2),(u0,0,v-w/2),(u1,h,v-w/2),(u1,h,v+w/2),(u0,0,v+w/2)]]
 faces=[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)];me=bpy.data.meshes.new(n);me.from_pydata(vs,[],faces);me.update();o=bpy.data.objects.new(n,me);bpy.context.collection.objects.link(o);finish(o,n,'warm_stone',zone='wet_access_surface',bev=0)
 # Handrails have their own floor-mounted supports; no unsupported floating rail.
 for j,q in enumerate([-w/2,w/2]):
  for k,u in enumerate([u0+.5,u1-.5]):
   y=h*(u-u0)/(u1-u0);post=rod(n+'_rail_post'+str(j)+'_'+str(k),(u,0,v+q),(u,y+1.05,v+q),.055,'champagne_metal')
   if k==0:rod(n+'_handrail'+str(j),(u0+.5,h*.5/(u1-u0)+1.05,v+q),(u1-.5,h*(u1-u0-.5)/(u1-u0)+1.05,v+q),.05,'champagne_metal',post.name)

def spring_basin(n,u,v,w,l):
 q=2;poly=[(u-w/2+q,v-l/2),(u+w/2-q,v-l/2),(u+w/2,v-l/2+q),(u+w/2,v+l/2-q),(u+w/2-q,v+l/2),(u-w/2+q,v+l/2),(u-w/2,v+l/2-q),(u-w/2,v-l/2+q)]
 base=prism(n+'_bottom',poly,0,.30,'warm_stone',zone='basin_structure')
 for j,(a,b) in enumerate(zip(poly,poly[1:]+poly[:1])):
  if a[1]==b[1] and ((v<0 and a[1]==v+l/2) or (v>0 and a[1]==v-l/2)):
   lo,hi=sorted([a,b]);wall(n+'_coping_left',lo,(24,a[1]),1.1,.35,'warm_stone',sup=base.name);wall(n+'_coping_right',(28,a[1]),hi,1.1,.35,'warm_stone',sup=base.name)
  else:wall(n+'_coping'+str(j),a,b,1.1,.35,'warm_stone',sup=base.name)
 prism(n+'_water',[(u+(x-u)*.99,v+(z-v)*.99) for x,z in poly],.88,.04,'bath_water',n+'_coping1','static_water',)
 signv=-1 if v<0 else 1
 for j in range(4):
  h=.9-.15*j;box(n+'_entry_tread'+str(j),(26,h/2,signv*(abs(v)-l/2+.4+j*.7)),(3.8,h,1.0),'warm_stone',base.name,'basin_entry')

def springs():
 water=bpy.data.materials.new('ASTRAEA_STATIC_MINERAL_WATER');water.use_nodes=True;bs=water.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(.06,.23,.20,1);bs.inputs['Roughness'].default_value=.28;M['bath_water']=water
 spring_basin('mineral_court',27,-15,16,18);spring_basin('quiet_court',29,16,18,18)
 box('wet_landing',(26,.45,0),(12,.9,4),'warm_stone',zone='wet_access_surface');ramp('accessible_wet_ramp',8,20,0,4,.9)
 box('south_entry_bridge',(26,.45,-4),(4,.9,6),'warm_stone',zone='basin_entry');box('north_entry_bridge',(26,.45,4.5),(4,.9,7),'warm_stone',zone='basin_entry')
 # Grounded mineral specimen, an opaque interpretive focus, never a treatment claim.
 pl=cyl('mineral_plinth',(39,0,-15),1.2,.55,'warm_stone');cyl('mineral_form',(39,.55,-15),.7,1.4,'champagne_metal',pl.name);sign('mineral_label','MINERAL COURT',38.35,-15,1.1,'mineral_form')
 for i,v in enumerate([-20,20]):seat('recovery'+str(i),12,v,7,1,'oatmeal_weave')
def native_export():
 bpy.context.view_layer.update()
 # All bitmap resources embedded in actual editable source.
 for im in bpy.data.images:
  if im.source=='FILE' and not im.packed_file:im.pack()
 bpy.context.scene['deterministic_source_sha256']=sha(__file__)
 bpy.ops.wm.save_as_mainfile(filepath=str(P/'source/section.blend'))
 # Export evaluated production copies into a clean scene: no inherited collection selection/visibility state.
 dg=bpy.context.evaluated_depsgraph_get();prepared=[]
 for i,o in enumerate(A):
  name=o.name;eo=o.evaluated_get(dg);me=bpy.data.meshes.new_from_object(eo,preserve_all_data_layers=True,depsgraph=dg);prepared.append((name,me,o.matrix_world.copy(),dict(o.items())))
 for i,o in enumerate(A):o.name='NATIVE_HOLD_'+str(i)
 ex=bpy.data.scenes.new('Production exchange only');bpy.context.window.scene=ex
 for name,me,matrix,extra in prepared:
  clone=bpy.data.objects.new(name,me);ex.collection.objects.link(clone);clone.matrix_world=matrix
  for k,v in extra.items():clone[k]=v
  if not me.uv_layers:uv(clone)
 bpy.ops.export_scene.gltf(filepath=str(P/'exports'/(KEY+'.glb')),export_format='GLB',use_selection=False,use_active_scene=True,export_yup=True,export_extras=True,export_apply=True,export_texcoords=True,export_materials='EXPORT')
 (P/'qa/fixtures.json').write_text(json.dumps(LIGHTS,indent=2))


def preview():
 # Reload actual exported GLB for all reviewed pixels; retain native independently.
 bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(P/'exports'/(KEY+'.glb')))
 # QA floor from the separate proposal; never saved/exported with section.
 poly=CONFIG['footprint'];me=bpy.data.meshes.new('QA_FLOOR');me.from_pydata([xyz((u,0,v)) for u,v in poly],[],[tuple(range(len(poly)))]);me.update();o=bpy.data.objects.new('QA_ONLY_FLOOR_PROPOSAL',me);bpy.context.collection.objects.link(o);o.data.materials.append(next((m for m in bpy.data.materials if 'warm_stone' in m.name),next(iter(bpy.data.materials))));uv(o)
 for n,p,power,w,l in LIGHTS:
  da=bpy.data.lights.new(n,'AREA');da.energy=power;da.color=tuple(CONFIG.get('light_color',[1,.82,.60]));da.shape='RECTANGLE';da.size=w;da.size_y=l;ob=bpy.data.objects.new(n,da);bpy.context.collection.objects.link(ob);ob.location=xyz(p)
 sc=bpy.context.scene;sc.render.engine='CYCLES';sc.cycles.samples=8;sc.cycles.use_denoising=True;sc.render.threads_mode='FIXED';sc.render.threads=4;sc.render.resolution_x=960;sc.render.resolution_y=540;sc.render.resolution_percentage=100
 sc.world=bpy.data.worlds.new('Dim QA neutral');sc.world.use_nodes=True;sc.world.node_tree.nodes['Background'].inputs['Color'].default_value=(.18,.20,.23,1);sc.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.17;sc.view_settings.view_transform='AgX';sc.view_settings.exposure=.8
 camd=bpy.data.cameras.new('Eye165');cam=bpy.data.objects.new('Eye165',camd);bpy.context.collection.objects.link(cam);sc.camera=cam;camd.lens=18;camd.clip_start=.05;camd.clip_end=120
 rows=[]
 for n,p,t in CONFIG['views']:
  cam.location=xyz(p);cam.rotation_euler=(xyz(t)-cam.location).to_track_quat('-Z','Y').to_euler();sc.render.filepath=str(P/'qa/views'/(n+'.png'));bpy.ops.render.render(write_still=True);rows.append({'name':n,'eye_world':world(p),'eye_above_proposed_floor':p[1],'target_world':world(t),'file':'qa/views/'+n+'.png','sha256':sha(sc.render.filepath)})
 (P/'qa/view_receipt.json').write_text(json.dumps({'deterministic_source_sha256':sha(__file__),'scope':'Actual exported GLB reimport; source preview floor and fixture preview illumination; no Godot/CRT acceptance','native_sha256':sha(P/'source/section.blend'),'glb_sha256':sha(P/'exports'/(KEY+'.glb')),'views':rows},indent=2))


if __name__=='__main__':
 bpy.ops.wm.read_factory_settings(use_empty=True);s=importlib.util.spec_from_file_location('materials',C/'standards/materials.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);M=m.materials();enclosure();springs();native_export();preview();print('SECTION_BUILD_COMPLETE',KEY,len(A))
