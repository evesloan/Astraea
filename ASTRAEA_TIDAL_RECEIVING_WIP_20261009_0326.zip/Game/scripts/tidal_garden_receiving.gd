extends RefCounted

# Retained source architecture only. Explicitly invoked for receiving validation;
# not enabled in the main ship until adjacent support and route gates pass.
static func build(ship: Node3D) -> Node3D:
	var definition: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://data/architecture/TIDAL_GARDEN_RECEIVING_CANDIDATE.json"))
	var path := "res://assets/models/" + str(definition.model_file)
	assert(FileAccess.get_sha256(path) == str(definition.source_sha256))
	assert(FileAccess.get_sha256("res://data/generated/structural_meshes.json") == str(definition.preserved_compiled_floor_sha256))
	var parent := ship.get_node("ShipSpace/Districts")
	assert(parent.get_node_or_null("TidalGardenReceivingCandidate") == null)
	var house := Node3D.new()
	house.name = "TidalGardenReceivingCandidate"
	house.set_meta("source_only_interiors", 85)
	house.set_meta("installed_guest_units", 0)
	house.set_meta("acceptance", "receiving_validation_pending")
	parent.add_child(house)
	var visual := (load(path) as PackedScene).instantiate()
	house.add_child(visual)
	var meshes := visual.find_children("*", "MeshInstance3D", true, false)
	assert(meshes.size() == int(definition.mesh_count))
	var contacts := 0
	for part: MeshInstance3D in meshes:
		var source: Dictionary = part.get_meta("extras", {})
		assert(source.has("category") and source.has("runtime_collision"), "Retain source collision semantics")
		assert(str(source.source_plan_sha256) == str(definition.plan_sha256))
		if bool(source.runtime_collision):
			load("res://scripts/static_contact_cache.gd").attach(part)
			contacts += 1
	house.set_meta("source_contact_count", contacts)
	return house
