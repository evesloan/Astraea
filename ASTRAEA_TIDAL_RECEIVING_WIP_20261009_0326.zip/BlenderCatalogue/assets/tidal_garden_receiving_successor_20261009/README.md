# Tidal Garden receiving successor

This architecture-only derivative preserves the original whole-house source and its 85 separate interior mappings. It is not enabled in the default scene and adds zero installed guest units.

The original export failed 5 of 9 planned routes because disconnected-face normal recalculation changed floor winding. The corrected source restores exact PLAN face topology on 45 floor/landing parts with unchanged coordinate sets and UV correspondences. All 339 compact batches remain; 301 have source-declared collision. The actual default ship plus this candidate passes 2,603 static support/capsule samples with zero failed routes. This is not full traversal, cart/species, support-transfer, operating lift, visual review or final-art acceptance.

Original inputs remain independently retained. ATTEMPT001 records the unsuccessful weld approach; ATTEMPT002 records original floor-support failures. The correction does not enable double-sided collision, move vertices, widen routes or weaken assertions. Adjacent Horizon/Listening support and remaining house construction stay open.
