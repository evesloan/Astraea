"""Preserve retained architecture coordinates and repair closed floor orientation.
The full original house and linked interiors remain unchanged in their source package.
"""
from pathlib import Path
import bpy,bmesh,json,hashlib
R=Path('/workspace/shared/Astraea_direct_recovery_20261008_hcozu5z4')
SRC=R/'BlenderCatalogue/assets/residential_hotels/tidal_garden_20261007_r001/residential-neighborhood-courts-20261007/tidal_garden_house/outputs/house_r001'
OUT=Path(__file__).resolve().parents[1];EXP=OUT/'exports';EXP.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
pins={str(SRC/f):sha(SRC/f)for f in ['PLAN.json','house.blend','architecture.glb']}
plan=json.loads((SRC/'PLAN.json').read_text());names=[p['name']for p in plan['parts']]
assert not(OUT/'source/architecture_floor_winding.blend').exists()
bpy.ops.wm.read_factory_settings(use_empty=True)
with bpy.data.libraries.load(str(SRC/'house.blend'),link=False)as(src,dst):
 assert set(names)<=set(src.objects)
 dst.objects=names
objects={o.name:o for o in dst.objects};sourcecol=bpy.data.collections.new('EditableRetainedArchitecture');bpy.context.scene.collection.children.link(sourcecol)
groupkeys={};before={};fixes=[]
for p in plan['parts']:
 o=objects[p['name']];sourcecol.objects.link(o)
 coords=[o.matrix_world@v.co for v in o.data.vertices]
 groupkeys[o.name]=(p['role'],p['category'],int((sum(v.y for v in coords)/len(coords))//25),int(((sum(v.z for v in coords)/len(coords))-78)//4.5))
 before[o.name]=sorted(set(tuple(round(c,6)for c in v)for v in coords))
 if p['category'] not in ['floor','stair_landing']:continue
 me=o.data;bm=bmesh.new();bm.from_mesh(me);oldverts=len(bm.verts)
 bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.000001)
 assert all(e.is_manifold for e in bm.edges),(o.name,'not a closed slab after welding')
 bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
 volume=bm.calc_volume(signed=True);assert volume>0,(o.name,volume)
 bm.to_mesh(me);bm.free();me.update()
 assert before[o.name]==sorted(set(tuple(round(c,6)for c in o.matrix_world@v.co)for v in me.vertices)),o.name
 fixes.append({'name':o.name,'before_vertices':oldverts,'after_vertices':len(me.vertices),'positive_volume_m3':volume,'coordinate_set_unchanged':True})
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'source/architecture_floor_winding.blend'))
groups={}
for p in plan['parts']:
 o=objects[p['name']];g=groups.setdefault(groupkeys[o.name],{'verts':[],'faces':[],'uv':[],'parts':[],'material':o.data.materials[0]})
 coords=[o.matrix_world@v.co for v in o.data.vertices];off=len(g['verts']);foff=len(g['faces']);g['verts'].extend(tuple(v)for v in coords);g['faces'].extend(tuple(off+j for j in f.vertices)for f in o.data.polygons);g['uv'].extend(tuple(u.uv)for u in o.data.uv_layers.active.data);g['parts'].append({'source_part_id':o.name,'vertex_start':off,'vertex_count':len(coords),'face_start':foff,'face_count':len(o.data.polygons)})
exportcol=bpy.data.collections.new('EXPORT_COMPACT_ARCHITECTURE');bpy.context.scene.collection.children.link(exportcol)
bpy.ops.object.select_all(action='DESELECT')
for i,(key,g)in enumerate(groups.items()):
 me=bpy.data.meshes.new('TG_Batch_'+str(i));me.from_pydata(g['verts'],[],g['faces']);me.materials.append(g['material']);uv=me.uv_layers.new(name='MetreScaled');assert len(uv.data)==len(g['uv'])
 for a,b in zip(uv.data,g['uv']):a.uv=b
 ob=bpy.data.objects.new('TG_Batch_'+str(i),me);exportcol.objects.link(ob);ob.select_set(True);ob['source_part_ranges']=g['parts'];ob['role']=key[0];ob['category']=key[1];ob['source_plan_sha256']=sha(SRC/'PLAN.json');ob['runtime_collision']=key[1]not in ['soil','fixture','water']
bpy.ops.export_scene.gltf(filepath=str(EXP/'architecture_floor_winding.glb'),export_format='GLB',use_selection=True,export_yup=True,export_extras=True)
assert len(groups)==339
assert all(sha(p)==h for p,h in pins.items())
report={'status':'SOURCE_DERIVATIVE_READY_FOR_RUNTIME_CHECK','purpose':'Weld coincident vertices within closed floor parts before normal recalculation; no moved vertices, widened routes or double-sided collision workaround','original_inputs':pins,'source_parts':len(names),'compact_batches':len(groups),'corrected_closed_parts':fixes,'native_sha256':sha(OUT/'source/architecture_floor_winding.blend'),'export_sha256':sha(EXP/'architecture_floor_winding.glb'),'limits':'Architecture derivative only. Full original linked house retained; no guest-unit, runtime support-transfer or final-art acceptance.'}
(OUT/'SOURCE_CORRECTION_RECEIPT.json').write_text(json.dumps(report,indent=2)+'\n');print('TIDAL_FLOOR_CORRECTION',len(fixes),'parts',len(groups),'batches',flush=True)
