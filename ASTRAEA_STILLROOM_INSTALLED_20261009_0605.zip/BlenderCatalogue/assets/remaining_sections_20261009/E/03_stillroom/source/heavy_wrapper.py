import ctypes,subprocess,sys,time,json,pathlib,datetime
from ctypes import wintypes
k=ctypes.WinDLL('kernel32',use_last_error=True)
k.CreateMutexW.argtypes=[ctypes.c_void_p,wintypes.BOOL,wintypes.LPCWSTR];k.CreateMutexW.restype=wintypes.HANDLE
k.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD];k.WaitForSingleObject.restype=wintypes.DWORD
k.ReleaseMutex.argtypes=[wintypes.HANDLE];k.CloseHandle.argtypes=[wintypes.HANDLE]
h=k.CreateMutexW(None,False,r'Local\Astraea_SolBatch_20261008_HeavyBuild')
if not h:raise ctypes.WinError(ctypes.get_last_error())
held=False
try:
 print('WAITING_SHARED_HEAVY_MUTEX',flush=True)
 while True:
  state=k.WaitForSingleObject(h,60000)
  if state not in [0,0x80]:
   if state==0x102:
    print('STILL_WAITING_SHARED_HEAVY_MUTEX',datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True);continue
   raise ctypes.WinError(ctypes.get_last_error())
  held=True
  # Scan after both ordinary and abandoned acquisitions; other non-batch jobs are protected.
  out=subprocess.check_output(['powershell','-NoProfile','-Command',"Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(blender|godot).*\\.exe$' } | Select-Object ProcessId,Name,CommandLine | ConvertTo-Json -Compress"],text=True).strip()
  if out:
   print('SURVIVING_HEAVY_PROCESS_DEFER',out,flush=True);k.ReleaseMutex(h);held=False;time.sleep(5);continue
  print('HEAVY_MUTEX_ACQUIRED',state,datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True);break
 cmd=sys.argv[1:]
 print('HEAVY_COMMAND',json.dumps(cmd),flush=True)
 result=subprocess.run(cmd)
 print('HEAVY_COMMAND_EXIT',result.returncode,flush=True);sys.exit(result.returncode)
finally:
 if held:k.ReleaseMutex(h)
 k.CloseHandle(h)
