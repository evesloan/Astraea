import pathlib,sys,math,json
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
import toolkit as t,assembly as a
SEC='D12_directory_04';R=(8,54,-250,-182);t.init(SEC,'03_stillroom',78,5.5)
poly=[(8.2,-246),(12.2,-249.8),(49.8,-249.8),(53.8,-245.8),(53.8,-186.2),(49.8,-182.2),(12.2,-182.2),(8.2,-186.2)]
t.ZONE='enclosing_bearing_shell'
for i,(p,q) in enumerate(zip(poly,poly[1:]+poly[:1])):
 if i==7:
  t.linewall('west_north',p,(8.2,-213),5.5,'blue',.36);t.linewall('west_south',(8.2,-219),q,5.5,'blue',.36)
 else:t.linewall('perimeter'+str(i),p,q,5.5,'blue',.36)
t.prism('fitted_upper_cap',poly,5.5,.14,'white',sup='perimeter_bearing_shell',role='closed_roof_proposal')
t.ZONE='compressed_acoustic_arrival'
t.portal('entry',8.55,-216,'x',4,3.2)
t.linewall('vestibule_return',(12.5,-222),(18.5,-222),2.8,'white',.45)
t.linewall('vestibule_quiet_screen',(15,-212),(21,-212),2.8,'blue',.45)
t.box('arrival_low_canopy',(15,3.3,-217),(10,.24,8),'white',sup='E_arrival_canopy_bearing')
t.box('arrival_canopy_bearing',(19.7,1.6,-220.4),(.35,3.2,.35),'zinc',role='bearing_floor_contact')
t.sign('identity','STILLROOM',13,-221.75,2.3,.22,sup='E_vestibule_return')
t.ZONE='woven_quiet_coves'
# Six deep, ground-level quiet niches wrap an open middle. Their open mouths face the
# longitudinal lanes rather than one another, giving usable privacy without dead-end rooms.
for row,z in enumerate([-238,-216,-194]):
 for side,x in enumerate([24,45]):
  ang0,ang1=(-math.pi/2,math.pi/2) if side else (math.pi/2,3*math.pi/2)
  points=[(x+5.2*math.cos(ang0+j*(ang1-ang0)/12),z+7.5*math.sin(ang0+j*(ang1-ang0)/12)) for j in range(13)]
  for j,(p,q) in enumerate(zip(points,points[1:])):t.linewall('cove_'+str(row)+str(side)+'_'+str(j),p,q,2.6,'quiet',.28)
  # Sheltered sitting edge with reachable shelf/table and broad open rest position.
  for k,dz in enumerate([-1.2,1.2]):
   a.family('cove_chair_'+str(row)+str(side)+str(k),'AST-FUR-002_day_reading_chair.glb',x+(-2.1 if side==0 else 2.1),z+dz,(-math.pi/2 if side==0 else math.pi/2))
  t.table('cove_table_'+str(row)+str(side),x,z,2.4,1.4)
  t.box('cove_low_shelf_'+str(row)+str(side),(x+(-3.9 if side==0 else 3.9),.65,z),(.8,1.3,7),'blue',role='shelf_floor_contact')
  for k,zz in enumerate([z-5,z+5]):
   t.box('cove_roof_bearing_'+str(row)+str(side)+str(k),(x+(-3.2 if side==0 else 3.2),1.75,zz),(.3,3.5,.3),'zinc',role='bearing_floor_contact')
  cap=[(x+(-4.4 if side==0 else -1.9),z-5.3),(x+(1.9 if side==0 else 4.4),z-5.3),(x+(1.9 if side==0 else 4.4),z+5.3),(x+(-4.4 if side==0 else -1.9),z+5.3)]
  t.prism('cove_roof_'+str(row)+str(side),cap,3.5,.14,'white',sup='E_cove_roof_bearing_'+str(row)+str(side)+'0')
  t.light('cove_light_'+str(row)+str(side),x,z,y=3.22,l=2)
t.ZONE='central_still_focus'
# The central lantern is a quiet solid object, not a pool, external view or gameplay device.
focus=[(34+2.4*math.cos(j*math.tau/16),-216+5*math.sin(j*math.tau/16)) for j in range(16)]
t.prism('still_focus_base',focus,0,.55,'white',role='focus_floor_contact')
t.box('still_focus_lantern',(34,1.5,-216),(1,1.9,1),'quiet',sup='E_still_focus_base')
t.box('still_focus_cap',(34,2.49,-216),(1.25,.12,1.25),'zinc',sup='E_still_focus_lantern')
t.ZONE='branching_high_spine'
for i,z in enumerate([-242,-230,-202,-190]):
 for side,x in enumerate([9.0,53.0]):
  p=t.box('spine_bearing_'+str(i)+str(side),(x,2.2,z),(.35,4.4,.4),'blue',role='bearing_floor_contact')
  t.rod('swept_spine_'+str(i)+str(side),(x,4.35,z),(34,5.25,z+(2 if i%2 else -2)),.14,'white',sup=p.name)
 t.light('spine_light_'+str(i),34,z,y=4.9,l=3)
t.ZONE='entry_rest_and_care'
t.bench('arrival_pause',13.5,-230,5,math.pi/2,'quiet')
t.bench('return_pause',13.5,-201,5,math.pi/2,'cloth')
t.linewall('care_screen',(18.2,-189.4),(18.2,-183.4),2.7,'blue',.3)
t.cabinet('stillroom_stock',14,-183.7,math.pi)
t.table('care_worktop',13.5,-187.9,3.2,1.5)
t.sign('care','LOCAL CARE',14.5,-182.41,2.1,.15,face='north',sup='E_perimeter5')
t.light('care_task',14.5,-188.5,y=3.8,l=2)
t.light('entry_task',15,-217,y=3,l=3)
contract=next(x for x in json.loads((t.BASE/'SOURCE_SCOPE_RECONCILIATION.json').read_text()) if x['programme_key']==SEC)
(t.P/'docs/CONTRACT.json').write_text(json.dumps(contract,indent=2))
(t.P/'docs/DESIGN_INTENT.json').write_text(json.dumps(dict(purpose='Quiet guest retreat with sheltered rest niches and clear care access; no capacity or sleep berth claim',primary_form='Six opposed curved cove edges around a branching high spine and solid contemplative lantern',arrival='Deep low threshold turns between staggered acoustic screens into a level loop; centre focus visible before private sitting edges',reference_application='Direct original lounge and library pixels inspected: intimate chair/table reach, layered quiet alcoves and organizing ceiling; no exterior window, pool, loft or cabin copied',floor='Root-owned receiving slab required at Y78; preview excluded',upper_interface='Source top Y83.64 below Y83.76 residential floor underside. No upper-house receiving members authored or load-path certification.',below='Retain Cinema 2 at D11_directory_03 and its upper ceiling; all source contacts stop at Y78',body_cart='Entry clear 4m x3.2m; level circulation target 3.4m, species and loaded cart acceptance root-held'),indent=2))
(t.P/'docs/APPROACH_PROPOSALS.json').write_text(json.dumps([dict(name='arrival_main_lane',radius_m=.65,points_xz=[[8.6,-216],[11,-216],[11,-226],[16,-226],[16,-241],[16,-246.7],[34,-246.7],[34,-226]]),dict(name='care_cart',radius_m=1.7,points_xz=[[8.6,-216],[11,-216],[11,-206],[16,-206],[16,-191],[14.5,-190.6]]),dict(name='stock_service_body',radius_m=.65,points_xz=[[16,-191],[16.3,-188.8],[16.3,-185.1],[14,-185.1]])],indent=2))
h=t.save_export(R)
floor=json.loads((t.P/'docs/FLOOR_PROPOSAL.json').read_text());floor['boundary']=poly;floor['root_entry_joint']=dict(point=[8,78,-216],source_shell_plane_x=8.2,gap_m=.2,owner='Root receiver; no exported threshold floor');(t.P/'docs/FLOOR_PROPOSAL.json').write_text(json.dumps(floor,indent=2))
t.render(R,[('01_arrival',(11,-216),(32,-226)),('02_still_focus',(34,-231),(34,-216)),('03_quiet_cove',(30,-236),(23,-238)),('04_care',(14.5,-191),(14.5,-186)),('05_room_arrival',(16,-226),(34,-216))],h)
print('STILLROOM_SOURCE_COMPLETE',h,flush=True)
