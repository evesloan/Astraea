# WP02 Sports care & changing — source candidate

Revision 2 current receiving contract replaces the initial local stage-one plan. The only public portal is **[8,35.5,460]**, with a 4m clear aperture across Z458–462. The former Z432 entrance, 0.2m core-gap argument and independent staff opening are withdrawn. The 4m external X4–8 strip is Higgins-owned, held and unbuilt. Future external staff connections remain sealed and unbuilt.

The package is entirely inside X8–54, Z398–466, with local GLB origin at world [8,35.5,460]. Local Blender origin is the same physical point; X is east, Y points toward decreasing ship Z, and Z is height above D07. GLB mapping is (x,z,-y); runtime placement is translation only. Maximum proposed enclosure height is7.8m, leaving0.7m below D08 datum44. No cross-deck cuts or exterior openings. D06 Sunset garden cafe and D08 Towels & care remain protected.

## Authored composition

An aft reception/rest chamber opens into a long, vaulted changing promenade. Lower opaque changing rooms form a quiet west edge; fitted locker islands and an enclosed wash/rinse block form the east activity edge. A screened service lane lies at X49.7–53.6. This gives an understandable progression from public welcome, through dry changing and storage, into wet care without exposing private use from the entry.

The whole section includes reception desk and lower counter, supported upholstered resting benches, 6 private changing compartments with lockers/benches/hooks,26 day lockers with seats,3 mounted vanity basins,4 mounted rinse fixtures with drying seats/returns,2 WC compartments, clean textile cabinets, segregated used-textile containers, cleaning cupboard, an internal staff threshold, signs and effective source-mounted lights. These quantities are design proposals, not recovered required counts or certified occupancy. Imported fixtures retain their source families without scale distortion.

The curved promenade lining is backed between explicit transverse ribs bearing on substantial piers, with capitals and terminated longitudinal channels. The reception canopy has visible hangers reaching the overhead opaque enclosure. Low wing ceilings bear on full-height partitions. Lamps include ceiling mount, stem, housing and lens plus actual exported point lights. Refinement must inspect these joins at ordinary height; numerically touching parts alone do not prove convincing architecture.

Materials reuse original catalogue textures at metric scale: ivory enamel, muted walnut, warm stone, champagne metal and patterned teal/clay/oatmeal fabrics. Existing native fixture materials are retained and packed. The source previews show authored materials and lights; the game CRT pipeline is not duplicated or claimed by these renders.

## References and authority

The complete master chapters4,5,7,8,13,19,21,24,30,32,33 and current overrides were read in stage1. Architectural rules now require complete first-pass materials, furnishings, signs and effective light; the old map-first bare-platform interpretation is superseded.

Full original pixels inspected in stage1: public sports/service blueprint REF-1d51d4a06e (changing/service provision, grouped support near sports; printed D08 maps to canonical D07); REF-10dc8358ad (thick piers, deep supported thresholds, coherent ceiling/edge composition); REF-523733d277 (practical service built-ins, visible utilities and physically mounted local lighting). Image capacities, photoreal rendering, species speculation, atrium voids and hull windows are not imported. Parent audit AME-014 establishes the programme; exact child counts remain proposals. Current snapshot and source SHA256s are retained in current_allocation.json.

## Delivery and limits

The native source uses an explicitly named SOURCE_PREVIEW_ONLY collection for the floor, floor finish overlays and review cameras. It is excluded from GLB. The floor contact proposal requests a single parent-adopted floor at Y35.5; it creates no installed slab. Walls/fixtures provide collision proposals but capsule, broad-body and loaded-cart acceptance remains for the receiving engine. No geometry outside the approved footprint, operating doors, plumbing, medical treatment, species physiology, gameplay or current live integration is claimed.

Portable rebuild uses bundled dependencies and Blender4.3.2. Build receipt, fresh native reopen, actual GLB hierarchy/bounds comparison, packed-image check and actual source-eye renders are separate evidence. Parent must independently inspect rendered arrival, promenade, private changing, lockers, wash, care stock and ceiling mounts before any handoff-ready claim. Meaningful defects should be corrected in this package before Higgins integration.
