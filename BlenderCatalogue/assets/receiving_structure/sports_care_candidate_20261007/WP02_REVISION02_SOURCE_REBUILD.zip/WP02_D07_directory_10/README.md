# WP02 Sports care & changing — revision02

Root accepted this fitted source successor after inspecting all18 final views and independently checking the actual export. Frozen for packaging; not installed or live accepted. Original shipment is preserved; this successor corrects the fresh-review findings and records exact final evidence in docs/REVISION02_CORRECTION_RECEIPT.json.

The warm public promenade, private changing and locker gallery remain. The wet edge now has true screened WC/rinse entries, joined wash/dry furniture and supported useful amenities. Seating faces usable approaches. Staff stock sits on actual checked source supports. All18 final views come from the final saved native with unchanged geometry, materials, lights and exposure; view18 is an explicitly recorded camera-only supplement.

Source: source/WP02_sports_care.blend. Exchange: exports/WP02_sports_care.glb. Placement: Godot offset[8,35.5,460], identity rotation/unit scale. Native FONT remains editable; exchange lettering is mesh with UV. Textures/native approved dependencies are bundled. Preview floor is excluded from GLB. Higgins retains floor and external4m connection ownership.

Use Blender4.3.2, CPU12, --python-exit-code1, serialized by the coordinator. Build source/build_section.py; run source/verify_revision02.py with --stage native, then --stage glb; run qa/check_revision02_binary.py with Python. Final17-camera render command and supplemental18 source script are recorded in qa logs and render receipts. Do not rerun preparatory predecessor-copy scripts against an accepted package.

See docs/EXPERIENCE_BRIEF.md for design/application, docs/reference_library for the complete catalogue receipt and exact relevant originals, and runtime/interaction_candidates.json for two proposed fitted information targets. Final receipt separates demonstrated source fixes from receiving/runtime/hull and engineering holds. Historic docs/BRIEF.md programme is retained; its old phase status does not override this receipt.

Both fitted information targets also passed isolated actual-GLB import tests using the unchanged player ray and triangle occlusion, including read/close behavior. See runtime/isolated_verification.json and the portable runtime/adapter. This does not establish receiving installation, access control, input-event/HUD acceptance, capsule/cart movement or live appearance. Root-owned root_review.json and adapter files remain unchanged.
