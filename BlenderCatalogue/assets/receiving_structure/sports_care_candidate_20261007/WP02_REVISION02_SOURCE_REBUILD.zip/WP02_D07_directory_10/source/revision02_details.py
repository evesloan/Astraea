"""Executed in portable builder namespace; authored fitted details, no new programme."""
# Warm guest tiers are construction levels, not needless floor steps: seat plinth,
# storage ledge, shaped backing/wing, and lower canopy beneath the promenade vault.
for x0,x1 in ((10.4,18),(32.5,40.6)):
    poly('RestBayWeightedBacking',[(x0,465.60),(x1,465.60),(x1,465.03),(x1-.65,464.94),(x0+.65,464.94),(x0,465.03)],0,1.34,'warm_walnut')
    poly('RestBayStoneCoping',[(x0,465.6),(x1,465.6),(x1,465.00),(x1-.65,464.88),(x0+.65,464.88),(x0,465.00)],1.34,1.43,'warm_stone')
    for x in (x0,x1-.28):
        box('RestBayEndStandard',x,x+.28,465.02,465.60,1.43,3.40,'ivory_enamel',True,bevel=.10)
    poly('RestBayCanopy',[(x0,465.6),(x1,465.6),(x1,464.8),(x1-.6,464.30),(x0+.6,464.30),(x0,464.8)],3.30,3.48,'warm_walnut')
    for x in (x0+.45,x1-.45):
        box('RestBayAcousticBack',x,x+.25,465.0,465.59,1.43,3.30,'teal_weave',bevel=.055)
    lamp('RestBayLocal'+str(x0),(x0+x1)/2,465.02,3.30,power=80)

# Fore vault terminus: substantial fitted textile end destination and a deep
# faceted overhead return instead of an unassigned plain rectangular wall.
for x0,x1 in ((19.6,21.0),(27.0,28.4)):
    box('TerminusFoot',x0,x1,398.38,399.35,0,.32,'warm_stone',True,bevel=.12)
    poly('TerminusPier',[(x0,398.38),(x1,398.38),(x1,398.95),(x1-.25,399.25),(x0+.25,399.25),(x0,398.95)],.32,4.4,'ivory_enamel')
poly('TerminusCrown',[(19.6,398.38),(28.4,398.38),(28.4,399.1),(27.7,399.55),(20.3,399.55),(19.6,399.1)],4.1,4.48,'warm_walnut')
box('TerminusTextileCabinet',21.3,26.7,398.38,399.03,.12,2.25,'warm_walnut',True,bevel=.08)
for x0 in (21.42,24.1):
    box('TerminusInsetDoor',x0,x0+2.44,399.031,399.09,.28,2.09,'ivory_enamel',bevel=.06)
    box('TerminusDoorPull',x0+2.10,x0+2.16,399.09,399.18,.95,1.30,'champagne_metal',bevel=.025)
sign('TerminusIdentity','DRY TEXTILES',24,399.22,2.5,5.4)

# Wet block made as a fitted wash/service edge. All additions stay off the
# clear shared aisle; real returns, plinths and junctions attach to the host.
poly('WetEntrySplayedJamb',[(29.4,418.25),(29.7,418.25),(30.45,419.00),(30.45,419.5),(29.4,419.5)],0,3.60,'warm_stone')
box('WetEntryCrown',29.4,32.0,419.10,419.5,3.30,3.60,'warm_walnut')
box('WetBoundaryPlinth',29.30,29.72,398.4,418.25,0,.22,'warm_stone',True,bevel=.045)
box('WetBoundaryHead',29.30,29.78,398.4,418.25,3.30,3.6,'warm_walnut')
for z in (401.5,409.5,417.5):
    box('WashBayBackPanel',29.71,29.79,z-.90,z+.90,.20,2.75,'ivory_enamel',bevel=.045)
    for zz in (z-.91,z+.83):box('WashBaySideReturn',29.70,30.06,zz,zz+.08,.20,2.75,'champagne_metal',bevel=.022)
    box('WashBayTopReturn',29.70,30.06,z-.91,z+.91,2.70,2.80,'champagne_metal',bevel=.03)
    # Separate raised soap tray beside each existing supported basin.
    box('WashSupplyBracket',29.74,30.11,z+.68,z+.82,.55,.9,'champagne_metal')
    box('WashSupplyTray',29.79,30.25,z+.51,z+.85,.9,.96,'warm_stone',bevel=.035)
    box('WashSoapBody',29.90,30.10,z+.57,z+.77,.96,1.19,'ivory_enamel',bevel=.04)
    box('WashSoapPump',29.96,30.14,z+.63,z+.69,1.19,1.24,'champagne_metal',bevel=.022)

# One useful joined wash/dry work edge: continuous base, cabinet bridges and
# recessed towel stations between the three existing basins. No basin is covered.
box('JoinedWashPlinth',29.70,30.25,400.59,418.41,0,.20,'warm_stone',True,bevel=.045)
for i,(za,zb) in enumerate(((402.41,408.59),(410.41,416.59))):
    box('DryCounterCarcass'+str(i),29.71,30.10,za,zb,.20,.89,'warm_walnut',True,bevel=.025)
    box('JoinedDryCounter'+str(i),29.70,30.25,za,zb,.89,.97,'warm_stone',True,bevel=.035)
    for k in range(4):
        zz=za+(zb-za)*(k+.5)/4
        box('DryCabinetInset'+str((i,k)),30.105,30.14,zz-.68,zz+.68,.31,.80,'ivory_enamel',bevel=.025)
        box('DryCabinetPull'+str((i,k)),30.14,30.20,zz-.07,zz+.07,.56,.64,'champagne_metal',bevel=.018)
    zz=(za+zb)/2
    box('TowelNicheBack'+str(i),29.72,29.80,zz-1.05,zz+1.05,.97,2.30,'ivory_enamel',bevel=.018)
    for zedge in (zz-1.05,zz+1.0):box('TowelNicheEnd'+str((i,zedge)),29.80,30.18,zedge,zedge+.05,.97,2.30,'warm_walnut')
    for h in (1.05,1.62,2.23):box('TowelNicheShelf'+str((i,h)),29.80,30.18,zz-1.0,zz+1.0,h,h+.07,'warm_walnut')
    for dz in (-.5,.45):
        for k in range(3):box('WashDryCloths'+str((i,dz,k)),29.85,30.13,zz+dz-.29,zz+dz+.29,1.12+k*.05,1.17+k*.05,'oatmeal_weave',bevel=.018)
    lab=text('WashDryIdentity'+str(i),'CLEAN HAND TOWELS',30.192,zz,2.05,.105,face='east')

# Privacy-entry construction: joined reveals and occupancy identities. The
# screens themselves provide the sightline block; signage is not the repair.
for i,z in enumerate((400,408)):
    for zz in (z+5.5,z+7.05):box('WCEntryReveal'+str(i),33.60,34.12,zz,zz+.15,0,3.28,'warm_walnut',True,bevel=.035)
    box('WCEntryHeader'+str(i),33.60,34.12,z+5.5,z+7.2,3.15,3.48,'warm_walnut')
    label=text('WCIdentity'+str(i),f'WC {i+1:02d}',33.60,z+6.25,2.65,.21,role='dark');label.rotation_euler.z=-math.pi/2
    box('WCPrivacyToe'+str(i),35.76,36.12,z+3,z+7.2,0,.18,'warm_stone',True)
    # Existing tissue holder is moved from the distant side wall into the usable
    # fixture grouping. Source also gains a hygienic bin, closed brush holder and hook.
    box('WCTissueHostExtension'+str(i),36.18,36.70,z+2.80,z+3.02,0,1.10,'ivory_enamel',True)
    box('WCTissueBracket'+str(i),36.30,36.62,z+2.48,z+2.82,.76,.81,'champagne_metal')
    box('WCTissueBack'+str(i),36.25,36.65,z+2.76,z+2.81,.78,1.05,'champagne_metal')
    box('WCTissuePack'+str(i),36.31,36.60,z+2.49,z+2.76,.81,.96,'oatmeal_weave',bevel=.035)
    box('WCTissueFold'+str(i),36.38,36.53,z+2.52,z+2.64,.96,.985,'ivory_enamel',bevel=.009)
    ring=[(38.82+.19*math.cos(j*math.tau/12),z+2.12+.19*math.sin(j*math.tau/12)) for j in range(12)]
    poly('WCHygienicBin'+str(i),ring,0,.43,'ivory_enamel');poly('WCBinLid'+str(i),ring,.435,.48,'champagne_metal')
    box('WCBinHinge'+str(i),38.71,38.93,z+2.26,z+2.34,.41,.48,'champagne_metal')
    ring=[(39.21+.095*math.cos(j*math.tau/12),z+2.48+.095*math.sin(j*math.tau/12)) for j in range(12)]
    poly('WCClosedBrushHolder'+str(i),ring,0,.36,'ivory_enamel')
    beam('WCBrushHandle'+str(i),p(39.21,z+2.48,.34),p(39.21,z+2.48,.62),.035,.035)
    box('WCHookPlate'+str(i),39.62,39.73,z+.95,z+1.18,1.63,1.85,'champagne_metal')
    beam('WCHookArm'+str(i),p(39.63,z+1.07,1.72),p(39.43,z+1.07,1.72),.045,.045)
    beam('WCHookTip'+str(i),p(39.43,z+1.07,1.72),p(39.43,z+1.07,1.79),.045,.045)
for i,z in enumerate((400,406,412,418)):
    box('RinseReturnBase'+str(i),44.16,44.52,z+2.6,z+5.1,0,.18,'warm_stone',True)
    box('RinseProductBacking'+str(i),47.80,48.45,z+1.80,z+1.88,.86,1.66,'ivory_enamel')
    box('RinseProductShelf'+str(i),47.80,48.45,z+1.43,z+1.88,1.02,1.08,'champagne_metal',bevel=.025)
    for x in (47.89,48.28):box('RinseProductBracket'+str((i,x)),x,x+.06,z+1.48,z+1.86,.87,1.04,'champagne_metal')
    for j,x in enumerate((47.97,48.27)):
        box('RinseWashProduct'+str((i,j)),x-.09,x+.09,z+1.52,z+1.71,1.08,1.36,'ivory_enamel',bevel=.03)
        box('RinseWashPump'+str((i,j)),x-.025,x+.045,z+1.55,z+1.65,1.36,1.42,'champagne_metal',bevel=.012)
        text('RinseWashLabel'+str((i,j)),'WASH',x,z+1.509,1.19,.04,face='north')
    box('RinseDryNicheBack'+str(i),46.8,47.6,z+5.01,z+5.12,1.04,2.32,'ivory_enamel')
    for x in (46.80,47.54):box('RinseDryNicheEnd'+str((i,x)),x,x+.06,z+4.69,z+5.01,1.04,2.32,'warm_walnut')
    for h in (1.06,1.58,2.25):box('RinseDryShelf'+str((i,h)),46.86,47.54,z+4.69,z+5.01,h,h+.07,'warm_walnut')
    for k in range(3):box('RinseFoldedTowel'+str((i,k)),46.94,47.44,z+4.76,z+5.00,1.65+k*.05,1.70+k*.05,'oatmeal_weave',bevel=.016)
    text('RinseTowelIdentity'+str(i),'DRY TOWELS',47.2,z+4.678,2.03,.087,face='north')

# Cooler staff wall is a working edge with secured panels, task shelf, real
# folded pads and legible neutral supply identities, retaining clear counter.
for x in (43.1,44.2,45.3,46.4,47.5,48.6):
    box('ServiceLiningPanel',x-.50,x+.50,465.38,465.61,.22,3.3,'ivory_enamel',bevel=.018)
    for h in (.32,3.18):box('ServicePanelFastener',x-.38,x-.33,465.35,465.39,h,h+.05,'champagne_metal')
box('StaffKickProtection',42.0,49.66,465.29,465.62,0,.20,'dark',True)
for x in (44.6,47.3):
    box('StaffShelfBracket',x,x+.07,465.08,465.36,1.58,2.10,'champagne_metal')
box('StaffShallowStockShelf',44.5,47.5,464.98,465.36,2.04,2.12,'ivory_enamel')
for i,x in enumerate((44.75,45.35,45.95,46.55)):
    box('StaffPadCarton'+str(i),x,x+.40,465.00,465.30,2.12,2.46,'oatmeal_weave',bevel=.035)
    text('StaffPadIdentity'+str(i),'PADS',x+.20,464.987,2.26,.10,face='north')
for i,x in enumerate((46.28,46.60)):
    text('CareBottleIdentity'+str(i),'CARE',x,464.329,1.045,.043,face='north')

# Fitted, small interaction targets share the existing RMB / E / 2.5m contract.
box('SportsInfoStand',26.35,26.43,460.10,460.28,1.15,1.72,'champagne_metal')
box('SportsInfoPlaque',25.9,26.9,460.24,460.30,1.38,1.78,'ivory_enamel',bevel=.035)
text('SportsInfoTitle','SunCorp / SPORTS CARE',26.4,460.311,1.64,.075)
text('SportsInfoCopy','CHANGING / LOCKERS / RINSE',26.4,460.311,1.48,.064)
box('CareInfoStand',46.91,46.98,464.28,464.39,.94,1.78,'champagne_metal')
box('CareInfoPlaque',46.55,47.15,464.17,464.24,1.4,1.8,'ivory_enamel',bevel=.03)
text('CareInfoTitle','CARE STOCK',46.85,464.16,1.66,.085,face='north')
text('CareInfoCopy','CLOTHS / PADS',46.85,464.16,1.50,.068,face='north')
(ROOT/'runtime').mkdir(exist_ok=True)
candidates=[
 {'id':'WP02_info_reception_01','visual_node':'SportsInfoPlaque','action':'read_information','label':'Read sports care information','information':'Private changing rooms are along the dry promenade. Day lockers and rinse facilities are to the right.','focus_world_m':[26.4,37.08,460.32],'approach_feet_world_m':[26.4,35.5,462.1],'target_size_m':[.72,.28,.045],'access':'public','status':'proposed; source geometry and receiving access to verify'},
 {'id':'WP02_info_care_01','visual_node':'CareInfoPlaque','action':'read_information','label':'Read care stock information','information':'Clean cloths and pads are kept here. Used textiles have a separate return beside the staff threshold.','focus_world_m':[46.85,37.1,464.16],'approach_feet_world_m':[46.85,35.5,462.5],'target_size_m':[.45,.28,.045],'access':'staff','status':'proposed; source geometry and receiving access to verify'}]
(ROOT/'runtime/interaction_candidates.json').write_text(json.dumps({'schema':1,'status':'Isolated receiving proposal; no live controller or registry edits','coordinate_space':'Godot world metres after placement [8,35.5,460]','candidates':candidates},indent=2),encoding='utf-8')



