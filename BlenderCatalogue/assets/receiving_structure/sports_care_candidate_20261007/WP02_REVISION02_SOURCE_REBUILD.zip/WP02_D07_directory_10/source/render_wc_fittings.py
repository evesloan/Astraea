from pathlib import Path
import bpy,json,hashlib
from mathutils import Vector
R=Path(__file__).resolve().parents[1]
native=R/'source/WP02_sports_care.blend'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
pin=sha(native)
bpy.ops.wm.open_mainfile(filepath=str(native));s=bpy.context.scene
c=s.camera.copy();c.data=c.data.copy();s.collection.objects.link(c)
def p(x,z,h):return Vector((x-8,460-z,h))
c.location=p(36.7,400.8,1.65);c.rotation_euler=(p(38.25,401.95,1.15)-c.location).to_track_quat('-Z','Y').to_euler();c.data.lens=23;s.camera=c
s.render.threads_mode='FIXED';s.render.threads=12;s.render.filepath=str(R/'renders/18_wc_fittings_source_only.png');bpy.ops.render.render(write_still=True)
assert sha(native)==pin
(R/'qa/revision02_render_wc_fittings.json').write_text(json.dumps({'scope':'Camera-only supplement of unchanged final native, no save, geometry/light/material/world/exposure changes','native_sha256':pin,'image_sha256':sha(Path(s.render.filepath)),'camera_blender':list(c.location),'rotation':list(c.rotation_euler),'lens':23,'eye_height_m':1.65,'exposure':s.view_settings.exposure,'samples':s.cycles.samples},indent=2))

