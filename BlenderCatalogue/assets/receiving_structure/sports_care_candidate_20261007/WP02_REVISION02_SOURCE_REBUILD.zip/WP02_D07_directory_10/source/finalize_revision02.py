"""Write final revision02 receipts only after final native QA and all18 views pass."""
from pathlib import Path
import json,hashlib,datetime
P=Path(__file__).resolve().parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
native=P/'source/WP02_sports_care.blend';glb=P/'exports/WP02_sports_care.glb';pins={'native':sha(native),'glb':sha(glb)}
checks={}
for name in ['revision02_native.json','revision02_glb_import.json','revision02_cart_routes.json','revision02_privacy_width.json','revision02_stock_support.json','revision02_binary_export.json']:
 p=P/'qa'/name;r=json.loads(p.read_text());assert r.get('passed',r.get('pass')) is True,name
 if 'pins'in r:assert r['pins']==pins,(name,r['pins'],pins)
 if name=='revision02_binary_export.json':assert r['sha256']==pins['glb']
 checks[name]=sha(p)
r=json.loads((P/'qa/revision02_render_11_wc_privacy_shared_aisle.json').read_text());assert r['pins']==pins and len(r['views'])==17
views=[]
for v in r['views']:
 p=P/v['path'];assert sha(p)==v['sha256'];views.append(v)
r=json.loads((P/'qa/revision02_render_wc_fittings.json').read_text());assert r['native_sha256']==pins['native'];p=P/'renders/18_wc_fittings_source_only.png';assert sha(p)==r['image_sha256'];views.append({'path':str(p.relative_to(P)),'sha256':sha(p),'camera_blender':r['camera_blender'],'camera_rotation':r['rotation'],'lens_mm':r['lens']})
findings=[{'id':'WP02-F01','disposition':'Source correction implemented; independent root review pending','change':'Joined wash/dry counter with inset storage and usable supported towel niches, deep threshold returns/base/crown, and shaped fitted promenade terminus. Plain privacy-screen fields remain functional opaque screening.','evidence':['renders/03_changing_spine_source_only.png','renders/06_wash_threshold_source_only.png','renders/14_wash_fitted_edge_source_only.png','renders/17_joined_wash_detail_source_only.png','qa/revision02_native.json']},{'id':'WP02-F03','disposition':'Source correction implemented; independent root review pending','change':'Both WC compartments and repeated rinse entries have true doglegs, supported privacy returns and open routes. Both shared-aisle sampling sets report no exposed use-zone target. Tissue fixture previously on far wall was relocated into the reachable fixture grouping, not claimed as a prior omission. Added bin/brush/hook and wash/towel amenities.','evidence':['renders/11_wc_privacy_shared_aisle_source_only.png','renders/12_wc_interior_source_only.png','renders/13_rinse_interior_source_only.png','renders/16_rinse_dry_amenities_source_only.png','renders/18_wc_fittings_source_only.png','qa/revision02_native.json','qa/revision02_privacy_width.json','qa/revision02_cart_routes.json']},{'id':'WP02-F04','disposition':'Source correction implemented; independent root review pending','change':'Guest-facing private locker identities changed from literal authoring placeholders to numbered paired identities; all native editable text resolves to exported mesh with UV.','evidence':['renders/04_private_changing_source_only.png','renders/10_locker_working_face_source_only.png','qa/revision02_native.json']}]
limits=['Not installed or live accepted; source geometry gates are bounded samples, not species fit, body poses, operating amenities or runtime collision proof.','Higgins owns source-preview floor/slab reconciliation and external4m link.','Hull screen is21.918m inboard: sweeping starboard observation opportunity remains held for actual connected frontage/service/hull reconciliation; no internal-edge fake window or upper cut.','Two actual visible information targets are proposed; receiving interaction/runtime/light/performance and acoustic/engineering acceptance remain separate.','Original shipments and rejected revision attempts preserved.']
receipt={'package':'WP02_D07_directory_10','revision':'02','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'source candidate ready for independent root review','root_accepted':False,'live_accepted':False,'pins':pins,'checks':checks,'findings':findings,'final_views':views,'visual_review':'Owner inspected final actual ordinary-eye images; bounded local construction correction, not whole-ship acceptance.','reference_study_sha256':sha(P/'docs/reference_library/REFERENCE_STUDY.json'),'receiving_limits':limits,'prior_failures':'qa/revision02_attempt01, attempt02 and attempt03; prior logs retained','source_join_correction':'Towel shelf and upright spans meet at inner faces; backing/side fields abut; tissue host abuts retained WC backing. Actual final stock contact checks remain unweakened.'}
(P/'docs/REVISION02_CORRECTION_RECEIPT.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
(P/'README.md').write_text('''# WP02 Sports care & changing — revision02

Fitted isolated source candidate ready for independent root review. Not installed or live accepted. Original shipment is preserved; this successor corrects the fresh-review findings and records exact final evidence in docs/REVISION02_CORRECTION_RECEIPT.json.

The warm public promenade, private changing and locker gallery remain. The wet edge now has true screened WC/rinse entries, joined wash/dry furniture and supported useful amenities. Seating faces usable approaches. Staff stock sits on actual checked source supports. All18 final views come from the final saved native with unchanged geometry, materials, lights and exposure; view18 is an explicitly recorded camera-only supplement.

Source: source/WP02_sports_care.blend. Exchange: exports/WP02_sports_care.glb. Placement: Godot offset[8,35.5,460], identity rotation/unit scale. Native FONT remains editable; exchange lettering is mesh with UV. Textures/native approved dependencies are bundled. Preview floor is excluded from GLB. Higgins retains floor and external4m connection ownership.

Use Blender4.3.2, CPU12, --python-exit-code1, serialized by the coordinator. Build source/build_section.py; run source/verify_revision02.py with --stage native, then --stage glb; run qa/check_revision02_binary.py with Python. Final17-camera render command and supplemental18 source script are recorded in qa logs and render receipts. Do not rerun preparatory predecessor-copy scripts against an accepted package.

See docs/EXPERIENCE_BRIEF.md for design/application, docs/reference_library for the complete catalogue receipt and exact relevant originals, and runtime/interaction_candidates.json for two proposed fitted information targets. Final receipt separates demonstrated source fixes from receiving/runtime/hull and engineering holds. Historic docs/BRIEF.md programme is retained; its old phase status does not override this receipt.
''',encoding='utf-8')
print('WP02_REVISION02_FINAL_RECEIPT_READY',pins)
