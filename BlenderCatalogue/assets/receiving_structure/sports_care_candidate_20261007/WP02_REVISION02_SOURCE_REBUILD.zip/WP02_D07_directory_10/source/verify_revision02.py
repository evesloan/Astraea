"""Fresh native/actual GLB review; explicit source-only limits, never saves native."""
from pathlib import Path
import bpy,json,hashlib,sys,argparse,math,struct
from mathutils import Vector
from mathutils.bvhtree import BVHTree
R=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--stage',choices=['native','glb','render'],required=True);ap.add_argument('--views',default='');args=ap.parse_args(sys.argv[sys.argv.index('--')+1:])
native=R/'source/WP02_sports_care.blend';glb=R/'exports/WP02_sports_care.glb'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
pins={'native':sha(native),'glb':sha(glb)}
def p(x,z,h):return Vector((x-8,460-z,h))
def bounds(v):return [[min(q[i] for q in v) for i in range(3)],[max(q[i] for q in v) for i in range(3)]]
def dump(name,data):(R/'qa'/name).write_text(json.dumps(data,indent=2),encoding='utf-8')
if args.stage=='glb':
 bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(glb));bpy.context.view_layer.update()
 verts=[]
 for o in bpy.context.scene.objects:
  if o.type=='MESH':verts += [tuple(o.matrix_world@v.co) for v in o.data.vertices]
 # Imported GLB is Blender axes; compare native exact evaluated bounds.
 b=bounds(verts);prev=json.loads((R/'qa/revision02_native.json').read_text());delta=max(abs(b[j][i]-prev['native_blender_bounds'][j][i]) for j in (0,1) for i in range(3))
 rec={'scope':'Factory-empty actual GLB import; source-only','pins':pins,'imported_meshes':len([o for o in bpy.context.scene.objects if o.type=='MESH']),'blender_bounds':b,'native_bound_delta_m':delta,'passed':delta<.003,'no_runtime_acceptance':True};dump('revision02_glb_import.json',rec);assert rec['passed'],rec;print('WP02_R02_ACTUAL_GLB_PASS');raise SystemExit
bpy.ops.wm.open_mainfile(filepath=str(native));sc=bpy.context.scene;bpy.context.view_layer.update();dg=bpy.context.evaluated_depsgraph_get();objects=list(bpy.data.collections['WP02_ARCHITECTURE'].objects)
if args.stage=='render':
 rec={'pins':pins,'scope':'Final-native ordinary-eye source-only; unchanged geometry/material/world/exposure/samples','views':[],'exposure':sc.view_settings.exposure,'samples':sc.cycles.samples}
 for name in args.views.split(','):
  o=bpy.data.objects['REVIEW_'+name];sc.camera=o;sc.render.threads_mode='FIXED';sc.render.threads=12;sc.render.image_settings.file_format='PNG';dest=R/'renders'/f'{name}_source_only.png';sc.render.filepath=str(dest);bpy.ops.render.render(write_still=True)
  rec['views'].append({'path':str(dest.relative_to(R)),'sha256':sha(dest),'camera_blender':list(o.location),'camera_rotation':list(o.rotation_euler),'lens_mm':o.data.lens});dump('revision02_render_'+args.views.split(',')[0]+'.json',rec)
 assert sha(native)==pins['native'];print('WP02_R02_RENDER_PASS');raise SystemExit
verts=[];faces=[];face_names=[];wallverts=[];wallfaces=[]
for o in objects:
 if o.type not in {'MESH','CURVE','FONT'}:continue
 e=o.evaluated_get(dg);me=e.to_mesh();vs=[tuple(e.matrix_world@v.co) for v in me.vertices];off=len(verts);verts+=vs
 faces += [tuple(off+i for i in f.vertices) for f in me.polygons];face_names += [o.name]*len(me.polygons)
 if o.name.startswith(('WCCell','WCOuterPrivacy','WCInnerPrivacy','WCEastEnclosure','RinseRear','RinseFront','RinsePrivacy','RinseInnerReturn','WetPrivacyWall','ServiceScreen')):
  off=len(wallverts);wallverts+=vs;wallfaces += [tuple(off+i for i in f.vertices) for f in me.polygons]
 e.to_mesh_clear()
tree=BVHTree.FromPolygons(verts,faces,all_triangles=False);privacy=BVHTree.FromPolygons(wallverts,wallfaces,all_triangles=False)
errors=[];bb=bounds(verts)
if not(bb[0][0]>=-.003 and bb[1][0]<=46.003 and bb[0][1]>=-6.003 and bb[1][1]<=62.003 and bb[0][2]>=-.003 and bb[1][2]<=7.803):errors.append({'containment':bb})
exposed=[];rays=0
for kind,zs,xs,viewer_x,targetx in [('WC',(400,408),(37.1,37.9),32.6,37.5),('rinse',(400,406,412,418),(47.3,47.9),41.0,47.6)]:
 for z in zs:
  for vz in [398.8+k*.5 for k in range(52)]:
   for vh in (1.2,1.65):
    for tx in xs:
     for tz in ((z+1.4,z+2.7) if kind=='WC' else (z+.9,z+1.5)):
      for th in (.8,1.7):
       a=p(viewer_x,vz,vh);b=p(tx,tz,th);d=b-a;rays+=1;hit=privacy.ray_cast(a,d.normalized(),d.length-.02)[0]
       if hit is None:exposed.append({'kind':kind,'cell_z':z,'viewer':[viewer_x,vz,vh],'target':[tx,tz,th]})
if exposed:errors.append({'privacy_exposed':len(exposed),'examples':exposed[:12]})
# Test additional lateral positions across each shared aisle, rather than one line.
wide_exposed=[];wide_rays=0
for kind,zs,xpositions,targetx in [('WC',(400,408),(30.7,31.7,33.15),37.5),('rinse',(400,406,412,418),(40.6,41.6),47.6)]:
 for z in zs:
  for vx in xpositions:
   for vz in [398.8+k*.5 for k in range(52)]:
    for vh in (1.2,1.65):
     for th in (.8,1.7):
      a=p(vx,vz,vh);b=p(targetx,z+(2.1 if kind=='WC' else 1.2),th);d=b-a;wide_rays+=1
      if privacy.ray_cast(a,d.normalized(),d.length-.02)[0] is None:wide_exposed.append({'kind':kind,'cell_z':z,'viewer':[vx,vz,vh],'target':list(b)})
dump('revision02_privacy_width.json',{'pins':pins,'scope':'Additional sampled lateral shared-aisle positions; structural screens only','rays':wide_rays,'exposed':wide_exposed,'passed':not wide_exposed})
if wide_exposed:errors.append({'lateral_privacy_exposed':len(wide_exposed),'examples':wide_exposed[:12]})
# Derive every item's actual evaluated bottom, then ray against actual support
# geometry with that item excluded. This includes every inter-cloth stack contact.
stock_prefixes=('WCTissuePack','RinseWashProduct','RinseFoldedTowel','WashDryCloths','StaffPadCarton','CareSupplyBottle','CleanFoldedCloth')
support_prefixes=('WCTissueBracket','RinseProductShelf','RinseDryShelf','TowelNicheShelf','RinseFoldedTowel','WashDryCloths','StaffShallowStockShelf','CleaningCupboard','CleanFoldedCloth')

def support_identity(actual,expected):
 return actual is not None and all(part in actual for part in expected)
def intended_support(name):
 import ast
 if name.startswith('WCTissuePack'):return ('WCTissueBracket'+name.removeprefix('WCTissuePack'),)
 if name.startswith('RinseWashProduct'):i,j=ast.literal_eval(name.removeprefix('RinseWashProduct'));return ('RinseProductShelf'+str(i),)
 if name.startswith('RinseFoldedTowel'):
  i,k=ast.literal_eval(name.removeprefix('RinseFoldedTowel'));return ('RinseDryShelf'+str((i,1.58)),) if k==0 else ('RinseFoldedTowel'+str((i,k-1)),)
 if name.startswith('WashDryCloths'):
  i,z,k=ast.literal_eval(name.removeprefix('WashDryCloths'));return ('TowelNicheShelf'+str((i,1.05)),) if k==0 else ('WashDryCloths'+str((i,z,k-1)),)
 if name.startswith('StaffPadCarton'):return ('StaffShallowStockShelf',)
 if name.startswith('CareSupplyBottle'):return ('CleaningCupboard','COUNTER_continuous_rolled_nose')
 if name.startswith('CleanFoldedCloth'):
  k=int(name.rsplit('_',1)[1]);return ('CleaningCupboard','COUNTER_continuous_rolled_nose') if k==0 else ('CleanFoldedCloth_'+str(k-1),)
 raise AssertionError(('unmapped stock',name))
support_results=[]
for o in objects:
 if o.type!='MESH' or not o.name.startswith(stock_prefixes):continue
 ev=o.evaluated_get(dg);me=ev.to_mesh();pts=[ev.matrix_world@q.co for q in me.vertices];bbstock=bounds(pts);ev.to_mesh_clear()
 center=Vector(((bbstock[0][0]+bbstock[1][0])/2,(bbstock[0][1]+bbstock[1][1])/2,bbstock[0][2]+.02))
 selected=[(f,n) for f,n in zip(faces,face_names) if n!=o.name and n.startswith(support_prefixes)]
 st=BVHTree.FromPolygons(verts,[f for f,n in selected]);hit,n,index,d=st.ray_cast(center,Vector((0,0,-1)),.04)
 actual=selected[index][1] if hit is not None else None;bottom=bbstock[0][2]
 expected=intended_support(o.name);passed=hit is not None and abs(hit.z-bottom)<.001 and support_identity(actual,expected)
 support_results.append({'name':o.name,'actual_evaluated_bounds':bbstock,'first_support':actual,'expected_support_identity':expected,'actual_support_height':hit.z if hit is not None else None,'actual_stock_bottom':bottom,'passed':passed})
dump('revision02_stock_support.json',{'pins':pins,'scope':'Actual evaluated item bottoms and support surface contacts, including stacked cloths; item excluded from its own support ray; no engineering certification','results':support_results,'passed':all(x['passed'] for x in support_results)})
if not all(x['passed'] for x in support_results):errors.append({'unsupported_stock':[x for x in support_results if not x['passed']]})
# Swept source body screens at bounded sample spacing. Runtime/body/species still separate.
routes={
 'guest_spine':[(9.1,460),(20,460),(23,452),(24,447),(24,403)],
 'wet_shared':[(24,423),(28,423),(28,426),(33.5,426),(34.2,420),(32.6,419),(32.6,400)],
 'wc_01':[(32.6,406.3),(34.85,406.3),(34.85,401.0),(37.5,400.65)],
 'wc_02':[(32.6,414.3),(34.85,414.3),(34.85,409.0),(37.5,408.65)],
 'care_approach':[(39,459),(44,459),(46.85,462.5)]}
# Continue the actual public approach through every rinse dogleg and open
# shower side; route follows the true glazing and mount-wall geometry.
routes['rinse_shared']=[(33.5,426),(41,426),(41,424),(41,400)]
for i,z in enumerate((400,406,412,418)):
 routes['rinse_%d_shower'%(i+1)]=[(41,z+4.4),(43.35,z+4.4),(43.35,z+1.6),(45.5,z+1.6),(45.5,z+2.5),(49.05,z+2.5),(49.05,z+.95),(47.65,z+.95)]
 routes['rinse_%d_dry_towels'%(i+1)]=[(45.5,z+2.5),(47.2,z+2.8),(47.2,z+4.15)]
route_hits=[];samples=0
for name,path in routes.items():
 radius=.30
 for a,b in zip(path,path[1:]):
  count=max(2,math.ceil(math.dist(a,b)/.20))
  for k in range(count+1):
   x=a[0]+(b[0]-a[0])*k/count;z=a[1]+(b[1]-a[1])*k/count;samples+=1
   for h in (.25,.8,1.4,1.75):
    for ang in range(8):
     direction=Vector((math.cos(ang*math.tau/8),math.sin(ang*math.tau/8),0));hit,normal,index,dist=tree.ray_cast(p(x,z,h),direction,radius)
     if hit is not None:route_hits.append({'route':name,'point':[x,z,h],'radius':radius,'object':face_names[index]})
# Wider cart source envelope on the public spine and actual staff supply approach.
# Small private fixture spaces retain explicit .30m body scope, not cart certification.
cart_routes={name:routes[name] for name in ['guest_spine','care_approach']}
cart_samples=0;cart_hits=[]
for name,path in cart_routes.items():
 for a,b in zip(path,path[1:]):
  count=max(2,math.ceil(math.dist(a,b)/.20))
  for k in range(count+1):
   x=a[0]+(b[0]-a[0])*k/count;z=a[1]+(b[1]-a[1])*k/count;cart_samples+=1
   for h in (.25,.8,1.4,1.75):
    for ang in range(16):
     direction=Vector((math.cos(ang*math.tau/16),math.sin(ang*math.tau/16),0));hit,normal,index,dist=tree.ray_cast(p(x,z,h),direction,.65)
     if hit is not None:cart_hits.append({'route':name,'point':[x,z,h],'radius':.65,'object':face_names[index]})
dump('revision02_cart_routes.json',{'pins':pins,'radius_m':.65,'scope':'Source public spine and staff stock approach envelope; not runtime cart proof','routes':cart_routes,'samples':cart_samples,'hits':cart_hits,'passed':not cart_hits})
if cart_hits:errors.append({'cart_hits':len(cart_hits),'examples':cart_hits[:12]})
if route_hits:errors.append({'route_body_hits':len(route_hits),'examples':route_hits[:15]})
camera_hits=[]
for o in sc.objects:
 if o.type=='CAMERA' and o.name.startswith('REVIEW_'):
  for axis in [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]:
   hit,n,index,d=tree.ray_cast(o.location,Vector(axis),.15)
   if hit is not None:camera_hits.append({'camera':o.name,'object':face_names[index]})
if camera_hits:errors.append({'camera_proximity':camera_hits})
interaction=[]
for c in json.loads((R/'runtime/interaction_candidates.json').read_text())['candidates']:
 fx,fy,fz=c['focus_world_m'];ax,ay,az=c['approach_feet_world_m'];a=p(ax,az,ay-35.5+1.65);b=p(fx,fz,fy-35.5);d=b-a;hit,n,index,dist=tree.ray_cast(a,d.normalized(),d.length+.08);name=face_names[index] if hit is not None else None
 valid=d.length<=2.5 and name is not None and (name.startswith('SportsInfo') if 'reception' in c['id'] else name.startswith('CareInfo'))
 interaction.append({'id':c['id'],'distance_m':d.length,'first_hit':name,'passed':valid})
 if not valid:errors.append({'interaction':interaction[-1]})
raw=glb.read_bytes();length,typ=struct.unpack_from('<II',raw,12);doc=json.loads(raw[20:20+length]);meshprims=[p for m in doc['meshes'] for p in m['primitives']];names={n.get('name') for n in doc['nodes']};fonts=[o for o in objects if o.type=='FONT'];missingtext=[o.name for o in fonts if o.name not in names];badlabels=[o.name for o in fonts if 'lockerA' in o.data.body or 'lockerB' in o.data.body]
uvmissing=sum('TEXCOORD_0' not in pr['attributes'] for pr in meshprims);external=[im for im in doc.get('images',[]) if 'uri'in im];unpacked=[im.name for im in bpy.data.images if im.source=='FILE' and not im.packed_file]
if missingtext or badlabels or uvmissing or external or unpacked:errors.append({'missing_exported_text':missingtext,'authoring_labels':badlabels,'missing_UV':uvmissing,'external_images':external,'unpacked':unpacked})
rec={'scope':'Fresh native actual evaluated mesh containment, structural privacy rays, bounded source route samples and candidate sightlines; not runtime traversal, body poses or physical hull certification','pins':pins,'native_blender_bounds':bb,'privacy_rays':rays,'exposed':exposed,'body_radius_m':.30,'route_samples':samples,'routes':routes,'route_hits':route_hits,'camera_hits':camera_hits,'interaction_checks':interaction,'editable_native_text_objects':len(fonts),'exported_text_missing':missingtext,'glb_primitives':len(meshprims),'missing_uv_primitives':uvmissing,'external_image_uris':len(external),'unpacked_native_images':unpacked,'errors':errors,'passed':not errors};dump('revision02_native.json',rec);print(json.dumps({'stage':'native','passed':not errors,'errors':errors},indent=2),flush=True);assert not errors,'Revision02 source gates failed; preserve evidence and correct actual cause'
