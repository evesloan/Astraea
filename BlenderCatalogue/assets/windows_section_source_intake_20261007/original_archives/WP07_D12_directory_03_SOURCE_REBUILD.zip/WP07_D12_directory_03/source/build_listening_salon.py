"""WP07 original, deterministic source architecture. Blender 4.3.2.
Run --background --python this_file; optional -- --render arrival/activity/care/quiet/section.
Source preview floor excluded from GLB. Actual engine adoption remains unverified.
"""
import bpy, math, json, hashlib, sys
from pathlib import Path
from mathutils import Vector, Matrix
P=Path(__file__).resolve().parents[1]
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
for c in list(bpy.data.collections):
    if c.name!='Collection' and c.users==0: bpy.data.collections.remove(c)
scene=bpy.context.scene
scene.unit_settings.system='METRIC'; scene.unit_settings.scale_length=1
scene.render.engine='CYCLES'; scene.cycles.samples=20; scene.cycles.use_denoising=True
scene.render.resolution_x=1280; scene.render.resolution_y=800; scene.render.resolution_percentage=100
scene.world.use_nodes=True; scene.world.node_tree.nodes['Background'].inputs[0].default_value=(0.11,0.14,0.18,1)
scene.world.node_tree.nodes['Background'].inputs[1].default_value=0.10
scene.view_settings.view_transform='AgX'
scene.view_settings.exposure=.8
materials={}; manifest=json.loads((P/'dependencies/materials/material_manifest.json').read_text())
for role,r in manifest['materials'].items():
    m=bpy.data.materials.new('WP07_'+role); m.use_nodes=True
    m['astraea_material_role']=role; m['meters_per_tile_uv']=r['meters_per_tile_uv']
    bs=m.node_tree.nodes.get('Principled BSDF'); bs.inputs['Roughness'].default_value=r['roughness']; bs.inputs['Metallic'].default_value=r['metallic']
    im=bpy.data.images.load(str(P/'dependencies/materials'/r['base_color_file']),check_existing=True); im.pack()
    t=m.node_tree.nodes.new('ShaderNodeTexImage'); t.image=im; t.interpolation='Closest'
    m.node_tree.links.new(t.outputs['Color'],bs.inputs['Base Color']); materials[role]=m
def emissive(name,color,strength):
    m=bpy.data.materials.new(name); m.use_nodes=True
    b=m.node_tree.nodes.get('Principled BSDF'); b.inputs['Base Color'].default_value=(*color,1); b.inputs['Emission Color'].default_value=(*color,1); b.inputs['Emission Strength'].default_value=strength
    return m
materials['lamp']=emissive('WP07_warm_opal',(1,.72,.34),2)
materials['indicator']=emissive('WP07_equipment_indicator',(.22,.7,.65),.5)
records=[]; lights=[]; markers=[]; seats=[]; tables=[]
def finish(o,name,role,bevel=0):
    o.name='WP07_'+name; o['package_id']='WP07_D12_directory_03'; o['programme']='D12_directory_03'; o['semantic_role']=role
    o.data.materials.append(materials[role])
    if o.type=='MESH':
        # Dominant-normal planar UV, physical metres per texture repeat.
        uv=o.data.uv_layers.new(name='PhysicalScaleUV') if not o.data.uv_layers else o.data.uv_layers.active
        mt=manifest['materials'].get(role,{}).get('meters_per_tile_uv',[1,1])
        for poly in o.data.polygons:
            normal=poly.normal; ax=max(range(3),key=lambda j:abs(normal[j])); ij=[j for j in range(3) if j!=ax]
            for li in poly.loop_indices:
                v=o.data.vertices[o.data.loops[li].vertex_index].co
                uv.data[li].uv=(v[ij[0]]/mt[0],v[ij[1]]/mt[1])
        if bevel:
            mod=o.modifiers.new('Editable softened join','BEVEL'); mod.width=bevel; mod.segments=2
            o.modifiers.new('Weighted corner normals','WEIGHTED_NORMAL')
    return o
def box(name,loc,size,role,bevel=.025):
    bpy.ops.mesh.primitive_cube_add(size=1,location=loc); o=bpy.context.object
    o.dimensions=size; bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    return finish(o,name,role,bevel)
def cyl(name,loc,r,depth,role,verts=24):
    bpy.ops.mesh.primitive_cylinder_add(vertices=verts,radius=r,depth=depth,location=loc)
    return finish(bpy.context.object,name,role,.018)
def mesh(name,verts,faces,role,bevel=0):
    me=bpy.data.meshes.new(name); me.from_pydata(verts,[],faces); me.update()
    o=bpy.data.objects.new(name,me); scene.collection.objects.link(o); return finish(o,name,role,bevel)
def marker(name,loc,kind,**data):
    o=bpy.data.objects.new('WP07_MARK_'+name,None); scene.collection.objects.link(o); o.location=loc; o.empty_display_size=.14
    o['marker_kind']=kind; o['package_id']='WP07_D12_directory_03'
    markers.append({'id':o.name,'kind':kind,'blender_source':list(loc),'local_gltf':[loc[0],loc[2],-loc[1]],**data})
    return o
def arc(name,cx,cy,r0,r1,a0,a1,z0,z1,role,n=24):
    vs=[]
    for z in [z0,z1]:
        for r in [r0,r1]:
            for j in range(n+1):
                a=math.radians(a0+(a1-a0)*j/n); vs.append((cx+r*math.cos(a),cy+r*math.sin(a),z))
    k=n+1; fs=[]
    for j in range(n): fs.extend([(j,j+1,k+j+1,k+j),(2*k+j,3*k+j,3*k+j+1,2*k+j+1),(j,2*k+j,2*k+j+1,j+1),(k+j,k+j+1,3*k+j+1,3*k+j)])
    fs.extend([(0,k,3*k,2*k),(n,2*k+n,3*k+n,k+n)])
    return mesh(name,vs,fs,role,.025)
def light(name,loc,power,size=1,target=None):
    d=bpy.data.lights.new('WP07_'+name,'SPOT'); d.energy=power; d.color=(1,.85,.66); d.shadow_soft_size=size*.4; d.spot_size=math.radians(145); d.spot_blend=.8
    o=bpy.data.objects.new('WP07_'+name,d); scene.collection.objects.link(o); o.location=loc
    if target is not None: o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
    lights.append({'id':o.name,'source_frame':list(loc),'watts':power,'fixture_visible':True})
    return o
def pendant(name,x,y,ceiling,bottom=3.55,power=180):
    cyl(name+'_ceiling_socket',(x,y,ceiling-.07),.19,.14,'champagne_metal')
    cyl(name+'_stem',(x,y,(ceiling+bottom)/2),.038,ceiling-bottom,'champagne_metal',12)
    cyl(name+'_shade',(x,y,bottom+.1),.43,.23,'champagne_metal')
    cyl(name+'_opal',(x,y,bottom-.025),.37,.04,'lamp')
    light(name+'_source',(x,y,bottom-.065),power*5,1.1)
    # A second physical opal aperture lights the supported vault above.
    cyl(name+'_upper_opal',(x,y,bottom+.235),.37,.025,'lamp')
    light(name+'_upper_source',(x+.10,y,bottom+.27),power*2,1.0,(x+.10,y,ceiling))
    marker(name+'_mount',(x,y,ceiling),'fixture_mount')
def text(name,body,loc,size=.24,rotation=(math.pi/2,0,0),role='champagne_metal'):
    cu=bpy.data.curves.new(name,'FONT'); cu.body=body; cu.size=size; cu.align_x='CENTER'; cu.extrude=.003
    o=bpy.data.objects.new('WP07_'+name,cu); scene.collection.objects.link(o); o.location=loc; o.rotation_euler=rotation; o.data.materials.append(materials[role]); o['package_id']='WP07_D12_directory_03'
    return o

# Preview backing slab and finish. Both are expressly excluded from delivery architecture.
floor=box('SOURCE_PREVIEW_ONLY_floor',(0,0,-.13),(46,68,.24),'warm_stone',0); floor['SOURCE_PREVIEW_ONLY']=True
for x,w in [(-5.5,25),(9.5,5)]:
    o=box('SOURCE_PREVIEW_ONLY_floor_inlay',(x,0,-.008),(w,65,.016),'teal_weave' if x<0 else 'warm_walnut',0); o['SOURCE_PREVIEW_ONLY']=True
# Opaque shared envelope; no borrowed neighbour volumes or windows.
box('west_acoustic_wall',(-22.72,0,2.8),(.56,68,5.6),'ivory_enamel')
box('north_wall',(0,33.72,2.8),(45.45,.56,5.6),'ivory_enamel')
box('south_wall',(0,-33.72,2.8),(45.45,.56,5.6),'ivory_enamel')
for y in [-18,18]: box('east_wall',(22.72,y,2.8),(.56,32,5.6),'ivory_enamel')
box('portal_head',(22.72,0,4.5),(.56,4,2.2),'ivory_enamel')
box('opaque_ceiling_cap',(0,0,5.625),(45.45,67.45,.25),'ivory_enamel')
# Deep public portal, clear +/-2m in source Y.
for y in [-2.27,2.27]:
    box('portal_solid_reveal',(21.65,y,1.75),(2.1,.54,3.5),'warm_walnut',.09)
    box('portal_inlay',(20.57,y,1.75),(.055,.28,3.1),'champagne_metal',.015)
box('portal_lintel',(21.65,0,3.68),(2.1,5.1,.36),'warm_walnut',.09)
marker('public_portal',(23,0,0),'opening',width=4,height=3.4)
# Offset acoustic screen stops direct entry sound/view without blocking the floor route.
box('vestibule_acoustic_screen',(15.8,1.0,1.45),(.5,5.6,2.9),'warm_walnut',.09)
box('vestibule_fabric_liner',(15.51,1,1.52),(.07,5.1,2.48),'teal_weave',.025)
box('vestibule_supported_soffit',(19,0,3.43),(7.0,13,.36),'ivory_enamel',.09)
for y in [-6.2,6.2]:
    box('vestibule_end_bearing',(18,y,1.65),(.38,.4,3.3),'warm_walnut')
    box('vestibule_soffit_fascia',(18.9,y,3.34),(7.1,.25,.35),'warm_walnut')
text('arrival_identity','LISTENING SALON',(21.1,-2.58,2.75),.25,rotation=(math.pi/2,0,0))
text('arrival_quiet','D12  /  QUIET CONVERSATION',(15.49,1,2.4),.15,rotation=(math.pi/2,0,-math.pi/2))
pendant('vestibule_1',19,-2.7,3.25,2.9,130); pendant('vestibule_2',19,2.7,3.25,2.9,130)

# Three vaulted listening bays. Panels, fascia, capitals, and bearings resolve all joints.
def vault(name,cx,cy):
    n=24; vs=[]
    for dz in [0,.24]:
        for y in [cy-7,cy+7]:
            for j in range(n+1):
                x=-12+j; z=4.6+.62*(1-(x/12)**2)+dz; vs.append((cx+x,y,z))
    k=n+1; fs=[]
    for j in range(n): fs.extend([(j,j+1,k+j+1,k+j),(2*k+j,3*k+j,3*k+j+1,2*k+j+1),(j,2*k+j,2*k+j+1,j+1),(k+j,k+j+1,3*k+j+1,3*k+j)])
    fs.extend([(0,k,3*k,2*k),(n,2*k+n,3*k+n,k+n)])
    mesh(name+'_acoustic_vault',vs,fs,'warm_walnut')
    for y in [cy-7,cy+7]:
        # Full-depth profiled edge: actual fascia, not a floating ornamental strip.
        vs2=[]
        for dy in [-.14,.14]:
            for dz in [-.24,.26]:
                for j in range(n+1):
                    x=-12+j; vs2.append((cx+x,y+dy,4.6+.62*(1-(x/12)**2)+dz))
        mesh(name+'_curved_fascia',vs2,fs,'ivory_enamel',.02)
        for x in [cx-12,cx+12]:
            box(name+'_pier',(x,y,2.26),(.56,.62,4.52),'warm_walnut',.08)
            box(name+'_capital',(x,y,4.5),(.98,.95,.30),'champagne_metal',.05)
            box(name+'_plinth',(x,y,.22),(.9,.95,.44),'warm_stone',.06)
    for x in [cx-12,cx+12]:box(name+'_longitudinal_bearing',(x,cy,4.57),(.54,14.3,.36),'ivory_enamel',.05)
    for x in [cx-7,cx,cx+7]:
        for y in [cy-3.5,cy+3.5]:
            z=4.6+.62*(1-((x-cx)/12)**2)
            pendant(name+f'_lamp_{x}_{y}',x,y,z,3.8,340)
for i,y in enumerate([-19,0,19]): vault('bay_'+str(i),-6,y)

# Furniture library instances: source geometry remains unaltered; only rigid placement.
asset_templates={}
def load_template(asset,filename):
    f=P/'dependencies/furniture'/filename
    with bpy.data.libraries.load(str(f),link=False) as (src,dst): dst.objects=src.objects
    loaded=[o for o in dst.objects if o]
    for o in loaded:scene.collection.objects.link(o)
    bpy.context.view_layer.update()
    obs=[(o,o.matrix_world.copy()) for o in loaded if o.type=='MESH']
    # Evaluate source hierarchy before detaching; unlinked matrices are stale.
    for o in loaded:scene.collection.objects.unlink(o)
    asset_templates[asset]=obs
    return obs
load_template('AST-FUR-002','AST-FUR-002_day_reading_chair.blend')
load_template('AST-FUR-003','AST-FUR-003_day_table.blend')
def instance(asset,name,x,y,ang=0):
    trans=Matrix.Translation((x,y,0)) @ Matrix.Rotation(ang,4,'Z')
    for src,source_matrix in asset_templates[asset]:
        o=src.copy(); o.data=src.data; o.name='WP07_'+name+'_'+src.name; scene.collection.objects.link(o)
        o.parent=None; o.matrix_world=trans @ source_matrix; o['source_catalogue_id']=asset; o['instance_id']=name; o['package_id']='WP07_D12_directory_03'
    if asset=='AST-FUR-002':
        pt=trans @ Vector((0,-.11,.475)); marker(name+'_seat',pt,'seat_contact',asset=asset)
        seats.append({'id':name,'x':x,'y':y,'yaw':ang,'asset':asset})
    else:
        marker(name+'_table',(x,y,.665),'table_contact_proposal',asset=asset)
        tables.append({'id':name,'x':x,'y':y})
def chair(name,x,y,tx,ty):
    a=math.atan2(ty-y,tx-x)+math.pi/2; instance('AST-FUR-002',name,x,y,a)
def group(name,x,y):
    # Four inward seats: side table shared by pairs, central area remains reachable.
    for j,(dx,dy) in enumerate([(-1.45,-.7),(1.45,-.7),(-1.45,.85),(1.45,.85)]):chair(name+'_chair'+str(j),x+dx,y+dy,x,y)
    for j,dy in enumerate([-.65,.8]):instance('AST-FUR-003',name+'_table'+str(j),x,y+dy)
    marker(name+'_open_position',(x,y+2.1,0),'open_body_position_proposal')
for k,y in enumerate([-19,0,19]):
    for j,(dx,dy) in enumerate([(-12,-3),(.2,-3),(-12,3),(.2,3)]):group(f'listening{k}_cluster{j}',dx,y+dy)

# Real listening focus: framed acoustic baffle, stereo cabinets, protected controls.
def equipment(name,x,y):
    box(name+'_console_feet',(x,y,.13),(2.5,.95,.26),'dark_rubber',.04)
    box(name+'_console_case',(x,y,.56),(2.5,.95,.64),'warm_walnut',.10)
    box(name+'_control_face',(x,y-.49,.72),(2.2,.045,.24),'champagne_metal',.025)
    for dx in [-.85,-.45,0,.45,.85]:
        knob=cyl(name+'_knob',(x+dx,y-.535,.72),.055,.06,'dark_rubber',12); knob.rotation_euler[0]=math.pi/2
    for dx in [-.65,.65]: box(name+'_readout',(x+dx,y-.52,.84),(.32,.02,.05),'indicator',.006)
    for dx in [-2.4,2.4]:
        box(name+'_speaker_plinth',(x+dx,y,.12),(.95,.95,.24),'warm_stone',.06)
        box(name+'_speaker_case',(x+dx,y,.91),(.85,.72,1.45),'warm_walnut',.07)
        box(name+'_speaker_grille',(x+dx,y-.38,.97),(.72,.05,1.13),'dark_rubber',.05)
        for z,r in [(.7,.24),(1.28,.12)]:
            o=cyl(name+'_speaker_driver',(x+dx,y-.417,z),r,.025,'teal_weave',24); o.rotation_euler[0]=math.pi/2
    marker(name+'_control',(x,y-.55,.72),'equipment_control_proposal')
for k,y in enumerate([-19,0,19]):
    # Focus faces the bay interior; solid profiled baffle leaves 3m lateral routes.
    arc('focus'+str(k)+'_baffle',-6,y+3.8,4.9,5.2,35,145,0,2.15,'warm_walnut',20)
    arc('focus'+str(k)+'_acoustic',-6,y+3.8,4.84,4.91,38,142,.4,1.9,'teal_weave',20)
    equipment('focus'+str(k),-6,y+5.0)
    text('focus'+str(k)+'_label',['LISTEN / 01','LISTEN / 02','LISTEN / 03'][k],(-6,y+4.5,1.17),.2)

# Western inhabited acoustic edge, with built-in niches and comfortable curved retreats.
for i,y in enumerate([-27,-18,-9,0,9,18,27]):
    box(f'west{i}_niche_back',(-22.38,y,1.7),(.14,5.5,3.4),'warm_walnut')
    for yy in [y-2.8,y+2.8]: box(f'west{i}_fin',(-21.6,yy,1.75),(1.6,.24,3.5),'ivory_enamel',.06)
    box(f'west{i}_canopy',(-21.0,y,3.53),(3.3,5.9,.28),'warm_walnut',.08)
    box(f'west{i}_bench_plinth',(-21.42,y,.18),(1.35,4.9,.36),'warm_walnut',.10)
    box(f'west{i}_bench_seat',(-21.35,y,.47),(1.35,4.75,.24),'oatmeal_weave',.12)
    box(f'west{i}_bench_back',(-22.03,y,.97),(.27,4.75,.95),'teal_weave',.1)
    for yy in [y-1.25,y+1.25]:
        instance('AST-FUR-003',f'west{i}_table_{yy}',-19.92,yy)
        marker(f'west{i}_seat_{yy}',(-21.3,yy,.59),'broad_bench_contact_proposal')
    pendant(f'west{i}_pendant',-20.0,y,3.39,2.85,150)
    # Ground-level textural niche for physical recorded-media cases.
    for z in [1.6,2.35]:
        box(f'west{i}_shelf',(-22.02,y,z),(.63,4.6,.1),'warm_walnut')
        for j in range(12):
            box(f'west{i}_media_case',(-22,y-2.1+j*.34,z+.19),(.28,.17,.29+.035*(j%3)),['clay_weave','teal_weave','oatmeal_weave'][j%3],.01)

# End salons: curved shelters with reachable tables and no borrowed windows.
for k,y in enumerate([-30,30]):
    for j,x in enumerate([-13,-2]):
        arc(f'quiet{k}_{j}_screen',x,y,3.0,3.25,0 if y>0 else 180,180 if y>0 else 360,0,2.35,'warm_walnut',20)
        arc(f'quiet{k}_{j}_seat',x,y,2.05,2.95,15 if y>0 else 195,165 if y>0 else 345,.28,.56,'teal_weave',20)
        arc(f'quiet{k}_{j}_base',x,y,2.1,2.90,15 if y>0 else 195,165 if y>0 else 345,0,.29,'warm_walnut',20)
        for dx in [-1.15,1.15]:instance('AST-FUR-003',f'quiet{k}_{j}_table{dx}',x+dx,y+(.8 if y>0 else -.8))
        # Mounted ceiling and wall bearing, open front toward actual interior.
        box(f'quiet{k}_{j}_canopy',(x,y+(1.4 if y>0 else -1.4),3.63),(7,3.6,.26),'ivory_enamel',.12)
        for dx in [-3.2,3.2]:box(f'quiet{k}_{j}_bearing',(x+dx,y+(2.9 if y>0 else -2.9),1.8),(.35,.35,3.6),'warm_walnut')
        pendant(f'quiet{k}_{j}',x,y+(1 if y>0 else -1),3.5,3.0,230)

# East resting bays and controlled care/service pocket.
for i,y in enumerate([25,14,-12]):
    group('arrival_rest'+str(i),17.4,y)
    box('arrival_rest_wall_pad',(22.37,y,1.8),(.12,7,3.3),'teal_weave',.06)
    box('arrival_rest_roof',(18.5,y,4.1),(7.7,7.5,.3),'ivory_enamel',.1)
    for yy in [y-3.6,y+3.6]:box('arrival_rest_roof_bearing',(21.8,yy,2),(.4,.4,4),'warm_walnut')
    pendant('arrival_rest_light'+str(i),18,y,3.95,3.3,240)
# Care zone in source y=-19..-29 (engine z=19..29), away from resting approach.
box('care_screen',(13.4,-24,1.4),(.45,9,2.8),'warm_walnut',.07)
box('care_return',(16.8,-29,1.4),(7.2,.4,2.8),'warm_walnut',.07)
box('care_workbench',(20.9,-24,.85),(1.3,6.2,.16),'warm_stone',.055)
for yy in [-26.7,-21.3]:box('care_workbench_leg',(21,yy,.40),(.65,.12,.8),'champagne_metal')
box('care_cupboard',(21.4,-27.9,1.05),(1.5,1.45,2.1),'ivory_enamel',.10)
for yy in [-28.23,-27.57]:
    box('care_cupboard_leaf',(20.61,yy,1.08),(.08,.63,1.88),'teal_weave',.03)
    box('care_handle',(20.51,yy+.13,1.18),(.06,.055,.32),'champagne_metal',.02)
for y in [-25.8,-24.8,-23.8]:
    cyl('care_stock_bottle',(21,y,1.14),.12,.39,'ivory_enamel',16)
    cyl('care_stock_cap',(21,y,1.37),.07,.10,'champagne_metal',12)
box('care_fixture_mount',(22.3,-24,2.4),(.22,1.5,.22),'champagne_metal')
box('care_visible_task_emitter',(22.12,-24,2.36),(.15,1.35,.10),'lamp')
light('care_task_source',(21.95,-24,2.25),650,1.2,(20.5,-24,.8))
text('care_sign','CARE / LOCAL STOCK',(13.15,-24,2.25),.22,rotation=(math.pi/2,0,-math.pi/2))
marker('care_stock_access',(19.1,-27.9,0),'care_stance')
marker('care_cart_park',(16.4,-26,0),'cart_park_proposal',clear_rectangle=[3,3])

# Promenade ceiling-supported downlights and readable end destinations.
for i,y in enumerate([-29,-20,-10,0,10,20,29]):pendant('route'+str(i),9.5,y,5.5,4.2,350)
for y in [-31,31]:
    text('quiet_edge_identity'+str(y),'QUIET EDGE',(-6,y,2.5),.3,rotation=(math.pi/2,0,0 if y>0 else math.pi))
marker('datum',(0,0,0),'placement_datum')

def camera(name,loc,target,lens=24):
    d=bpy.data.cameras.new('WP07_'+name); o=bpy.data.objects.new('WP07_'+name,d); scene.collection.objects.link(o)
    o.location=loc; o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler(); d.lens=lens; d.clip_end=200
    o['SOURCE_PREVIEW_ONLY']=True; return o
cameras={
 'arrival':camera('arrival',(20.4,-1,1.65),(6,-5,1.8),22),
 'activity':camera('activity',(5,-8,1.65),(-7,2,2.2),22),
 'quiet':camera('quiet',(-15,25.8,1.65),(-20,29,1.6),24),
 'care':camera('care',(16.2,-20.6,1.65),(21,-26,1.3),23),
 'section':camera('section',(44,-53,48),(-2,0,1),34)
}
scene.camera=cameras['activity']
# Convert fonts only for export while native source retains editable text.
for im in bpy.data.images:
    if im.source=='FILE' and im.has_data: im.pack()
bpy.context.view_layer.update()
dg=bpy.context.evaluated_depsgraph_get()
for o in scene.objects:
    if o.type not in {'MESH','FONT'} or o.get('SOURCE_PREVIEW_ONLY'):continue
    ev=o.evaluated_get(dg); me=ev.to_mesh(); pts=[ev.matrix_world @ v.co for v in me.vertices]
    if pts:
        lo=[min(v[i] for v in pts) for i in range(3)]; hi=[max(v[i] for v in pts) for i in range(3)]
        records.append({'id':o.name,'source_bounds_min':lo,'source_bounds_max':hi,'vertex_count':len(me.vertices),'source_catalogue_id':o.get('source_catalogue_id'),'instance_id':o.get('instance_id')})
    ev.to_mesh_clear()
invalid=[r['id'] for r in records if any(r['source_bounds_min'][i]<[-23,-34,-.001][i]-.001 or r['source_bounds_max'][i]>[23,34,5.75][i]+.001 for i in range(3))]
(P/'qa/source_geometry.json').write_text(json.dumps({'scope':'source mesh bounds; no engine validation','bounds_violation_ids':invalid,'objects':records,'source_object_count':len(records),'light_count':len(lights),'seat_instance_count':len(seats),'table_instance_count':len(tables)},indent=2))
(P/'exports/contact_markers.json').write_text(json.dumps({'frame':'Blender source and local glTF explicitly labelled','placement':[-31,78,-324],'markers':markers,'lights':lights,'seats':seats,'tables':tables},indent=2))
(P/'exports/floor_proposal.json').write_text(json.dumps({'programme':'D12_directory_03','frame':'engine Y-up world metres','surface_y':78,'polygon_xz':[[-54,-358],[-8,-358],[-8,-290],[-54,-290]],'structural_floor_owner':'receiver_pending','collision_owner':'receiver_pending','package_visual_floor_exported':False,'preview_only_slab':'excluded from architecture GLB','external_4m_link':'unbuilt_parent_owned','material_regions_local_xz':[{'x':[-18,7],'z':[-32.5,32.5],'role':'teal_weave'},{'x':[7,12],'z':[-32.5,32.5],'role':'warm_walnut'},{'otherwise':'warm_stone'}]},indent=2))
bpy.ops.wm.save_as_mainfile(filepath=str(P/'source/WP07_listening_salon.blend'))
if invalid: raise RuntimeError('Out-of-allocation geometry: '+str(invalid))
# Preserve editable lettering in saved source, export evaluated mesh glyphs explicitly.
bpy.ops.object.select_all(action='DESELECT')
for o in list(scene.objects):
    if o.type=='FONT':
        o.select_set(True); bpy.context.view_layer.objects.active=o; bpy.ops.object.convert(target='MESH'); o.select_set(False)
bpy.ops.object.select_all(action='DESELECT')
for o in scene.objects:
    if not o.get('SOURCE_PREVIEW_ONLY'):o.select_set(True)
bpy.ops.export_scene.gltf(filepath=str(P/'exports/WP07_listening_salon.glb'),export_format='GLB',use_selection=True,export_apply=True,export_yup=True,export_extras=True,export_lights=True,export_cameras=False,export_texcoords=True)
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
if '--render' in args:
    for key in args[args.index('--render')+1:]:
        scene.camera=cameras[key]
        if key=='section':
            for o in scene.objects:
                if o.type=='MESH' and (any(s in o.name for s in ['ceiling_cap','acoustic_vault','curved_fascia','north_wall','east_wall','portal_head','soffit']) or 'lamp' in o.name or 'stem' in o.name):o.hide_render=True
        scene.render.filepath=str(P/'qa'/('SOURCE_ONLY_'+key+'.png')); bpy.ops.render.render(write_still=True)
print('WP07_BUILD_EXPORT_OK')
