"""Load native source independently, render chosen source-only views. Heavy scheduled job."""
import bpy,sys,json
from pathlib import Path
P=Path(__file__).resolve().parents[1]
bpy.ops.wm.open_mainfile(filepath=str(P/'source/WP07_listening_salon.blend'))
s=bpy.context.scene
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else ['arrival','activity','care','quiet','section']
baseline={o.name:o.hide_render for o in s.objects}
for key in args:
    for o in s.objects:o.hide_render=baseline[o.name]
    s.camera=bpy.data.objects['WP07_'+key]
    if key=='section':
        for o in s.objects:
            if o.type=='MESH' and any(v in o.name for v in ['ceiling_cap','acoustic_vault','curved_fascia','east_wall','south_wall','portal_head','soffit','_shade','_stem','_ceiling_socket']):o.hide_render=True
    s.render.filepath=str(P/'qa'/('SOURCE_ONLY_'+key+'.png'))
    bpy.ops.render.render(write_still=True)
print('WP07_SOURCE_RELOAD_RENDER_OK')
