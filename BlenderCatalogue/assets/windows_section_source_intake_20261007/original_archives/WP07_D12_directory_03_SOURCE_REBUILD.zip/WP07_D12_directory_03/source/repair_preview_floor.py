"""One-time parity repair of saved source after generator floor correction.
No delivered GLB geometry changes: preview backing floor is excluded.
"""
import bpy
from pathlib import Path
P=Path(__file__).resolve().parents[1]
f=P/'source/WP07_listening_salon.blend'
bpy.ops.wm.open_mainfile(filepath=str(f))
o=bpy.data.objects['WP07_SOURCE_PREVIEW_ONLY_floor']
assert o.get('SOURCE_PREVIEW_ONLY') and abs(o.location.z+.12)<.0001
o.location.z=-.13
bpy.ops.wm.save_as_mainfile(filepath=str(f))
print('WP07_PREVIEW_COPLANAR_BACKING_CORRECTED')
