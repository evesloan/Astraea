"""Standard Python GLB node-resolved mesh bounds and immutable input verification."""
import json,struct,hashlib,math
from pathlib import Path
P=Path(__file__).resolve().parents[1]
I=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]
def mul(a,b):return [sum(a[k*4+r]*b[c*4+k] for k in range(4)) for c in range(4) for r in range(4)]
def mat(n):
    if 'matrix' in n:return n['matrix']
    x,y,z,w=n.get('rotation',[0,0,0,1]);sx,sy,sz=n.get('scale',[1,1,1]);tx,ty,tz=n.get('translation',[0,0,0])
    return [(1-2*y*y-2*z*z)*sx,(2*x*y+2*w*z)*sx,(2*x*z-2*w*y)*sx,0,(2*x*y-2*w*z)*sy,(1-2*x*x-2*z*z)*sy,(2*y*z+2*w*x)*sy,0,(2*x*z+2*w*y)*sz,(2*y*z-2*w*x)*sz,(1-2*x*x-2*y*y)*sz,0,tx,ty,tz,1]
def apply(m,p):return [sum(m[k*4+r]*p[k] for k in range(3))+m[12+r] for r in range(3)]
raw=(P/'exports/WP07_listening_salon.glb').read_bytes();magic,ver,length=struct.unpack_from('<III',raw)
assert magic==0x46546c67 and ver==2 and length==len(raw)
jlen,jkind=struct.unpack_from('<II',raw,12);g=json.loads(raw[20:20+jlen]);bo=20+jlen;blen,bkind=struct.unpack_from('<II',raw,bo);binary=raw[bo+8:bo+8+blen]
def positions(index):
    a=g['accessors'][index];assert a['componentType']==5126 and a['type']=='VEC3';v=g['bufferViews'][a['bufferView']]
    start=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',12)
    return [struct.unpack_from('<fff',binary,start+i*stride) for i in range(a['count'])]
allpoints=[];items=[];visited=set();illegal=[]
def visit(i,parent):
    n=g['nodes'][i];m=mul(parent,mat(n));visited.add(i)
    if n.get('extras',{}).get('SOURCE_PREVIEW_ONLY') or 'SOURCE_PREVIEW_ONLY' in n.get('name',''):illegal.append(n.get('name'))
    if 'mesh' in n:
        pts=[]
        for pr in g['meshes'][n['mesh']]['primitives']:pts.extend(apply(m,p) for p in positions(pr['attributes']['POSITION']))
        if pts:
            lo=[min(v[k] for v in pts) for k in range(3)];hi=[max(v[k] for v in pts) for k in range(3)]
            items.append({'name':n.get('name'),'min':lo,'max':hi});allpoints.extend(pts)
    for ch in n.get('children',[]):visit(ch,m)
for i in g['scenes'][g.get('scene',0)]['nodes']:visit(i,I)
lo=[min(v[k] for v in allpoints) for k in range(3)];hi=[max(v[k] for v in allpoints) for k in range(3)]
checks={'no_preview_floor':not illegal,'within_allocation':all(lo[k]>=[-23,0,-34][k]-.002 and hi[k]<=[23,5.75,34][k]+.002 for k in range(3)),'embedded_textures':all('uri' not in im or im['uri'].startswith('data:') for im in g.get('images',[])),'punctual_lights_exported':len(g.get('extensions',{}).get('KHR_lights_punctual',{}).get('lights',[]))>0}
expected={'AST-FUR-002_day_reading_chair.blend':'d57540d49e130571e7a9c2f3882bae4ac6dd83daf763249e84c00d8e6fc8c96b','AST-FUR-003_day_table.blend':'1c61d8cbc18a2b92f31567b6b3bef5414d1ff49682a70e1407d24f8551ef5327'}
checks['reused_sources_match_current']=all(hashlib.sha256((P/'dependencies/furniture'/f).read_bytes()).hexdigest()==h for f,h in expected.items())
report={'scope':'actual GLB node-resolved vertices; no engine traversal/audio/lighting acceptance','checks':checks,'pass':all(checks.values()),'mesh_nodes':len(items),'vertex_samples':len(allpoints),'actual_local_gltf_bounds':[lo,hi],'actual_engine_bounds':[[v+offset for v,offset in zip(a,[-31,78,-324])] for a in [lo,hi]],'nodes':items,'illegal_preview_nodes':illegal}
(P/'qa/glb_validation.json').write_text(json.dumps(report,indent=2))
files=[]
for f in sorted(P.rglob('*')):
    if f.is_file() and f.suffix not in ['.pyc','.blend1'] and f.name!='manifest.json':files.append({'path':f.relative_to(P).as_posix(),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
(P/'manifest.json').write_text(json.dumps({'package':'WP07_D12_directory_03','programme':'D12_directory_03','alias':'D12_listening2','status':'source_export_candidate_pending_independent_visual_review','units':'metres','source_axes':'Blender Z-up','exchange_axes':'glTF Y-up','source_to_exchange':'(x,y,z) -> (x,z,-y)','placement_engine_yup':[-31,78,-324],'rotation_degrees':[0,0,0],'scale':[1,1,1],'floor':'preview excluded; receiver must adopt floor polygon first','actual_glb_local_bounds':[lo,hi],'checks':checks,'files':files},indent=2))
print(json.dumps({k:v for k,v in report.items() if k not in ['nodes']},indent=2))
assert all(checks.values()),checks
