"""Portable WP03 source-only conservatory builder. Blender 4.3.2, bundled inputs only.
Native editable asset collections retained; evaluated exchange proxies share meshes.
No main-game imports/adoption. Heavy job: coordinator must schedule execution.
"""
import bpy, bmesh, json, math, hashlib, random
from pathlib import Path
from mathutils import Vector, Matrix

P=Path(__file__).resolve().parents[1]
ID='WP03_D06_directory_02'; PROGRAMME='D06_directory_02'
for record in json.loads((P/'assets/dependencies.json').read_text()):
    assert hashlib.sha256((P/record['file']).read_bytes()).hexdigest()==record['sha256'],record
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
s=bpy.context.scene;s.unit_settings.system='METRIC';s.unit_settings.scale_length=1
s.render.engine='CYCLES';s.cycles.samples=24;s.cycles.use_denoising=True
s.render.resolution_x=1280;s.render.resolution_y=800;s.render.resolution_percentage=100
s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs[0].default_value=(.11,.15,.18,1)
s.world.node_tree.nodes['Background'].inputs[1].default_value=.06;s.view_settings.view_transform='AgX'
M={};material_records=json.loads((P/'assets/materials/material_manifest.json').read_text())['materials']
for role,r in material_records.items():
    m=bpy.data.materials.new('WP03_'+role);m.use_nodes=True;m['astraea_material_role']=role;m['meters_per_tile_uv']=r['meters_per_tile_uv']
    bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Roughness'].default_value=r['roughness'];bs.inputs['Metallic'].default_value=r['metallic']
    image=bpy.data.images.load(str(P/'assets/materials'/r['base_color_file']),check_existing=True);image.pack()
    tex=m.node_tree.nodes.new('ShaderNodeTexImage');tex.image=image;tex.interpolation='Closest';m.node_tree.links.new(tex.outputs['Color'],bs.inputs['Base Color']);M[role]=m
def simple(name,color,emission=0):
    m=bpy.data.materials.new(name);m.use_nodes=True;bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*color,1);bs.inputs['Roughness'].default_value=.72
    if emission:bs.inputs['Emission Color'].default_value=(*color,1);bs.inputs['Emission Strength'].default_value=emission
    M[name]=m;return m
simple('soil',(.12,.095,.062));simple('opal',(1,.86,.62),2);simple('daylight',(.78,.88,1),2)
# Original restrained mulch texture: packed pixels, stable metre scale, visible growing medium.
soil_image=bpy.data.images.new('WP03_original_dark_mulch',width=64,height=64)
soil_rng=random.Random(60321);pixels=[]
for i in range(64*64):
    grain=soil_rng.choice([.68,.84,1.0,1.15,1.30]);pixels.extend((.115*grain,.076*grain,.043*grain,1))
soil_image.pixels=pixels;soil_image.pack()
soil_tex=M['soil'].node_tree.nodes.new('ShaderNodeTexImage');soil_tex.image=soil_image;soil_tex.interpolation='Closest'
M['soil'].node_tree.links.new(soil_tex.outputs['Color'],M['soil'].node_tree.nodes['Principled BSDF'].inputs['Base Color'])
M['soil']['meters_per_tile_uv']=[.35,.35]
W=lambda u,v,h:Vector((8+u,466-v,27+h))
records=[];fixtures=[];markers=[];instances=[];templates={}
def uv_mesh(me,role):
    uv=me.uv_layers.active or me.uv_layers.new(name='metric_material_uv');scale=material_records.get(role,{}).get('meters_per_tile_uv',[.35,.35] if role=='soil' else [1,1])
    for face in me.polygons:
        ax=max(range(3),key=lambda k:abs(face.normal[k]));axes=[i for i in range(3) if i!=ax]
        for li in face.loop_indices:
            co=me.vertices[me.loops[li].vertex_index].co;uv.data[li].uv=(co[axes[0]]/scale[0],co[axes[1]]/scale[1])
def finish(o,name,role,bevel=0):
    o.name='WP03_'+name;o['programme_key']=PROGRAMME;o['package_id']=ID;o['role']=role;o.data.materials.append(M[role])
    if o.type=='MESH':
        uv_mesh(o.data,role)
        if bevel:
            mod=o.modifiers.new('Editable edge easing','BEVEL');mod.width=bevel;mod.segments=2
            o.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
    return o
def box(name,u,v,h,du,dv,dh,role,bevel=.03):
    bpy.ops.mesh.primitive_cube_add(size=1,location=W(u,v,h));o=bpy.context.object;o.dimensions=(du,dv,dh);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,name,role,bevel)
def cylinder(name,u,v,h,r,depth,role,n=20):
    bpy.ops.mesh.primitive_cylinder_add(vertices=n,radius=r,depth=depth,location=W(u,v,h));return finish(bpy.context.object,name,role,.02)
def beam(name,a,b,width,depth,role):
    a,b=W(*a),W(*b);mid=(a+b)/2
    bpy.ops.mesh.primitive_cube_add(size=1,location=mid);o=bpy.context.object;o.dimensions=(width,depth,(b-a).length);o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,name,role,.025)
def marker(name,u,v,h,kind,**extra):
    o=bpy.data.objects.new('WP03_MARK_'+name,None);s.collection.objects.link(o);o.location=W(u,v,h);o['kind']=kind;o['programme_key']=PROGRAMME
    markers.append({'id':o.name,'kind':kind,'world_godot':[8+u,27+h,-466+v],**extra});return o
def area(name,u,v,h,power,size=3,color=(.82,.90,1)):
    d=bpy.data.lights.new(name,'SPOT');d.energy=power;d.spot_size=math.radians(115);d.spot_blend=.65;d.shadow_soft_size=size*.2;d.color=color
    o=bpy.data.objects.new('WP03_LIGHT_'+name,d);s.collection.objects.link(o);o.location=W(u,v,h)
    fixtures.append({'id':o.name,'world_godot':[8+u,27+h,-466+v],'watts':power,'source':'Visible physically mounted luminaire; exported KHR_lights_punctual spot. Higgins applies current runtime light budget.'})
    return o
def pendant(name,u,v,mount,bottom=3.7,power=190):
    cylinder(name+'_mount',u,v,mount-.06,.15,.12,'champagne_metal')
    cylinder(name+'_stem',u,v,(mount+bottom)/2,.035,mount-bottom,'champagne_metal',12)
    cylinder(name+'_shade',u,v,bottom+.10,.40,.2,'champagne_metal')
    cylinder(name+'_diffuser',u,v,bottom-.012,.345,.035,'opal')
    area(name,u,v,bottom-.06,power,.7,(1,.78,.48));marker(name+'_mount',u,v,mount,'fixture_contact')
def text(name,body,u,v,h,size=.25,facing='south'):
    cu=bpy.data.curves.new(name,'FONT');cu.body=body;cu.size=size;cu.align_x='CENTER';cu.extrude=.003
    # Local text Y must remain vertical +Z. North-facing signs use local X=-world X.
    # The old negative-X rotation inverted the glyphs when seen from the public approach.
    o=bpy.data.objects.new('WP03_'+name,cu);s.collection.objects.link(o);o.location=W(u,v,h);o.rotation_euler=(math.pi/2,0,math.pi) if facing=='south' else (math.pi/2,0,-math.pi/2)
    o.data.materials.append(M['champagne_metal']);o['programme_key']=PROGRAMME;return o
def ellipsoid_plinth(name,u,v,ru,rv,top):
    # Closed polygonal island with substantial coping, actual soil and stepped beds.
    for suffix,h,depth,scale,mat in [('base',top/2,top,1,'warm_stone'),('soil',top+.005,.03,.94,'soil')]:
        o=cylinder(name+'_'+suffix,u,v,h,1,depth,mat,24);o.scale.x=ru*scale;o.scale.y=rv*scale;bpy.context.view_layer.objects.active=o;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
        uv_mesh(o.data,mat)
        if suffix=='base':o['collision_proposal']='solid planter; foliage separate'
    # Real annular coping; a full disc would bury the soil and root support surface.
    n=32;verts=[];faces=[]
    for h in [top-.03,top+.08]:
        for scale in [.93,1.035]:
            for i in range(n):
                a=2*math.pi*i/n;verts.append(tuple(W(u+ru*scale*math.cos(a),v+rv*scale*math.sin(a),h)))
    for i in range(n):
        j=(i+1)%n
        faces.extend([(i,j,n+j,n+i),(2*n+i,3*n+i,3*n+j,2*n+j),(i,2*n+i,2*n+j,j),(n+i,n+j,3*n+j,3*n+i)])
    me=bpy.data.meshes.new(name+'_open_coping');me.from_pydata(verts,[],faces);me.update()
    bm=bmesh.new();bm.from_mesh(me);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(me);bm.free();me.update()
    o=bpy.data.objects.new('WP03_'+name+'_open_coping',me);s.collection.objects.link(o);finish(o,name+'_open_coping','ivory_enamel',.018)
    marker(name+'_soil',u,v,top+.02,'soil_support')
def template(asset):
    if asset in templates:return templates[asset]
    with bpy.data.libraries.load(str(P/'assets/native'/f'{asset}.blend'),link=False) as (available,dst):dst.objects=available.objects
    loaded=[o for o in dst.objects if o]
    temp=bpy.data.collections.new('TEMP_EVALUATE_'+asset);s.collection.children.link(temp)
    for ob in loaded:temp.objects.link(ob)
    bpy.context.view_layer.update()
    obs=[o for o in loaded if o.type in {'MESH','CURVE','FONT'}]
    cached={o.name:o.matrix_world.copy() for o in obs}
    assert obs,asset
    col=bpy.data.collections.new('EDITABLE_RETAINED_'+asset)
    for ob in obs:
        world=cached[ob.name];ob.parent=None;ob.matrix_world=world;col.objects.link(ob)
    s.collection.children.unlink(temp);bpy.data.collections.remove(temp)
    templates[asset]=col;return col
def reuse(asset,name,u,v,h=0,angle=0):
    o=bpy.data.objects.new('WP03_'+name,None);s.collection.objects.link(o);o.instance_type='COLLECTION';o.instance_collection=template(asset);o.location=W(u,v,h);o.rotation_euler.z=math.radians(angle)
    o['retained_catalogue_id']=asset;o['programme_key']=PROGRAMME;o['package_id']=ID;instances.append((o,asset));return o

# Floor finish is visible source context only: parent adopts one explicit floor owner later.
floor=box('SOURCE_PREVIEW_ONLY_floor',23,34,-.12,46,68,.24,'warm_stone',0);floor['SOURCE_PREVIEW_ONLY']=True
for u,v,du,dv in [(14,34,4.3,37),(35,35,4.3,31),(24,16,16,4.3),(24,54,16,4.3),(42,34,4,48)]:
    o=box('SOURCE_PREVIEW_ONLY_path_inlay',u,v,.004,du,dv,.008,'ivory_enamel',0);o['SOURCE_PREVIEW_ONLY']=True
# Thick opaque envelope within allocation. West portal is at v10, never across the4m parent receiver.
box('east_enclosure',45.75,34,4,.5,68,8,'ivory_enamel')
box('north_enclosure',23,.25,4,45,.5,8,'ivory_enamel');box('south_enclosure',23,67.75,4,45,.5,8,'ivory_enamel')
box('west_forward_return',.25,3.9,4,.5,7.8,8,'ivory_enamel');box('west_aft_return',.25,40.05,4,.5,55.9,8,'ivory_enamel')
box('west_portal_head',.25,10,5.8,.5,4.4,4.4,'ivory_enamel')
box('opaque_protected_roof',23,34,8.05,45,67,.3,'ivory_enamel')
for v in [7.55,12.45]:
    box('entry_deep_jamb',1.8,v,1.8,3.2,.5,3.6,'warm_walnut',.08)
    box('entry_stone_foot',1.8,v,.18,3.4,.7,.36,'warm_stone')
box('entry_supported_lintel',1.8,10,3.82,3.2,5.4,.44,'warm_walnut',.07)
box('entry_soffit',5.5,10,4.55,9.8,10,.3,'ivory_enamel')
for v in [5.3,14.7]:box('entry_soffit_bearing',9.5,v,2.15,.5,.5,4.3,'warm_walnut')
box('identity_mounted_backboard',2,12.26,3.06,3.6,.16,.72,'warm_walnut',.04)
text('identity','CLOUD CONSERVATORY',2,12.165,2.9,.27)
box('wayfinding_supported_backboard',5.6,16,2.48,4.8,.18,.74,'warm_walnut',.04)
for u in [3.4,7.8]:
    box('wayfinding_visible_post',u,16,1.38,.12,.20,2.76,'champagne_metal',.018)
    box('wayfinding_floor_shoe',u,16,.06,.28,.34,.12,'warm_stone')
text('arrival_wayfinding','D06  /  GARDEN WALK',5.6,15.895,2.25,.24)
pendant('entry_1',4,8,4.4,3.7,250);pendant('entry_2',8,12,4.4,3.7,250)
marker('public_portal',0,10,0,'uninstalled_boundary_aperture',width=4.2,height=3.6,external_link='UNBUILT PARENT OWNED')
# Genuine bearing ribs, articulated pitched section, visibly attached coffers below opaque deck.
for j,v in enumerate([20,36,46]):
    for u in [11,38]:
        box(f'pier_{j}_{u}',u,v,3.35,.6,.8,6.7,'ivory_enamel',.09)
        box(f'plinth_{j}_{u}',u,v,.2,.78,.96,.4,'warm_stone',.05)
        box(f'capital_{j}_{u}',u,v,6.72,.95,1.1,.3,'champagne_metal',.05)
    for k,(a,b) in enumerate([((11,v,6.8),(18,v,7.5)),((18,v,7.5),(31,v,7.5)),((31,v,7.5),(38,v,6.8))]):beam(f'rib_{j}_{k}',a,b,.42,.60,'ivory_enamel')
    beam(f'haunch_left_{j}',(11,v,5.8),(16,v,7.3),.25,.42,'champagne_metal')
    beam(f'haunch_right_{j}',(38,v,5.8),(33,v,7.3),.25,.42,'champagne_metal')
for u in [11,18,31,38]:beam('longitudinal_supported_rail',(u,11,7.5),(u,58,7.5),.35,.35,'ivory_enamel')
for v in [22.5,46.5]:
    reuse('AST-ATR-002','retained_artificial_daylight',24.5,v,7.7)
    # Cofter spans12x24m; visible sockets bear to the continuous rails.
    for u in [18.5,30.5]:
        for vv in [v-10,v+10]:box('coffer_mount_block',u,vv,7.7,.35,.40,.4,'champagne_metal')
    for vv in [v-7,v,v+7]:area('coffer_daylight',24.5,vv,6.98,2300,5.5)
# Service screen contains two full-height actual openings; all external service interfaces sealed.
for lo,hi in [(10.8,22.2),(25.8,41.2),(44.8,59)]:box('service_screen',38.95,(lo+hi)/2,1.85,.35,hi-lo,3.7,'warm_walnut',.05)
for v in [24,43]:
    box('care_portal_lintel',38.95,v,3.85,.5,4,.3,'ivory_enamel');marker('internal_care_opening',38.95,v,0,'internal_care_aperture',width=3.6,height=3.6)
box('service_supported_ceiling',42.25,34.5,3.95,6.3,49,.3,'ivory_enamel')
for v in [15,31,51]:pendant('service_task',42.2,v,3.8,3.1,450)
# Enclosed north support suite; doors face service approach not the guest threshold.
box('stock_west_partition',11,5.5,1.8,.3,10,3.6,'ivory_enamel')
for lo,hi in [(.5,3.7),(7.3,10.5)]:box('return_bay_door_side',23.4,(lo+hi)/2,1.8,.3,hi-lo,3.6,'ivory_enamel')
box('return_bay_door_head',23.4,5.5,3.72,.3,3.6,.24,'ivory_enamel')
marker('return_bay_opening',23.4,5.5,0,'internal_care_aperture',width=3.6,height=3.6)
box('stock_south_return',25,10.7,1.8,28,.3,3.6,'ivory_enamel')
box('stock_ceiling',28,5.5,3.78,34,10,.28,'ivory_enamel')
for u in [17,29,37]:pendant('stock_lamp',u,5.5,3.64,3.05,300)
for u in [16,28,34]:
    for h in [.25,.95,1.65,2.35]:box('stock_shelf',u,1.25,h,4,.7,.09,'warm_walnut')
    for uu in [u-1.9,u+1.9]:box('shelf_upright',uu,1.25,1.35,.09,.7,2.7,'champagne_metal')
    for k in range(4):
        cylinder('care_container',u-1.35+k*.85,1.2,1.18,.24,.35,'ivory_enamel',12)
box('care_worktop',30,4.3,1,5,1.2,.12,'warm_stone')
for u in [27.8,32.2]:box('worktop_pedestal',u,4.3,.47,.45,.9,.94,'warm_walnut')
# Local task illumination only: real suspended worktop fitting and shelf-mounted bars.
# Leave the approved main conservatory coffers, camera exposure and world unchanged.
for u in [28,32]:
    cylinder('care_task_ceiling_plate',u,4.3,3.58,.15,.12,'champagne_metal')
    cylinder('care_task_drop_rod',u,4.3,3.145,.025,.87,'champagne_metal',12)
    marker('care_worktop_task_mount',u,4.3,3.64,'fixture_contact')
box('care_worktop_task_housing',30,4.3,2.64,4.8,.34,.20,'ivory_enamel',.04)
box('care_worktop_task_diffuser',30,4.3,2.525,4.56,.27,.03,'daylight',.012)
for u in [28.8,31.2]:
    area('care_worktop_task',u,4.3,2.50,260,1.5,(.92,.96,1))
for u in [16,28,34]:
    box('care_shelf_task_housing',u,1.56,1.565,3.7,.16,.08,'ivory_enamel',.012)
    box('care_shelf_task_diffuser',u,1.56,1.513,3.55,.12,.02,'daylight',.005)
    for offset in [-1.15,0,1.15]:
        lamp=area('care_shelf_task',u+offset,1.56,1.495,25,.20,(.92,.96,1))
        lamp.rotation_euler=(W(u+offset,1.19,1.12)-lamp.location).to_track_quat('-Z','Y').to_euler()
    marker('care_shelf_task_mount',u,1.56,1.605,'fixture_contact',bearing='underside of retained modeled shelf at h1.65 with0.09 thickness')
box('care_label_mounted_backboard',38.75,31,2.7,.10,3.9,.70,'ivory_enamel',.025)
text('service_label','HORTICULTURAL CARE',38.685,31,2.5,.25,'east')
marker('cart_park',42,7,0,'parking_target',footprint=[2,3]);marker('care_stance',30,6.8,0,'work_stance')
# Three planted islands with differentiated silhouettes and usable low edges.
ellipsoid_plinth('grove',23.5,26.5,5.0,4.0,.5)
ellipsoid_plinth('grove_raised_centre',24,26.5,2.5,1.8,1.1)
ellipsoid_plinth('flower_bank',25.5,42,5,4.5,.5)
ellipsoid_plinth('quiet_bed',2.2,50,1.1,5,.5)
ellipsoid_plinth('south_bed',24.5,64,8,2,.5)
rng=random.Random(603)
for i,(u,v) in enumerate([(21,24.5),(24,25.2),(27,26),(21,28),(24,28),(27,28.3),(22.9,26.1),(25.2,26.2),(26.1,24.2)]):
    raised=((u-24)/2.5)**2+((v-26.5)/1.8)**2<.85
    reuse('AST-BOT-001',f'branching_grove_{i}',u,v,1.12 if raised else .52,i*37)
for i,(u,v) in enumerate([(22,40),(25.5,40),(28.5,42),(24,44),(26.5,43.4),(23,42.1)]):reuse('AST-BOT-007',f'fan_crown_{i}',u,v,.52,i*47)
# Irregular layered ground planting fills actual soil instead of lining a sparse ring.
# All instance pivots stay inside the original planter footprints; final foliage bounds
# remain a separate route check. Raised grove roots land on the raised soil surface.
for bed,(cu,cv,ru,rv) in enumerate([(23.5,26.5,4.35,3.35),(25.5,42,4.35,3.85),(24.5,64,7.25,1.3)]):
    index=0
    for row in range(math.ceil(2*rv/.64)+1):
        v=cv-rv+row*.64
        for col in range(math.ceil(2*ru/.70)+1):
            u=cu-ru+col*.70+(row%2)*.22
            if ((u-cu)/ru)**2+((v-cv)/rv)**2>1:continue
            u+=rng.uniform(-.12,.12);v2=v+rng.uniform(-.10,.10)
            raised=((u-24)/2.5)**2+((v2-26.5)/1.8)**2 if bed==0 else 100
            if bed==0 and .80<raised<1.32:continue
            h=1.12 if raised<=.80 else .52
            reuse('AST-BOT-003',f'groundcover_{bed}_{index}',u,v2,h,rng.randrange(360))
            if index%4==0:reuse('AST-BOT-002',f'understory_{bed}_{index}',u+.08,v2+.06,h,rng.randrange(360))
            if index%9==0:reuse('AST-BOT-009',f'flowering_midstory_{bed}_{index}',u-.12,v2+.12,h,rng.randrange(360))
            index+=1
    # Deliberate midstory clumps leave two sightline gaps instead of a uniform hedge.
    for i in [0,1,2,4,5,7,8,9]:
        a=2*math.pi*i/11;u=cu+ru*.70*math.cos(a);v=cv+rv*.68*math.sin(a)
        raised=((u-24)/2.5)**2+((v-26.5)/1.8)**2 if bed==0 else 100
        if bed==0 and .80<raised<1.32:continue
        reuse('AST-BOT-009',f'midstory_clump_{bed}_{i}',u,v,1.12 if raised<=.80 else .52,i*31)
for i in range(7):reuse('AST-BOT-002' if i%2 else 'AST-BOT-009',f'quiet_understory_{i}',2.2,46.2+i*1.2,.52,i*35)
# Retained planted seating groups: actual editable supported seats, not box proxies.
for i,(u,v,angle) in enumerate([(6,53,0),(6,56,0),(6,23,0),(6,27,0),(20,60,0),(24,60,0),(28,60,0)]):
    reuse('AST-BOT-004',f'planted_seat_{i}',u,v,.02,angle)
    # AST-BOT-004 source is0..2.4m alongX. Its soil opening isY+.15..+.88,
    # soilZ+.39; source+Y maps to decreasing planv. Seat ribbon is sourceY<0.
    marker(f'seat_support_{i}',u+1.2,v+.25,.49,'proposed_seat_contact',all_species_fit=False)
    for j,dx in enumerate([.48,1.2,1.92]):
        reuse('AST-BOT-003',f'seat_plant_{i}_{j}',u+dx,v-.515,.41,i*25)
        marker(f'seat_soil_root_{i}_{j}',u+dx,v-.515,.41,'retained_planter_soil_contact',parent_asset='AST-BOT-004',parent_soil_z=.39,placement_z=.02)
    marker(f'seat_approach_{i}',u+1.2,v+1.8,0,'seated_group_approach')
# Quiet edge has low supported ceiling, rhythmic piers, mounted warm fixtures.
box('quiet_edge_soffit',5,40,4.65,9,38,.3,'ivory_enamel')
for v in [22,31,38,56]:
    box('quiet_edge_pier',9.6,v,2.2,.5,.5,4.4,'warm_walnut')
    box('quiet_edge_capital',9.6,v,4.35,.85,.85,.25,'champagne_metal')
for v in [24,36,52]:pendant('quiet_edge',5.5,v,4.5,3.6,400)
for v in [52.7,55.7]:pendant('quiet_seated_task',7.2,v,4.5,3.2,700)
for i,(u,v) in enumerate([(18,19.4),(32,34),(18,49)]):
    reuse('AST-GAR-002',f'path_lantern_{i}',u,v,.02)
    area('path_lantern_effective',u,v,2.92,110,.8,(1,.77,.43))
# Useful south pause with intentional material/focal wall and bounded seating.
box('south_low_soffit',24,61.5,4.6,27,11,.35,'ivory_enamel')
for u in [11,37]:box('south_soffit_support',u,61.5,2.2,.55,.55,4.4,'ivory_enamel')
for u in [18,25,32]:pendant('south_social',u,59.5,4.43,3.6,380)
box('south_identity_wall_panel',24.5,67.47,2.6,12,.14,1.65,'warm_walnut',.055)
text('garden_identity','CLOUD CONSERVATORY',24.5,67.385,2.7,.55)
text('garden_subtitle','A QUIET WALK THROUGH LIVING LAYERS',24.5,67.385,2.08,.22)
marker('future_service_sealed',42,0,0,'sealed_future_interface');marker('floor_owner',23,34,0,'candidate_floor_owner',external_receiver_excluded=True)

# Ordinary eye-height views use real source floor context; diagnostic section is separate.
camera_specs={'arrival':((4,10,1.68),(23,26,2.6)), 'grove':((14,20,1.68),(25,28,2.3)), 'activity':((34,48,1.68),(23,38,2.4)), 'quiet':((7.2,49.8,1.68),(5.5,55.5,1.1)), 'quiet_garden':((7,54,1.68),(22,42,2)), 'care':((36,7,1.68),(28,3,1.35)), 'care_route':((42,34,1.68),(42,18,1.7)), 'mounts':((14,17,1.68),(23,22,7.0)), 'section':((57,76,43),(23,34,2))}
for key,(pos,target) in camera_specs.items():
    d=bpy.data.cameras.new('WP03_'+key);d.lens=22 if key!='mounts' else 28
    o=bpy.data.objects.new('WP03_'+key,d);s.collection.objects.link(o);o.location=W(*pos);o.rotation_euler=(W(*target)-o.location).to_track_quat('-Z','Y').to_euler()
s.camera=bpy.data.objects['WP03_arrival'];s['acceptance']='SOURCE ONLY: isolated source floor; no live connection/traversal/door or final visual acceptance'
bpy.ops.file.pack_all();native=P/'source/WP03_cloud_conservatory.blend';bpy.ops.wm.save_as_mainfile(filepath=str(native),compress=True)

# Native source remains editable. Exchange builds one evaluated mesh per retained family.
def compact_asset(asset,col):
    s.collection.children.link(col);bpy.context.view_layer.update();deps=bpy.context.evaluated_depsgraph_get()
    vertices=[];faces=[];mat_indices=[];uv_faces=[];materials=[]
    for ob in list(col.objects):
        me=bpy.data.meshes.new_from_object(ob.evaluated_get(deps),depsgraph=deps);transform=ob.matrix_world;offset=len(vertices)
        vertices.extend(tuple(transform@v.co) for v in me.vertices)
        source_uv=me.uv_layers.active
        for f in me.polygons:
            faces.append(tuple(offset+j for j in f.vertices))
            material=me.materials[f.material_index] if me.materials else M['ivory_enamel']
            if material not in materials:materials.append(material)
            mat_indices.append(materials.index(material))
            uv_faces.append([tuple(source_uv.data[li].uv) if source_uv else (me.vertices[me.loops[li].vertex_index].co.x,me.vertices[me.loops[li].vertex_index].co.z) for li in f.loop_indices])
        bpy.data.meshes.remove(me)
    me=bpy.data.meshes.new('EXCHANGE_SHARED_'+asset);me.from_pydata(vertices,[],faces);me.update()
    for material in materials:me.materials.append(material)
    uv=me.uv_layers.new(name='retained_metric_uv')
    for i,f in enumerate(me.polygons):
        f.material_index=mat_indices[i]
        for li,co in zip(f.loop_indices,uv_faces[i]):uv.data[li].uv=co
    s.collection.children.unlink(col);return me
meshes={asset:compact_asset(asset,col) for asset,col in templates.items()}
for old,asset in instances:
    ob=bpy.data.objects.new(old.name,meshes[asset]);s.collection.objects.link(ob);ob.matrix_world=old.matrix_world.copy()
    for key,value in old.items():ob[key]=value
    bpy.data.objects.remove(old,do_unlink=True)
# Convert original text/curves so export includes visible signage and valid UVs.
for ob in list(s.objects):
    if ob.type in {'FONT','CURVE'}:
        bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob;bpy.ops.object.convert(target='MESH');uv_mesh(bpy.context.object.data,'champagne_metal')
bpy.ops.object.select_all(action='DESELECT')
for ob in s.objects:
    if ob.type in {'MESH','LIGHT','EMPTY'} and not ob.get('SOURCE_PREVIEW_ONLY'):ob.select_set(True)
bpy.ops.export_scene.gltf(filepath=str(P/'exports/WP03_cloud_conservatory.glb'),export_format='GLB',use_selection=True,export_yup=True,export_apply=True,export_extras=True,export_lights=True,export_cameras=False)
report={'status':'SOURCE ONLY built; independent export/source/visual review pending','programme_key':PROGRAMME,'world_coordinates':True,'glb_world_placement':[0,0,0],'blender_to_glb':'(x,y,z)->(x,z,-y)','allocation':{'x':[8,54],'z':[-466,-398],'y':[27,35.5]},'native_sha256':hashlib.sha256(native.read_bytes()).hexdigest(),'glb_sha256':hashlib.sha256((P/'exports/WP03_cloud_conservatory.glb').read_bytes()).hexdigest(),'retained_instances':len(instances),'retained_families':sorted(templates),'fixtures':fixtures,'markers':markers,'review_cameras':camera_specs,'preview_floor_exported':False,'integration_held':True,'floor_proposal':{'boundary_xz':[[8,-466],[54,-466],[54,-398],[8,-398]],'surface_y':27,'owner':'Higgins must allocate compiler ownership','receiving_link':'X4..8 UNBUILT and excluded'},'limits':['No live ship traversal or controls','External service routes sealed/planned','No atmosphere/fluid/NPC/care gameplay claim','Candidate supports not structural certification','Actual source appearance must be reviewed']}
(P/'qa/build_manifest.json').write_text(json.dumps(report,indent=2)+'\n')
print('WP03_BUILD_SOURCE_ONLY_COMPLETE',len(instances),'retained instances',len(fixtures),'mounted light sources')
