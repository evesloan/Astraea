"""Scheduled source-only ordinary-eye review. Does not modify native source."""
import bpy,sys
from pathlib import Path
P=Path(__file__).resolve().parents[1]
bpy.ops.wm.open_mainfile(filepath=str(P/'source/WP03_cloud_conservatory.blend'))
s=bpy.context.scene
keys=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else ['arrival','grove','activity','quiet','care','mounts']
baseline={o.name:o.hide_render for o in s.objects}
for key in keys:
    for o in s.objects:o.hide_render=baseline[o.name]
    s.camera=bpy.data.objects['WP03_'+key]
    if key=='section':
        for o in s.objects:
            if any(n in o.name for n in ['opaque_protected_roof','east_enclosure','south_enclosure','soffit','stock_ceiling','service_supported_ceiling']):o.hide_render=True
    s.render.filepath=str(P/'qa'/f'SOURCE_ONLY_{key}.png');bpy.ops.render.render(write_still=True)
print('WP03_SOURCE_ONLY_RENDER_DONE')
