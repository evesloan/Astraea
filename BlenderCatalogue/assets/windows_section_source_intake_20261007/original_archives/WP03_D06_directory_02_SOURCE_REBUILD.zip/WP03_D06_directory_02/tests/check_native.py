"""Independent native reload, bounds and source dependency verification; scheduled Blender job."""
import bpy,json,hashlib
from pathlib import Path
P=Path(__file__).resolve().parents[1]
for r in json.loads((P/'assets/dependencies.json').read_text()):assert hashlib.sha256((P/r['file']).read_bytes()).hexdigest()==r['sha256']
bpy.ops.wm.open_mainfile(filepath=str(P/'source/WP03_cloud_conservatory.blend'))
s=bpy.context.scene
assert any(o.get('SOURCE_PREVIEW_ONLY') for o in s.objects)
assert len([o for o in s.objects if o.instance_type=='COLLECTION'])>60
assert len([o for o in s.objects if o.type=='LIGHT'])>15
assert all(im.packed_file for im in bpy.data.images if im.source=='FILE' and im.users>0)
deps=bpy.context.evaluated_depsgraph_get();bounds=[[1e9]*3,[-1e9]*3];violations=[];meshes=0
for inst in deps.object_instances:
    ob=inst.object
    if ob.type not in {'MESH','CURVE','FONT'} or ob.original.get('SOURCE_PREVIEW_ONLY'):continue
    mesh=bpy.data.meshes.new_from_object(ob,depsgraph=deps);meshes+=1
    for vert in mesh.vertices:
        co=inst.matrix_world@vert.co;p=[co.x,co.z,-co.y]
        for k in range(3):bounds[0][k]=min(bounds[0][k],p[k]);bounds[1][k]=max(bounds[1][k],p[k])
        if not(7.9998<=p[0]<=54.0002 and 26.9998<=p[1]<=35.5002 and -466.0002<=p[2]<=-397.9998):
            if len(violations)<25:violations.append({'name':ob.name,'point':p})
    bpy.data.meshes.remove(mesh)
report={'pass':not violations,'scope':'native editable reload,packed images,retained dependencies and evaluated source bounds; not runtime/visual acceptance','evaluated_objects':meshes,'bounds_world_godot':bounds,'violations':violations}
(P/'qa/native_check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));assert not violations
