"""Actual exported vertices/resources/lights; source-only gate, never live acceptance."""
import json,struct,hashlib,math
from pathlib import Path
from glb_reader import glb
P=Path(__file__).resolve().parents[1];path=P/'exports/WP03_cloud_conservatory.glb'
raw=path.read_bytes();length=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+length])
assert all('bufferView' in im for im in doc.get('images',[])) and doc.get('images')
assert not any('SOURCE_PREVIEW_ONLY' in n.get('name','') for n in doc['nodes'])
lights=doc.get('extensions',{}).get('KHR_lights_punctual',{}).get('lights',[]);assert len(lights)>15
triangles=glb(path);bounds=[[float('inf')]*3,[-float('inf')]*3];violations=[]
for name,tri in triangles:
    for p in tri:
        assert all(math.isfinite(c) for c in p)
        for k in range(3):bounds[0][k]=min(bounds[0][k],p[k]);bounds[1][k]=max(bounds[1][k],p[k])
        if not(7.9998<=p[0]<=54.0002 and 26.9998<=p[1]<=35.5002 and -466.0002<=p[2]<=-397.9998):
            if len(violations)<25:violations.append({'object':name,'point':p})
for mesh in doc['meshes']:
    for primitive in mesh['primitives']:assert all(a in primitive['attributes'] for a in ['POSITION','NORMAL','TEXCOORD_0'])
report={'pass':not violations,'scope':'Actual GLB containment, texture portability and exported punctual fixtures; no runtime traversal or visual acceptance','sha256':hashlib.sha256(raw).hexdigest(),'bounds_world_godot':bounds,'triangles':len(triangles),'meshes':len(doc['meshes']),'nodes':len(doc['nodes']),'embedded_images':len(doc['images']),'punctual_lights':len(lights),'violations':violations}
(P/'qa/export_check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));assert not violations
