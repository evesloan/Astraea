# Source visual correction03 — focused quiet/care lighting and seat-soil contact

Viewed current actual quiet and care images. Main hall images are coordinator-reviewed as improved; this revision leaves all main coffers, structural framing, world strength, camera exposure and hall lighting unchanged.

Quiet edge: add two visible stemmed pendant fittings at u7.2/v52.7 and55.7, bearing on the existing soffit. Their local warm sources illuminate the actual supported seated groups and planted pockets.

Care: add a ceiling-mounted suspended linear fitting above the worktop, plus shelf-mounted task bars physically attached beneath the stocked shelves. Effective exported punctual sources light the table and container faces; no global exposure adjustment or invisible fill is introduced.

The suspected flower placement was a real defect. Verified unchanged AST-BOT-004 manifest: source X0..2.4, soil openingY+.15..+.88, soilZ+.39, seatZ+.47. The previous package placed plants in front of the seat and too high. Corrected the rigid plant instances to local x+.48/+1.2/+1.92, planv-.515, h.41 (=floor placement.02 + soil.39). Seat contacts now use the actual ribbon center and h.49. Original source asset remains untouched. Named soil-root contact markers capture this evidence.

This script revision has only syntax verification so far. Coordinator must rebuild, check source/export and rerender quiet/care; the accepted guest images retain their original reviewed geometry-hash provenance. They are historical evidence, not images of this revised source. New quiet/care images must bind to the newly generated native/export hashes.
