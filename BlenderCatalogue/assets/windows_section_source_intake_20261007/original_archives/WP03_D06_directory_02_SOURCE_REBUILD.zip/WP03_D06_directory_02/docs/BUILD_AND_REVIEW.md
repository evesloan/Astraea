# WP03 Cloud Conservatory build and review

Current stage: **scripts prepared and syntax checked; heavy build/export/render not executed by section owner**. Root coordinator schedules the following jobs with Blender4.3.2. No build, export, native-QA or visual-pass claim is made until those jobs run successfully.

All reconstruction dependencies are inside `assets/`: twelve SHA256-verified retained native component sources, shared material manifest and textures. Builders resolve only relative package paths. Reference images remain review inputs, not production textures. Source imported hierarchies are temporarily linked and updated before caching world transforms, then retained in editable collection instances.

From `C:\Users\cered\Dolphin`:

```powershell
& 'C:\Users\cered\Dolphin\AstraeaTools\blender-4.3.2-windows-x64\blender.exe' --background --python-exit-code 1 --python 'C:\Users\cered\Dolphin\AstraeaShip\external_packages\windows\WP03_D06_directory_02\source\build_conservatory.py'
& 'C:\Users\cered\Dolphin\AstraeaTools\blender-4.3.2-windows-x64\blender.exe' --background --python-exit-code 1 --python 'C:\Users\cered\Dolphin\AstraeaShip\external_packages\windows\WP03_D06_directory_02\tests\check_native.py'
python 'C:\Users\cered\Dolphin\AstraeaShip\external_packages\windows\WP03_D06_directory_02\tests\check_export.py'
& 'C:\Users\cered\Dolphin\AstraeaTools\blender-4.3.2-windows-x64\blender.exe' --background --python-exit-code 1 --python 'C:\Users\cered\Dolphin\AstraeaShip\external_packages\windows\WP03_D06_directory_02\source\render_review.py' -- arrival grove activity quiet care mounts
```

Native source output is `source/WP03_cloud_conservatory.blend`; exchange output is `exports/WP03_cloud_conservatory.glb`. World coordinates are explicit; GLB placement offset is zero. Geometry stays within X8..54/Z-466..-398/Y27..35.5. `SOURCE_PREVIEW_ONLY` floor/backing and route inlays are excluded from exchange. Higgins owns one candidate floor/compiler adoption and the external4m X4..8 receiving link. That link remains unbuilt. All external service endpoints are sealed.

Native editable originals remain collection instances. Exported instances share evaluated per-family geometry, while original materials and packed texture images remain portable. Modeled fixtures include diffuse artificial-daylight coffers, bracketed/stemmed lamps and path lanterns. Their effective spot sources export as `KHR_lights_punctual`; Higgins must map their budgets/shadows to the existing runtime selector. This is not target-GPU acceptance.

Review ordinary-height arrival/grove/activity/quiet/care views before deciding this is ready for Higgins. In particular inspect: substantial planting hierarchy, clear dry routes, supported rib/coffer joints, visible mount contacts, seating/support and reach, source illumination, inward enclosure and contextual scale. `mounts` shows the ceiling from ordinary player height. Optional `section` is a diagnostic cutaway only. Do not infer ordinary arrival or live physics from source renders.

Known further gates: all actual furnishing/foliage route intersections, actual loaded-cart motion, fitted functional doors, environmental-service integration, current species envelopes, runtime lighting budget, CRT on/off and final architectural acceptance. Newly authored members provide a visible bearing proposal, not engineering load certification. No extra programme capacity, biology, water, NPC behaviour or plant-care gameplay is asserted.
