# D06 Cloud conservatory: first-stage architectural proposal

**Identity:** `D06_directory_02`, AME-003. Reserved by Higgins via the coordinator on 6 October 2026. **Stage:** dimensioned plan/section proposal, pending live interface confirmation. Geometry, Blender authoring and exports are held. No live project files were edited.

## Authority and retained dimensions

`retained_evidence.json` was produced by the coordinator's `extract_section_brief.py`. The historical envelope is X **8..54**, Z **-466..-398**, floor Y **27**: **46 x 68 m / 3,128 m2**. The Movement studio (`D07_directory_02`) occupies the same footprint above at Y35.5; Medical bay (`D05_directory_02`) occupies it below at Y21. These are preserved allocation records, not proof of current floor geometry or live interior bounds. Higgins's current handoff confirms these allocation/datums and reports zero installed floor in this allocation. Its portal and source-manifest requirements supersede earlier internal proposals; final construction still awaits manifest verification.

Read complete master v0.3 chapters **4, 5, 7, 8, 21, 28, 30 and 32**, together with `MASTER_CURRENT_APPLICATION.json`, the architectural delivery rules, whole-ship section coordination, the amenity audit, reference application register and coordinate contract. Historical implementation and exact-bed claims remain overridden as documented. Current six-species canon and protected guest/crew allocations remain unchanged.

The retained amenity audit specifies this parent programme but gives **no canonical child IDs, child counts or occupancy total**. The proposal therefore names subordinate functional zones without registering new programmes or inventing botanical species requirements. Current child requirements are a hold point.

## Spatial proposition

This is a conservatory with a continuous **single-level dry garden walk** and three different planted encounters. A 4.4m-high deep arrival opens into a 7.4m-high faceted garden room. A branching grove near the first turn gives way to a lower flowering bank and a quieter understory recess; their different silhouettes preserve views into the next space. This avoids repeating the main ship atrium's giant tree or adding a competing multideck spectacle.

The plan uses local **u=X-8**, **v=Z+466**, **h=Y-27**, in metres. See `plan_contract.json` for exact proposed zone extents and route points. These dimensions are coordination proposals; they must be reconciled to Higgins's current shell before geometry.

| Element | Proposed dimensions and position | Architectural role |
|---|---|---|
| Arrival | u0.6..11, v5..15; soffit h4.4 | Deep, offset internal glazed threshold and turning space; long view into first planted room |
| Garden volume | Faceted polygon within u11..38, v11..58; clear soffit h7.4 | Main high volume with offset planting and visible frames |
| Public loop | 4.2m clear target, level at h0 | Continuous dry route around both central planting islands |
| Quiet recess | u0.6..10.5, v43..57; h4.4 overhead | Lower sheltered planted edge with companion-space provisions outside the through route |
| Horticultural support | u11..44.8, v0.6..10.5; h3.6 overhead | Separate clean receiving/stock and used-tool return bays |
| Screened service lane | u39.2..44.8, v10.5..59 | 3.6m clear target spine, recessed stock, two controlled garden access points |
| Southern pause | u11..38, v58..67.4; h4.4 overhead | Wider return/wayfinding space instead of an unexplained dead-end volume |

Functional bounds may share threshold/circulation areas; their areas are **not additive completion or net-use totals**. Planters and branch crowns must stay outside the complete buffered route, not just outside its centerline. The main floor stays at Y27; there are no stairs, artificial changes of level or reliance on an unfinished lift.

## Section, load path and genuinely mounted lighting

The high-room enclosure is proposed below Y35.0, leaving 0.5m to the next deck datum. This is a **coordination allowance**, not a confirmed slab or plant/service zone. Six visible piers at local u11/u38 and v20/36/46 support paired structural ribs with expressed haunches. Smaller opaque ceiling infill sits on that framework. The apparent 27m span is a visual structural proposition for Higgins to accept or revise; no load calculation or connection to a verified ship frame is claimed.

Any timber finish is confined to supported infill panels with visible end trims, joints and bearings. It is not a curved floating board or an implied unsupported structural roof. Lamps meet real bracket plates attached to ribs/pier capitals; short stems terminate at those plates. Soffit lighting occupies modeled recesses with cable routes to the service edge. Capture the approach view, underside of first haunch, infill termination and actual fixture mounts before judging the ceiling resolved.

All planter soil and support stay above the D06 datum. No pit or drain is pushed into medical below. The top is opaque under Movement studio: no glazed roof or skylight. Existing frame/slab and mechanical needs can require lower final ceiling heights.

## Planting, atmosphere and views

Use the existing editable botanical families as candidates: `AST-BOT-001` branching canopy; `002/003` understory/rosette; `007/008/009` fan, trailing and flowering groups; joined planter/seat pieces `004/005/006`. Retain native proportions, provenance, semantic materials and stable instance identities. Source dimensions and actual evaluated crowns must inform placement. A mass of uniformly scattered shrubs is insufficient; use canopy, middle layer and ground layer deliberately, with gaps and planted seats.

The three proposed planting footprints and maximum tips are recorded in the contract. Their height limits are **composition bounds, not permission to stretch an existing 2.69m canopy into a new giant species**. Existing plants can occupy designed stepped planting bases only where horticultural support, sightlines and route clearances remain plausible. New biology is not authorized.

Public surfaces remain dry. No waterfall, pool, wet walking surface or physical mist simulation is introduced. Framed internal glass separates atmosphere/support functions without inventing gas, humidity or temperature values. Real ventilation and drainage connections require explicit receiving interfaces. Quiet seating looks into internal planting; no exterior view is assumed at X54 and no wall window is cut through unverified neighbours.

## Actual reference study

Actual images were opened at full size during this assignment:

- **REF-f84205f20a**, `BlenderCatalogue/references/botanical/atrium_reference.png`: branching hierarchy; distinct canopy/shrub/groundcover scales; planted social edges; thick frames; gaps through planting that reveal destinations. Apply those relationships at this section's single-deck scale. Its giant tree, waterfall and transparent top are not dimensional authority.
- **REF-be035845a6**, `DesignArchive/References/Historical_Concepts_And_Blueprints/Futuristic Luxury Space Atrium Garden.png`: continuous framed garden edges, plants integrated with inhabited pockets. The displayed source is visually very similar to the botanical cutaway; it is not counted as an independent dimensional corroboration.
- **REF-48fd2aa4fe**, `DesignArchive/References/Historical_Concepts_And_Blueprints/image-gen-3.png`: public/service route distinction and clustered botanical grouping. Conflicting printed botanical decks 9-11, 28m height, 40m diameter and 200 plant-species labels remain historical illustrative conflicts; this package does not adopt them over D06 and its 8.5m datum interval.
- **Owner retro atrium benchmark**, `Game/docs/references/cruise_atrium_20261006/retro_atrium_quality_benchmark.png`: substantial piers, deep reveals, materially rich edges and fixture-backed warm light. Apply original low-poly construction and the existing presentation pipeline, not crystal complexity, crowds or photoreal gloss.

The supplied sources guide architectural composition. None are shipped as production textures or presented as construction screenshots.

## Interfaces requiring Higgins's current brief

1. Confirm live allocation, retained child-space requirements and occupied neighbour boundaries. Current plan assumes the historical 46x68m envelope only.
2. Higgins current portal is **(8,27,-456)**. The proposed opening is4.2m clear with3.6m height target. Built axial floor ends at X4; the4m X4..8 receiving link is **UNBUILT and parent-owned**. This package does not extend across it or edit any core sidewall.
3. Confirm service receiving route. Future north service interface is **(50,27,-466)**,3.6m clear; it remains **sealed** in the source candidate. The retained starboard service riser near X25/Z-490 does not prove a corridor to it. No external link is authored here.
4. Resolve need and receiving endpoint for a second guest/egress connection; provisional west point **(8,27,-407)** is uncut and uncounted.
5. Confirm floor/compiler ownership, shell ownership, slab underside, roof member bearings and service-zone depth. No duplicate walkable slab should be exported.
6. Confirm door leaf/pocket/control ownership and cart/species envelopes. Opening widths are geometric targets, not acceptance.
7. Agree ventilation, containment, planter maintenance and drainage provisions without adding new biology or deep service simulation.
8. Reserve catalogue identity and accept the support/fixture composition before geometry/export.

## Next-stage evidence

After the interface hold is released: retain editable native meshes and approved portable materials; derive bounded exports; independently reload sources; evaluate actual GLB transforms, bounds, UV/normals, shared instances and missing resources; exclude preview floor slabs; check full planting/fixture/structure envelopes against public and care routes. Review ordinary-height source views, supported ceiling joints and fixture mounts with exact source/export/capture hashes.

Higgins's integration must then prove actual supported public and loaded-cart travel, environmental boundaries, real door controls and ordinary in-game reference comparison. This first-stage proposal establishes none of those downstream passes.

## Current Higgins handoff applied

Read `../HIGGINS_CURRENT_HANDOFF.txt`. Final construction namespace is `external_packages/windows/WP03_D06_directory_02/`; this folder is the provisional design packet only. Public arrival moved to the current portal at local u0/v10. All future external service/secondary exits stay sealed. Candidate floor ownership remains with parent integration.

The complete first pass must include supported useful planted seats, care/storage/work furnishings, legible signs, approved material textures and effective visibly mounted fixtures. Artificial daylight comes from actual modeled ceiling cassettes; source appearance cannot rely on an unexplained ambient wash. Furniture support, care reach and plant maintenance paths are acceptance checks. No programme occupancy is invented.

Also opened full-size reference O, `DesignArchive/References/Uploaded_46/02/image(1).png` (REF-3813a0ecc3): its deck index puts botanical/hydroponics/nature on D06; its illustrative skylight and historical capacity labels do not authorize new openings or capacity. Current source-manifest hashes and required historical atlas page08 pixels remain to be verified when received through the parent.

`plan_section.svg` is the dimensioned proposal overview; `plan_screen.json` records a bounded2D check of route width targets against proposed piers and planter footprints. The minimum gap is not a general accessibility or runtime pass; actual fixtures, seats, foliage, doors, structures and body/cart motion need later checks.


Construction release: revision2 confirms WP03. Native hashes verified and bundled; source scripts prepared for scheduled build. Read BUILD_AND_REVIEW.md for current stage, commands and limitations. Earlier hold language describes plan history only.
