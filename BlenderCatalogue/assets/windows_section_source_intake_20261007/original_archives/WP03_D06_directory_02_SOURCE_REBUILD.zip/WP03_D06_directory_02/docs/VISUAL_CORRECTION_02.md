# Source visual correction 02 — prepared, rerender pending

Inspected actual SOURCE_ONLY arrival, grove, activity, quiet and care renders. The earlier source build/export/native checks passed their technical scope, but these images fail first-pass visual acceptance.

1. Growing medium was hidden beneath full coping discs. Replaced discs with genuinely open annular coping, retaining sealed planter bases and visible dark textured soil. Root support stays at soil Y offsets0.52/1.12; edge conflicts with the raised central island are avoided.
2. Planted islands were too sparsely populated. Added deterministic irregular groundcover, understory and flowering groups across the soil, plus several retained unscaled canopy specimens. The original island bounds, continuous public loops, opaque lit ceiling and frame supports remain unchanged. No new biology, giant tree, skylight or off-allocation planting is added.
3. Floating/reversed signage was unacceptable. Added actual mounted/backed sign panels, floor-supported wayfinding posts and contact shoes. Corrected text axes so local glyph-up is global vertical; guest-facing signs are upright. Wall signs bear directly on modeled returns.
4. Quiet camera looked directly at a pier; care camera showed a route rather than the work area. Reframed quiet toward actual supported seats and planting, added quiet_garden as the inward view, and moved care to the furnished north stock/work area. care_route retains the route view separately. No geometry is hidden for these ordinary-height views.
5. Confirmed support area is modeled: shelves, stock containers, supported worktop, return bay and internal aperture. Moved worktop0.7m north so its back edge stays outside the nominal3.6m cross-route at v7. Exterior service links remain sealed.

The revised generator passes syntax checking only. Parent must rebuild, rerun actual source/export checks and inspect new images. Suggested review set: arrival grove activity quiet quiet_garden care mounts. Previous pictures are preserved separately by the coordinator; current geometry/script revision invalidates their acceptance relevance.
