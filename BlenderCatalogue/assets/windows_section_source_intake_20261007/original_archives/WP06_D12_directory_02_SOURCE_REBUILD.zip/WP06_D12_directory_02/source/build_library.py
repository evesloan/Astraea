"""WP06 isolated complete library source candidate. Blender 4.3.2, no shared writes.
Usage: blender -b -t 4 --python build_library.py -- --build
Then: blender -b source/WP06_long_library.blend -t 4 --python build_library.py -- --render
Local plan u,v becomes Blender (u,-v,h); GLB (u,h,v), placement [8,78,-466].
"""
import bpy, math, json, hashlib, shutil, sys, random
from pathlib import Path
from mathutils import Vector, Matrix

ROOT=Path(__file__).resolve().parents[1]
SHIP=ROOT.parents[2]
CAT=SHIP/'BlenderCatalogue'
for p in ['source','exports','assets/components','assets/textures','tests','docs/views']:
    (ROOT/p).mkdir(parents=True,exist_ok=True)
SNAP=ROOT/'docs/coordination_snapshot.json'
ROW=next(r for r in json.loads(SNAP.read_text())['rows'] if r['package']=='WP06')
SHA=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,v): (ROOT/p).write_text(json.dumps(v,indent=2),encoding='utf8')
def xyz(u,v,h): return (u,-v,h)
def matrix(u,v,h=0,yaw=0):
    return Matrix.Translation(Vector(xyz(u,v,h))) @ Matrix.Rotation(math.radians(yaw),4,'Z')
PROT={}; INST=[]; CONTACT=[]; LIGHTS=[]; MAT={}

def material(name,color,rough=.7,metal=0,pattern=False):
    m=bpy.data.materials.new('WP06_'+name); m.use_nodes=True
    p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1)
    p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal
    if pattern:
        im=bpy.data.images.new('WP06_'+name+'_64',64,64); random.seed(name); px=[]
        for y in range(64):
            for x in range(64):
                f=.88+.18*random.random()
                if name=='walnut':f*=.88 if x%13 in [0,1] else 1
                if name=='fabric':f*=.90 if (x+y)%4==0 else 1
                px.extend([min(1,c*f) for c in color]+[1])
        im.pixels=px;im.filepath_raw=str(ROOT/'assets/textures'/f'{name}.png');im.file_format='PNG';im.save();im.pack()
        n=m.node_tree.nodes.new('ShaderNodeTexImage');n.image=im;n.interpolation='Closest'
        m.node_tree.links.new(n.outputs['Color'],p.inputs['Base Color'])
    MAT[name]=m;return m
def mesh_obj(name,verts,faces,mat):
    me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.materials.append(MAT[mat]);me.update()
    uv=me.uv_layers.new(name='WP06_metric_uv')
    for face in me.polygons:
        for li in face.loop_indices:
            p=me.vertices[me.loops[li].vertex_index].co
            uv.data[li].uv=(p.x/3,p.y/3) if abs(face.normal.z)>.8 else ((p.x+p.y)/3,p.z/3)
    o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o);o['package']='WP06';return o
def box(name,u,v,h,w,d,z,mat='ivory',bevel=.025):
    bpy.ops.mesh.primitive_cube_add(size=1,location=xyz(u,v,h));o=bpy.context.object;o.name=name;o.dimensions=(w,d,z)
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(MAT[mat]);o['package']='WP06'
    if bevel:
        b=o.modifiers.new('crafted_edge','BEVEL');b.width=bevel;b.segments=2
        o.modifiers.new('weighted_corner_normals','WEIGHTED_NORMAL')
    return o
def beam(name,a,b,width,depth,mat='walnut'):
    av=Vector(xyz(*a));bv=Vector(xyz(*b));delta=bv-av
    o=box(name,0,0,0,width,depth,delta.length,mat)
    o.location=(av+bv)/2;o.rotation_euler=delta.to_track_quat('Z','Y').to_euler();return o
def curveband(name,cx,cy,rx,ry,a0,a1,h,thickness,height,mat='walnut',steps=24):
    vs=[]
    for i in range(steps+1):
        a=math.radians(a0+(a1-a0)*i/steps)
        for z in [h-height/2,h+height/2]:
            for t in [-thickness/2,thickness/2]:vs.append(xyz(cx+(rx+t)*math.cos(a),cy+(ry+t)*math.sin(a),z))
    fs=[]
    for i in range(steps):
        j=i*4;k=j+4;fs += [(j,k,k+1,j+1),(j+2,j+3,k+3,k+2),(j,j+2,k+2,k),(j+1,k+1,k+3,j+3)]
    fs += [(0,1,3,2),(steps*4,steps*4+2,steps*4+3,steps*4+1)]
    return mesh_obj(name,vs,fs,mat)
def sign(name,text,u,v,h,width=3,yaw=0):
    # Native text front normal toward +v, readable from negative? front faces Blender -Y.
    plate=box(name+'_plaque',u,v,h,width,.12,.48,'teal',.05)
    bpy.ops.object.text_add(location=xyz(u-width*.44,v+.065,h-.12))
    o=bpy.context.object;o.name=name+'_lettering';o.data.body=text;o.data.size=.23;o.data.extrude=.002
    o.rotation_euler=(math.pi/2,0,0);o.data.materials.append(MAT['brass'])
    if yaw:
        pivot=Vector(xyz(u,v,h));R=Matrix.Rotation(math.radians(yaw),4,'Z')
        for q in [plate,o]:q.matrix_world=Matrix.Translation(pivot)@R@Matrix.Translation(-pivot)@q.matrix_world
    return o
def spot(name,u,v,h,power=2600,angle=145,color=(1,.78,.53),target=None):
    l=bpy.data.lights.new(name,'SPOT');l.energy=power;l.color=color;l.spot_size=math.radians(angle);l.spot_blend=.7;l.shadow_soft_size=.35
    o=bpy.data.objects.new(name,l);bpy.context.collection.objects.link(o);o.location=xyz(u,v,h)
    if target:o.rotation_euler=(Vector(xyz(*target))-o.location).to_track_quat('-Z','Y').to_euler()
    LIGHTS.append({'id':name,'position_blender':list(o.location),'watts':power,'fixture':name.replace('_light','')});return o
def fixture(u,v,h=4.35):
    key=f'WP06_CEILING_{u}_{v}'
    box(key+'_mount',u,v,4.69,.46,.46,.12,'brass')
    box(key+'_stem',u,v,(4.63+h+.12)/2,.08,.08,4.63-h-.12,'brass',0)
    box(key+'_housing',u,v,h+.1,1.5,.6,.24,'teal',.09)
    box(key+'_lens',u,v,h-.025,1.34,.45,.025,'glow',0)
    spot(key+'_light',u,v,h-.05)
    # Integral angled upper apertures wash the closed ceiling from real fixtures.
    # Their light origins sit outside the opaque case, never inside self-shadowing glass.
    for side in [-1,1]:
        box(key+f'_upper_aperture_{side}',u,v+side*.305,h+.15,1.2,.035,.10,'glow',0)
        spot(key+f'_upper_{side}_light',u,v+side*.33,h+.21,650,145,target=(u,v+side*3.5,4.86))

def pier_sconce(u,v,side):
    key=f'PIER_{u}_{v}_{side}'
    box(key+'_wall_plate',u,v+side*.29,3.15,.34,.09,.64,'brass')
    box(key+'_housing',u,v+side*.38,3.15,.42,.18,.58,'teal')
    box(key+'_opal_face',u,v+side*.48,3.15,.32,.022,.44,'glow',0)
    spot(key+'_light',u,v+side*.51,3.18,400,150,target=(u,v+side*4,4.0))
def prototype(rec):
    src=ROOT/'assets/components'/Path(rec['source']).name
    assert SHA(src)==rec['source_sha256_current'],f'Wrong source {src}'
    dest=ROOT/'assets/components'/src.name
    if not dest.exists():shutil.copy2(src,dest)
    with bpy.data.libraries.load(str(src),link=False) as (a,b):b.objects=a.objects
    objs=[]
    for o in b.objects:
        if o and o.type in ['MESH','FONT','CURVE']:
            bpy.context.collection.objects.link(o);objs.append(o)
    bpy.ops.object.select_all(action='DESELECT')
    for o in objs:o.select_set(True)
    bpy.context.view_layer.objects.active=objs[0];bpy.ops.object.convert(target='MESH');bpy.ops.object.join()
    o=bpy.context.object
    # bake actual component coordinates, with prototype origin at source zero
    o.data.transform(o.matrix_world);o.matrix_world=Matrix.Identity(4)
    PROT[rec['id']]=o.data;bpy.data.objects.remove(o,do_unlink=True)
def component(id,u,v,h=0,yaw=0,tag=None):
    name=tag or f'{id}__{len(INST):04d}';o=bpy.data.objects.new(name,PROT[id]);bpy.context.collection.objects.link(o);o.matrix_world=matrix(u,v,h,yaw)
    o['parent_catalogue_id']=id;o['package']='WP06';INST.append({'name':name,'catalogue_id':id,'matrix_blender':[list(r) for r in o.matrix_world]});return o
def at_matrix(id,T,name):
    o=component(id,0,0,tag=name);o.matrix_world=T;INST[-1]['matrix_blender']=[list(r) for r in T];return o
def stocked_shelf(u,v,yaw=0,kind='AST-LIB-STR-001'):
    o=component(kind,u,v,yaw=yaw); anchors=json.loads((ROOT/'assets/stock_anchors.json').read_text())['assets'][kind]
    # All seven shelves receive exact stock anchors. Reuse linked evaluated stock meshes.
    for i,a in enumerate(anchors):
        p=a['position_m'];T=o.matrix_world@Matrix.Translation(Vector(p))@Matrix.Rotation(math.radians(a.get('rotation_z_degrees',0)),4,'Z')
        at_matrix('AST-LIB-006',T,o.name+f'_stock_{i:02d}')
        CONTACT.append({'kind':'stock_shelf','name':o.name+f'_stock_{i:02d}','support':o.name,'source_anchor':p})
    if kind=='AST-LIB-STR-001':
        # Cornice-mounted projecting bookface fixture: attached arm, actual diffuser,
        # then broad source just beyond that diffuser, aimed at lower and middle stock.
        for suffix,p,d,mat in [
            ('backplate',(1.2,-.03,3.09),(.28,.10,.24),'brass'),
            ('cantilever',(1.2,-.55,3.09),(.09,1.04,.09),'brass'),
            ('housing',(1.2,-1.08,3.04),(1.8,.20,.16),'teal'),
            ('diffuser',(1.2,-1.07,2.951),(1.66,.15,.015),'glow')]:
            q=box(o.name+'_'+suffix,0,0,0,*d,mat)
            q.matrix_world=o.matrix_world@Matrix.Translation(Vector(p))
        p=o.matrix_world@Vector((1.2,-1.07,2.929));t=o.matrix_world@Vector((1.2,-.14,1.35))
        spot(o.name+'_bookface_light',p.x,-p.y,p.z,190,115,target=(t.x,-t.y,t.z))
        CONTACT.append({'kind':'bookface_fixture_mount','fixture':o.name+'_housing','support':o.name,'source_backplate':[1.2,-.03,3.09]})
    return o
def study(u,v,shared=True,yaw=0):
    id='AST-LIB-STUDY-01' if shared else 'AST-LIB-STUDY-02';o=component(id,u,v,yaw=yaw)
    mounts=[(0,0,.754)] if shared else [(-.433,.286,.756)]
    for p in mounts:
        T=o.matrix_world@Matrix.Translation(Vector(p));f=at_matrix('AST-LIB-008',T,o.name+'_task_fixture')
        q=T@Vector((0,-.041,.393));spot(o.name+'_task_light',q.x,-q.y,q.z,38,112)
        # Small visible emission lens only at existing lower diffuser face.
        q2=T@Vector((0,-.041,.400));lens=box(o.name+'_emitting_lens',q2.x,-q2.y,q2.z,.066,.055,.002,'glow',0)
        CONTACT.append({'kind':'fixture_receiver','fixture':f.name,'support':o.name,'receiver_blender_source':p})
    seats=[(-.55,-1.035,180),(.55,-1.035,180),(-.55,1.035,0),(.55,1.035,0)] if shared else [(.105,-.99,180)]
    for i,(x,y,a) in enumerate(seats):at_matrix('AST-FUR-002',o.matrix_world@Matrix.Translation(Vector((x,y,0)))@Matrix.Rotation(math.radians(a),4,'Z'),o.name+f'_seat{i}')
    at_matrix('AST-LIB-007',o.matrix_world@Matrix.Translation(Vector((-.45,0,.75))),o.name+'_folio') if shared else None
    return o

def build():
    bpy.ops.wm.read_factory_settings(use_empty=True);sc=bpy.context.scene;sc.unit_settings.system='METRIC'
    material('ivory',(.53,.46,.34),pattern=True);material('walnut',(.22,.095,.035),pattern=True)
    material('stone',(.3,.29,.24),pattern=True);material('teal',(.045,.12,.12));material('fabric',(.1,.23,.2),pattern=True)
    material('brass',(.47,.28,.10),.32,.65);material('service',(.24,.29,.29),pattern=True)
    glow=material('glow',(1,.67,.30));p=glow.node_tree.nodes.get('Principled BSDF');p.inputs['Emission Color'].default_value=(1,.66,.29,1);p.inputs['Emission Strength'].default_value=3
    for rec in ROW['asset_sources']:prototype(rec)
    # Separate source-only floor (no competing live floor/slab). One surface, no layered rugs.
    floor=box('SOURCE_PREVIEW_ONLY_floor',23,34,-.075,46,68,.15,'stone',0);floor['exclude_architecture_export']=True
    # Opaque enclosing perimeter; only proposed west portal remains open.
    for u,v,w,d in [(23,.2,46,.4),(23,67.8,46,.4),(45.8,34,.4,68),(.2,4,.4,8),(.2,40,.4,56)]:box('PERIMETER_opaque',u,v,2.6,w,d,5.2,'ivory',0)
    box('PORTAL_lintel',.55,10,4.2,1.1,4,2,'walnut');box('PORTAL_reveal_a',.65,7.8,1.6,1.3,.4,3.2,'walnut');box('PORTAL_reveal_b',.65,12.2,1.6,1.3,.4,3.2,'walnut')
    # Continuous top panels, explicit beams and piers; lower arrival soffit returns into partitions.
    box('ROOF_closed_assembly',23,34,5.05,45.2,67.2,.3,'ivory',0)
    box('ARRIVAL_suspended_panel',15.4,7.4,3.30,29.4,13.4,.20,'walnut')
    for u in [1,17,32,44.7]:
        for v in [15.2,31,47,65.8]:
            box('PIER_bearing_plinth',u,v,.12,.78,.78,.24,'stone');box('PIER_load_core',u,v,2.46,.52,.52,4.68,'ivory');box('PIER_capital',u,v,4.77,.95,.95,.25,'walnut')
            for side in [-1,1]:pier_sconce(u,v,side)
    for v in [15.2,23,31,39,47,55,65.8]:
        box('BEAM_cross_bearing',23,v,4.74,45.2,.42,.38,'walnut')
        for u in [7,22.5,37]:fixture(u,v)
    for u in [1,17,32,44.7]:box('BEAM_longitudinal',u,34,4.72,.42,66,.36,'walnut')
    # Low arrival has perimeter bearing closure and independent visible luminaires.
    for u in [5,13,22,28]:
        box('ARRIVAL_light_mount',u,8,3.14,.3,.3,.12,'brass')
        box('ARRIVAL_light_stem',u,8,2.99,.06,.06,.30,'brass')
        box('ARRIVAL_pendant_housing',u,8,2.81,1.4,.52,.16,'teal')
        box('ARRIVAL_lens',u,8,2.72,1.22,.38,.015,'glow',0)
        spot(f'ARRIVAL_{u}_light',u,8,2.70,900,145)
        for side in [-1,1]:
            box('ARRIVAL_upper_lens',u,8+side*.27,2.83,1.16,.025,.09,'glow',0)
            spot(f'ARRIVAL_{u}_upper_{side}_light',u,8+side*.29,2.86,330,145,target=(u,8+side*2.0,3.195))
    # Orientation and screened return suite. No unbuilt external door implied.
    component('AST-LIB-012',12,5,yaw=0,tag='ORIENTATION_crescent_counter')
    component('AST-LIB-010',7,5,tag='CATALOGUE_find_a_book')
    component('AST-LIB-009',21,5,tag='PERIODICALS_arrival')
    component('AST-LIB-009',24,5,tag='PERIODICALS_arrival_b')
    sign('ARRIVAL_title','THE LONG LIBRARY',12,2.5,2.7,5.3)
    sign('ARRIVAL_direction','READ / STUDY / DISCOVER',23,13,2.7,5)
    box('CARE_screen_west',31.2,6.8,1.8,.4,12.8,3.6,'service')
    box('CARE_north_screen',40.9,15,1.8,9.4,.4,3.6,'service')
    box('CARE_return_baffle',34.5,11.5,1.6,3.5,.35,3.2,'walnut')
    box('CARE_ceiling',38.5,7,3.7,13.8,13.2,.2,'service')
    for u in [34,40,44]:
        box('CARE_fixture_mount',u,7,3.57,1.2,.3,.12,'service');box('CARE_fixture_diffuser',u,7,3.50,1.05,.23,.02,'glow',0);spot(f'CARE_{u}_light',u,7,3.47,900,140,(.83,.9,1))
    for v in [3,6,9]:
        for h in [.3,.8,1.3,1.8]:box('CARE_stock_shelf',44.7,v,h,.65,2.2,.07,'service')
        box('CARE_stock_back',45.2,v,1.1,.12,2.25,2.2,'service')
        for h in [.50,1.00,1.50]:box('CARE_sorted_box',44.7,v,h,.5,1.4,.32,'teal')
    box('CARE_worktop',38,2,.9,5.5,1,.12,'walnut')
    for u in [35.6,40.4]:box('CARE_worktop_support',u,2,.42,.25,.8,.84,'service')
    # Neutral practical task sources mounted to the care ceiling above the worktop.
    for u in [36.5,39.5]:
        key=f'CARE_WORKTASK_{u}'
        box(key+'_ceiling_plate',u,2,3.56,.28,.28,.08,'service')
        box(key+'_stem',u,2,3.22,.06,.06,.60,'service')
        box(key+'_hood',u,2,2.87,1.3,.36,.16,'service')
        box(key+'_diffuser',u,2,2.78,1.16,.25,.016,'glow',0)
        spot(key+'_light',u,2,2.76,180,110,(.89,.94,1),target=(u,2,.96))
        CONTACT.append({'kind':'care_task_mount','fixture':key+'_hood','support':'CARE_ceiling','mount_local_uvh':[u,2,3.6]})
    # Shelf-back anchored cantilevers give stock faces their own visible source.
    for v in [3,6,9]:
        key=f'CARE_STOCKTASK_{v}'
        box(key+'_back_plate',45.1,v,2.07,.08,.25,.25,'service')
        box(key+'_arm',44.55,v,2.13,1.05,.065,.065,'service')
        box(key+'_hood',44,v,2.09,.35,.7,.14,'service')
        box(key+'_diffuser',44,v,2.008,.25,.56,.016,'glow',0)
        spot(key+'_light',43.98,v,1.986,120,110,(.89,.94,1),target=(44.72,v,1.06))
        CONTACT.append({'kind':'care_stock_mount','fixture':key+'_hood','support':'CARE_stock_back','mount_local_uvh':[45.1,v,2.07]})
    for u in [34,37]:
        box('RETURNS_bin_body',u,5,.58,1.8,1.2,1.05,'teal');box('RETURNS_bin_slot',u,5.61,.93,1.45,.035,.16,'walnut')
    sign('RETURNS_sign','RETURN / SORT',35.5,6.0,1.8,4)
    # Parked nonfunctional trolley with real shelf support and wheels, isolated within care.
    for h in [.3,.85]:box('CARE_trolley_shelf',37,10,h,1.25,.75,.08,'service')
    for u in [36.47,37.53]:
        for v in [9.7,10.3]:
            box('CARE_trolley_upright',u,v,.58,.06,.06,.72,'brass')
            bpy.ops.mesh.primitive_cylinder_add(vertices=12,radius=.13,depth=.07,location=xyz(u,v,.14),rotation=(math.pi/2,0,0));bpy.context.object.name='CARE_trolley_wheel';bpy.context.object.data.materials.append(MAT['teal'])
    # Book-lined western sequence, and intermediate returns create sheltered reading niches.
    for start,count in [(20,5),(36,4),(48,4)]:
        for i in range(count):stocked_shelf(2.0,start+2.4*i,90)
    # Curved approved components supply real end conditions and framing into the study hall.
    for v in [21,36,48]:
        stocked_shelf(8,v,0,'AST-LIB-STR-002');component('AST-LIB-STR-003',10,v-1.8,yaw=90)
    for v in [23,30,37,44]:
        study(42,v,False,-90)
        stocked_shelf(44.3,v+3.3,-90)
    # Shared table islands: arranged around open lateral approaches, not random props.
    for u in [22,29]:
        for v in [23,30,37]:study(u,v,True)
    sign('SHARED_identity','SHARED STUDY',25,18,3.2,4)
    # West reading pockets grounded in curved side screens; independent front approach.
    for v in [25,40,57,63]:
        curveband('RECESS_thick_back',6,v,3,2.4,20,160,1.6,.35,3.2,'walnut',16)
        component('AST-FUR-002',5.2,v,yaw=25);component('AST-FUR-002',7.2,v,yaw=-25)
        box('RECESS_table_base',6.2,v-1.3,.27,.6,.6,.54,'walnut');box('RECESS_table_top',6.2,v-1.3,.57,1.2,.8,.12,'ivory')
        box('RECESS_task_bracket',6,v+2.2,2.4,.35,.3,.2,'brass');box('RECESS_task_lens',6,v+2.2,2.28,.22,.2,.03,'glow',0)
        spot(f'RECESS_{v}_light',6,v+2.2,2.24,85,100,target=(6,v,.6))
    # The oval end is visibly a separate reading room, with two broad openings.
    for a,b in [(15,145),(195,325)]:
        curveband('OVAL_enclosing_book_back',26,57,10,8,a,b,1.6,.3,3.2,'walnut',26)
        for h in [.35,.82,1.29,1.76,2.23,2.7]:curveband('OVAL_supported_shelf',26,57,9.7,7.7,a,b,h,.65,.07,'walnut',26)
        curveband('OVAL_canopy_closed_soffit',26,57,9.6,7.6,a,b,3.3,1.3,.25,'ivory',26)
        for theta in range(a+5,b,12):
            t=math.radians(theta);u=26+9.7*math.cos(t);v=57+7.7*math.sin(t)
            box('OVAL_shelf_bearing',u,v,1.65,.15,.15,3.3,'brass')
            for h in [.385,.855,1.325,1.795,2.265]:
                component('AST-LIB-006',u,v,h,yaw=theta-90,tag=f'OVAL_stock_{theta}_{h}')
        for theta in range(a+12,b,26):
            t=math.radians(theta);u=26+8.9*math.cos(t);v=57+6.9*math.sin(t)
            # Bearing arm reaches from shelf canopy to inward-facing stock-wash hood.
            beam('OVAL_fixture_arm',(26+9.6*math.cos(t),57+7.6*math.sin(t),3.23),(u,v,3.23),.08,.08,'brass')
            box('OVAL_fixture_hood',u,v,3.18,.5,.5,.13,'teal')
            box('OVAL_fixture_lens',u,v,3.105,.38,.38,.014,'glow',0)
            spot(f'OVAL_{theta}_bookface_light',u,v,3.084,145,120,target=(26+9.7*math.cos(t),57+7.7*math.sin(t),1.55))
    sign('QUIET_identity','QUIET READING',26,48.5,3.4,4.6)
    for u,v in [(22,54),(30,54),(22,60),(30,60)]:
        component('AST-FUR-002',u-1.2,v,yaw=-35);component('AST-FUR-002',u+1.2,v,yaw=35)
        box('READING_table_pedestal',u,v+1,.31,.4,.4,.62,'walnut');box('READING_table_surface',u,v+1,.66,1.5,.9,.08,'ivory')
        component('AST-LIB-007',u,v+1,.70)
    # Light beyond the book ring remains physically mounted to ceiling structure.
    for u,v in [(22.5,55),(37,55),(22.5,65.8)]: pass
    # Contact markers have no visual/collision mass.
    for name,p in [('PORTAL_DATUM',(0,10,0)),('FLOOR_DATUM',(23,34,0)),('CARE_APPROACH',(33.5,15,0))]:
        o=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(o);o.location=xyz(*p);o['marker_only']=True
    # Source render configuration: no invisible general-purpose fill lights.
    sc.render.engine='CYCLES';sc.cycles.samples=24;sc.cycles.use_denoising=True
    sc.world=bpy.data.worlds.new('WP06_low_ambient_world');sc.world.use_nodes=True;sc.world.node_tree.nodes['Background'].inputs[0].default_value=(.12,.16,.20,1);sc.world.node_tree.nodes['Background'].inputs[1].default_value=.06
    sc.render.resolution_x=1280;sc.render.resolution_y=720;sc.render.resolution_percentage=100
    sc.view_settings.view_transform='AgX';sc.view_settings.look='AgX - Medium High Contrast';sc.view_settings.exposure=1.3
    # Copy/export each image, retaining portable embedded copies as well as editable sources.
    for im in bpy.data.images:
        if im.type=='IMAGE' and im.size[0]>0:
            safe=''.join(c if c.isalnum() or c in '._-' else '_' for c in im.name)
            try:im.filepath_raw=str(ROOT/'assets/textures'/(safe+'.png'));im.file_format='PNG';im.save();im.pack()
            except Exception as e:print('IMAGE_PRESERVE_WARNING',im.name,str(e))
    bpy.context.view_layer.update()
    checks=audit_source();dump('tests/source_geometry.json',checks)
    assert checks['bounds_pass'],checks['intrusions'][:5]
    bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'source/WP06_long_library.blend'))
    bpy.ops.object.select_all(action='DESELECT')
    for o in sc.objects:
        if o.type in ['MESH','FONT','CURVE','LIGHT','EMPTY'] and not o.get('exclude_architecture_export'):o.select_set(True)
    bpy.ops.export_scene.gltf(filepath=str(ROOT/'exports/WP06_long_library.glb'),export_format='GLB',use_selection=True,export_yup=True,export_extras=True,export_lights=True)
    dump('exports/floor_contact_proposal.json',{'ownership':'Higgins compiler pending','programme':'D12_directory_02','frame':'Godot world metres Y-up','polygon_xz':[[8,-466],[54,-466],[54,-398],[8,-398]],'finished_y':78,'floor_geometry_in_architecture_glb':False,'source_preview_slab_excluded':True,'lower_slab_limit':None})
    dump('exports/manifest.json',{'programme':'D12_directory_02','alias':'D12_library1','status':'source candidate; live acceptance pending','blender_version':bpy.app.version_string,'placement_godot':[8,78,-466],'axes':'Blender(u,-v,h) -> glTF(u,h,v); do not reconvert GLB','source_sha256':SHA(ROOT/'source/WP06_long_library.blend'),'glb_sha256':SHA(ROOT/'exports/WP06_long_library.glb'),'sources':ROW['asset_sources'],'instances':INST,'contacts':CONTACT,'lights':LIGHTS,'floor':'floor_contact_proposal.json','geometry':checks,'pending':['independent visual review','live integration','cart controls','species fit','NPC/library interaction','runtime light budget']})
    print('WP06_BUILD_COMPLETE',len(INST),'instances')

def audit_source():
    lo=Vector((1e9,1e9,1e9));hi=Vector((-1e9,-1e9,-1e9));bad=[];count=0;tri=0;deps=bpy.context.evaluated_depsgraph_get()
    for o in bpy.context.scene.objects:
        if o.type!='MESH' or o.get('exclude_architecture_export'):continue
        e=o.evaluated_get(deps);pts=[e.matrix_world@Vector(p) for p in e.bound_box]
        for p in pts:
            for j in range(3):lo[j]=min(lo[j],p[j]);hi[j]=max(hi[j],p[j])
        if any(p.x<-.002 or p.x>46.002 or p.y< -68.002 or p.y>.002 or p.z<-.003 or p.z>5.202 for p in pts):bad.append(o.name)
        count+=1
        me=e.to_mesh();me.calc_loop_triangles();tri+=len(me.loop_triangles);e.to_mesh_clear()
    return {'bounds_blender':[list(lo),list(hi)],'bounds_pass':not bad,'intrusions':bad,'mesh_objects':count,'triangles':tri,'floor_excluded':True,'source_only':True,'live_clearance_claim':False}

def render():
    sc=bpy.context.scene
    # Quiet enters through the actual western gap in its elliptical bookshelves.
    # Care camera follows the open dogleg past the returns baffle, inside its aisle.
    cams=[('01_arrival',(2,10,1.65),(17,13,1.9)),('02_shared_study',(16,20,1.65),(29,31,1.7)),('03_book_sequence',(14,38,1.65),(5,42,1.7)),('04_quiet_reading',(14,57,1.65),(27,57,1.7)),('05_sheltered_study',(37,32,1.65),(42,35,1.5)),('06_care',(38,12,1.65),(40,5,1.4))]
    selected=next((a.split('=',1)[1] for a in sys.argv if a.startswith('--view=')),None)
    if selected:
        cams=[c for c in cams if c[0]==selected]
        assert cams, f'Unknown view {selected}'
    records=[]
    for name,p,t in cams:
        origin=Vector(xyz(*p));direction=(Vector(xyz(*t))-origin).normalized()
        hit,location,normal,index,obj,mat=sc.ray_cast(bpy.context.evaluated_depsgraph_get(),origin,direction,distance=1.0)
        assert not hit, f'Camera {name} blocked within 1m by {obj.name}'
        d=bpy.data.cameras.new(name);o=bpy.data.objects.new(name,d);sc.collection.objects.link(o);o.location=xyz(*p);o.rotation_euler=(Vector(xyz(*t))-o.location).to_track_quat('-Z','Y').to_euler();d.lens=23;sc.camera=o
        sc.render.filepath=str(ROOT/'docs/views'/(name+'_SOURCE_ONLY.png'));bpy.ops.render.render(write_still=True)
        records.append({'view':name,'eye_local_uvh':p,'target':t,'source_only':True})
    if selected:
        old=ROOT/'docs/views/cameras.json'
        prior=json.loads(old.read_text()) if old.exists() else []
        records=[r for r in prior if r['view']!=selected]+records
    dump('docs/views/cameras.json',records)
    print('WP06_RENDERS_COMPLETE')

if '--build' in sys.argv:build()
elif '--render' in sys.argv:render()
elif '--audit' in sys.argv:dump('tests/source_reload_geometry.json',audit_source())
else:raise SystemExit('Specify --build / --render / --audit')
