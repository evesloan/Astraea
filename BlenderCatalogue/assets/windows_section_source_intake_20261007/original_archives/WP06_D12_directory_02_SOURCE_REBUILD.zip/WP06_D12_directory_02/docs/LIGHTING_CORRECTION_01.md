# Lighting correction 01 — actual source image review

Reviewed actual rendered `01_arrival`, `02_shared_study` and `03_book_sequence` pixels. The first pass fails: downlights leave the ceiling, bearing beams, book faces and enclosing walls nearly black; isolated bright floor/table pools do not make the library legible or welcoming.

Generator corrections:

- Ceiling fixtures now include modeled upper side apertures with actual angled ceiling-wash sources. Downward distribution widens from 110 to 145 degrees with larger sources and greater output for overlap across the broad bays.
- Bearing piers receive attached plate/housing/opal-face sconces illuminating upper walls, adjacent ceiling and vertical structure.
- Every straight bookshelf receives a cornice-mounted projecting bookface fixture, visibly supported by a cantilever arm and aimed toward middle/lower shelves.
- Oval book-room shelves receive bearing-mounted hood fixtures aimed at stock. Both the room destination and its collection should now be visible from the approach.
- Arrival fixtures become shallow, stem-supported dual-output pendants: broad downlight plus real light onto the low timber soffit.

Ambient world strength and camera exposure are unchanged. The correction does not use a free-floating fill lamp. Light counts and runtime budgeting remain explicit integration work, and the revised actual source images still require independent review. No claim of passing visual review is made by this patch.

Portability changes retained: current snapshot, native components and stock-anchor inputs resolve inside this package. Floor exclusion and placement remain unchanged. Parent must preserve the rejected images/logs before rebuilding and rerendering.

## Camera and approach correction

Also inspected actual 04/05/06 images. Quiet view04 looked into the opaque southern book arc; care view06 looked straight into the returns baffle. Relocated quiet eye to local [14,57,1.65] aiming through the real west opening along the central reading-room aisle; care eye to [38,12,1.65] on the inner side of the dogleg, looking into the work room. A pre-render forward-ray check rejects an opaque hit within 1m of each eye. No geometry is hidden for any of these views.

The main-loop reservation now passes through the quiet room's actual west/east gaps at localv57, between seat/table groups, instead of crossing its opaque north arc. The care baffle moves fromv12.3 tov11.5, providing 3.125m between its upper face and the north screen for the dogleg turn. These are geometric provisions; a live loaded-cart pass remains required.

View05 exposed east-edge shelves and study facing outwards: both rotate to source yaw−90, so stock faces and study approaches now face the library interior. This corrects the actual asset orientation, not merely the camera angle.
