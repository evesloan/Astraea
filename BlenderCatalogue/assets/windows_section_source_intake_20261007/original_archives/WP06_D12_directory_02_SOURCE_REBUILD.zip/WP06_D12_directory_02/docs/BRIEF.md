# WP06 — The long library

Status: **source design proposal; geometry held for current-input verification**. Dedicated owner: section_owner_06. Programme `D12_directory_02`; retained alias `D12_library1`. This is an isolated source package for Higgins, not an installed destination. No complete-room source assembly from Star Atlas, residential libraries or courts is reused.

## Authority and evidence

Read the complete chapter blocks and tables for master v0.3 chapters 4, 5, 19, 21 and 30 in `Game/docs/master_source/MASTER_FULL_CONTENT_INDEX.json`, and all current overrides in `MASTER_CURRENT_APPLICATION.json`. Binding applications: nonuniform datums and protected homes; ship/district/threshold/activity hierarchy; library recreation without invented gameplay; original low-poly forms, low-resolution authored materials, actual fixture light; reference composition rather than literal imported layouts. Historical implementation/capacity claims remain superseded where the current overlay says so.

Also read `ARCHITECTURAL_DELIVERY_RULES.md`, relevant whole-ship coordination, `BLUEPRINT_AMENITY_SCOPE_AUDIT.md` AME-066, `REFERENCE_APPLICATION_SETS.md`, catalogue `COORDINATE_CONTRACT.md`, and the current printed Higgins handoff. AME-066 establishes required programme, not a verified room. Atlas p14/directory02/drawing44 is a required current packet input; the old local atlas is not substituted for the requested verified packet.

Full-size actual pixels of all five library-set references and the retro benchmark were inspected. See `REFERENCE_EVIDENCE.md` and `local_input_receipts.json`. Local hash receipts establish bytes inspected, not correspondence to Higgins's current source packet. Construction remains held until the coordinator verifies that correspondence.

## Fixed allocation and interfaces

- Godot world, metres: X **8…54**, Z **−466…−398**; finished floor datum Y **78**; next datum Y **84**. Allocation is 46 × 68 m; it does not prescribe a rectangular interior.
- Below: Cinema 1; above: D13 protected residential allocations. No cuts, mezzanine, skylight, exterior window, floor extension or penetration into neighbours.
- Proposed portal centre **[8,78,−456]** on the west face. Proposed clear width **4 m**, height **3.2 m**, opening Z −458…−454. Reserve an interior arrival/turning zone X 8…18, Z −462…−450.
- The X4…8 receiving link is UNBUILT, Higgins-owned. This package stops at X8. The existing axial route and core shells are not edited. No live connected route is claimed.
- Staff use the internal screened return/care route. There is no invented external service connection; all external walls besides the proposed guest aperture remain opaque and closed.

## Architectural composition

**A sequence through a collection, ending in a shared reading room.** The library has a low, buffered entrance; a taller shared study room framed by curved bookshelves; and an oval quiet reading end. The full depth is legible through offset views and a continuous level loop. The rooms differ in orientation and overhead form instead of repeating a generic curved module.

1. **Quiet arrival and orientation**, X8.4…39, Z−465.6…−450: the entrance reveal opens onto a low, book-lined vestibule. The crescent orientation counter is visible without standing in the entrance path. A catalogue stand and low periodical browser provide useful threshold activity. A deep opaque screen conceals returns handling from the principal inward view.
2. **Collection and care**, X40…53.6, Z−465.6…−450: separate returned/unsorted storage, clean reshelving stock, work surface and parked trolley; an opaque dogleg screens the care point. Internal doors open into reserved approaches, never into the public loop. This is functional architectural provision, not an implemented lending system.
3. **The shared study room**, furniture zone X27…43, Z−446…−430: arranged study tables receive individually mounted task lamps and supported seats. Curved book bays form an inhabited west edge; an open internal view reaches the quiet end. Supported ceiling beams span between substantial bookcase piers and defined wall receivers.
4. **Book-lined browsing sequence**, X10…20, Z−448…−421: staggered short shelves and curved ends create short discoveries beside a broad longitudinal route. Books occupy usable shelves at reachable lower heights; upper architecture is enclosure, not falsely accessible stock.
5. **Sheltered study edge**, X49…53.5, Z−447…−421: shallow individual study niches face inward. Their fronts open onto the east return route. Exact seat and approach count is determined from verified components; no recovered venue capacity is invented.
6. **Quiet reading end**, X24…44, Z−418…−400: an oval, book-lined room gives the long sequence a clear destination. Low round reading recesses on the western edge and a few outward-facing shared seat groups have reachable tables and sightlines back into the library. The oval is a single-level enclosure with open entries; no upper ring or gallery.
7. **Low reading recesses**, X10…19, Z−417…−400: sheltered seats are integrated into thick curved book walls with visible bases, low task surfaces and accessible flat approaches. They are not assigned to children or a species by size. Body fit remains an explicit review gate.

The main circulation reservation is 3 m wide minimum at this proposal stage. Its loop runs from arrival along X22 into the north reading threshold, returns along X46, and reconnects at Z−451. It provides access to the collection, study and reading pockets and care room without using table/chair clearances as through traffic. Individual shelf browsing clearance target is 1.5 m; turning pockets target 3 × 3 m. These are geometric design targets pending checks against the current cart and guest envelopes, not accessibility certification.

## Vertical section and construction logic

All public walking and cart movement stays at Y78. Proposed arrival/reading recess soffit underside Y81.2; shared study underside Y82.55; upper enclosure top Y83.2. The 0.8 m interval to D13 is a **proposed untouched buffer**, not a verified interdeck structural reservation. The current-source packet must confirm overhead ownership before these values become geometry constraints.

The source ceiling will be a closed assembly: broad faceted timber panels on explicit ribs, ribs bearing into wall/bookcase piers, visible end blocks and defined soffit-to-wall terminations. No unsupported curved floating timber skin. Surface fixtures bolt to the ribs; task lamps mate with their actual receiver plates; service lights have visible brackets and housings. A source light accompanies each light-emitting housing. Lighting will be reviewed at ordinary arrival height with a low ambient contribution; emission alone cannot pass.

Floor ownership is **unresolved**. Candidate section proposal is a separately named finish/deck surface with top Y78 and provisionally 0.15 m depth below. This is not permission to intrude into Cinema 1. No floor is adopted, layered onto an existing compiler slab or exported for integration until Higgins assigns ownership and confirms its lower limit. Keep it independently removable if the receiving compiler owns the eventual floor. Walls and furniture reference the finished datum, not the bottom of this candidate slab.

## Component and material strategy

Use only coordinator-verified current copies of approved components: AST-LIB-STR-001/002/003 (readable shelf structures/end conditions), AST-LIB-STUDY-01/02 (shared/sheltered work surfaces), AST-LIB-006/007 (stock), AST-LIB-008 (housed task fixture), AST-LIB-009 (periodicals), AST-LIB-010 (catalogue stand), AST-LIB-012 (orientation counter), AST-FUR-002 and AST-LGT-001. The task fixture source datum is its contact plane; place it on the recorded receiver, not the floor. Shared study surfaces do not include seats; a proposed chair marker is not a supported seated pose.

Preserve source hashes, parent IDs and materials; keep any derivative within this package. Timber and quiet patterned fabric establish the reading zones, warm stone provides durable routes, ivory enamel and restrained champagne metal articulate structural ends and fixtures. Care storage uses practical muted panels. No change to shared materials or new catalogue registration. Texture detail must remain legible at the current 360p world render rather than becoming high-frequency noise.

## Verification and delivery gates

After construction release: deterministic Blender 4.3.2 authoring; editable native source; portable textures and GLB; named floor, contact, fixture and portal markers; manifest identifying local origin [8,78,−466] in Godot and explicit basis mapping. Blender local (x,y,z) maps to GLB (x,z,−y); source-world to engine conversion is performed exactly once.

Check all mesh bounds against allocation and approved vertical limits; structure/fixture contacts; each stocked shelf's support; chair/table access; light mount/receiver transforms; main loop and care turns; door sweeps; source/export correspondence and source reload. Preserve failed evidence. Schedule heavy jobs with coordinator.

Source-only review cameras: arrival [10,79.65,−456]; shared study [23,79.65,−442]; quiet end [22,79.65,−409]; sheltered edge [46,79.65,−438]; care [46,79.65,−454]; longitudinal section. Check deep reveals, ceiling terminations, effective fixture light, table reaches, opaque service screening and meaningful internal views. Final normal-arrival, cart/control, species fit, acoustics and CRT on/off checks remain Higgins's live integration gates.

## Unresolved before geometry release

Current row/reference/source hash packet; exact ceiling buffer and underside of D13-owned structure; floor/slab ownership and permitted lower bound; actual cart/guest design envelopes; exact service-door swings after component verification. These do not authorize speculative changes to protected space. The dimensions in `plan_contract.json` are reviewable proposals unless marked frozen.

