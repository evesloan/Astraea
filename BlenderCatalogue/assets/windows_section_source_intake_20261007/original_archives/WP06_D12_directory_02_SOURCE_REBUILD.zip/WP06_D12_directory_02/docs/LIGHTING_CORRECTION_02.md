# Care task lighting correction

Actual six-view review: parent accepted the five guest-area images as source-candidate evidence. This does not establish live integration or final ship acceptance. Actual care image06 still left the worktop and stock fronts too dark for useful service activity.

Generator now raises the three existing care ceiling fixtures from280W/115 degrees to900W/140 degrees, adds two ceiling-mounted neutral worktop task fixtures, and adds three stock-back-mounted cantilever task fixtures aimed at the shelf faces. Each source has an explicit housing, diffuser and physical supporting member. Guest geometry, guest lights, all cameras, global ambient and exposure are unchanged. New sources and supports remain entirely inside the care room.

The final-source hash necessarily changes; the parent should bind retained guest images to their previously reviewed source hash and record this localized care-only revision. They must not be falsely relabelled as newly rendered final-source images. New care-only evidence comes from the rebuilt source with the command suffix `-- --render --view=06_care`; the script preserves the other five camera records.

No heavy jobs were run by the section owner for this correction. Rebuild, source/export audit and care-image review remain required.
