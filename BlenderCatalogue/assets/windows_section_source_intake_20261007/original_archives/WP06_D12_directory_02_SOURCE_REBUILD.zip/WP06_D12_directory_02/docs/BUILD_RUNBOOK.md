# WP06 construction commands

Generator prepared; syntax compiled locally. Heavy build/export/render has not yet run. Parent schedules these commands and preserves output logs. No visual or source-export pass is claimed before actual results.

From `C:\Users\cered\Dolphin` in PowerShell:

```powershell
& '.\AstraeaTools\blender-4.3.2-windows-x64\blender.exe' -b -t 4 --python '.\AstraeaShip\external_packages\windows\WP06_D12_directory_02\source\build_library.py' -- --build
& '.\AstraeaTools\blender-4.3.2-windows-x64\blender.exe' -b '.\AstraeaShip\external_packages\windows\WP06_D12_directory_02\source\WP06_long_library.blend' -t 4 --python '.\AstraeaShip\external_packages\windows\WP06_D12_directory_02\source\build_library.py' -- --audit
python '.\AstraeaShip\external_packages\windows\WP06_D12_directory_02\tests\check_export.py'
& '.\AstraeaTools\blender-4.3.2-windows-x64\blender.exe' -b '.\AstraeaShip\external_packages\windows\WP06_D12_directory_02\source\WP06_long_library.blend' -t 4 --python '.\AstraeaShip\external_packages\windows\WP06_D12_directory_02\source\build_library.py' -- --render
```

The build verifies every native source against the exact-current snapshot, copies native components into package assets, appends and assembles only components, creates editable source, embeds/retains image textures, checks evaluated source bounds, exports GLB without floor geometry, and writes contacts/lights/instances/provenance manifests. Root must inspect assertions in the output even if Blender returns exit 0.

Expected outputs:

- `source/WP06_long_library.blend`
- `exports/WP06_long_library.glb`, `manifest.json`, `floor_contact_proposal.json`
- `tests/source_geometry.json`, `source_reload_geometry.json`, `glb_actual_check.json`
- `docs/views/01_arrival_SOURCE_ONLY.png` through `06_care_SOURCE_ONLY.png`, plus camera records.

GLB placement translation in Godot: **[8,78,−466]**, rotation identity, scale one. Local source Blender `(u,−v,h)` maps once through glTF export to `(u,h,v)`. Architecture is bounded to source X0…46/Y−68…0/Z0…5.2. Floor top at worldY78 remains a separate compiler-owned proposal; the native source's single preview slab is excluded from export. No second walkable surface is layered over it.

The ceiling uses closed panels, supported crossbeams and wall/bookcase bearing piers. Warm source light is physically mounted to ceiling fixtures, task-light receivers and recess brackets. No ambient directional lamp is used. The actual views must still establish that lighting and joins look correct. Library gameplay, live collisions/routes, body fits and runtime light-budget acceptance remain open.

Construction release supersedes the earlier geometry hold in the stage-one brief. Floor ownership convention likewise supersedes its provisional 0.15m candidate export suggestion: source-preview-only belowY78, with no floor mesh in architecture GLB. Exact-current architectural rules require complete first-pass presentation, which the generator targets; no successful generation or count alone establishes that it achieved it.
