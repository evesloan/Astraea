# WP06 reference inspection

Inspection: actual local image pixels opened at original detail on 6 October 2026. These are reference observations, not approval of modeled geometry. `local_input_receipts.json` records local byte hashes; current remote correspondence remains pending.

| Reference | Visible architectural evidence | Application / excluded detail |
|---|---|---|
| REF-b74349b557, library image(20261001-191914).png | Curving timber book enclosure; thick round sheltered seat opening; shared route passing individual seats; desk lamps; nested reveals and structural ceiling members. | Principal source: book-lined curved rooms and low round recesses with physical mounts. Reject upper gallery, stair and exterior window because this allocation is one internal deck. |
| REF-bacc0c55bb, library image(20261001-191915).png | Paired seats face a common focal direction; table lies within reach; side shelves frame the room; broad ceiling ring joins thick perimeter. | Translate into end-room shared reading clusters and framed internal view. No celestial window, skylight, copied room or unsupported ceiling ring. |
| REF-980fe8b7e6, library image(20261001-191916).png | Deep portal profile, seating backed by useful shelving, aligned ceiling detail, bookcase-mounted lights. | Use depth and coordinated furniture/enclosure; reject astronomical wall view and exact ornament. |
| REF-4e1375543a, library image(20261001-191917).png | Dense shelf bands become enclosing architectural form; circulation clearly curves around a central focus; places to pause are visibly integrated. | Useful library-wide collection rhythm and readable loop. No enormous globe, multilevel steps, gallery, exterior glazing or impossible high-level stock access. |
| REF-0478dfabb9, Uploaded_46/23/image(20261001-072858).png | Large curved book structures differ in height; shared tables occupy lower edge; warm shelving light establishes hierarchy within a grand room. | Reading-room enclosure height varies at one floor datum; bookshelves have substantial ends. No escalators, upper gallery or glazed roof. |
| retro_atrium_quality_benchmark.png | Thick layered thresholds, varied connected spaces, weighted piers, visible illuminated fixtures, inhabited edges; cohesive warm material hierarchy. | Quality threshold for proportion, integrated use and coherent source lighting. Library stays intimate; no chandelier spectacle or atrium void is copied. |

Atlas p14/directory02/drawing44 and source O/D12 remain required verified packet evidence. No image title has been treated as proof of those unread current pixels.
