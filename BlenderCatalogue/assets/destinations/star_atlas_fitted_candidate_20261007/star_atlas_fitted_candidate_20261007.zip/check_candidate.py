from pathlib import Path
import json,struct,math,hashlib,numpy as np
S=Path(__file__).resolve().parent;LIVE=Path('/workspace/shared/Astraea_recovery_20261007_AXWr5x/Game');CAT=LIVE.parent/'BlenderCatalogue'
def glb(path):
 b=path.read_bytes();n=struct.unpack_from('<I',b,12)[0];j=json.loads(b[20:20+n]);off=20+n;buf=b[off+8:];nodes=j['nodes'];out=[]
 def access(i):
  a=j['accessors'][i];v=j['bufferViews'][a['bufferView']];count={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];dtype={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}[a['componentType']];dt=np.dtype(dtype);o=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',count*dt.itemsize);return np.ndarray((a['count'],count),dt,buffer=buf,offset=o,strides=(stride,dt.itemsize)).copy()
 def walk(i,parent):
  n=nodes[i];m=np.eye(4)
  if 'matrix'in n:m=np.array(n['matrix']).reshape(4,4).T
  else:
   x,y,z,w=n.get('rotation',[0,0,0,1]);m[:3,:3]=np.array([[1-2*y*y-2*z*z,2*x*y-2*z*w,2*x*z+2*y*w],[2*x*y+2*z*w,1-2*x*x-2*z*z,2*y*z-2*x*w],[2*x*z-2*y*w,2*y*z+2*x*w,1-2*x*x-2*y*y]])@np.diag(n.get('scale',[1,1,1]));m[:3,3]=n.get('translation',[0,0,0])
  m=parent@m
  if 'mesh'in n:
   for p in j['meshes'][n['mesh']]['primitives']:
    v=access(p['attributes']['POSITION']);v=v@m[:3,:3].T+m[:3,3]
    # Retained exports batch by material. Split indexed connected parts instead
    # of treating a room-wide material batch's AABB as solid room volume.
    faces=access(p['indices']).ravel().reshape(-1,3) if 'indices'in p else np.arange(len(v)).reshape(-1,3)
    from scipy.sparse import coo_matrix
    from scipy.sparse.csgraph import connected_components
    rows=np.concatenate([faces[:,0],faces[:,1],faces[:,2]]);cols=np.concatenate([faces[:,1],faces[:,2],faces[:,0]])
    graph=coo_matrix((np.ones(len(rows)),(rows,cols)),shape=(len(v),len(v)))
    count,labels=connected_components(graph,directed=False)
    for cc in range(count):out.append((n.get('name','')+'_'+str(cc),v[labels==cc]))
  for child in n.get('children',[]):walk(child,m)
 for i in j['scenes'][j.get('scene',0)]['nodes']:walk(i,np.eye(4))
 return out
cache={}
def geometry(file,p,a):
 if file not in cache:cache[file]=glb(LIVE/'assets/models'/file)
 rot=np.array([[math.cos(a),0,math.sin(a)],[0,1,0],[-math.sin(a),0,math.cos(a)]])
 return [(name,v@rot.T+np.array(p)) for name,v in cache[file]]
def bound(parts):
 v=np.concatenate([v for _,v in parts]);return np.array([v.min(0),v.max(0)])
def overlap(a,b,eps=.008):return bool(np.all(np.minimum(a[1],b[1])-np.maximum(a[0],b[0])>eps))
def inside(p,poly):
 x,y=p;c=False
 for a,b in zip(poly,poly[1:]+poly[:1]):
  if (a[1]>y)!=(b[1]>y) and x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0]:c=not c
 return c

def seg_rect(a,b,lo,hi):
 t0,t1=0.,1.
 for i in range(2):
  d=b[i]-a[i]
  if abs(d)<1e-9:
   if a[i]<lo[i] or a[i]>hi[i]:return False
  else:
   x,y=sorted(((lo[i]-a[i])/d,(hi[i]-a[i])/d));t0=max(t0,x);t1=min(t1,y)
   if t0>t1:return False
 return True
D=json.load(open(S/'Game/data/architecture/star_atlas_fitted_interiors.json'));C=json.load(open(LIVE/'data/architecture/D12_D14_star_atlas.json'));pins=json.load(open(S/'INPUT_PINS.json'))
errors=[];warn=[]
for f,h in pins['protected_live_inputs'].items():
 if hashlib.sha256((LIVE/f).read_bytes()).hexdigest()!=h: errors.append('Live preimage changed '+f)
# Verify all consumed representations, including variants absent from global catalogue.
used=set(m['file']for m in D['models'])|{'AST-LIB-006_reordered.glb','AST-LIB-006_short_flat.glb'}
for file in sorted(used):
 h=hashlib.sha256((LIVE/'assets/models'/file).read_bytes()).hexdigest();matches=[p for p in CAT.glob('assets/**/*.glb') if hashlib.sha256(p.read_bytes()).hexdigest()==h]
 if not matches:errors.append('Runtime lacks retained export '+file)
records={};all_parts={}
from scipy.spatial import ConvexHull
arch=[]
for n,v in geometry('AST-LIB-011.glb',[-80,78,0],0):
 try:eq=ConvexHull(v,qhull_options='QJ').equations
 except Exception:eq=None
 arch.append((n,np.array([v.min(0),v.max(0)]),eq))
def hull_reject(bb,eq):
 if eq is None:return False
 corners=np.array([[x,y,z]for x in bb[:,0]for y in bb[:,1]for z in bb[:,2]])
 return bool(np.any(np.all(corners@eq[:,:3].T+eq[:,3]>.004,axis=0)))
for m in D['models']:
 parts=geometry(m['file'],m['position'],m['yaw']);bb=bound(parts);records[m['id']]=bb;all_parts[m['id']]=[(n,np.array([v.min(0),v.max(0)]))for n,v in parts]
 deck='D'+str({78:12,84:13,88.5:14}[m['position'][1]]) if m['role']=='floor' else None
 if deck:
  regions=[r for r in C['floor_regions'] if r['deck']==deck and r['walkable_public']]
  for x in np.linspace(bb[0,0],bb[1,0],4):
   for z in np.linspace(bb[0,2],bb[1,2],4):
    if not any(inside((x,z),r['boundary']) and not any(inside((x,z),h)for h in r['holes'])for r in regions):errors.append('Unsupported footprint '+m['id']);break
  if abs(bb[0,1]-m['position'][1])>.003:errors.append('Floor contact '+m['id']+' '+str(bb[0,1]))
  for route in C['route_reservations']:
   if route['deck']!=deck:continue
   radius=route['half_width_m'];lo=bb[0,[0,2]]-radius;hi=bb[1,[0,2]]+radius
   if any(seg_rect(a,b,lo,hi)for a,b in zip(route['centerline_xz'],route['centerline_xz'][1:])):errors.append('Reserved route intersection '+m['id']+' / '+route['purpose'])
 for n,b,eq in arch:
  if not overlap(bb,b) or hull_reject(bb,eq):continue
  hits=[nn for nn,small in all_parts[m['id']] if overlap(small,b) and not hull_reject(small,eq)]
  if hits:errors.append('Architecture intersection '+m['id']+' / '+n+' / '+','.join(hits[:2]))
for i,m in enumerate(D['models']):
 for other in D['models'][i+1:]:
  if m.get('support')==other['id'] or other.get('support')==m['id']:continue
  if not overlap(records[m['id']],records[other['id']]):continue
  hits=[(a,b)for a,aa in all_parts[m['id']]for b,bb in all_parts[other['id']]if overlap(aa,bb)]
  if hits:errors.append('Model intersection '+m['id']+' / '+other['id']+' / '+str(hits[:1]))
# Every new approach segment checked against new whole object bounds expanded by
# 0.4m player envelope. These are source-only conservative checks, not engine travel.
for cl in D['clusters']:
 y=cl['origin'][1];points=cl['approach_route']
 for m in D['models']:
  bb=records[m['id']]
  if bb[1,1]<y+.05 or bb[0,1]>y+2.0:continue
  if any(seg_rect(a,b,bb[0,[0,2]]-.4,bb[1,[0,2]]+.4)for a,b in zip(points,points[1:])):errors.append('Activity approach obstruction '+cl['id']+' / '+m['id'])
# Compare candidate against all existing floor-supported activity models. Original
# fixture/stock mounts are inside these source furniture bounds and are unchanged.
legacy=[('NorthStart','AST-LIB-STR-003_start.glb',[-88,78,-26.5],0),('NorthBay0','AST-LIB-STR-001.glb',[-88,78,-26.5],0),('NorthBay1','AST-LIB-STR-001.glb',[-85.6,78,-26.5],0),('NorthTurn','AST-LIB-STR-002.glb',[-83.2,78,-26.5],0),('NorthEnd','AST-LIB-STR-003.glb',[-81.4,78,-28.3],math.pi/2),('NorthTable','AST-LIB-STUDY-01.glb',[-86,78,-21.5],0),('Counter','AST-LIB-012.glb',[-63,78,5],math.pi),('Terminal','AST-LIB-010.glb',[-55.7,78,7.4],2.65),('Browser','AST-LIB-009.glb',[-59,78,12],math.pi),('AtriumTable','AST-FUR-003_day_table.glb',[-55.2,78,17.25],0),('AtriumChairN','AST-FUR-002_day_reading_chair.glb',[-55.2,78,16],0),('AtriumChairS','AST-FUR-002_day_reading_chair.glb',[-55.2,78,18.5],math.pi),('AtriumLamp','AST-GST-001.glb',[-56.1,78,16.1],math.pi/3),('D13Study','AST-LIB-STUDY-02.glb',[-64.7,84,-4.8],-math.pi/2),('D13Chair','AST-FUR-002_day_reading_chair.glb',[-65.69,84,-4.695],math.pi/2),('D14Table','AST-FUR-003_day_table.glb',[-88.5,88.5,9],0),('D14ChairW','AST-FUR-002_day_reading_chair.glb',[-89.7,88.5,9],math.pi/2),('D14ChairE','AST-FUR-002_day_reading_chair.glb',[-87.3,88.5,9],-math.pi/2)]
for x in [-.55,.55]:
 for z in [-1.035,1.035]:legacy.append(('NorthChair'+str(x)+str(z),'AST-FUR-002_day_reading_chair.glb',[-86+x,78,-21.5+z],math.pi if z>0 else 0))
for name,file,p,a in legacy:
 pp=geometry(file,p,a);bb=bound(pp)
 for m in D['models']:
  if overlap(bb,records[m['id']]):errors.append('Legacy overlap '+m['id']+' / '+name)
 for cl in D['clusters']:
  y=cl['origin'][1]
  if bb[1,1]<y+.05 or bb[0,1]>y+2:continue
  if any(seg_rect(a,b,bb[0,[0,2]]-.4,bb[1,[0,2]]+.4)for a,b in zip(cl['approach_route'],cl['approach_route'][1:])):errors.append('Legacy branch obstruction '+cl['id']+' / '+name)
# Sample every approach segment for floor support, excluding genuine holes.
for cl in D['clusters']:
 deck='D'+str({78:12,84:13,88.5:14}[cl['origin'][1]])
 regions=[r for r in C['floor_regions']if r['deck']==deck and r['walkable_public']]
 for a,b in zip(cl['approach_route'],cl['approach_route'][1:]):
  for t in np.linspace(0,1,max(2,int(np.linalg.norm(np.array(b)-a)/.25))):
   pt=np.array(a)+(np.array(b)-a)*t
   if not any(inside(pt,r['boundary']) and not any(inside(pt,h)for h in r['holes'])for r in regions):errors.append('Unsupported branch '+cl['id'])
result={'status':'PASS'if not errors else 'FAIL','model_instances':len(D['models']),'activity_clusters':len(D['clusters']),'local_lights':len(D['fixtures']),'errors':sorted(set(errors)),'limits':['Conservative source mesh AABBs, not engine physics','Legacy furnishing branches additionally require root engine regression','Eye-level rendering and loaded-cart untested'],'bounds':{k:v.tolist()for k,v in records.items()}}
(S/'STATIC_CHECK.json').write_text(json.dumps(result,indent=2)+'\n');print(result['status']);print('\n'.join(result['errors']));print('errors',len(result['errors']))
