# Star Atlas candidate adoption and verification

## Exact scope
Three new Game files only:
- scripts/star_atlas_fitted_interiors.gd
- data/architecture/star_atlas_fitted_interiors.json
- tests/validate_star_atlas_fitted_interiors.gd

No current Game/Catalogue file has been edited by this worker. No new GLB, catalogue identity, structural owner, opening, room registry, passenger capacity, renderer, controller or transport. All furniture references are retained runtime exports with verified editable source or generator. An additive root call is required at the END of existing scripts/star_atlas.gd build():

load("res://scripts/star_atlas_fitted_interiors.gd").build(district,ship)

Do not overwrite star_atlas.gd from a copied preimage. Verify INPUT_PINS.json against the live file immediately before applying this one-line addition. Root retains ownership of shared wiring, test registration, imports, application, receipts and backup. Keep all five existing Star Atlas floor/roof owners and all282 current compiled records exact.

## Candidate extent
24 activity clusters,105 retained-source model instances,14 straight collection profiles with authored start/end caps and294 additional static stock groups,15 physical fixture-driven local lights and5 small integrated SunCorp text marks. Existing counter/search hardware remains static. The added return surface is a real working surface and clear stance, not functioning circulation software. Furniture count is NOT admission/seating-capacity certification.

The source-only gate checks native/export/runtime identities, protected preimages, floor footprints, all declared route reservations, new/legacy activity overlap, sampled activity-branch floor support and conservative0.4m expanded branch obstructions. It splits material-batched GLBs into indexed connected components and uses convex-hull rejection to avoid interpreting a diagonal wall's enclosing rectangle as solid volume. This remains a conservative source geometry check, not collision-engine acceptance or triangle-perfect intersection proof. Failed attempts are retained as STATIC_CHECK_failed001–004.json.

## Serialized root engine sequence
1. Verify current backup heartbeat and independent receipt. Check all preimages and candidate manifest. Adopt the three NEW files and append the one-line hook only when root is ready. Do not recopy any retained model or rebuild any native asset.
2. Refresh Godot imports using the current validate.py workflow before running tests. Inspect script errors; the worker has NOT launched any engine.
3. Run existing star_atlas and star_atlas_lift tests unchanged via tools/validate.py --only with their current supported selection names. Preserve failed logs.
4. Run tests/validate_star_atlas_fitted_interiors.gd with the same pinned Godot/Compatibility/fixed60 workflow; root may register it in the shared runner. It checks real mounted contacts, every new stock support, fixture exits, integrated label backing,24 bidirectional scripted capsule branches and all three ordinary arrival interfaces. It deliberately does not relabel those scripted moves as physical W/A/S/D input.
5. Run actual normal-input entry and walking from the three existing entrances. Visit all24 activity endpoints, walk both stairs bidirectionally, use the existing three-stop lift, operate each new study switch through the existing RMB/E interaction, and repeat arrival/return with effects on and off. No node-position jumps during a claimed continuous traversal. Keep every old original Star Atlas check.
6. Real loaded cart: start D12 normal entrance, reach counter rear and return surface, turn into north/south browse aisles, turn back, reach unchanged west lift forecourt, board and ride all three stops with retained products, visit D13/D14 activity approaches, then return and regrip. All skinny upper edges stay circulation; do not claim cart access to seated furniture gaps. Existing lift straight/obstruction checks alone do not certify these turns.
7. Check fixture mounts and controls at normal eye height. New lights have requested shadows and ranges2m(task)/3m(floor) and are discovered by the existing shared budget, whose eight-shadow-source cap remains unchanged. Check dark pockets and visible-source selection in motion, not just source count.
8. Review capture itinerary below, inspect close stock/cap/fixture joints, signs, clipping, ceiling relationships and views. Whole-destination first-pass visual acceptance remains false until this is actually done. If framing remains sparse, expand the source-backed composition based on those views rather than claiming105 instances finish the room.
9. Run the CURRENT full aggregate after adoption, not the historical31/111/117 result. Confirm all old282 compiled records and master/capacity/transport identities remain exact. Commit meaningful verified changes and independently verify resulting retained checkpoint.

## Normal-eye capture itinerary
Position columns are floor positions; camera eye is1.65m above each. Look targets are world XYZ.
- D12 entrance: (-50,78,0) toward(-82,82,0), to see arrival/court hierarchy
- D12 north sequence: (-77,78,-17) toward(-73,79.4,-29), north layered shelves and study
- D12 existing/new collection junction: (-89,78,-20) toward(-82,80,-28)
- D12 east reading: (-60,78,-19) toward(-54,79.4,-19), real inward glazing
- D12 south sharing: (-74,78,19) toward(-84,79.6,28), shelves/table/ceiling composition
- D12 west retreat: (-86,78,14) toward(-95,79.4,17), bench and shelf returns
- D12 care: (-62,78,9) toward(-67,79,11.5), return work surface and rear service stance
- D13 shared overlook: (-80.5,84,11) toward(-89,85,8), offset court and social edge
- D13 west pocket: (-91.8,84,9) toward(-94,85.2,6.5)
- D14 upper arrival: (-72.2,88.5,12.5) toward(-88,89.7,8), quiet threshold and existing conversation
- D14 quiet southwest: (-92,88.5,9.2) toward(-94.5,89.5,6.8)
- D14 quiet south: (-81.5,88.5,11) toward(-82,89.5,8)

Capture default effects and effects-off at matched poses. Add slow pans across arrival/court, north collection caps, low canopy and upper edge; no final quality claim from a plan image or static source render. Ordinary freehand comfort, all-species ergonomics, occupied service, NPC use, pickups/persistence and target-laptop1080p60 remain open.

## Source continuation
PLAN.md explains master/reference application and the actual visitor/care journeys. FITTED_PLAN.png is a layout diagram with original outlines, openings and protected routes. FITTED_SECTION.png is an explicitly projected section relationship diagram, not engine evidence. The original four library references and D12/D13/D14 working blueprint plates were inspected before authoring.
