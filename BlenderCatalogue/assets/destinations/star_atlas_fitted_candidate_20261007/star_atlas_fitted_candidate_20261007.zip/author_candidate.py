from pathlib import Path
import json,math
S=Path(__file__).resolve().parent; G=S/'Game';(G/'scripts').mkdir(parents=True,exist_ok=True);(G/'data/architecture').mkdir(parents=True,exist_ok=True);(G/'tests').mkdir(parents=True,exist_ok=True)
models=[]; clusters=[]; fixtures=[];stock_profiles=[]
def rot(v,a):return [math.cos(a)*v[0]+math.sin(a)*v[2],v[1],-math.sin(a)*v[0]+math.cos(a)*v[2]]
def addv(a,b):return [round(x+y,6) for x,y in zip(a,b)]
def model(cid,file,p,yaw=0,role='floor',support=None):
 d=dict(id=cid,file=file+'.glb',position=p,yaw=yaw,role=role)
 if support:d['support']=support
 models.append(d);return cid
F='AST-FUR-002_day_reading_chair'; T='AST-FUR-003_day_table'; B='AST-FUR-001_day_window_bench'
def cluster(cid,kind,p,a,route):
 clusters.append(dict(id=cid,kind=kind,origin=p,yaw=a,approach_route=route))
def lamp(cid,p,a=0):
 model(cid,'AST-GST-001',p,a);fixtures.append(dict(id=cid,type='floor'))
def task(cid,p,a,parent):
 model(cid,'AST-LIB-008',p,a,'mounted',parent);fixtures.append(dict(id=cid,type='task'))
def shared(cid,p,a,route,care=False):
 cluster(cid,'return_care' if care else 'shared_study',p,a,route);model(cid+'_Table','AST-LIB-STUDY-01',p,a)
 if not care:
  for x in [-.55,.55]:
   for z in [-1.035,1.035]:model(cid+'_Chair_'+str(int(x*1000))+'_'+str(int(z*1000)),F,addv(p,rot([x,0,z],a)),a+(math.pi if z>0 else 0))
 model(cid+'_Folio','AST-LIB-007',addv(p,rot([.55,.75,.27],a)),a,'mounted',cid+'_Table')
 task(cid+'_Fixture',addv(p,[0,.754,0]),a,cid+'_Table')
def single(cid,p,a,route):
 cluster(cid,'sheltered_study',p,a,route);model(cid+'_Desk','AST-LIB-STUDY-02',p,a)
 model(cid+'_Chair',F,addv(p,rot([.105,0,.99],a)),a+math.pi)
 for h in [.42,.83]:model(cid+'_Stock_'+str(round(h*100)),'AST-LIB-006',addv(p,rot([-.711,h,-.075],a)),a,'static_stock',cid+'_Desk')
 task(cid+'_Fixture',addv(p,rot([-.433,.756,-.286],a)),a,cid+'_Desk')
def lounge(cid,p,a,route,bench=False):
 cluster(cid,'paired_bench_reading' if bench else 'conversation',p,a,route);model(cid+'_Table',T,p,a)
 for i,z in enumerate([-1.5,1.5]):model(cid+'_Seat_'+str(i),B if bench else F,addv(p,rot([0,0,z],a)),a+(math.pi if z>0 else 0))
 lamp(cid+'_Lamp',addv(p,rot([-.82 if not bench else -1.6,0,-1.5],a)),a)
def browse(cid,p,a,route):
 cluster(cid,'periodical_browse',p,a,route);model(cid+'_Browser','AST-LIB-009',p,a)
def shelf(cid,p,a,n,route):
 cluster(cid,'collection_shelter',p,a,route);model(cid+'_Start','AST-LIB-STR-003_start',p,a)
 for i in range(n):
  at=addv(p,rot([2.4*i,0,0],a));mid=model(cid+'_Bay_'+str(i),'AST-LIB-STR-001',at,a);stock_profiles.append(dict(id=mid,profile='AST-LIB-STR-001',position=at,yaw=a))
 model(cid+'_End','AST-LIB-STR-003',addv(p,rot([2.4*n,0,0],a)),a)
# Three lower wings, clustered around the existing authored canopies.
shelf('D12_NorthAtlas',[-75,78,-29.8],0,3,[[-60,0],[-64,-17],[-70,-26.8]])
shelf('D12_NorthLivingWorlds',[-66,78,-29.8],0,3,[[-60,0],[-59,-17],[-61,-26.8]])
shared('D12_NorthAtlasStudy',[-72,78,-23.6],0,[[-60,0],[-64,-17],[-68.7,-23.6]])
shared('D12_NorthWorldStudy',[-64.5,78,-23.6],0,[[-60,0],[-59,-17],[-61.2,-23.6]])
browse('D12_NorthwestBrowse',[-94,78,-23],math.pi/2,[[-87,-15],[-90,-20],[-92.5,-23]])
lounge('D12_NorthwestPause',[-91,78,-26],0,[[-87,-15],[-90,-20],[-90,-26]])
single('D12_InwardStudyNorth',[-55.6,78,-22],-math.pi/2,[[-60,0],[-59,-17],[-58,-22]])
single('D12_InwardStudyNear',[-55.6,78,-15],-math.pi/2,[[-60,0],[-59,-15],[-58,-15]])
shelf('D12_SouthAtlas',[-78,78,30],math.pi,5,[[-60,0],[-70,5],[-70,17],[-75,27.3],[-84,27.3]])
shared('D12_SouthAtlasStudy',[-86,78,24.7],0,[[-60,0],[-70,5],[-70,17],[-89.3,19],[-89.3,24.7]])
shared('D12_SouthMakingStudy',[-79,78,24.7],0,[[-60,0],[-70,5],[-70,17],[-75.7,24.7]])
shelf('D12_WestRetreat',[-95.8,78,20.5],math.pi/2,3,[[-60,0],[-83,3],[-91,7],[-93,16]])
lounge('D12_WestReading',[-89.5,78,17],math.pi/2,[[-60,0],[-83,3],[-86,7],[-86,17]],True)
lounge('D12_SouthConversation',[-69,78,26],0,[[-60,0],[-70,5],[-70,17],[-65,24]],True)
browse('D12_SouthJournal',[-64,78,29],math.pi,[[-60,0],[-70,5],[-70,17],[-61.5,23],[-64,27.6]])
lounge('D12_InwardReadingSouth',[-56.6,78,23.5],math.pi/2,[[-60,0],[-59,7.5],[-61,9],[-61,20.5],[-59,23.5]],True)
shared('D12_ReturnCare',[-65,78,11.5],0,[[-60,0],[-59,7.5],[-62,9],[-65,9]],True)
browse('D12_ReturnReference',[-68.5,78,11.5],math.pi/2,[[-60,0],[-70,5],[-70,8.5],[-67,8.5],[-67,11.5]])
# Upper rooms retain all narrow transfer strips and transport reservations.
shared('D13_CommonAtlasTable',[-84.5,84,12.45],math.pi/2,[[-63,0],[-72.2,0],[-72.2,12.5],[-76,12.5],[-81.7,12]])
lounge('D13_WestOverlook',[-93.3,84,6.5],0,[[-63,0],[-72.2,0],[-72.2,12.5],[-81,12.5],[-81,10.7],[-91.8,10.7],[-91.8,6.5]])
browse('D13_WestJournal',[-94,84,10.7],0,[[-63,0],[-72.2,0],[-72.2,12.5],[-81,12.5],[-81,10.7],[-90,10.7],[-91.7,12.3],[-94,12.3]])
single('D14_QuietWestNorth',[-94.5,88.5,6.8],0,[[-63,0],[-72.2,0],[-72.2,12.5],[-92,12.5],[-92,9.2],[-94.5,9.2]])
single('D14_QuietWestSouth',[-81.5,88.5,8.7],0,[[-63,0],[-72.2,0],[-72.2,12.5],[-81.5,12.5],[-81.5,11]])
browse('D14_QuietJournal',[-95,88.5,11.1],0,[[-63,0],[-72.2,0],[-72.2,12.5],[-92,12.5],[-95,12.5]])
labels=[dict(parent=p,position=[1.2,3.0,-.013],rotation_x=0,text=t,pixel_size=.0016) for p,t in [('D12_NorthAtlas_Bay_1','SunCorp · ATLAS'),('D12_NorthLivingWorlds_Bay_1','SunCorp · LIVING WORLDS'),('D12_SouthAtlas_Bay_2','SunCorp · SHARED READING'),('D12_WestRetreat_Bay_1','SunCorp · QUIET READING')]]
labels.append(dict(parent='D12_ReturnCare_Table',position=[-.65,.753,.3],rotation_x=-math.pi/2,text='SunCorp · RETURNS',pixel_size=.0011))
D=dict(labels=labels,schema=1,status='candidate; source checks do not imply runtime or visual acceptance',owner='D12_D14_star_atlas',programme_keys=['D12_directory_05','D13_directory_04','D14_directory_03'],models=models,clusters=clusters,fixtures=fixtures,stock_profiles=stock_profiles,capacity_change=0,new_floor_owners=[],operating_services_claimed=False)
(G/'data/architecture/star_atlas_fitted_interiors.json').write_text(json.dumps(D,indent=2)+'\n')
print(len(models),'model instances',len(clusters),'activity clusters',len(fixtures),'local lights')
