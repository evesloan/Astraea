from pathlib import Path
import json,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon,Rectangle,Circle
S=Path(__file__).resolve().parent;G=Path('/workspace/shared/Astraea_recovery_20261007_AXWr5x/Game');D=json.load(open(S/'Game/data/architecture/star_atlas_fitted_interiors.json'));C=json.load(open(G/'data/architecture/D12_D14_star_atlas.json'));B=json.load(open(S/'STATIC_CHECK.json'))['bounds']
fig,axes=plt.subplots(1,3,figsize=(18,12));colors={'collection_shelter':'#865b39','shared_study':'#c09653','return_care':'#618997','sheltered_study':'#509483','conversation':'#9a8169','paired_bench_reading':'#b09076','periodical_browse':'#bfa584'}
for ax,deck,y in zip(axes,['D12','D13','D14'],[78,84,88.5]):
 for r in C['floor_regions']:
  if r['deck']==deck and r['walkable_public']:
   ax.add_patch(Polygon(r['boundary'],facecolor='#f0ece2',edgecolor='#534b41',lw=1.5))
   for hole in r['holes']:ax.add_patch(Polygon(hole,facecolor='white',edgecolor='#697985',hatch='//'))
 for route in C['route_reservations']:
  if route['deck']==deck:
   xs,zs=zip(*route['centerline_xz']);ax.plot(xs,zs,color='#74a6af',lw=8,alpha=.3,zorder=2)
 for p in C['support_reservations']:ax.add_patch(Circle(p['center_xz'],.6,color='#676c68'))
 for m in D['models']:
  if abs(m['position'][1]-y)>.01:continue
  lo,hi=B[m['id']];ax.add_patch(Rectangle((lo[0],lo[2]),hi[0]-lo[0],hi[2]-lo[2],facecolor='#a67d50',edgecolor='#735d48',lw=.3,zorder=3))
 for i,c in enumerate(D['clusters']):
  if c['origin'][1]!=y:continue
  x,_,z=c['origin'];ax.text(x,z,str(i+1),fontsize=8,ha='center',va='center',bbox=dict(boxstyle='circle',fc='white',ec=colors[c['kind']],alpha=.85),zorder=5)
 for name,x,z,sx,sz in ([('Existing north study',-86,-21.5,4,4),('Existing counter',-63,5,4,1.5),('Existing collection',-84,-26.5,8,3),('Existing atrium seats',-55.2,17.25,2,4)] if deck=='D12' else [('Existing east study',-64.7,-4.8,2.5,2)] if deck=='D13' else [('Existing conversation',-88.5,9,4,2)]):
  ax.add_patch(Rectangle((x-sx/2,z-sz/2),sx,sz,fill=False,edgecolor='#34515f',lw=1.5));ax.text(x,z,name,fontsize=6,ha='center',color='#34515f')
 ax.set_xlim(-100,-47);ax.set_ylim(-36,36);ax.set_aspect('equal');ax.invert_yaxis();ax.set_title(f'{deck} / Y{y}m');ax.set_xlabel('Ship X (m)');ax.set_ylabel('Ship Z (m)');ax.grid(alpha=.15)
fig.suptitle('STAR ATLAS · FITTED CANDIDATE / exact existing outlines and holes\nBlue = protected routes; brown = new retained-source furniture; blue outlines = existing activities',fontsize=15)
fig.tight_layout();fig.savefig(S/'FITTED_PLAN.png',dpi=150);plt.close(fig)
fig,ax=plt.subplots(figsize=(14,5))
for r in C['floor_regions']:
 y=C['floor_y'].get(r['deck'],93);b=r['boundary'];xs=[p[0]for p in b]
 if 'ground'in r['id']:ax.plot([min(xs),max(xs)],[y,y],lw=5,color='#70685c')
 elif 'cover'in r['id']:ax.plot([min(xs),max(xs)],[y,y],lw=5,color='#70685c')
 elif 'gallery'in r['id']:
  ax.plot([-97,-90 if r['deck']=='D13' else -93],[y,y],lw=5,color='#70685c');ax.plot([-74 if r['deck']=='D13'else-76,-48],[y,y],lw=5,color='#70685c')
for m in D['models']:
 lo,hi=B[m['id']]
 if lo[2]<15 and hi[2]>-15:ax.add_patch(Rectangle((lo[0],lo[1]),hi[0]-lo[0],hi[1]-lo[1],facecolor='#ac8555',alpha=.35))
ax.text(-84,85,'EXISTING STAGGERED COURT\nKept free for views and orientation',ha='center',fontsize=11)
ax.text(-84,93.5,'D15 protected cover / underside92.76',ha='center');ax.text(-84,76.7,'D11 Performers commons protected below',ha='center');ax.set_xlim(-99,-47);ax.set_ylim(76,95);ax.set_aspect('equal');ax.grid(alpha=.2);ax.set_title('Section relationship at the court · projected furnishings, not a measured perspective');ax.set_xlabel('Ship X (m)');ax.set_ylabel('Ship Y (m)');fig.tight_layout();fig.savefig(S/'FITTED_SECTION.png',dpi=150)
